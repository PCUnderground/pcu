////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Shadow Depth Maps with OpenGL using                   //
//  GL_SGIX_depth_texture/GL_SGIX_shadow or               //
//  GL_ARB_depth_texture/GL_ARB_shadow                    //
//                                                        //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////

#include	<windows.h>			
#include	<stdio.h>			
#include	<math.h>
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	"glext.h"
#include	"texture.h"

PCUTexture *spotLight;
PCUTexture *texMetal;

GLUquadric	*sphere, *cube, *cone;
GLuint listCube, listSphere, listCone;

#define SPOT_ANGLE	80.0f

static GLfloat material1a[] = { 0.0f, 0.6f, 0.0f, 1.0f };
static GLfloat material2a[] = { 1.4f, 1.5f, 3.0f, 1.0f };
static GLfloat material1c[] = { 1.0f, 1.0f, 1.0f, 1.0f };
static GLfloat material2c[] = { 1.0f, 0.6f, 1.0f, 1.0f };

#include "keys.h"

PFNGLACTIVETEXTUREARBPROC	glActiveTextureARB;
PFNGLMULTITEXCOORD2FARBPROC	glMultiTexCoord2fARB;

GLuint shadowDepthMap;

const int SHADOWSIZE = 256;

#define useARB_SHADOW	1
#define useSGIX_SHADOW	2

int		useExtension;

void	createShadowTextures()
{
	// zuerst erzeugen wir die Shadow Depth Map
	glGenTextures( 1, &shadowDepthMap );
	glBindTexture( GL_TEXTURE_2D, shadowDepthMap );

	// und definieren das Textureformat, n�mlich die GL_DEPTH_COMPONENT
	// man k�nnte auch z.B. GL_DEPTH_COMPONENT16_SGIX/GL_DEPTH_COMPONENT24_SGIX f�r
	// die SGIX Extension oder GL_DEPTH_COMPONENT16_ARB/GL_DEPTH_COMPONENT24_ARB f�r
	// die ARB Extension verwenden, um die Bittiefe explizit anzugeben
	glCopyTexImage2D( GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, 0, 0, SHADOWSIZE, SHADOWSIZE, 0 );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
	
	// Depth Map so einstellen, dass der Z-Wert der Texture (also die Tiefe) mit
	// der R Texturekoordinate verglichen wird. Die Texturematrizen werden so eingestellt,
	// das die R Komponente gleich dem Z-Wert bzgl. der Lichtquelle ist.
	// Vergleich <= (GL_LEQUAL) liefert dann 0 (schwarz) oder 1 (weiss):
	if ( useExtension == useARB_SHADOW )
	{
		glTexEnvi( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
		glTexParameteri( GL_TEXTURE_2D, GL_DEPTH_TEXTURE_MODE_ARB, GL_LUMINANCE );
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE_ARB, GL_COMPARE_R_TO_TEXTURE_ARB );
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC_ARB, GL_LEQUAL );
	} else
	if ( useExtension == useSGIX_SHADOW )
	{
		glTexEnvi( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
		glTexParameteri( GL_TEXTURE_2D, GL_DEPTH_TEXTURE_MODE_ARB, GL_LUMINANCE );
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_COMPARE_SGIX, GL_TRUE );
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_COMPARE_OPERATOR_SGIX, GL_TEXTURE_LEQUAL_R_SGIX );
	}
}

void	init3DEngine()
{
	// Allgemeine Renderstates
    glShadeModel( GL_SMOOTH );

	glHint( GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST );

	glDisable( GL_POLYGON_SMOOTH );

	glEnable( GL_DEPTH_TEST );
	glFrontFace( GL_CCW );
	glEnable( GL_CULL_FACE );

	// Lichtquelle zur Beleuchtung der 3D Modelle
	glEnable( GL_LIGHT0 );

	GLfloat light_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat light_diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat light_ambient[] = { 0.0f, 0.0f, 0.0f, 1.0f };

	glLightfv( GL_LIGHT0, GL_AMBIENT, light_ambient );
	glLightfv( GL_LIGHT0, GL_DIFFUSE, light_diffuse );
	glLightfv( GL_LIGHT0, GL_SPECULAR, light_specular );

	glLightf( GL_LIGHT0, GL_SPOT_EXPONENT, 18 );

	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);

	glEnable( GL_TEXTURE_2D );

	//
	// Display Lists erstellen
	//
	listCube = glGenLists( 1 );
	glNewList( listCube, GL_COMPILE );
	cube = gluNewQuadric();
	gluQuadricTexture( cube, GL_TRUE );

	glPushMatrix();

	glTranslatef( 0, 0, -12 );

	gluCylinder( cube, 13.0f, 13.0f, 24.0f, 4, 3 );
	
	glPushMatrix();
	glTranslatef( 0.0f, 0.0f, 24.0f );
	gluDisk( cube, 0.0f, 13.0f , 4, 1);
	glPopMatrix();

	glPushMatrix();
	glScalef( -1.0f, 1.0f, -1.0f );
	gluDisk( cube, 0.0f, 13.0f, 4, 1);
	glPopMatrix();

	glPopMatrix();

	gluDeleteQuadric( cube );
	glEndList();


	listSphere = glGenLists( 1 );
	glNewList( listSphere, GL_COMPILE );
	sphere = gluNewQuadric();
	gluQuadricTexture( sphere, GL_TRUE );
 	gluSphere( sphere, 5.0f, 32, 32 );
	gluDeleteQuadric( sphere );
	glEndList();


	listCone = glGenLists( 1 );
	glNewList( listCone, GL_COMPILE );
	cone = gluNewQuadric();
	gluQuadricTexture( cone, GL_TRUE );
 	gluCylinder( cone, 3.0f, 0.0f, 35.0f, 32, 2 );
	gluDeleteQuadric( cone );
	glEndList();


	texMetal = new PCUTexture();
	texMetal->loadBMP( "./data/texture.bmp" );

	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_TEXTURE_WRAP_S );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_TEXTURE_WRAP_T );
	glTexEnvi( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

	spotLight = new PCUTexture();
	spotLight->loadBMP( "./data/spot.bmp" );

	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
	glTexEnvi( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

	glMaterialfv( GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, (float*)&material2a );

	loadKeyTexture();

	char *extensions;	
	extensions = strdup( (char*)glGetString( GL_EXTENSIONS ) );

	useExtension = 0;
	if ( strstr( extensions, "GL_SGIX_depth_texture" ) &&
		 strstr( extensions, "GL_SGIX_shadow" ) )
	{
		useExtension = useSGIX_SHADOW;
	} else
	if ( strstr( extensions, "GL_ARB_depth_texture" ) &&
		 strstr( extensions, "GL_ARB_shadow" ) )
	{
		useExtension = useARB_SHADOW;
	}

	glActiveTextureARB = (PFNGLACTIVETEXTUREARBPROC)wglGetProcAddress( "glActiveTextureARB" );
	glMultiTexCoord2fARB = (PFNGLMULTITEXCOORD2FARBPROC)wglGetProcAddress( "glMultiTexCoord2fARB" );

	GLint maxTexelUnits;

	glGetIntegerv( GL_MAX_TEXTURE_UNITS_ARB, &maxTexelUnits );

	if ( useExtension == 0 || glActiveTextureARB == NULL || maxTexelUnits < 3 )
	{
		MessageBox( 0, "Ben�tigte OpenGL Extensions werden nicht unterst�tzt !", "-=[ ACHTUNG ]=-", MB_OK | MB_ICONSTOP );
		exit( 1 );
	}

	createShadowTextures();
}

void drawSphere()
{
	glPushMatrix();

	float time = GetTickCount() * 0.001f;
	glTranslatef(
		(float)sin( time * 1.01212 ) * 15.0f, 
		(float)cos( time * 1.23412 ) * 7.0f,
		30.0f
		);

	glMaterialfv( GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, (float*)&material2a );
	glCallList( listSphere );
	glPopMatrix();
}

void drawCube()
{
	glMaterialfv( GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, (float*)&material1a );

	glPushMatrix();
	float time = (float)GetTickCount();
	glRotatef( (float)time * 0.11212f, 0, 1, 2 );

	glCallList( listCube );
	glPopMatrix();
}



static GLfloat lightPosition[] = { 10.0f, 20.0f, 60.0f, 1.0f };
static GLfloat lightDirection[] = { -10.0f, -20.0f, -60.0f, 1.0f };

static int first = 1;

void drawScene()
{
	glPushMatrix();

	drawSphere();
	drawCube();

	glMaterialfv( GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, (float*)&material2c );
	for ( int i = 0; i < 8; i++ )
	{
		glPushMatrix();
		float j = (float)i / 4.0f * 3.141592f + GetTickCount() * 0.0005f;
		glTranslatef( 
			(float)cos( j ) * 25.0f, -20,
			(float)sin( j ) * 25.0f );
		glRotatef( -90, 1, 0, 0 );

		glCallList( listCone );

		glPopMatrix();
	}

	glMaterialfv( GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, (float*)&material1c );

	glBegin( GL_QUADS );

	glMultiTexCoord2fARB( GL_TEXTURE2_ARB, -6, -6 );
	glVertex3f( -240, -20, -240 );
	glMultiTexCoord2fARB( GL_TEXTURE2_ARB, -6, 6 );
	glVertex3f( -240, -20, 240 );
	glMultiTexCoord2fARB( GL_TEXTURE2_ARB, 6, 6 );
	glVertex3f( 240, -20, 240 );
	glMultiTexCoord2fARB( GL_TEXTURE2_ARB, 6, -6 );
	glVertex3f( 240, -20, -240 );

	glEnd();

	glPopMatrix();
}

void updateShadow()
{
	glViewport( 0, 0, SHADOWSIZE, SHADOWSIZE );
	
	glMatrixMode( GL_PROJECTION );
	glPushMatrix();
	glLoadIdentity();
	gluPerspective( SPOT_ANGLE, 1.0f, 1.0f, 500.0f );

	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();
	
	glLoadIdentity();

	gluLookAt( 
		lightPosition[ 0 ], 
		lightPosition[ 1 ], 
		lightPosition[ 2 ], 
		0, 0, 0, 
		0, 1, 0 );

	glDisable( GL_LIGHTING );
	glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);

	glEnable( GL_POLYGON_OFFSET_FILL );
	
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	drawScene();

	glBindTexture( GL_TEXTURE_2D, shadowDepthMap );
	glCopyTexSubImage2D( GL_TEXTURE_2D, 0, 0, 0, 0, 0, SHADOWSIZE, SHADOWSIZE );
	
/*	unsigned short depthMap[ 256*256 ];
	glReadPixels( 0, 0, 256, 256, GL_DEPTH_COMPONENT, GL_UNSIGNED_SHORT, depthMap );

	FILE *f = fopen( "depth.raw", "wb" );
	fwrite( depthMap, 256, 256*2, f );
	fclose( f );*/

	glEnable( GL_LIGHTING );
	glColorMask( GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE );
	glDisable( GL_POLYGON_OFFSET_FILL );
	
	extern int windowX, windowY;
	glViewport(0, 0, windowX, windowY );

	glMatrixMode( GL_PROJECTION );
	glPopMatrix();

	glMatrixMode( GL_MODELVIEW );
	glPopMatrix();
	
	glClear( GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT );
}


void	setupShadowDepth()
{
	static float genS[] = { 1.0f, 0.0f, 0.0f, 0.0f };
	static float genT[] = { 0.0f, 1.0f, 0.0f, 0.0f };
	static float genR[] = { 0.0f, 0.0f, 1.0f, 0.0f };
	static float genQ[] = { 0.0f, 0.0f, 0.0f, 1.0f };
	

#define SETUP_TEXTURE_UNIT() \
	glEnable( GL_TEXTURE_2D );								\
	glEnable( GL_TEXTURE_GEN_S );							\
	glEnable( GL_TEXTURE_GEN_T );							\
	glEnable( GL_TEXTURE_GEN_R );							\
	glEnable( GL_TEXTURE_GEN_Q );							\
	glTexGeni( GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR );	\
	glTexGeni( GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR );	\
	glTexGeni( GL_R, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR );	\
	glTexGeni( GL_Q, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR );	\
	glTexGenfv( GL_S, GL_EYE_PLANE, genS );					\
	glTexGenfv( GL_T, GL_EYE_PLANE, genT );					\
	glTexGenfv( GL_R, GL_EYE_PLANE, genR );					\
	glTexGenfv( GL_Q, GL_EYE_PLANE, genQ );					\
															\
	glMatrixMode( GL_TEXTURE );								\
	glLoadIdentity();										\
	glTranslatef( 0.5f, 0.5f, 0.5f );						\
	glScalef( 0.5f, 0.5f, 0.5f );							\
	gluPerspective( SPOT_ANGLE, 1.0f, 1.0f, 500.0f );		\
															\
	gluLookAt(												\
		lightPosition[ 0 ],									\
		lightPosition[ 1 ],									\
		lightPosition[ 2 ],									\
		0, 0, 0,											\
		0, 1, 0 );											\
															\
	glMatrixMode( GL_MODELVIEW );			

	glActiveTextureARB( GL_TEXTURE1_ARB );
	SETUP_TEXTURE_UNIT()
	spotLight->select();

	glActiveTextureARB( GL_TEXTURE0_ARB );
	SETUP_TEXTURE_UNIT()
	glBindTexture( GL_TEXTURE_2D, shadowDepthMap );

	glMatrixMode( GL_MODELVIEW );
}

void	clearShadowDepth()
{
#define CLEAR_TEXTURE_UNIT()				\
	glMatrixMode( GL_TEXTURE );				\
	glLoadIdentity();						\
											\
	glDisable( GL_TEXTURE_2D );				\
											\
	glDisable( GL_TEXTURE_GEN_S );			\
	glDisable( GL_TEXTURE_GEN_T );			\
	glDisable( GL_TEXTURE_GEN_R );			\
	glDisable( GL_TEXTURE_GEN_Q );			\
											\
	glMatrixMode( GL_MODELVIEW );

	glActiveTextureARB( GL_TEXTURE1_ARB );
	CLEAR_TEXTURE_UNIT()

	glActiveTextureARB( GL_TEXTURE0_ARB );
	CLEAR_TEXTURE_UNIT()
}

void	draw3DEngine()
{
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();
	
	extern int windowX, windowY;
	
	gluPerspective( 45.0f, (float)windowX / (float)max( 1, windowY ), 0.1f, 5000.0f );
	
	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();

	gluLookAt( 60, 60, 60, 0, -10, 0, 0, 1, 0 );
	

	glEnable ( GL_NORMALIZE );
	glEnable ( GL_LIGHTING );
	glDisable( GL_BLEND );
	glEnable ( GL_DEPTH_TEST );

	glPolygonOffset( 2, 2 );
	
	updateShadow();
	
	setupShadowDepth();

	glLightfv( GL_LIGHT0, GL_POSITION, (float*)&lightPosition );
	glLightfv( GL_LIGHT0, GL_SPOT_DIRECTION, (float*)&lightDirection );

	glActiveTextureARB( GL_TEXTURE2_ARB );
	glEnable( GL_TEXTURE_2D );
	texMetal->select();
	drawScene();
	glDisable( GL_TEXTURE_2D );
	
	clearShadowDepth();


	glEnable( GL_TEXTURE_2D );
	glDisable( GL_LIGHTING );
	drawKeys();

	glFlush();
}

void	quit3DEngine()
{
}


