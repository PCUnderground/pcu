////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Einsatz Beispiel der Mini-3D-Engine                   //
//  (w)(c)2000 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include	"3DObject.h"

C3DObject	*ludwig;
C3DObject	*bunny;
C3DObject	*torus;

void	init3DEngine()
{
	glDisable( GL_CULL_FACE );
	glDepthFunc( GL_LEQUAL );

	ludwig = new C3DObject( "data/ludwig.3d" );
	ludwig->setShadeMode( SHADE_GOURAUD );
	ludwig->setColor( 0.6f, 0.6f, 1.0f );

	bunny = new C3DObject( "data/bunny.3d" );
	bunny->setShadeMode( SHADE_GOURAUD );
	bunny->setColor( 0.7f, 0.6f, 0.0f );
	
	torus = new C3DObject( "data/torus.3d" );
	torus->setShadeMode( SHADE_FLAT );

	// Licht an 
	glEnable( GL_LIGHTING );
	glEnable( GL_LIGHT0 );

	GLfloat light_diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat light_ambient[] = { 0.1f, 0.1f, 0.1f, 1.0f };

	glLightfv( GL_LIGHT0, GL_AMBIENT, light_ambient );
	glLightfv( GL_LIGHT0, GL_DIFFUSE, light_diffuse );

	GLfloat light_position[3];
	GLfloat light_destination[] = {0.0f, 0.0f, 0.0f, 0.0f };
	GLfloat light_direction[3];

	light_position[ 0 ] = 30.0f;
	light_position[ 1 ] = 0.0f;
	light_position[ 2 ] = 30.0f;
	light_position[ 3 ] = 0.0f;

	light_direction[ 0 ] = 0.0f;
	light_direction[ 1 ] = 0.0f;
	light_direction[ 2 ] = 1.0f;
	light_direction[ 3 ] = 0.0f;

	light_direction[ 0 ] = light_destination[ 0 ] - light_position[ 0 ];
	light_direction[ 1 ] = light_destination[ 1 ] - light_position[ 1 ];
	light_direction[ 2 ] = light_destination[ 2 ] - light_position[ 2 ];
	light_direction[ 3 ] = light_destination[ 3 ] - light_position[ 3 ];

	glLightfv( GL_LIGHT0, GL_POSITION, light_position );
	glLightfv( GL_LIGHT0, GL_SPOT_DIRECTION, light_direction );

	glEnable( GL_NORMALIZE );
}

void	draw3DEngine()
{
	float time = (float)GetTickCount();

	glPushMatrix();
	glRotatef( time * 0.05f, 0.0f, 1.0f, 0.0f );
	glTranslatef( 10.0f, 0.0f, 0.0f );
	glRotatef( time * 0.1f, 0.0f, 1.0f, 0.0f );
	glTranslatef( 0.0f, 15.0f, 0.0f );
	glScalef( 2.0f, 2.0f, 2.0f );
	ludwig->drawObject();
	glPopMatrix();
	
	glPushMatrix();
	glRotatef( -time * 0.0689f, 0.0f, 1.0f, 0.0f );
	glTranslatef( 0.0f, -30.0f, 0.0f );
	glScalef( 80.0f, 80.0f, 80.0f );
	bunny->drawObject();
	glPopMatrix();

	for ( int i = 0; i < 5; i++ )
	{
		glPushMatrix();
			float t = 0.25f * i;
			torus->setColor( t, 1.0f - t, 0.0f );
			glRotatef( time * 0.05f, 1.0f, 0.0f, 1.0f );
			glTranslatef( (i-2) * 9.0f, 0.0f, 0.0f );
			glRotatef( -(time+i*1000) * 0.0689f, 0.0f, 1.0f, 0.0f );
			glRotatef( -(time+i*1000) * 0.0589f, 1.0f, 1.0f, 0.0f );
			glScalef( 3.0f, 3.0f, 3.0f );
			torus->drawObject();
		glPopMatrix();
	}
}

void	quit3DEngine()
{
	delete ludwig;
}