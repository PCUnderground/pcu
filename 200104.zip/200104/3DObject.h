////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Mini-3D-Engine                                        //
//  (w)(c)2000 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#ifndef _3DOBJECT__H
#define _3DOBJECT__H

#include	<windows.h>			
#include	<gl\gl.h>			
#include	<gl\glu.h>			

#define	SHADE_FLAT		0x00000001
#define	SHADE_GOURAUD	0x00000002

class C3DObject
{
	private:
		typedef struct
		{
			GLfloat		x, y, z;
		}VERTEX3D;
		typedef struct
		{
			GLint		a, b, c;
			VERTEX3D	normal;
		}FACE;

		VERTEX3D	*pVertexList;
		VERTEX3D	*pNormalList;
		FACE		*pFaceList;

		int			nVertices,
					nFaces;

		int			shadeMode;

		// Farbe
		GLfloat		r, g, b;

	public:
		C3DObject( char *file = NULL );
		~C3DObject();

		void		drawObject();
		void		setShadeMode( int s ) { shadeMode = s; };
		void		setColor( GLfloat rr, GLfloat gg, GLfloat bb )
		{
			r = rr; g = gg; b = bb;
		}
};

#endif