///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - Demo Projekt                            //
//                                                       //
//  Splineroutinen								         //
//  Headerfile und Klassendeklaration                    //
//                                                       //
///////////////////////////////////////////////////////////
#ifndef __SPLINE_H
#define __SPLINE_H

struct KeyPoint
{
   int          frame;
   float *      values;
   float *      tangents;
};


class CardinalSpline
{
    float          tension;
    unsigned int   nkeys;
    unsigned int   keypos;
    KeyPoint       *Keys;
    unsigned int   dimension;
    void           swap      (const unsigned int i,    const unsigned int j);
    void           quicksort (const unsigned int left, const unsigned int right);
  public:
    CardinalSpline    (unsigned int aDimension, float aTension, unsigned int keys);
    ~CardinalSpline   ();
    void  prepare     (void);
    void  set         (unsigned int frame, float *data);
    void  get         (float x, float *data);
};


#endif

