///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - Demo Projekt                            //
//                                                       //
//  Voxelspace Beispielprogramm                          //
//                                                       //
///////////////////////////////////////////////////////////
#include "demo.h"
#include "spline.h"
#include <stdio.h>

// Diese Zeilen ben�tigen Sie, um eigene Fl�ge aufzuzeichnen
//#define WIN32_LEAN_AND_MEAN
//#include <windows.h>

#define FOG
#define DRAW_OVERVIEW

extern HWND DemoHWND;


// Konstanten f�r die Gr��e der Landschaftsbitmaps
#define MAPBITS                 8
#define MAPSIZE                 (1 << MAPBITS)
#define MAPMEMORY               (MAPSIZE * MAPSIZE)

// Konstanten f�r die Darstellung
#define VSCALE                  0x600
#define ZCLIP                   (256 * VSCALE)
#define RADIX                   (32 - MAPBITS)
#define BLICKWINKEL             (0x1000/12)	// 0x1000 entspricht 360�

// Makros f�r Sinus und Cosinus
#define SIN(x)                  sintab[(x) & 0xFFF]
#define COS(x)                  sintab[((x) + 0x400) & 0xFFF]

int             sintab[0x1000];

// Die Startposition und Blickrichtung
int             xpos = 128L << 16;
int             ypos = 128L << 16;
int             zpos = 180L << 16;
int             drehwinkel=0x400;
// Die Neigung der Kamera wird durch die H�he angegeben, auf der
// der Horizont zu sehen ist !
int             neigung = 80;     

// Diverse Variablen
bitmaptype colormapbmp;
bitmaptype heightmapbmp;
bitmaptype skymapbmp;

CardinalSpline *spline;
unsigned short *colormap;
unsigned char *colormap8;
unsigned char *heightmap;
unsigned short *screen;
int fogtable[ 256 ][ 32 ];
int frame = 0;


///////////////////////////////////////////////////////////
//  Diese Routine l�dt alle Bitmaps und die Splines      //
///////////////////////////////////////////////////////////
int loadmaps( char * keyfile )
{
	// Speicher f�r das Bild
	screen = (unsigned short*)malloc( SCREEN_X * SCREEN_Y * 2 );
	if ( screen == NULL ) return 0;
	
	FILE *f = fopen (keyfile, "rt");
	if (!f) exit (1);
	
	// Informationen aus dem Keyframing File laden (Bitmap, Keyframes, Anzahl der Keys)
	char landname[80];
	char heightname[80];
	int  nKeys;
	int  speed;
	
	fscanf (f, "%s\n", landname);
	fscanf (f, "%s\n", heightname);
	fscanf (f, "%i\n", &nKeys);
	fscanf (f, "%i\n", &speed);
	
	// Bitmaps laden
	if ( bmp_load( landname,   colormapbmp  ) != BMP_NOERROR ) exit(1);
	if ( bmp_load( heightname, heightmapbmp ) != BMP_NOERROR ) exit(1);
	if ( bmp_load( "sky.BMP", skymapbmp     ) != BMP_NOERROR ) exit(1);
	
	// Splines laden
	spline = new CardinalSpline (5, 0.5, nKeys);
	
	float loadarray[5];
	
	for ( int key=0; key<nKeys; key++)
	{
		fscanf (f, "%f %f %f %f %f\n", &loadarray[0], &loadarray[1],
			&loadarray[2], &loadarray[3], &loadarray[4]);
		
		spline->set (key*speed, loadarray);
	};
	
	fclose (f);
	spline->prepare();
	
	
	// Shading Tables usw. berechnen
	colormap8 = (unsigned char *)colormapbmp.cBitmap;
	heightmap = (unsigned char *)heightmapbmp.cBitmap;
	
	for ( int j = 0; j < 32;  j++ )
        for ( int i = 0; i < 256; i++ )
        {
			int value = j*j/32;
			fogtable[ i ][ j ] = 
				ColorCode( 
					(colormapbmp.cColors[ i * 4 + 0 ]*(32-value) + value * 256)/32,
					(colormapbmp.cColors[ i * 4 + 1 ]*(32-value) + value * 256)/32,
					(colormapbmp.cColors[ i * 4 + 2 ]*(32-value) + value * 256)/32 );
        }
		
        colormap = (unsigned short *)malloc( 512 * 512 * sizeof( short ) );
		
        bmp_make16bitpalette( colormapbmp );
        bmp_make16bitpalette( skymapbmp );
		
        for ( int ofs = 0; ofs < MAPSIZE * MAPSIZE; ofs ++ )
			colormap[ ofs ] = colormapbmp.sColors[colormapbmp.cBitmap[ofs]];
		
        return 1;
}

///////////////////////////////////////////////////////////
//  Diese Routine ist das Raycasting                     //
///////////////////////////////////////////////////////////
void castray(int col, int horiz, int delta_x, int delta_y)
{
	int x, y, z, delta_z, h, ph;
	int pixel;
	int c;
	int distance = 0;
	
	// delta_z aus der Position des Horizontes berechnen
	delta_z = (horiz - (SCREEN_Y - 1)) * VSCALE;
	
	// Adresse des Pixels, also ganz unten in der aktuellen
	// Spalte
	pixel = col + (SCREEN_Y - 1) * SCREEN_X;
	
	// Sonstige Werte
	ph = 0;
	x = xpos << (16 - MAPBITS);
	y = ypos << (16 - MAPBITS);
	z = zpos;
	
	while (ph < ZCLIP)
	{
		y += delta_y;
		x += delta_x;
		z += delta_z;
		ph += VSCALE;
		
		unsigned int ofs;

		//ofs = ( ( x >> (32-MAPBITS))&(MAPSIZE-1) ) + 
		//  	  ( ( (y >> (32-MAPBITS))&(MAPSIZE-1) ) << MAPBITS );
		//h = heightmap[ ofs ] << 17;

		// Die Offset und H�henberechnung ist in Assembler schneller:
		__asm
		{
			mov ecx, x
			mov ebx, y
			shr ebx, (32-MAPBITS)
			shld ebx, ecx, MAPBITS
			mov ofs, ebx

			mov edi, [heightmap]
			sub eax, eax
			add edi, ebx
			mov al, [edi]
			shl eax, 17
			mov h, eax
		}
		
		
		// Schnittpunkt
		if (h > z)
		{
#ifdef FOG
			c = fogtable[ colormap8[ ofs ] ][ distance>>3 ];
#else
			c = colormap[ ofs ];
#endif
			int runs=0;

			// Diese Schleife wird durchschnittlich 2 mal durchlaufen !
			do
			{
				// Steigung erh�hen
				delta_z += VSCALE;
				// Pixel setzen
				screen[pixel] = c;
				// Z erh�hen
				z += ph;
				// in die n�chsth�here Bildschirmzeile gehen
				pixel -= SCREEN_X;
				if (pixel < 0) return;
			} while ( h > z );
		}
		distance ++;
	}
}


///////////////////////////////////////////////////////////
//  In dieser Routine werden die Splinedaten ausgelesen. //
//  Als Beispiel finden Sie hier einen Code-Auszug, mit  //
//  dem Sie eigene Rundfl�ge aufzeichnen k�nnen.         //
///////////////////////////////////////////////////////////
void Lenkung (float time)
{
    // Mit den folgenden auskommentierten Zeilen
	// k�nnen Sie eigene Fl�ge aufzeichnen
	/*
	static long oldtime;
	static int  recording = FALSE;
	
	  if ( GetAsyncKeyState (VK_LBUTTON) <0)  neigung++;
	  if ( GetAsyncKeyState (VK_RBUTTON) <0)  neigung--;
	  if ( GetAsyncKeyState (VK_UP) <0)       speed+=16;
	  if ( GetAsyncKeyState (VK_DOWN) <0)     speed-=16;
	  if ( GetAsyncKeyState (27)  <0)         DemoRunning= FALSE;
	  if ( GetAsyncKeyState (' ') <0)         recording = TRUE;
	  
		drehwinkel = (drehwinkel*7 + (-mousex*8192)/800)/8;
		zpos = (zpos*7+((380<<16)-(2*mousey<<16)))/8;
		xpos += (COS(drehwinkel)*speed)>>8;
		ypos += (SIN(drehwinkel)*speed)>>8;
		
		  
			if ((time/1000) != (oldtime/1000))
			{
			oldtime = time;
			if ( recording)
			{
			FILE *f = fopen ("e:\\keys2.txt","at");
			fprintf (f, "%i %i %i %i %i\n", xpos, ypos, zpos, drehwinkel, neigung);
			fclose (f);
			}
			}
	*/
	float data[5];
	spline->get (time, data);
	xpos       = (int)data[0];
	ypos       = (int)data[1];
	zpos       = (int)data[2];
	drehwinkel = (int)data[3];
	neigung    = (int)data[4];
}





///////////////////////////////////////////////////////////
//  Zeichnen den Himmel, mit angebebener vertikalen      //
//  Verschiebung "horizont"                              //
///////////////////////////////////////////////////////////
void ZeichneHimmel (int horizont)
{
	int maxy           = __max(0,__min (horizont-40, SCREEN_Y));
	int xmap           = (-drehwinkel&1023)>>1;
	
	for ( int y = 0; y<maxy; y++)
	{
		unsigned short *scr     = &screen[y*SCREEN_X];
		unsigned char  *skyline = &skymapbmp.cBitmap[512*(255-(maxy-y))];
		
		for ( int x=0; x<SCREEN_X; x++)
		{
			*scr++ = skymapbmp.sColors[ skyline[(x+xmap)&511]];
		}
	}
	for ( y=maxy; y<maxy+40; y++)
	{
		unsigned short *scr     = &screen[y*SCREEN_X];
		for ( int x=0; x<SCREEN_X; x++) *scr++ = -1;
		
	}
}



///////////////////////////////////////////////////////////
//  Voxel f�r einen bestimmten Zeitpunkt zeichnen        //
///////////////////////////////////////////////////////////
void ZeichneVoxel(float time)
{
	int delta_x, delta_y;
	int x, winkel;
	
	// Splineberechnung
	Lenkung(time);
	
	// Himmelzeichnen
	ZeichneHimmel (neigung + ((zpos - (256*VSCALE))>>18));
	
	// Den Voxel selbst zeichnen
	for ( x = 0; x < SCREEN_X; x++ )
	{
		winkel = (BLICKWINKEL * (SCREEN_X - x * 2)) / SCREEN_X;
		delta_x = COS(drehwinkel + winkel)<<(RADIX - 16);
		delta_y = SIN(drehwinkel + winkel)<<(RADIX - 16);
		castray(x, neigung, delta_x, delta_y);
	}
	
	// Eventuell die kleine Karte links-oben zeichnen
#ifdef DRAW_OVERVIEW
	colormap[((xpos>>16)&0xff)+256*((ypos>>16)&0xff)] = -1;
	for ( int y=0; y<64; y++)
        for ( int x=0; x<64; x++)
        {
			int xx = (x-32 + (xpos>>16))&((1<<MAPBITS)-1);
			int yy = (y-32 + (ypos>>16))&((1<<MAPBITS)-1);
			screen[SCREEN_X*y+x] = colormap[xx+yy*(1<<MAPBITS)];
        }
#endif
}


///////////////////////////////////////////////////////////
//  DemoInit Prozedur                                    //
///////////////////////////////////////////////////////////
int demoinit()
{
	Fenster_Modus = FENSTER;
	
	// Sinustabelle erstellen
	for (int i = 0; i < 0x1000; i++)
		sintab[i] = (int)(sin((double)i * 3.14 / 0x800) * 0x10000L);
	
	return loadmaps("keys2.txt");
}



///////////////////////////////////////////////////////////
//  DemoMain Prozedur                                    //
///////////////////////////////////////////////////////////
void demomain()
{
	long start = GetDemoTime();

	while ( DemoRunning )
	{
		ZeichneVoxel( (float)( GetDemoTime() - start ) );
		BlitGraphic( screen );
	}
}


///////////////////////////////////////////////////////////
//  DemoQuit Prozedur                                    //
///////////////////////////////////////////////////////////
void demoquit()
{
	static int quitted = 0;
	if ( quitted ) return;
	quitted = 1;
	
	if (spline)
	{
		delete spline;
		spline=0;
	}
}

