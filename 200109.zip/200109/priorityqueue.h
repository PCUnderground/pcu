////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//                                                        //
//  Optimierte Implementation des A*-Algorithmus          //
//                                                        //
//  (w)(c)2001 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include <queue>
#include <vector>

static const int xofs[ 8 ] = {  0,  1,  1,  1,  0, -1, -1, -1 };
static const int yofs[ 8 ] = { -1, -1,  0,  1,  1,  1,  0, -1 };

#define COSTDIAGONAL 554    // sqrt(2)*100000/255
#define COSTSTRAIGHT 392    // 100000/255

//#define PREFER_STRAIGHT
static const int costModify[] = { 0, COSTSTRAIGHT * 128, COSTSTRAIGHT * 256, 0x7fffff, 0x7fffff, 0x7fffff, 0x7fffff, 0x7fffff };

static const int travCost[ 8 ] = 
    { COSTSTRAIGHT, COSTDIAGONAL, COSTSTRAIGHT, 
      COSTDIAGONAL, COSTSTRAIGHT, COSTDIAGONAL, 
      COSTSTRAIGHT, COSTDIAGONAL };

class Position
{
    private:

        int _x, _y;

    public:

        Position( int x, int y ) : _x( x ), _y( y ) {};
        Position() : _x( 0 ), _y( 0 ) {};

        const int x() const { return _x; };
        const int y() const { return _y; };

        void x( int x ) { _x = x; };
        void y( int y ) { _y = y; };

        const bool operator == ( const Position &p ) const { return ( p._x == _x && p._y == _y ); }
        const bool operator != ( const Position &p ) const { return !( p._x == _x && p._y == _y ); }

        Position & operator = ( const Position &p ) { _x = p._x; _y = p._y; return *this; }

        const Position neighbour( const int d ) const { return Position( _x + xofs[ d ], _y + yofs[ d ] ); }
};

class Node
{
    friend class AStar;
	friend class NodeCompare;
	friend class MasterNodeList;

    private:
    public:
        int         g,      // kosten vom start bis zu dieser node
                    h,      // gesch�tzte restkosten
                    f;      // f = g + h
        Node        *pred;  // zeiger auf vorg�ngerknoten
        int         nPred;
        Position    p;      // eigene position
		bool		inOpen,
					inClosed;

        Node() : pred( NULL ), g( 0 ), h( 0 ), f( 0 ), nPred( 0 ) { p.x(0); p.y(0); };

		Node( int _g, int _h, Node *_pred, int _nPred, Position _p )
		{
			g = _g;
			h = _h;
			f = g + h;
			pred = _pred;
			nPred = _nPred;
			p = _p;
			inOpen = inClosed = false;
		}
		void set( int _g, int _h, Node *_pred, int _nPred, Position _p )
		{
			g = _g;
			h = _h;
			f = g + h;
			pred = _pred;
			nPred = _nPred;
			p = _p;
		}
};

class NodeCompare 
{
	public:
	   bool operator()( Node *a, Node *b ) const 
	   {
		  return( a->f > b->f );
	   }
};

// Die NodeBank allokiert einfach im Vorraus Speicher f�r Nodes. 
// Speicherallokieren ist sonst zu zeitaufwendig
class NodeBank
{
	#define MAXBANKSIZE (256*256)
	private:
		int n;
		Node *nodebank;
	public:
		NodeBank(): n(0)
		{
			nodebank = new Node[ MAXBANKSIZE ];
		}
		~NodeBank()
		{
			delete nodebank;
		}
		Node *getNewNode()
		{
			if ( n < MAXBANKSIZE )
			{
				return &nodebank[ n++ ];
			} else
			{
				MessageBox( NULL, "Zuwenig Speicher im NodeBank Pool !", "Memory low !", MB_OK );
				exit( 1 );
			}
		}
};

// Die MasterNodeList speichern alle Nodes und sucht sieht mittels Hashing
class MasterNodeList
{
	#define MAXHASHSIZE 65536
	#define HASHFUNC( p ) { ((p.x()&255)<<8)|((p.y())&255) }

	private:
		typedef struct HASHNODEPTR
		{
			Node		*node;
			HASHNODEPTR *next;
		}HASHNODE;

		HASHNODE	*pool;
		int			poolCount;

		HASHNODE	*hash;

		NodeBank	*nodeBank;

	public:

		MasterNodeList()
		{
			hash = new HASHNODE[ MAXHASHSIZE ];
			pool = new HASHNODE[ MAXHASHSIZE ];
			poolCount = 0;

			for ( int i = 0; i < MAXHASHSIZE; i++ )
			{
				hash[ i ].node = NULL;
				hash[ i ].next = NULL;
			}

			nodeBank = new NodeBank();
		}
		~MasterNodeList()
		{
			delete hash;
			delete pool;

			delete nodeBank;
		}

		Node *getNodeStored( Position p )
		{
			int hashcode = HASHFUNC( p );
			HASHNODE *node = &hash[ hashcode ];

			while ( node != NULL && node->node != NULL && node->node->p != p )
			{
				node = node->next;
			}

			if ( node != NULL )
			{
				return node->node;
			} else
				return NULL;
		}

		Node *getNode( Position p )
		{
			// mal schauen, ob die Node schon in der Liste ist

			Node *node = this->getNodeStored( p );
			if( node )
				return( node ); else
			{   
				// noch nicht drin => neue Node erzeugen
				Node *newNode = nodeBank->getNewNode();
				newNode->p = p;
				newNode->inOpen = false;
				newNode->inClosed = false;
				
				// und speichern
				this->storeNode( newNode );
				return( newNode ); 
			}
		}

		void storeNode( Node *node )
		{
			int hashcode = HASHFUNC( node->p );

			HASHNODE *hashnode = &hash[ hashcode ];

			if ( hash[ hashcode ].node == NULL )
			{
				hash[ hashcode ].node = node;
				hash[ hashcode ].next = NULL;
			} else
			{
				while ( hashnode != NULL && hashnode->next != NULL )
				{
					hashnode = hashnode->next;
				}
				if ( poolCount < MAXHASHSIZE )
				{
					hashnode->next = &pool[ poolCount ++ ];
					hashnode->next->next = NULL;
					hashnode->next->node = node;
				} else
				{
					MessageBox( NULL, "Zuwenig Speicher im HASHNODE Pool !", "Memory low !", MB_OK );
					exit( 1 );
				}
			}

		}
};

// Eine PriorityQueue in einem Heap
class PriorityQueue
{
	private:
		std::vector<Node*> heap;

	public:

		Node *pop()
		{  
			// O(log n)
			
			// Erste Node (mit niedrigsten Kosten !)
			Node *node = this->heap.front();
			
			// wir nehmen die erste node, bewegen sie zum ende (N) und sortieren 1 bis N-1 neu
			std::pop_heap( this->heap.begin(), this->heap.end(), NodeCompare() );
			
			// letzte Node wegnehmen => Heap ist wieder sortiert
			this->heap.pop_back();
			
			return( node );
		}

		void push( Node* node )
		{  
			// O(log n)
			
			// Node am Ende speichern => Heap ist unsortiert !
			this->heap.push_back( node );
			
			// Element einsortieren !
			std::push_heap( this->heap.begin(), this->heap.end(), NodeCompare() );
		}


		void updateNode(Node* node ) 
		{  
			// O(n+log n)
			std::vector<Node*>::iterator i;
			for( i = this->heap.begin(); i != this->heap.end(); i++ )
			{
				if( (*i)->p == node->p )
				{  
					// Node gefunden, von dieser Position aus neu sortieren !
					std::push_heap( this->heap.begin(), i+1, NodeCompare() );
					return;
				}
			}
		}

		bool isEmpty()
		{
			return( this->heap.empty() );
		}
};
