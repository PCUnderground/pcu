////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//                                                        //
//  Optimierte Implementation des A*-Algorithmus          //
//                                                        //
//  (w)(c)2001 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include    <windows.h>         
#include    <stdio.h>
#include    <assert.h>
#include    <math.h>
#include    <gl\gl.h>           
#include    <gl\glu.h>          
#include    "glext.h"

#include    "texture.h"

#include	"priorityqueue.h"

#define     MAPSIZE 32

unsigned char   map[ MAPSIZE ][ MAPSIZE ];
unsigned char   marked[ MAPSIZE ][ MAPSIZE ];

#define		MARKED_NONE		0
#define		MARKED_OPEN		1
#define		MARKED_CLOSE	2

class AStar
{
    private:
        Position    start,
                    goal;

		int			nodesExpanded;

		MasterNodeList	*masterNodeList;
		PriorityQueue	*pqueue;

        Node			*goalNode;

        int     pathCostEstimate( Position &s, Position &g )
        {
            int c = ( map[ s.x() ][ s.y() ] + 
				      map[ g.x() ][ g.y() ] ) >> 1;

			// nur entfernung als ma�, keine unterschiedlichen bewegungskosten !
            return sqrt( ( s.x() - g.x() ) * ( s.x() - g.x() ) + ( s.y() - g.y() ) * ( s.y() - g.y() ) ) * COSTSTRAIGHT * 128;

            // variante 1
            int straight = max( abs( s.x() - g.x() ), abs( s.y() - g.y() ) );
            int diagonal = min( abs( s.x() - g.x() ), abs( s.y() - g.y() ) );
            //return ( diagonal * COSTDIAGONAL + ( straight - diagonal ) * COSTSTRAIGHT ) * c;
            // variante 2
            //return max( abs( s.x() - g.x() ), abs( s.y() - g.y() ) ) * COSTSTRAIGHT * c;
            // variante 3
            //return sqrt( abs( s.x() - g.x() ) * abs( s.x() - g.x() ) + abs( s.y() - g.y() ) * abs( s.y() - g.y() ) ) * COSTSTRAIGHT * c;
            // triviale variante
            return 0;
        }

        int     traversalCost( Position &a, Position &b, int d )
        {
            int c = ( map[ a.x() ][ a.y() ] +
                      map[ b.x() ][ b.y() ] ) >> 1;

            return c * travCost[ d ];
        }

		int		getDirIndex( int dx, int dy )
		{
			for ( int dir = 0; dir < 8; dir ++ )
				if ( xofs[ dir ] == dx && yofs[ dir ] == dy )
					return dir;
			return 0;
		}

		int		isValid( Position &p )
		{
 			if ( p.x() < 0 || p.x() >= MAPSIZE || p.y() < 0 || p.y() >= MAPSIZE || map[ p.x() ][ p.y() ] == 255 )
				return 0;
			return 1;
		}

    public:
        AStar( Position &_start, Position &_goal ) : start( _start ), goal( _goal ), nodesExpanded( 0 ) 
		{
			masterNodeList = new MasterNodeList();
			pqueue = new PriorityQueue();
		};
        AStar() : start( 0, 0 ), goal( 0, 0 ), nodesExpanded( 0 ) 
		{
			masterNodeList = new MasterNodeList();
			pqueue = new PriorityQueue();
		};

        ~AStar()
        {
			delete masterNodeList;
			delete pqueue;
        }

        void    init( Position &s, Position &g )
        {
			Node *startNode = masterNodeList->getNode( s );

			startNode->inOpen = true;
			startNode->inClosed = false;
			startNode->pred = NULL;
			startNode->nPred = 0;
			startNode->g = 0;
			startNode->h =
				startNode->f = pathCostEstimate( s, g );

			pqueue->push( startNode );

            goal = g;
        };

		void	expandNode( Node *node )
		{
			for ( int d = 0; d < 8; d++ )
			{
				Position p = node->p.neighbour( d );
				
				if ( isValid( p ) )
				{
					int travCostModify = 0;
#ifdef PREFER_STRAIGHT
					if ( node->pred )
					{
						int dirX = p.x() - node->p.x();
						int dirY = p.y() - node->p.y();
						int lastDirX = node->p.x() - node->pred->p.x();
						int lastDirY = node->p.y() - node->pred->p.x();

						int dir = getDirIndex( dirX, dirY );
						int lastDir = getDirIndex( lastDirX, lastDirY );

						int rot = lastDir - dir;
						if ( rot > 4 ) rot = 8 - rot;
						if ( rot < -4 ) rot = 8 + rot;
						rot = abs( rot );
						travCostModify = costModify[ rot ];
					}
#endif

					// nicht die Node durchsuchen, von der wir kommen !
					if( node->pred == NULL || 
						node->pred->p != p )
					{   
						Node newNode;
						newNode.p     = p;
						newNode.pred  = node;
						newNode.nPred = node->nPred + 1;
						newNode.g     = node->g + traversalCost( node->p, p, d ) + travCostModify;
						newNode.f     = newNode.g + pathCostEstimate( p, goal );

						// eine preallokierte Node f�r die MasterNodeList holen
						Node *pNode = masterNodeList->getNode( newNode.p );
						
						// pr�fen, ob sich die neue Node lohnt
						if( !( pNode->inOpen && newNode.f > pNode->f ) &&
							!( pNode->inClosed && newNode.f > pNode->f ) )
						{  
							// ja, ab in die Open Liste oder zumindest updaten !
							// (theoretisch aus der Open und Close Liste nehmen und neu in die
							// OpenList einf�gen !)
							pNode->inClosed = false;
							pNode->pred     = newNode.pred;
							pNode->nPred    = newNode.nPred;
							pNode->g        = newNode.g;
							pNode->f        = newNode.f;
							
							if( pNode->inOpen )
							{  
								// Update Fall => nur Position in der PriorityQueue updaten !
								pqueue->updateNode( pNode );
							}
							else
							{  
								// Neue Node => ab in die OpenList
								pqueue->push( pNode );
								pNode->inOpen = true;
							}

							marked[ pNode->p.x() ][ pNode->p.y() ] = MARKED_OPEN;
						}
					}
				}
			}
		}

		int searchPath()
		{
			while( !pqueue->isEmpty() )
			{
				// beste Node holen
				Node *node = pqueue->pop();
				
				if( node->p == goal )
				{  
					// Ziel gefunden ?
					goalNode = node;
					return node->nPred + 1;
				}

				expandNode( node );

				// Feld f�r Visualisierung markieren
				marked[ node->p.x() ][ node->p.y() ] = MARKED_CLOSE;
                nodesExpanded ++;
				
				// node in die Closed Liste
				node->inClosed = true;
			}
			
			// kein Pfad gefunden
			return -1;
		}

        int getPath( Position *p )
        {
			int length = 0;
			Node *node = goalNode;
			while ( node->pred != NULL )
			{
				node = node->pred;
				length ++;
			}

            Position *dst = &p[ length - 1 + 1 ];
			node = goalNode;

            while ( 1 ) 
            {
                *dst = node->p;
                *dst --;
                if ( node->pred != NULL )
                    node = node->pred; else
                    break;
            };

            return length;
        }

		int reducePath( Position *p, Position *o, int size )
		{
			int newSize = 2;

			Position *dst = p;
			Position *src = o;
			Position *last = src;

			*(dst++) = *(src++);

			int lastDir = getDirIndex( src->x() - last->x(), src->y() - last->y() );

			for ( int i = 1; i < size - 1; i++ )
			{
				int dir = getDirIndex( src->x() - last->x(), src->y() - last->y() );

				if ( lastDir != dir )
				{
					*(dst++) = *last;
					lastDir = dir;
					newSize ++;
				}

				last = src;
				src++;
			}
			*(dst++) = *(src++);

			return newSize;
		}
};










void    drawMap()
{
    glLineWidth( 1.0f );

    for ( int j = 0; j < MAPSIZE; j++ )
        for ( int i = 0; i < MAPSIZE; i++ )
        {
            int c = 255 - map[ i ][ j ];

            glColor3ub( c, c, c );
            glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );

            glBegin( GL_QUADS );
            glVertex2i( i, j );
            glVertex2i( i+1, j );
            glVertex2i( i+1, j+1 );
            glVertex2i( i, j+1 );
            glEnd();

            glColor3ub( 0, 0, 0 );
            glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );

            glBegin( GL_QUADS );
            glVertex2i( i, j );
            glVertex2i( i+1, j );
            glVertex2i( i+1, j+1 );
            glVertex2i( i, j+1 );
            glEnd();
        }

    for ( j = 0; j < MAPSIZE; j++ )
        for ( int i = 0; i < MAPSIZE; i++ )
		if ( marked[ i ][ j ] != MARKED_NONE )
        {
			if ( marked[ i ][ j ] == MARKED_OPEN )
	            glColor3ub( 0, 255, 0 );
			if ( marked[ i ][ j ] == MARKED_CLOSE )
	            glColor3ub( 0, 0, 255 );

            glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );
            glBegin( GL_QUADS );
            glVertex2f( i+0.4f, j+0.4f );
            glVertex2f( i+0.6f, j+0.4f );
            glVertex2f( i+0.6f, j+0.6f );
            glVertex2f( i+0.4f, j+0.6f );
            glEnd();
        }

}

void    drawPath( Position *path, int length )
{
    if ( path == NULL )
        return;

    for ( int i = 1; i < length; i++ )
    {
        Position *last = &path[ i - 1 ];
        Position *curr = &path[ i ];

        // draw line
        glColor3ub( 255, 0, 0 );

        glLineWidth( 2.0f );

        glBegin( GL_LINES );

        glVertex2f( last->x() + 0.5f, last->y() + 0.5f );
        glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );

        // Pfeilspitzen nicht sch�n, aber einfach !
        int dx = last->x() - curr->x();
        int dy = last->y() - curr->y();

        if ( dx == 0 && dy > 0 )
        {
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.35f, curr->y() + 0.85f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.65f, curr->y() + 0.85f );
        } else
        if ( dx == 0 && dy < 0 )
        {
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.35f, curr->y() + 0.15f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.65f, curr->y() + 0.15f );
        } else
        if ( dy == 0 && dx > 0 )
        {
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.85f, curr->y() + 0.35f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.85f, curr->y() + 0.65f );
        } else
        if ( dy == 0 && dx < 0 )
        {
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.15f, curr->y() + 0.35f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.15f, curr->y() + 0.65f );
        } else
        if ( dx < 0 && dy < 0 )
        {
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.15f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.15f );
        } else
        if ( dx < 0 && dy > 0 )
        {
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.15f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.85f );
        } else
        if ( dx > 0 && dy < 0 )
        {
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.85f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.15f );
        } else
        if ( dx > 0 && dy > 0 )
        {
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.85f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.85f );
        } 

        glEnd();
    }
}

void interpolatedPosition( float *x, float *y, Position *a, Position *b, Position *c, Position *d, float u )
{
	u = 0.66666666f;
	float u3 = u * u * u;
	float u2 = u * u;
	float f1 = -0.5f * u3 +        u2 - 0.5f * u;
	float f2 =  1.5f * u3 - 2.5f * u2 + 1.0f;
	float f3 = -1.5f * u3 + 2.0f * u2 + 0.5f * u;
	float f4 =  0.5f * u3 - 0.5f * u2;

	*x = (float)a->x() * f1 + (float)b->x() * f2 + (float)c->x() * f3 + (float)d->x() * f4;
	*y = (float)a->y() * f1 + (float)b->y() * f2 + (float)c->y() * f3 + (float)d->y() * f4;
}

void    drawPathCatmullRom( Position *path, int length )
{
    if ( path == NULL )
        return;

    glColor3ub( 255, 0, 0 );

    glLineWidth( 2.0f );


    glBegin( GL_LINE_STRIP );
    for ( int i = 0; i < length; i++ )
    {
		for ( float u = 0.0f; u < 1.0f; u += 0.01f )
		{
			float x, y;
			interpolatedPosition( &x, &y,
				&path[ max( 0, i-1 ) ], 
				&path[ i ],
				&path[ min( i+1, length-1 ) ],
				&path[ min( i+2, length-1 ) ], u );

			glVertex2f( x + 0.5f, y + 0.5f );
		}

    }
    glEnd();
}


AStar       pathFinder;
Position    *path = NULL;
int         length = 0;
Position    *path2 = NULL;
int			length2 = 0;

void    initGLoutput()
{
    Position start( 30, 30 );
    Position end( 1, 1 );

    pathFinder.init( start, end );

    memset( (unsigned char *)map, 1, MAPSIZE * MAPSIZE );
    memset( (unsigned char *)marked, 0, MAPSIZE * MAPSIZE );

	FILE *f = fopen( "cost2.raw", "rb" );
	//FILE *f = fopen( "labyrinth.raw", "rb" );
	fread( map, MAPSIZE*MAPSIZE, 1, f );
	fclose( f );

	for ( int i = 0; i < MAPSIZE*MAPSIZE; i++ )
		((unsigned char*)&map)[ i ] = (255-((unsigned char*)&map)[ i ]);

	// Barriere hinzuf�gen !
    //for ( int j = 0; j < 31; j++ )
      //map[ j ][ 16 ] = 255;

    if ( ( length = pathFinder.searchPath() ) != -1 )
    {
        // pfad gefunden
        path = new Position[ length + 2 ];

        length = pathFinder.getPath( path );

        path2 = new Position[ length + 2 ];
		length2 = pathFinder.reducePath( path2, path, length );
    }
}



void    drawGLOutput()
{
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

    glMatrixMode( GL_PROJECTION );
    glLoadIdentity();
    glTranslatef( -1.0f, -1.0f, -1.0f );
    glScalef( 2.0f / (float)MAPSIZE, 2.0f / (float)MAPSIZE, 2.0f / (float)MAPSIZE );

    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();

    drawMap();

	drawPath( path, length );
}

void    quitGLOutput()
{
    delete path;
    delete path2;
}
