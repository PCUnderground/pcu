////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  (w)(c)2000 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#ifndef HELPERS__H
#define HELPERS__H

typedef struct 
{
  float x;
  float y;
  float z;
} VERTEX;

typedef struct 
{
  VERTEX position;
  VERTEX tangentSpaceLightVector;
  VERTEX tangentSpaceHalfAngleVector;
  short  s, t;
} VERTEXDOT3;

typedef struct 
{
  VERTEX tangent;
  VERTEX binormal;
  VERTEX normal;
} ONBASIS;

static void	normVector( float *v )
{
	float l = (float)sqrt( v[ 0 ] * v[ 0 ] + v[ 1 ] * v[ 1 ] + v[ 2 ] * v[ 2 ] );

	if ( l == 0.0f )
	{
		v[ 0 ] = v[ 1 ] = 0.0f;
		v[ 2 ] = 1.0f;
	} else
	{
		l = 1.0f / l;
		v[ 0 ] *= l;
		v[ 1 ] *= l;
		v[ 2 ] *= l;
	}
}

static void	addVector( VERTEX *a, VERTEX *b )
{
	a->x += b->x;
	a->y += b->y;
	a->z += b->z;
}

static void	subVector( VERTEX *c, VERTEX *a, VERTEX *b )
{
	c->x = a->x - b->x;
	c->y = a->y - b->y;
	c->z = a->z - b->z;
}

static void	convVEC2RGB( unsigned char *rgb, float *v )
{
	rgb[ 0 ] = (unsigned char)( 128.0f + 127.0f * v[ 0 ] );
	rgb[ 1 ] = (unsigned char)( 128.0f + 127.0f * v[ 1 ] );
	rgb[ 2 ] = (unsigned char)( 128.0f + 127.0f * v[ 2 ] );
}

static float	dotProduct( VERTEX *a, VERTEX *b )
{
	return a->x * b->x + a->y * b->y + a->z * b->z;
}

#endif