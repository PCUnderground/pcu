////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Wrapper f�r Textureloader                             //
//  (w)(c)2000 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include	<windows.h>
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	<gl\glaux.h>			
#include	<assert.h>
#include	<stdio.h>
#include	<math.h>
#include	"glut.h"			
#include	"Texture.h"
#include	"helpers.h"

PCUTexture::PCUTexture()
{
	ID = 0;
}

PCUTexture::~PCUTexture()
{
	deleteTexture();
}

bool PCUTexture::createTexture()
{
	deleteTexture();

	glGenTextures(1, &ID);

	ID ++;

	glBindTexture( GL_TEXTURE_2D, ID - 1 );
	glTexParameterf( GL_TEXTURE_2D,GL_TEXTURE_WRAP_S, GL_REPEAT );
	glTexParameterf( GL_TEXTURE_2D,GL_TEXTURE_WRAP_T, GL_REPEAT );
	glTexParameterf( GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER, GL_LINEAR );
	glTexParameterf( GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST );
	
	return true;
}

void PCUTexture::deleteTexture()
{
	if( ID )
	{
		ID --;
		glDeleteTextures( 1, &ID );
		ID = 0;
	}
}

void PCUTexture::select()
{
	glBindTexture( GL_TEXTURE_2D, ID - 1 );
}

// diese methode l�dt NUR TGAs mit 256x256 Pixel und 32 Bit !!!
bool PCUTexture::loadTGA32Bit256x256( char *fileName )
{
	createTexture();

	FILE *f = fopen( fileName, "rb" );
	assert( f );

	unsigned char image[ 256 * 256 * 4 + 4 ];

	fseek( f, 44, SEEK_SET );
	fread( image, 4, 256 * 256, f );

	fclose( f );

	width = height = 256;

	gluBuild2DMipmaps(GL_TEXTURE_2D, 4, width, height, GL_RGBA, GL_UNSIGNED_BYTE, image+2 );

	return true;
}

bool PCUTexture::loadBMP( char *fileName )
{
	createTexture();

    AUX_RGBImageRec *texture;

    texture = auxDIBImageLoad( fileName );

	if ( !texture )
		return false;

	width = texture->sizeX;
	height = texture->sizeY;

	gluBuild2DMipmaps(GL_TEXTURE_2D, 3, width, height, GL_RGB, GL_UNSIGNED_BYTE, texture->data );

	free( texture->data );
	texture->data = NULL;

	return true;
}

 
void PCUTexture::downSampleNormalMap( DOT3NORMAL *dst, DOT3NORMAL *old, int w2, int h2, int w, int h )
{
	const float f127 = 1.0f / 127.0f;
	const float f255 = 1.0f / 255.0f;

	VERTEX normal;
	float l;
	float mag00, mag01, mag10, mag11;
	int   i, j, ii, jj;
	
	for ( i = 0; i < h2; i += 2 ) 
	{
		for ( j = 0; j < w2; j += 2 ) 
		{
			// l�nge der alten vektoren holen
			mag00 = f255 * old[ (i  )    *w2 +  (j  )    ].mag;
			mag01 = f255 * old[ (i  )    *w2 + ((j+1)%h2)].mag;
			mag10 = f255 * old[((i+1)%w2)*w2 +  (j  )    ].mag;
			mag11 = f255 * old[((i+1)%w2)*w2 + ((j+1)%h2)].mag;
			
			// summe der 2x2 rot anteile (auf [-1,1] skaliert !)
			normal.x =  mag00 * ( f127 * old[ (i  )     * w2 +  (j  )    ].nx - 1.0f );
			normal.x += mag01 * ( f127 * old[ (i  )     * w2 + ((j+1)%h2)].nx - 1.0f );
			normal.x += mag10 * ( f127 * old[((i+1)%w2) * w2 +  (j  )    ].nx - 1.0f );
			normal.x += mag11 * ( f127 * old[((i+1)%w2) * w2 + ((j+1)%h2)].nx - 1.0f );
			
			// summe der 2x2 gr�n anteile (auf [-1,1] skaliert !)
			normal.y =  mag00 * ( f127 * old[ (i  )     * w2 +  (j  )    ].ny - 1.0f );
			normal.y += mag01 * ( f127 * old[ (i  )     * w2 + ((j+1)%h2)].ny - 1.0f );
			normal.y += mag10 * ( f127 * old[((i+1)%w2) * w2 +  (j  )    ].ny - 1.0f );
			normal.y += mag11 * ( f127 * old[((i+1)%w2) * w2 + ((j+1)%h2)].ny - 1.0f );
			
			// summe der 2x2 blau anteile (auf [-1,1] skaliert !)
			normal.z =  mag00 * ( f127 * old[ (i  )     * w2 +  (j  )    ].nz - 1.0f );
			normal.z += mag01 * ( f127 * old[ (i  )     * w2 + ((j+1)%h2)].nz - 1.0f );
			normal.z += mag10 * ( f127 * old[((i+1)%w2) * w2 +  (j  )    ].nz - 1.0f );
			normal.z += mag11 * ( f127 * old[((i+1)%w2) * w2 + ((j+1)%h2)].nz - 1.0f );

			l = sqrt( normal.x * normal.x + 
					  normal.y * normal.y + 
					  normal.z * normal.z );
			if ( l > 0.0f )
				l = 1.0f / l; else l = 0.0f;

			normVector( (float*)&normal );
			
			ii = i >> 1;
			jj = j >> 1;
			
			dst[ ii * w + jj ].nx = (unsigned char)( 128.0f + 127.0f * normal.x );
			dst[ ii * w + jj ].ny = (unsigned char)( 128.0f + 127.0f * normal.y );
			dst[ ii * w + jj ].nz = (unsigned char)( 128.0f + 127.0f * normal.z );
			
			dst[ ii * w + jj ].mag = min( 255, (unsigned char)( 255.0f * l * 0.25f ) );
		}
	}
}

// diese funktion l�dt bitmaps, die vom nvidia bumpmap tool generiert wurden !
bool PCUTexture::loadBMPasBump( char *fileName )
{
	createTexture();

    AUX_RGBImageRec *texture;

    texture = auxDIBImageLoad( fileName );

	if ( !texture )
		return false;

	width = texture->sizeX;
	height = texture->sizeY;

	unsigned char *data = new unsigned char[ width * height * 4 ];
	unsigned char *src = (unsigned char*)texture->data;

	for ( unsigned int i = 0; i < width * height; i++ )
	{
		data[ 0 ] = src[ 2 ];
		data[ 1 ] = src[ 0 ];
		data[ 2 ] = src[ 1 ];
		data[ 3 ] = 255;
		data += 4;
		src  += 3;
	}
	data -= width * height * 4;

	int level = 0;

	glTexImage2D( GL_TEXTURE_2D, level, GL_RGBA8, width, height, 0,
				  GL_BGRA_EXT, GL_UNSIGNED_BYTE, data );

	// jetzt alle Mipmap Stufen erstellen
	while ( width > 1 || height > 1 )
	{
		int nw, nh;

		level ++;

		nw = width >> 1;
		nh = height >> 1;
		if ( nw == 0 ) nw = 1;
		if ( nh == 0 ) nh = 1;

		unsigned char *datanew = new unsigned char[ nw * nh * 4 ];

		downSampleNormalMap( (DOT3NORMAL*)datanew, (DOT3NORMAL*)data, width, height, nw, nh );

		glTexImage2D( GL_TEXTURE_2D, level, GL_RGBA8, nw, nh, 0,
					  GL_BGRA_EXT, GL_UNSIGNED_BYTE, datanew );

		delete data;

		data = datanew;

		width = nw;
		height = nh;
	}

	delete data;

	free( texture->data );
	texture->data = NULL;

	return true;
}

