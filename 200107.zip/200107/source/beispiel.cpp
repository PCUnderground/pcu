////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//                                                        //
//  Bumpmapping Beispielprogramm                          //
//                                                        //
//  (w)(c)2000 Carsten Dachsbacher                        //
//                                                        //
//  Dot3 Bumpmapping nach Mark J. Kilgard:                //
//  A Practical and Robust Bump-Mapping Technique for     //
//  Today's GPUs                                          //
//                                                        //
////////////////////////////////////////////////////////////
#include	<windows.h>			
#include	<stdio.h>
#include	<stdlib.h>
#include	<assert.h>
#include	<math.h>
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	"glext.h"
#include	"texture.h"

//#define		EMBOSSBUMP

#ifndef		EMBOSSBUMP
#define		DOT3BUMP
#endif

#include	"helpers.h"

#ifdef DOT3BUMP
void makeNormalizeVectorCubeMap( int size );
#endif

void	checkOpenGLError()
{
	GLenum glError = GL_NO_ERROR;
	assert( (glError = glGetError() ) == GL_NO_ERROR );
}

#define MAX_EXTENSION_SPACE		10240
#define MAX_EXTENSION_LENGTH	256

static bool	extensionsSupported = false;
static bool	useExtensions = true;
static int	maxTexelUnits = 1;
static bool dot3Supported = false;
static bool specularSupported = false;


// hier die definitionen f�r den import der extensions
PFNGLMULTITEXCOORD1FARBPROC		glMultiTexCoord1fARB	 = NULL;
PFNGLMULTITEXCOORD2FARBPROC		glMultiTexCoord2fARB	 = NULL;
PFNGLMULTITEXCOORD3FARBPROC		glMultiTexCoord3fARB	 = NULL;
PFNGLMULTITEXCOORD3FVARBPROC	glMultiTexCoord3fvARB	 = NULL;
PFNGLMULTITEXCOORD4FARBPROC		glMultiTexCoord4fARB	 = NULL;
PFNGLACTIVETEXTUREARBPROC		glActiveTextureARB		 = NULL;
PFNGLCLIENTACTIVETEXTUREARBPROC	glClientActiveTextureARB = NULL;	
PFNGLCOMBINERPARAMETERFVNVPROC	glCombinerParameterfvNV  = NULL;
PFNGLCOMBINERPARAMETERIVNVPROC	glCombinerParameterivNV  = NULL;
PFNGLCOMBINERPARAMETERFNVPROC	glCombinerParameterfNV   = NULL;
PFNGLCOMBINERPARAMETERINVPROC	glCombinerParameteriNV   = NULL;
PFNGLCOMBINERINPUTNVPROC		glCombinerInputNV        = NULL;
PFNGLCOMBINEROUTPUTNVPROC		glCombinerOutputNV       = NULL;
PFNGLFINALCOMBINERINPUTNVPROC	glFinalCombinerInputNV   = NULL;

PCUTexture	bumpTex, invBumpTex, textureMap;
int			cubeMap;

float		xrot, yrot;
float		xspeed = 0.61f;
float		yspeed = 0.42f;

bool initExtensions() 
{
	char *extensions;	
	extensions = strdup( (char*)glGetString( GL_EXTENSIONS ) );
	
	for ( unsigned int i = 0; i < strlen( extensions ); i ++ )
		if ( extensions[ i ] == ' ' ) extensions[ i ] = '\n';

	if ( strstr( extensions, "GL_ARB_texture_cube_map") )
	{
		glCombinerParameteriNV   = (PFNGLCOMBINERPARAMETERINVPROC)		wglGetProcAddress( "glCombinerParameteriNV" );
		glCombinerParameterfvNV  = (PFNGLCOMBINERPARAMETERFVNVPROC)     wglGetProcAddress( "glCombinerParameterfvNV" );
		glCombinerParameterivNV  = (PFNGLCOMBINERPARAMETERIVNVPROC)     wglGetProcAddress( "glCombinerParameterivNV" );
		glCombinerParameterfNV   = (PFNGLCOMBINERPARAMETERFNVPROC)		wglGetProcAddress( "glCombinerParameterfNV" );
		glCombinerInputNV        = (PFNGLCOMBINERINPUTNVPROC)           wglGetProcAddress( "glCombinerInputNV" );
		glCombinerOutputNV		 = (PFNGLCOMBINEROUTPUTNVPROC)          wglGetProcAddress( "glCombinerOutputNV" );
		glFinalCombinerInputNV   = (PFNGLFINALCOMBINERINPUTNVPROC)      wglGetProcAddress( "glFinalCombinerInputNV" );

		dot3Supported = true;
	}

	int alphaBits;

	glGetIntegerv( GL_ALPHA_BITS, &alphaBits );
    if ( alphaBits > 0 )
		specularSupported = true;

	if ( strstr( extensions, "GL_ARB_multitexture" ) && 
		 strstr( extensions, "GL_EXT_texture_env_combine" ) )
	{	
		glGetIntegerv( GL_MAX_TEXTURE_UNITS_ARB, &maxTexelUnits );
		glMultiTexCoord1fARB	 = (PFNGLMULTITEXCOORD1FARBPROC)		wglGetProcAddress( "glMultiTexCoord1fARB" );
		glMultiTexCoord2fARB	 = (PFNGLMULTITEXCOORD2FARBPROC)		wglGetProcAddress( "glMultiTexCoord2fARB" );
		glMultiTexCoord3fARB	 = (PFNGLMULTITEXCOORD3FARBPROC)		wglGetProcAddress( "glMultiTexCoord3fARB" );
		glMultiTexCoord4fARB	 = (PFNGLMULTITEXCOORD4FARBPROC)		wglGetProcAddress( "glMultiTexCoord4fARB" );
		glActiveTextureARB		 = (PFNGLACTIVETEXTUREARBPROC)			wglGetProcAddress( "glActiveTextureARB" );
		glClientActiveTextureARB = (PFNGLCLIENTACTIVETEXTUREARBPROC)	wglGetProcAddress( "glClientActiveTextureARB" );		
		glMultiTexCoord3fvARB    = (PFNGLMULTITEXCOORD3FVARBPROC)       wglGetProcAddress( "glMultiTexCoord3fvARB" );

		free( extensions );
		return true;
	} else
		free( extensions );

	useExtensions = false;
	return false;
}

float lightAmbient[]	= { 0.0f, 0.0f, 0.0f, 1.0f };
float lightDiffuse[]	= { 1.0f, 1.0f, 1.0f, 1.0f };
float lightSpecular[]	= { 1.0f, 1.0f, 1.0f, 1.0f };
float lightPosition[]   = { 5.0f, 0.0f, 0.5f, 1.0f };
float grayColor[]       = { 0.5f, 0.5f, 0.5f, 1.0f };

void makeTorus(float r, float R, GLint sides, GLint rings);

void	init3DEngine()
{
	initExtensions();

#ifdef EMBOSSBUMP
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

	glPixelTransferf( GL_RED_SCALE, 0.5f );
	glPixelTransferf( GL_GREEN_SCALE, 0.5f );
	glPixelTransferf( GL_BLUE_SCALE, 0.5f );

	bumpTex.loadBMP( "./data/bump.bmp" );
	invBumpTex.loadBMP( "./data/invbump.bmp" );

	glPixelTransferf( GL_RED_SCALE, 1.0f );
	glPixelTransferf( GL_GREEN_SCALE, 1.0f );
	glPixelTransferf( GL_BLUE_SCALE, 1.0f );

	textureMap.loadBMP( "./data/marble.bmp" );
#endif

#ifdef DOT3BUMP

	if ( !dot3Supported )
		exit( 1 );

	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

	invBumpTex.createTexture();
	invBumpTex.select();
	invBumpTex.loadBMPasBump( "./data/mdbump.bmp" );

	textureMap.loadBMP( "./data/marble.bmp" );

	glGenTextures(1, (GLuint*)&cubeMap);
	glActiveTextureARB( GL_TEXTURE1_ARB );
	glBindTexture( GL_TEXTURE_CUBE_MAP_EXT, cubeMap );
	makeNormalizeVectorCubeMap( 32 );
	glMatrixMode( GL_TEXTURE );
	glLoadIdentity();

	glEnable(GL_TEXTURE_CUBE_MAP_EXT);
	glActiveTextureARB(GL_TEXTURE0_ARB);
	glMatrixMode( GL_TEXTURE );
	glLoadIdentity();
	glScalef( 0.125f, 0.125f, 0.125f );
	glScalef( 0.5f, 0.5f, 0.5f );

#endif

	glLightfv( GL_LIGHT0, GL_AMBIENT, lightAmbient );
	glLightfv( GL_LIGHT0, GL_DIFFUSE, lightDiffuse );	
	glLightfv( GL_LIGHT0, GL_SPECULAR, lightSpecular );	
	glLightfv( GL_LIGHT0, GL_POSITION, lightPosition );

	glEnable( GL_LIGHT0 );	

	glEnable( GL_TEXTURE_2D );
	glShadeModel( GL_SMOOTH );
	glEnable( GL_DEPTH_TEST );
	glDepthFunc( GL_LEQUAL );
	glHint( GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST );

	glEnable(GL_NORMALIZE);

	makeTorus( 0.27f, 0.61f, 32, 32 );
}

int					torusSides, 
					torusRings;
VERTEXDOT3			*torusVertex;
ONBASIS				*torusAxis;

void makeTorus( float r, float R, int sides, int rings )
{ 
	const float pi = 3.1415926535898f;
	const float ringDelta = 2.0f * pi / (float)rings;
	const float sideDelta = 2.0f * pi / (float)sides;
	
	VERTEXDOT3	*vertex;
	ONBASIS		*axis;
	int i, j;
	
	sides ++;
	rings ++;
	
	torusSides  = sides;
	torusRings  = rings;
	torusVertex = new VERTEXDOT3[ sides * rings ];
	torusAxis   = new ONBASIS[ sides * rings ];
	
	vertex = torusVertex;
	axis   = torusAxis;
	
	for ( i = 0; i < rings; i ++ )
	{
		float theta = (float)i * ringDelta;
		float cosTheta = (float)cos( theta );
		float sinTheta = (float)sin( theta );
		
		for ( j = 0; j < sides; j ++ )
		{
			float phi = j * sideDelta;
			float cosPhi = (float)cos( phi );
			float sinPhi = (float)sin( phi );
			float dist = R + r * cosPhi;
			float dxdtheta, dydtheta, d;
			
			// die vertex koordinaten ergeben sich durch die
			// parametrische beschreibung eines torus
			vertex->position.x = cosTheta * dist;
			vertex->position.y = -sinTheta * dist;
			vertex->position.z = r * sinPhi;
		
			vertex->s = j;
			vertex->t = i;
			
			// ableitung von x, y bilden und normalisieren => tangente
			dxdtheta = -sinTheta * dist;
			dydtheta = -cosTheta * dist;
			d = 1.0f / (float)sqrt( dxdtheta * dxdtheta + dydtheta * dydtheta );
			axis->tangent.x = dxdtheta * d;
			axis->tangent.y = dydtheta * d;
			axis->tangent.z = 0.0;
			
			axis->normal.x =  cosTheta * cosPhi;
			axis->normal.y = -sinTheta * cosPhi;
			axis->normal.z = sinPhi;
			
			// binormale ist kreuzprodukt von normale und tangente 
			axis->binormal.x =
				axis->normal.y * axis->tangent.z - axis->normal.z * axis->tangent.y;
			axis->binormal.y =
				axis->normal.z * axis->tangent.x - axis->normal.x * axis->tangent.z;
			axis->binormal.z =
				axis->normal.x * axis->tangent.y - axis->normal.y * axis->tangent.x;
			
			vertex ++;
			axis ++;
		}
	}
	
}

#ifdef DOT3BUMP

void transformPosition(VERTEX *out, VERTEX *in, float m[4][4])
{
  float w;

  w = in->x * m[0][3] + in->y * m[1][3] + in->z * m[2][3] + m[3][3];
  out->x = (in->x * m[0][0] + in->y * m[1][0] + in->z * m[2][0] + m[3][0])/w;
  out->y = (in->x * m[0][1] + in->y * m[1][1] + in->z * m[2][1] + m[3][1])/w;
  out->z = (in->x * m[0][2] + in->y * m[1][2] + in->z * m[2][2] + m[3][2])/w;
}

void initCombiners( int shadowing, int specular )
{
	float baseColor[] = { 0.2f, 0.2f, 0.3f, 0.0f };
	
	if ( specular )
		shadowing = 1;
	
	if ( shadowing == 1 || specular ) 
		glCombinerParameteriNV( GL_NUM_GENERAL_COMBINERS_NV, 2 ); else
		glCombinerParameteriNV( GL_NUM_GENERAL_COMBINERS_NV, 1 );

	glCombinerParameterfvNV( GL_CONSTANT_COLOR0_NV, baseColor );
	
	// GENERAL Combiner #0, RGB 
	// Argb = 3x3 matrix column1 = expand(texture0rgb) = N'
	glCombinerInputNV(
		GL_COMBINER0_NV, GL_RGB, GL_VARIABLE_A_NV,
		GL_TEXTURE0_ARB, GL_EXPAND_NORMAL_NV, GL_RGB );
	// Brgb = expand(texture1rgb) = L (oder H, falls specular)
	glCombinerInputNV(
		GL_COMBINER0_NV, GL_RGB, GL_VARIABLE_B_NV,
		GL_TEXTURE1_ARB, GL_EXPAND_NORMAL_NV, GL_RGB );
	
	// spare0rgb = Argb * Brgb = expand( texture0rgb ) * expand( texture1rgb ) = L * N'
	// im specular fall: spare0rgb = H dot N'
	glCombinerOutputNV(
		GL_COMBINER0_NV, GL_RGB,
		GL_SPARE0_NV, GL_DISCARD_NV, GL_DISCARD_NV,
		GL_NONE, GL_NONE, GL_TRUE, GL_FALSE, GL_FALSE );
	
	if ( shadowing == 1 )
	{
		// GENERAL Combiner #1, RGB
		// Argb = 0
		glCombinerInputNV(
			GL_COMBINER1_NV, GL_RGB, GL_VARIABLE_A_NV,
			GL_ZERO, GL_UNSIGNED_IDENTITY_NV, GL_RGB );
		// Brgb = 0
		glCombinerInputNV(
			GL_COMBINER1_NV, GL_RGB, GL_VARIABLE_B_NV,
			GL_ZERO, GL_UNSIGNED_IDENTITY_NV, GL_RGB );

		if ( specular ) 
			// Crgb = spare0rgb = H * N'
			glCombinerInputNV(
				GL_COMBINER1_NV, GL_RGB, GL_VARIABLE_C_NV,
				GL_SPARE0_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB ); else
			// Crgb = 1
			glCombinerInputNV(
				GL_COMBINER1_NV, GL_RGB, GL_VARIABLE_C_NV,
				GL_ZERO, GL_UNSIGNED_INVERT_NV, GL_RGB );

		// Drgb = spare0rgb = L * N' (oder H * N', falls specular)
		glCombinerInputNV(
			GL_COMBINER1_NV, GL_RGB, GL_VARIABLE_D_NV,
			GL_SPARE0_NV, GL_SIGNED_IDENTITY_NV, GL_RGB );
		
		// spare0rgb = ((spare0a >= 0.5) ? spare0rgb^2 : 0) = ((L * N > 0) ? (L * N')^2 : 0)
		glCombinerOutputNV(
			GL_COMBINER1_NV, GL_RGB,
			GL_DISCARD_NV, GL_DISCARD_NV, GL_SPARE0_NV,
			GL_NONE, GL_NONE, GL_FALSE, GL_FALSE, GL_TRUE );
	}
	
	// FINAL Combiner
	// A = EF
	glFinalCombinerInputNV(
		GL_VARIABLE_A_NV,
		GL_E_TIMES_F_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB );
	// B = EF
	glFinalCombinerInputNV(
		GL_VARIABLE_B_NV,
		GL_E_TIMES_F_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB );
	// C = 0
	glFinalCombinerInputNV(
		GL_VARIABLE_C_NV,
		GL_ZERO, GL_UNSIGNED_IDENTITY_NV, GL_RGB );

	if ( specular )
		// D = zero = keine extra specular beleuchtung
		glFinalCombinerInputNV(GL_VARIABLE_D_NV,
			GL_ZERO, GL_UNSIGNED_IDENTITY_NV, GL_RGB ); else
		// D = C0 = ambiente beleuchtung
		glFinalCombinerInputNV(
			GL_VARIABLE_D_NV,
			GL_CONSTANT_COLOR0_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB );

	if ( specular )
		// E = spare0rgb = diffuse beleuchtung = H * N'
		glFinalCombinerInputNV(
			GL_VARIABLE_E_NV,
			GL_SPARE0_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB ); else
		// E = 1
		glFinalCombinerInputNV(
			GL_VARIABLE_E_NV,
			GL_ZERO, GL_UNSIGNED_INVERT_NV, GL_RGB );

	// F = spare0rgb = diffuse beleuchtung = L * N' (oder H * N' bei specular)
	glFinalCombinerInputNV(
		GL_VARIABLE_F_NV,
		GL_SPARE0_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB );
	
	// diffuse RGB color  = A * E * F + D = diffuse modulated mit self-shadowing term + ambient
	// specular RGB color = A * E * F     = specular modulated mit self-shadowing term
	
	// G = spare0a = beitrag der diffusen beleuchtung = L * N'
	glFinalCombinerInputNV(
		GL_VARIABLE_G_NV,
		GL_SPARE0_NV, GL_UNSIGNED_IDENTITY_NV, GL_ALPHA );
	
	glEnable( GL_REGISTER_COMBINERS_NV );
}


void makeNormalizeVectorCubeMap( int size )
{
	float vector[3];
	
	unsigned char *pixels = new unsigned char[ size * size * 3 ];
	
	glTexParameteri( GL_TEXTURE_CUBE_MAP_EXT, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
	glTexParameteri( GL_TEXTURE_CUBE_MAP_EXT, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
	glTexParameteri( GL_TEXTURE_CUBE_MAP_EXT, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
	glTexParameteri( GL_TEXTURE_CUBE_MAP_EXT, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
	
	for ( int i = 0; i < 6; i++ ) 
	{
		for ( int y = 0; y < size; y++ )
			for ( int x = 0; x < size; x++ )
			{
				float s = 2.0f * ( (float)x + 0.5f ) / (float)size - 1.0f;
				float t = 2.0f * ( (float)y + 0.5f ) / (float)size - 1.0f;
				
				switch ( i )
				{
				case 0:
					vector[ 0 ] = 1.0f;
					vector[ 1 ] = -t;
					vector[ 2 ] = -s;
					break;
				case 1:
					vector[ 0 ] = -1.0f;
					vector[ 1 ] = -t;
					vector[ 2 ] = s;
					break;
				case 2:
					vector[ 0 ] = s;
					vector[ 1 ] = 1.0f;
					vector[ 2 ] = t;
					break;
				case 3:
					vector[ 0 ] = s;
					vector[ 1 ] = -1.0f;
					vector[ 2 ] = -t;
					break;
				case 4:
					vector[ 0 ] = s;
					vector[ 1 ] = -t;
					vector[ 2 ] = 1.0f;
					break;
				case 5:
					vector[ 0 ] = -s;
					vector[ 1 ] = -t;
					vector[ 2 ] = -1.0f;
					break;
				}
				normVector( vector );
				convVEC2RGB( &pixels[ 3 * ( y * size + x ) ], vector );
			}
			
			glTexImage2D( GL_TEXTURE_CUBE_MAP_POSITIVE_X_EXT + i, 0, GL_RGB8,
				          size, size, 0, GL_RGB, GL_UNSIGNED_BYTE, pixels );
	}
	
	delete pixels;
}


void drawObjectLightVector()
{
	VERTEXDOT3 *v1;
	VERTEXDOT3 *v2;
	
	for ( int i = 0, ofs = 0; i < torusRings - 1; i++, ofs += torusSides )
	{
		glBegin(GL_QUAD_STRIP);
		for ( int j = 0; j < torusSides; j ++ )
		{
			v1 = &torusVertex[ ofs + j ];
			v2 = &torusVertex[ ofs + torusSides + j ];
			
			glTexCoord2sv( &v1->s );
			glMultiTexCoord3fvARB( GL_TEXTURE1_ARB, &v1->tangentSpaceLightVector.x );
			glVertex3fv( &v1->position.x );
			
			glTexCoord2sv( &v2->s );
			glMultiTexCoord3fvARB( GL_TEXTURE1_ARB, &v2->tangentSpaceLightVector.x );
			glVertex3fv( &v2->position.x );
		}
		glEnd();
	}
}

void drawObjectHalfAngle()
{
	VERTEXDOT3 *v1;
	VERTEXDOT3 *v2;
	
	for ( int i = 0, ofs = 0; i < torusRings - 1; i++, ofs += torusSides )
	{
		glBegin(GL_QUAD_STRIP);
		for ( int j = 0; j < torusSides; j ++ )
		{
			v1 = &torusVertex[ ofs + j ];
			v2 = &torusVertex[ ofs + torusSides + j ];
			
			glTexCoord2sv( &v1->s );
			glMultiTexCoord3fvARB( GL_TEXTURE1_ARB, &v1->tangentSpaceHalfAngleVector.x );
			glVertex3fv( &v1->position.x );
			
			glTexCoord2sv( &v2->s );
			glMultiTexCoord3fvARB( GL_TEXTURE1_ARB, &v2->tangentSpaceHalfAngleVector.x );
			glVertex3fv( &v2->position.x );
		}
		glEnd();
	}
}


void drawObject( int decal, int specular )
{
	if ( decal )
	{
		// decal modus:
		// normal texturiert zeichnen => register combiners und cube map ausschalten
		glActiveTextureARB( GL_TEXTURE1_ARB );
		glDisable( GL_TEXTURE_CUBE_MAP_EXT );
		glActiveTextureARB( GL_TEXTURE0_ARB );
		textureMap.select();
		glMatrixMode( GL_MODELVIEW );
		glDisable( GL_REGISTER_COMBINERS_NV );
	} else {
		glActiveTextureARB( GL_TEXTURE1_ARB );
		glEnable( GL_TEXTURE_CUBE_MAP_EXT );
		glActiveTextureARB( GL_TEXTURE0_ARB );
		invBumpTex.select();
		glEnable( GL_REGISTER_COMBINERS_NV );
		glMatrixMode( GL_MODELVIEW );
	}
	
	if ( specular ) 
        drawObjectHalfAngle(); else
        drawObjectLightVector();
}

void updateTangentSpaceVectors( VERTEX *lightPosition, VERTEX *eyePosition )
{
	VERTEXDOT3  *vertex = torusVertex;
	ONBASIS		*axis = torusAxis;
	
	for ( int i = 0; i < torusRings * torusSides; i++ )
	{
		VERTEX	toLight, toEye;
		
		// den vektor vom vertex zur lichtquelle berechnen
		subVector( &toLight, lightPosition, &vertex[ i ].position );
		
		// diesen vektor in den normal space rotieren und normalisieren
		vertex[ i ].tangentSpaceLightVector.x = dotProduct( &toLight, &axis[ i ].tangent );
		vertex[ i ].tangentSpaceLightVector.y = dotProduct( &toLight, &axis[ i ].binormal );
		vertex[ i ].tangentSpaceLightVector.z = dotProduct( &toLight, &axis[ i ].normal );
		
		normVector( (float*)&vertex[ i ].tangentSpaceLightVector );
		
		// den vektor zum betrachter berechnen
		subVector( &toEye, eyePosition, &vertex[ i ].position );
		
		// in den tangent space rotieren und normalisieren
		vertex[ i ].tangentSpaceHalfAngleVector.x = dotProduct( &toEye, &axis[ i ].tangent );
		vertex[ i ].tangentSpaceHalfAngleVector.y = dotProduct( &toEye, &axis[ i ].binormal );
		vertex[ i ].tangentSpaceHalfAngleVector.z = dotProduct( &toEye, &axis[ i ].normal );
		normVector( (float*)&vertex[ i ].tangentSpaceHalfAngleVector );
		
		// jetzt noch der half angle vektor und nochmals normalisieren
		addVector( &vertex[ i ].tangentSpaceHalfAngleVector, &vertex[ i ].tangentSpaceLightVector );
		normVector( (float*)&vertex[ i ].tangentSpaceHalfAngleVector );
	}
}


void renderMeshDot3Bump()
{
	float invm[ 4 ][ 4 ];

	VERTEX objectSpaceLightPosition;
	VERTEX objectSpaceEyePosition;
	
	glDisable( GL_LIGHTING );
	
	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();
	glRotatef( -yrot, 1.0f, 0.0f, 0.0f );
	glRotatef( -xrot, 0.0f, 1.0f, 0.0f );
	glTranslatef( 0.0f, 0.0f, 3.0f );
	glGetFloatv(GL_MODELVIEW_MATRIX,(float*)invm);
	
	VERTEX eyePosition = { 0.0f, 0.0f, 5.0f };
	transformPosition( &objectSpaceLightPosition, (VERTEX*)&lightPosition, invm );
	transformPosition( &objectSpaceEyePosition,   (VERTEX*)&eyePosition, invm );
	
	updateTangentSpaceVectors( &objectSpaceLightPosition, &objectSpaceEyePosition );
	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatef( 0.0f, 0.0f, -3.0f );
	glRotatef( xrot, 0.0f, 1.0f, 0.0f );
	glRotatef( yrot, 1.0f, 0.0f, 0.0f );
	
	glMatrixMode(GL_MODELVIEW);
	
	int shadowing = 0;

	glMatrixMode( GL_MODELVIEW );
	glCullFace( GL_FRONT );

	// 1. Pass: Diffuse Beleuchtung !
	initCombiners( 0, 0 );
	drawObject( 0, 0 );
	
	glDepthFunc( GL_EQUAL );
	glEnable( GL_BLEND );
	glColorMask( 1, 1, 1, 0 );

	// 2. Pass: Farbe !
	glMatrixMode( GL_TEXTURE );
	glPushMatrix();
	glScalef( 0.25f, 0.25f, 0.25f );
	
	glBlendFunc( GL_DST_COLOR, GL_ZERO );
	drawObject( 1, 0 );

	glMatrixMode( GL_TEXTURE );
	glPopMatrix();

	// 3. Pass: Specular Term !
	// ziel blenden mit dem specular teil im alpha buffer

	if ( specularSupported )
	{
		initCombiners( 0, 1 );
		glBlendFunc( GL_DST_ALPHA, GL_ONE );
		drawObject( 0, 1 );
	}
	
	glColorMask( 1, 1, 1, 1 );
	glDepthFunc( GL_LESS );
	glDisable( GL_BLEND );
}
#endif

#ifdef EMBOSSBUMP

#define MAX_EMBOSS 0.008f
void calculateEmbossDisplacement(GLfloat *n, GLfloat *c, GLfloat *l, GLfloat *s, GLfloat *t) {

	float v[ 3 ];

	// v ist der vektor von zur lichtposition
	v[ 0 ] = l[ 0 ] - c[ 0 ];		
	v[ 1 ] = l[ 1 ] - c[ 1 ];		
	v[ 2 ] = l[ 2 ] - c[ 2 ];		

	normVector( v );

	// nun wird v projeziert auf die texture koordinaten achsen (skalarprodukt)
	// entspricht rotation in den tangent space (der ersten beiden komponenten)
	c[ 0 ] = dotProduct( (VERTEX*)s, (VERTEX*)v ) * MAX_EMBOSS;
	c[ 1 ] = dotProduct( (VERTEX*)t, (VERTEX*)v ) * MAX_EMBOSS;
}

void transformPosition( float *dst, float *src, float *m ) 
{
	float r[ 3 ];

	r[ 0 ] = m[ 0 ] * src[ 0 ] + m[ 1 ] * src[ 1 ] + m[ 2] * src[2] + m[ 3 ]  * src[ 3 ];
	r[ 1 ] = m[ 4 ] * src[ 0 ] + m[ 5 ] * src[ 1 ] + m[ 6] * src[2] + m[ 7 ]  * src[ 3 ];
	r[ 2 ] = m[ 8 ] * src[ 0 ] + m[ 9 ] * src[ 1 ] + m[10] * src[2] + m[ 11 ] * src[ 3 ];	

	dst[ 0 ] = r[ 0 ];
	dst[ 1 ] = r[ 1 ];
	dst[ 2 ] = r[ 2 ];
	dst[ 3 ] = 1.0f;
}

void renderMeshEmbossBump()
{
	GLfloat c[ 4 ] = { 0.0f, 0.0f, 0.0f, 1.0f };
	GLfloat n[ 4 ] = { 0.0f, 0.0f, 0.0f, 1.0f };
	GLfloat s[ 4 ] = { 0.0f, 0.0f, 0.0f, 1.0f };
	GLfloat t[ 4 ] = { 0.0f, 0.0f, 0.0f, 1.0f };
	GLfloat l[ 4 ];
	GLfloat invm[ 4 ][ 4 ];

	int i, j, ofs;

	glMatrixMode( GL_TEXTURE );
	glLoadIdentity();
	glScalef( 0.125f, 0.125f, 0.125f );

	glMatrixMode( GL_MODELVIEW );
	glCullFace( GL_FRONT );

	glLoadIdentity();								
	glRotatef( -yrot, 0.0f, 1.0f, 0.0f );
	glRotatef( -xrot, 1.0f, 0.0f, 0.0f );
	glTranslatef( 0.0f, 0.0f, 3.0f );
	glGetFloatv(GL_MODELVIEW_MATRIX, (float*)invm);

	glLoadIdentity();
	glTranslatef( 0.0f, 0.0f, -3.0f );

	glRotatef( xrot, 1.0f, 0.0f, 0.0f );
	glRotatef( yrot, 0.0f, 1.0f, 0.0f );	
	
	// Transform The Lightposition Into Object Coordinates:
	transformPosition( l, lightPosition, (float*)invm );

	// pass 1: bump texture, blend/lighting aus
	bumpTex.select();
	glDisable(GL_BLEND);
	glDisable(GL_LIGHTING);

	VERTEXDOT3 *v1;
	VERTEXDOT3 *v2;

	for ( i = 0, ofs = 0; i < torusRings - 1; i++, ofs += torusSides )
	{
		glBegin( GL_QUAD_STRIP );
		for ( j = 0; j < torusSides; j++ )
		{
			v1 = &torusVertex[ ofs + j ];
			v2 = &torusVertex[ ofs + torusSides + j ];

			glTexCoord2sv( &v1->s );
			glVertex3fv( &v1->position.x );

			glTexCoord2sv( &v2->s );
			glVertex3fv( &v2->position.x );
		}
		glEnd();
	}

	// pass 2: inverse bump texture, blending an, verschobene texture koordinaten
	invBumpTex.select();
	glBlendFunc(GL_ONE,GL_ONE);
	glDepthFunc(GL_LEQUAL);
	glEnable(GL_BLEND);	

	for ( i = 0, ofs = 0; i < torusRings - 1; i++, ofs += torusSides )
	{
		glBegin( GL_QUAD_STRIP );
		for ( j = 0; j < torusSides; j++ )
		{
			v1 = &torusVertex[ ofs + j ];
			v2 = &torusVertex[ ofs + torusSides + j ];

			*(VERTEX*)&n = torusAxis[ ofs + j ].normal;
			*(VERTEX*)&s = torusAxis[ ofs + torusSides + j ].binormal;
			*(VERTEX*)&t = torusAxis[ ofs + torusSides + j ].tangent;

			s[ 0 ] *= v2->s; s[ 1 ] *= v2->s; s[ 2 ] *= v2->s;
			t[ 0 ] *= v2->t; t[ 1 ] *= v2->t; t[ 2 ] *= v2->t;
			*(VERTEX*)&c = v1->position;

			calculateEmbossDisplacement( n, c, l, s, t );
			glTexCoord2f( c[ 0 ] + v1->s, c[ 1 ] + v1->t );
			glVertex3fv( &v1->position.x );

			*(VERTEX*)&n = torusAxis[ ofs + torusSides + j ].normal;
			*(VERTEX*)&s = torusAxis[ ofs + torusSides + j ].binormal;
			*(VERTEX*)&t = torusAxis[ ofs + torusSides + j ].tangent;
			s[ 0 ] *= v2->s; s[ 1 ] *= v2->s; s[ 2 ] *= v2->s;
			t[ 0 ] *= v2->t; t[ 1 ] *= v2->t; t[ 2 ] *= v2->t;
			*(VERTEX*)&c = v2->position;

			calculateEmbossDisplacement( n, c, l, s, t );
			glTexCoord2f( c[ 0 ] + v2->s, c[ 1 ] + v2->t );
			glVertex3fv( &v2->position.x );
		}
		glEnd();
	}

	// pass 3: farbe durch die texture mit blending und lighting
	glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	textureMap.select();
	glBlendFunc(GL_DST_COLOR,GL_SRC_COLOR);	
	glEnable(GL_LIGHTING);

	for ( i = 0, ofs = 0; i < torusRings - 1; i++, ofs += torusSides )
	{
		glBegin( GL_QUAD_STRIP );
		for ( j = 0; j < torusSides; j++ )
		{
			v1 = &torusVertex[ ofs + j ];
			v2 = &torusVertex[ ofs + torusSides + j ];

			glTexCoord2sv( &v1->s );
			glNormal3fv( (float*)&torusAxis[ ofs + j ].normal );
			glVertex3fv( &v1->position.x );

			glTexCoord2sv( &v2->s );
			glNormal3fv( (float*)&torusAxis[ ofs + torusSides + j ].normal );
			glVertex3fv( &v2->position.x );
		}
		glEnd();
	}

}
#endif


static float	lastTime = -1.0f;

void	draw3DEngine()
{
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	float time, elapsed;

	time = (float)GetTickCount();

	if ( lastTime == -1.0f )
		elapsed = 1.0f; else
	{
		elapsed = ( time - lastTime ) * 0.1f;
	}
	lastTime = time;

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective( 45.0f, 1.33f, 1.0f, 10.0f );

	xrot += xspeed * elapsed;
	yrot += yspeed * elapsed;

#ifdef EMBOSSBUMP
	renderMeshEmbossBump();
#endif
#ifdef DOT3BUMP
	renderMeshDot3Bump();
#endif

}

void	quit3DEngine()
{
	delete torusVertex;
	delete torusAxis;
}