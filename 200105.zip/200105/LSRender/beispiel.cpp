////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Landschaftsrendering Beispiel f�r Vertex Submission   //
//  (w)(c)2000 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include	<windows.h>			
#include	<stdio.h>
#include	<assert.h>
#include	<gl\gl.h>			
#include	<gl\glu.h>			

#include	"texture.h"
#include	"spline.h"

void	checkOpenGLError()
{
	GLenum glError = GL_NO_ERROR;
	assert( (glError = glGetError() ) == GL_NO_ERROR );
}

typedef void (APIENTRY *LOCKARRAYS_PROC)(int first, int count);
typedef void (APIENTRY *UNLOCKARRAYS_PROC)(void);

LOCKARRAYS_PROC		pfLockArrays;
UNLOCKARRAYS_PROC	pfUnlockArrays;

#define SIZE		256
#define RESOLUTION	2

// Struktur zu GL_T2F_C3F_V3F
typedef struct 
{
	float texCoord[ 2 ];
	float color[ 3 ];
	float vertex[ 3 ];
}INTERLEAVEDVERTEX;


INTERLEAVEDVERTEX	*pVertex;
int					nVertices;
float				*pTexCoordStream;
float				*pColorStream;
float				*pVertexStream;

PCUTexture	shadowTexture;

void renderImmediateMode()
{
    glBegin( GL_TRIANGLE_STRIP );

	for ( int i = 0; i < SIZE/RESOLUTION; i++ )
	{
		INTERLEAVEDVERTEX *p = &pVertex[ i * ( SIZE/RESOLUTION * 2 - 2 ) ];
		for ( int j = 0; j < SIZE/RESOLUTION * 2; j++ )
		{
			glTexCoord2fv( &p->texCoord[0] );
			glColor3fv( &p->color[0] );
			glVertex3fv( &p->vertex[0] );
			p ++;
		}
	}

	glEnd();
	checkOpenGLError();
	
	glFlush();
	checkOpenGLError();
}

void renderInterleaved()
{
	glInterleavedArrays( GL_T2F_C3F_V3F, 0, pVertex );
	checkOpenGLError();
	
	for ( int i = 0; i < SIZE/RESOLUTION - 1; i++ )
		glDrawArrays( GL_TRIANGLE_STRIP, i * ( SIZE/RESOLUTION * 2 - 2 ), SIZE/RESOLUTION * 2 - 2 );
	checkOpenGLError();
	
	glFlush();
	checkOpenGLError();
}

void renderStream()
{
	// Arrays anschalten
	glEnableClientState( GL_COLOR_ARRAY );
	checkOpenGLError();
	
	glEnableClientState( GL_VERTEX_ARRAY );
	checkOpenGLError();
	
	glEnableClientState( GL_TEXTURE_COORD_ARRAY );
	checkOpenGLError();
	
	// die Pointer auf die Arrays setzen
	glVertexPointer( 3, GL_FLOAT, 0, pVertexStream );
	checkOpenGLError();
	
	glTexCoordPointer( 2, GL_FLOAT, 0, pTexCoordStream );
	checkOpenGLError();
	
	glColorPointer( 3, GL_FLOAT, 0, pColorStream );
	checkOpenGLError();
	
	// und Zeichnen
	
	for ( int i = 0; i < SIZE/RESOLUTION - 1; i++ )
		glDrawArrays( GL_TRIANGLE_STRIP, i * ( SIZE/RESOLUTION * 2 - 2 ), SIZE/RESOLUTION * 2 - 2 );
	checkOpenGLError();
	
	glFlush();
	checkOpenGLError();
	
	glDisableClientState( GL_COLOR_ARRAY );
	checkOpenGLError();
	
	glDisableClientState( GL_VERTEX_ARRAY );
	checkOpenGLError();
	
	glDisableClientState( GL_TEXTURE_COORD_ARRAY );
	checkOpenGLError();
}

void	streamLockBuffer()
{
	// Arrays anschalten
	glEnableClientState( GL_COLOR_ARRAY );
	checkOpenGLError();
	
	glEnableClientState( GL_VERTEX_ARRAY );
	checkOpenGLError();
	
	glEnableClientState( GL_TEXTURE_COORD_ARRAY );
	checkOpenGLError();
	
	// die Pointer auf die Arrays setzen
	glVertexPointer( 3, GL_FLOAT, 0, pVertexStream );
	checkOpenGLError();
	
	glTexCoordPointer( 2, GL_FLOAT, 0, pTexCoordStream );
	checkOpenGLError();
	
	glColorPointer( 3, GL_FLOAT, 0, pColorStream );
	checkOpenGLError();
	
	if ( pfLockArrays )
	{
		(*pfLockArrays)( 0, nVertices );
		checkOpenGLError();
	}
}

void streamUnlockBuffer()
{
	if (pfUnlockArrays)
	{
		(*pfUnlockArrays)();
		checkOpenGLError();
	}
	glDisableClientState( GL_COLOR_ARRAY );
	checkOpenGLError();
	
	glDisableClientState( GL_VERTEX_ARRAY );
	checkOpenGLError();
	
	glDisableClientState( GL_TEXTURE_COORD_ARRAY );
	checkOpenGLError();
}

void renderStreamLocked()
{
	for ( int i = 0; i < SIZE/RESOLUTION - 1; i++ )
		glDrawArrays( GL_TRIANGLE_STRIP, i * ( SIZE/RESOLUTION * 2 - 2 ), SIZE/RESOLUTION * 2 - 2 );
	checkOpenGLError();
	glFlush();
	checkOpenGLError();
}

CardinalSpline *colorSpline;

void height2color( float h, float *c )
{
	colorSpline->get( h*1.0f, c );
	c[0] *= 2.0f;
	c[1] *= 2.0f;
	c[2] *= 2.0f;
}

void createLandscapeVertexData()
{
	unsigned char terrain[ SIZE * SIZE ];
	
	FILE *f = fopen( "landscape.raw", "rb" );
	fread( terrain, SIZE*SIZE, 1, f );
	fclose( f );
	
	pVertex = new INTERLEAVEDVERTEX[ SIZE * SIZE * 2 * 3 ];
	
	INTERLEAVEDVERTEX *p = pVertex;
	
	#define addVertex( x, y )						\
	{												\
	float height = (float)terrain[(x)+(y)*SIZE ];	\
	p->vertex[ 0 ] = (float)( x - SIZE/2 );			\
	p->vertex[ 1 ] = (float)( y - SIZE/2 );			\
	p->vertex[ 2 ] = height * 0.2f;					\
	height2color( height, p->color );				\
	p->texCoord[ 0 ] = (float)(x) / (float)SIZE;	\
	p->texCoord[ 1 ] = 1-(float)(y) / (float)SIZE;	\
	p ++;											\
	nVertices ++;									\
	}
	
	// hier bauen wir die Vertexdaten aus unserer Heightmap !
	for ( int j = 0; j < SIZE-RESOLUTION; j+=RESOLUTION )
		for ( int i = 0; i < SIZE-RESOLUTION; i+=RESOLUTION )
		{
			// GL_TRIANGLE_STRIPS
			addVertex( i, j+RESOLUTION );
			addVertex( i, j );
		}
		
	// die Streaming Daten vorbereiten 
	
	pTexCoordStream	= new float[ nVertices * 2 ];
	pColorStream	= new float[ nVertices * 3 ];
	pVertexStream	= new float[ nVertices * 3 ];
	
	p = pVertex;
	for ( int i = 0; i < nVertices; i++, p++ )
	{
		memcpy( &pTexCoordStream[ i * 2 ], &p->texCoord[ 0 ], 2 * sizeof( float ) );
		memcpy( &pColorStream[ i * 3 ], &p->color[ 0 ], 3 * sizeof( float ) );
		memcpy( &pVertexStream[ i * 3 ], &p->vertex[ 0 ], 3 * sizeof( float ) );
	}
}


void	init3DEngine()
{
	// hier bereiten wir die Farbberechnung vor
	colorSpline = new CardinalSpline( 3, 0.5f, 5 );

	// Farben gr�n, braun, weiss
	const float	color[ 5 ][ 3 ] =
	{
		{ 0.1f, 0.2f, 0.05f },
		{ 0.3f, 0.35f, 0.2f },
		{ 0.4f, 0.35f, 0.35f },
		{ 0.6f, 0.6f, 0.6f },
		{ 0.8f, 0.8f, 0.8f }
	};

/*	// Berge in grau
	const float	color[ 5 ][ 3 ] =
	{
		{ 0.1f, 0.1f, 0.1f },
		{ 0.3f, 0.3f, 0.3f },
		{ 0.35f, 0.35f, 0.35f },
		{ 0.6f, 0.6f, 0.6f },
		{ 0.8f, 0.8f, 0.8f }
	};
*/
	colorSpline->set( 0,   (float*)color[ 0 ] );
	colorSpline->set( 150, (float*)color[ 1 ] );
	colorSpline->set( 176, (float*)color[ 2 ] );
	colorSpline->set( 256, (float*)color[ 3 ] );
	colorSpline->set( 258, (float*)color[ 4 ] );
	colorSpline->prepare();

	// die landschaftsdaten
	createLandscapeVertexData();

	pfLockArrays   = (LOCKARRAYS_PROC)   wglGetProcAddress( "glLockArraysEXT" );
	
	pfUnlockArrays = (UNLOCKARRAYS_PROC) wglGetProcAddress( "glUnlockArraysEXT" );
	
	if ( !pfLockArrays || !pfUnlockArrays )
	{
		MessageBox( NULL, "Compiled Vertex Arrays werden vom Grafikkartentreiber nicht unterst�tzt !", "Achtung !", MB_OK );
	}

	streamLockBuffer();

	// Textur laden
//	shadowTexture.loadJPG( "shadow.jpg" );
	shadowTexture.loadBMP( "shadow.bmp" );

}

void	draw3DEngine()
{
	float time = (float)GetTickCount();

	glScalef( 0.3f, 0.3f, 0.3f );
	glRotatef( -45.0f, 1.0f, 0.0f, 0.0f );
	glRotatef( time * 0.05f, 0.0f, 0.0f, 1.0f );

	glEnable( GL_CULL_FACE );
	glCullFace( GL_BACK );

	glDisable( GL_LIGHTING );
    glShadeModel( GL_SMOOTH );

	glEnable( GL_TEXTURE_2D );
	shadowTexture.select();
	glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );

//	renderImmediateMode();
//	renderInterleaved();
//	renderStream();
	renderStreamLocked();
}

void	quit3DEngine()
{
	streamUnlockBuffer();
	delete	pVertex;
	delete	pTexCoordStream;
	delete	pColorStream;
	delete	pVertexStream;
}