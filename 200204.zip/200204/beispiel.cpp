////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//                                                        //
//  Dynamische Cube Reflection Map Berechnung             //
//                                                        //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
// extension beschreibung: http://www.viaduk.net/intear/siv/OpenGL_Extension.htm
//
#include	<windows.h>			
#include	<math.h>
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	<glut.h>			
#include	"glext.h"
#include	"texture.h"
#include	"skybox.h"

// Kantenlaenge einer Cubemap-Texture Seite in Pixel
#define CUBEMAPSIZE	64

// Mipmapping und MipMap Generation f�r die Cubemaps
//#define MIPMAP_CUBE

// Parameter der Kugeln
#define SPHERE_SIZE 6.0f
#define SPHERE_SUBDIVX 24
#define SPHERE_SUBDIVY 24

#define SHOW_CUBEMAP

typedef struct
{
	GLfloat x, y, z;
}VERTEX3D;

VERTEX3D spherePos[ 2 ];

GLuint cubeMapConstants[ 6 ] = 
{
	GL_TEXTURE_CUBE_MAP_POSITIVE_X_ARB,
	GL_TEXTURE_CUBE_MAP_NEGATIVE_X_ARB,
	GL_TEXTURE_CUBE_MAP_POSITIVE_Y_ARB,
	GL_TEXTURE_CUBE_MAP_NEGATIVE_Y_ARB,
	GL_TEXTURE_CUBE_MAP_POSITIVE_Z_ARB,
	GL_TEXTURE_CUBE_MAP_NEGATIVE_Z_ARB
};

static bool automipmap = false;
GLuint cubeMap, cubeMap2;

#ifdef SHOW_CUBEMAP
GLuint cubeMapSides[ 6 ];
#endif

GLuint createCubeMap()
{
	GLuint texture;

	glEnable( GL_TEXTURE_CUBE_MAP_ARB );

	glGenTextures( 1, &texture );

	glBindTexture( GL_TEXTURE_CUBE_MAP_ARB, texture );

#ifdef MIPMAP_CUBE
	if ( automipmap )
	{
		glTexParameteri( GL_TEXTURE_CUBE_MAP_ARB, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR );
		glTexParameteri( GL_TEXTURE_CUBE_MAP_ARB, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
		glTexParameteri( GL_TEXTURE_CUBE_MAP_ARB, GL_GENERATE_MIPMAP_SGIS, GL_TRUE );
	} else
	{
		glTexParameteri( GL_TEXTURE_CUBE_MAP_ARB, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
		glTexParameteri( GL_TEXTURE_CUBE_MAP_ARB, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
	}
#else
	glTexParameteri( GL_TEXTURE_CUBE_MAP_ARB, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
	glTexParameteri( GL_TEXTURE_CUBE_MAP_ARB, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
#endif
	
	for ( int i = 0; i < 6; i++ )
		glTexImage2D(
			cubeMapConstants[ i ], 0, GL_RGB8, 
			CUBEMAPSIZE, CUBEMAPSIZE,
			0, GL_RGB, GL_UNSIGNED_BYTE, NULL );


	return texture;
}

PCUTexture marble;

void	init3DEngine()
{
	char *extensions;	
	extensions = strdup( (char*)glGetString( GL_EXTENSIONS ) );
	for ( unsigned int i = 0; i < strlen( extensions ); i ++ )
		if ( extensions[ i ] == ' ' ) extensions[ i ] = '\n';

	automipmap = false;
	if ( strstr( extensions, "GL_ARB_texture_cube_map" ) ||
		 strstr( extensions, "GL_NV_texgen_reflection" ) )
	{
		// ben�tigte extensions unterst�tzt

		// optionale extension
		if ( strstr( extensions, "GL_SGIS_generate_mipmap" ) )
			automipmap = true;
	} else
	{
		MessageBox( NULL, "Cube Mapping und/oder Reflection Mapping nicht unterst�tzt !", "Schade !", MB_OK );
		exit( 1 );
	}

	cubeMap = createCubeMap();
	cubeMap2 = createCubeMap();

	// Cube Mapping anschalten
	glTexGeni( GL_S, GL_TEXTURE_GEN_MODE, GL_REFLECTION_MAP_ARB );
	glTexGeni( GL_T, GL_TEXTURE_GEN_MODE, GL_REFLECTION_MAP_ARB );
	glTexGeni( GL_R, GL_TEXTURE_GEN_MODE, GL_REFLECTION_MAP_ARB );

	// skybox initialisieren
	skyboxInit();

	glEnable( GL_CULL_FACE );
	glCullFace( GL_BACK );
	glDisable( GL_BLEND );
	glDepthFunc( GL_LEQUAL );
	glEnable( GL_TEXTURE_2D );

    glEnable( GL_DEPTH_TEST );
    glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );

	marble.loadBMP( "./data/marble.bmp" );

#ifdef SHOW_CUBEMAP
	glGenTextures( 6, cubeMapSides );

	for ( i = 0; i < 6; i++ )
	{
		glBindTexture( GL_TEXTURE_2D, cubeMapSides[ i ] );
		glTexParameterf( GL_TEXTURE_2D,GL_TEXTURE_WRAP_S, GL_REPEAT );
		glTexParameterf( GL_TEXTURE_2D,GL_TEXTURE_WRAP_T, GL_REPEAT );
		glTexParameterf( GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER, GL_LINEAR );
		glTexParameterf( GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER, GL_LINEAR );

		glTexImage2D(
			GL_TEXTURE_2D, 0, GL_RGB8, 
			CUBEMAPSIZE, CUBEMAPSIZE,
			0, GL_RGB, GL_UNSIGNED_BYTE, NULL );
	}
#endif

}

static float lastTime = -1.0f;
static float startTime = -1.0f;
static int frame = 0;

static float xangle;
static float yangle;
static float zangle;

void	renderCubeMap( int cubemap, int sphere );
void	renderSkyBox();
void	renderScene();
void	renderSphere( int sphere );

void	draw3DEngine()
{
	float time;
	
	time = (float)GetTickCount() * 0.1f;

	frame ++;

	if ( frame & 1 )
		renderCubeMap( cubeMap, 0 ); else
		renderCubeMap( cubeMap2, 1 );

/*
	if ( (frame % 4) == 0 )
		renderCubeMap( cubeMap, 0 );
	if ( (frame % 4) == 2 )
		renderCubeMap( cubeMap2, 1 );
*/
	glClear(GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

	extern int windowX, windowY;
    gluPerspective( 70, (float)windowX / (float)windowY, 1, 5000 );

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	xangle = -90;
	zangle = GetTickCount() * 0.01f;

	spherePos[ 0 ].x = (float)cos( GetTickCount() * 0.001f ) * 12.0f;
	spherePos[ 0 ].y = (float)sin( GetTickCount() * 0.001f ) * 12.0f;
	spherePos[ 0 ].z = 0.0f;

	spherePos[ 1 ].x = -(float)cos( GetTickCount() * 0.001f ) * 12.0f;
	spherePos[ 1 ].y = -(float)sin( GetTickCount() * 0.001f ) * 12.0f;
	spherePos[ 1 ].z = 0.0f;


	glRotatef( xangle, 1.0f, 0.0f, 0.0f );

	glPushMatrix();

	glRotatef( zangle, 0.0f, 0.0f, 1.0f );
	renderSkyBox();

	glPopMatrix();

	glTranslatef( 0, 30, 0 );
	glRotatef( zangle, 0.0f, 0.0f, 1.0f );

	renderSphere( 0 );
	renderSphere( 1 );

	renderScene();

#ifdef SHOW_CUBEMAP
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();
	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();

	glTranslatef( -1, -1, -1 );
	extern int windowX, windowY;
	glScalef( 1.0f / (float)windowX, 1.0f / (float)windowY, 1.0f );
	glScalef( 160.0f, 160.0f, 160.0f );

	glColor3ub( 255, 255, 255 );
	glEnable( GL_TEXTURE_2D );
	glDisable( GL_TEXTURE_CUBE_MAP_ARB );
	for ( int i = 0; i < 6; i++ )
	{
		glBindTexture( GL_TEXTURE_2D, cubeMapSides[ i ] );

		glBegin( GL_QUADS );
		for ( int k = 0; k < 4; k++ )
		{
			float tx[]={0,1,1,0};
			float ty[]={0,0,1,1};
			float px[]={4,6,5,5,3,5};
			float py[]={1,1,0,2,1,1};

			float x = px[i]+tx[k];
			float y = py[i]+ty[k];

			if ( i == 2 || i == 3 )
				glTexCoord2f( 1-tx[k], 1-ty[k] ); else
				glTexCoord2f( tx[k], ty[k] );
			glVertex2f( x-2.6, 0.4+y );
		}
		glEnd();
	}
#endif
}

void	quit3DEngine()
{
}

void	renderSphere( int sphere )
{
	glEnable( GL_TEXTURE_CUBE_MAP_ARB );
	
	if ( sphere == 0 )
		glBindTexture( GL_TEXTURE_CUBE_MAP_ARB, cubeMap ); else
		glBindTexture( GL_TEXTURE_CUBE_MAP_ARB, cubeMap2 );

	glEnable( GL_TEXTURE_GEN_S );
	glEnable( GL_TEXTURE_GEN_T );
	glEnable( GL_TEXTURE_GEN_R );

	glPushMatrix();

	glTranslatef( spherePos[ sphere ].x, spherePos[ sphere ].y, spherePos[ sphere ].z );

	glMatrixMode( GL_TEXTURE );

	glPushMatrix();

	glRotatef( -zangle, 0.0f, 0.0f, 1.0f );
	glRotatef( -xangle, 1.0f, 0.0f, 0.0f );
		
	if ( sphere == 0 )
		glColor4ub( 255, 255, 150, 128 ); else
		glColor4ub( 150, 255, 255, 128 );

	glutSolidSphere( SPHERE_SIZE, SPHERE_SUBDIVX, SPHERE_SUBDIVY );

	glPopMatrix();

	glMatrixMode( GL_MODELVIEW );

	glPopMatrix();

	glDisable( GL_TEXTURE_GEN_S );
	glDisable( GL_TEXTURE_GEN_T );
	glDisable( GL_TEXTURE_GEN_R );
}

void	renderSphereMirror( int sphere )
{
	glEnable( GL_TEXTURE_CUBE_MAP_ARB );
	
	if ( sphere == 0 )
		glBindTexture( GL_TEXTURE_CUBE_MAP_ARB, cubeMap ); else
		glBindTexture( GL_TEXTURE_CUBE_MAP_ARB, cubeMap2 );

	glEnable( GL_TEXTURE_GEN_S );
	glEnable( GL_TEXTURE_GEN_T );
	glEnable( GL_TEXTURE_GEN_R );

	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();

	glTranslatef( spherePos[ sphere ].x, spherePos[ sphere ].y, spherePos[ sphere ].z );

	if ( sphere == 0 )
		glColor4ub( 255, 255, 150, 128 ); else
		glColor4ub( 150, 255, 255, 128 );

	glutSolidSphere( SPHERE_SIZE, SPHERE_SUBDIVX, SPHERE_SUBDIVY );

	glMatrixMode( GL_MODELVIEW );

	glPopMatrix();

	glDisable( GL_TEXTURE_GEN_S );
	glDisable( GL_TEXTURE_GEN_T );
	glDisable( GL_TEXTURE_GEN_R );
}



void renderSkyBox()
{	
	glDepthMask( 0 );

	glDisable( GL_TEXTURE_CUBE_MAP_ARB );
	
	drawSkybox();

	glDepthMask( 1 );
}

void	renderScene()
{
	glDisable( GL_TEXTURE_CUBE_MAP_ARB );

	glColor3ub( 255, 255, 255 );

	marble.select();

	glBegin( GL_QUADS );
		glTexCoord2f( 0, 0 );
		glVertex3f( -40, -40, -10 );
		glTexCoord2f( 1, 0 );
		glVertex3f( 40, -40, -10 );
		glTexCoord2f( 1, 1 );
		glVertex3f( 40, 40, -10 );
		glTexCoord2f( 0, 1 );
		glVertex3f( -40, 40, -10 );
	glEnd();

	glDisable( GL_TEXTURE_2D );

	for ( int j = 0; j < 2; j++ )
		for ( int i = 0; i < 6; i++ )
		{
			float time = GetTickCount() * 0.01f;

			int r, g, b;
			r = sin( time + i / 3.0f * 3.1415 ) * 127.0f + 128.0f;
			g = sin( time + (i+2) / 3.0f * 3.1415 ) * 127.0f + 128.0f;
			b = sin( time + (i+4) / 3.0f * 3.1415 ) * 127.0f + 128.0f;

			glColor3ub( r, g, b );

			glPushMatrix();

				glTranslatef( spherePos[ j ].x, spherePos[ j ].y, spherePos[ j ].z );

				glRotatef( GetTickCount() * 0.1f, j, 1-j, 0 );
				glRotatef( GetTickCount() * 0.1123f, j, j, 1-j );

				glTranslatef( 
					sin( i / 3.0f * 3.1415 ) * 9.0f,
					cos( i / 3.0f * 3.1415 ) * 9.0f, 0.0f );

				glutSolidCube( 2.5f );

			glPopMatrix();
		}

	glEnable( GL_TEXTURE_2D );

}

float cubeMapRotation[6][4] = 
{
	{	-90.0f,		0.0f,	1.0f,	0.0f	},
	{	 90.0f,		0.0f,	1.0f,	0.0f	},
	{	-90.0f,		1.0f,	0.0f,	0.0f	},
	{	 90.0f,		1.0f,	0.0f,	0.0f	},
	{	180.0f,		1.0f,	0.0f,	0.0f	},
	{	180.0f,		0.0f,	0.0f,	1.0f	},
};

void	renderCubeMap( int cubemap, int sphere )
{
	glViewport( 0, 0, CUBEMAPSIZE, CUBEMAPSIZE );

    glMatrixMode( GL_PROJECTION );
    glLoadIdentity();

    gluPerspective( 90, 1.0f, 1, 500 );

	glMatrixMode( GL_MODELVIEW );

	for( int i = 0; i < 6; i++ )
	{
		glClear( GL_DEPTH_BUFFER_BIT );

		glLoadIdentity();
		
		glRotatef(
			cubeMapRotation[ i ][ 0 ], 
			cubeMapRotation[ i ][ 1 ], 
			cubeMapRotation[ i ][ 2 ],
			cubeMapRotation[ i ][ 3 ] );

		if( i < 2 )
			glRotatef( 180.0f, 0.0f, 0.0f, 1.0f );

		renderSkyBox();

		glTranslatef( -spherePos[ sphere ].x, -spherePos[ sphere ].y, -spherePos[ sphere ].z );

		// bei der spiegelnden gespiegelten Kugel m�ssen
		// wir nat�rlich die gerade aktuelle Transformation
		// umkehren. Deshalb gibts hier Spezialbehandlung:
		glMatrixMode( GL_TEXTURE );
		glPushMatrix();

		if( i < 2 )
			glRotatef( -180.0f, 0.0f, 0.0f, 1.0f );
		
		glRotatef(
			-cubeMapRotation[ i ][ 0 ], 
			cubeMapRotation[ i ][ 1 ], 
			cubeMapRotation[ i ][ 2 ],
			cubeMapRotation[ i ][ 3 ] );
				
		renderSphereMirror( 1 - sphere );
		
		// und wieder sauber hinterlassen !
		glMatrixMode( GL_TEXTURE );
		glPopMatrix();
		glMatrixMode( GL_MODELVIEW );

		renderScene();

		glEnable( GL_TEXTURE_CUBE_MAP_ARB );

		glFlush();

		glBindTexture( GL_TEXTURE_CUBE_MAP_ARB, cubemap );

		glCopyTexSubImage2D(
			cubeMapConstants[ i ], 0, 0, 0, 0, 0, CUBEMAPSIZE, CUBEMAPSIZE );

		glFlush();
		glDisable( GL_TEXTURE_CUBE_MAP_ARB );

#ifdef SHOW_CUBEMAP
		if ( sphere == 0 )
		{
			glBindTexture( GL_TEXTURE_2D, cubeMapSides[ i ] );
			glCopyTexSubImage2D(
				GL_TEXTURE_2D, 0, 0, 0, 0, 0, CUBEMAPSIZE, CUBEMAPSIZE );
			glFlush();
		}
#endif



	}

	extern int windowX, windowY;
	extern void ReSizeGLScene( GLsizei width, GLsizei height );
	ReSizeGLScene( windowX, windowY );
}








