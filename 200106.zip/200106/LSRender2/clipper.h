////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Landschaftsrendering: Clipper Code	  		          //
//  (w)(c)2000 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#ifndef CLIPPER__H
#define CLIPPER__H

void	prepareClipper( float *pVertex, int size, float hScale, unsigned char *heightmap );
void	drawClipped();

#endif