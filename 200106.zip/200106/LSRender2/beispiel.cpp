////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Landschaftsrendering Beispiel mit                     //
//  - Multitexturing                                      //
//  - Tastatursteuerung                                   //
//  - und optimiertem Clipping                            //
//                                                        //
//  (w)(c)2000 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include	<windows.h>			
#include	<stdio.h>
#include	<assert.h>
#include	<math.h>
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	"glext.h"

#include	"texture.h"
#include	"spline.h"

#include	"skybox.h"
#include	"clipper.h"

// hier kann man den Rendermodus w�hlen !
//#define BLENDTEXTURE

#ifndef BLENDTEXTURE
#define COLOR_DETAILMAP
#endif

void	checkOpenGLError()
{
	GLenum glError = GL_NO_ERROR;
	assert( (glError = glGetError() ) == GL_NO_ERROR );
}

typedef void (APIENTRY *LOCKARRAYS_PROC)(int first, int count);
typedef void (APIENTRY *UNLOCKARRAYS_PROC)(void);

LOCKARRAYS_PROC		pfLockArrays;
UNLOCKARRAYS_PROC	pfUnlockArrays;

#define MAX_EXTENSION_SPACE		10240
#define MAX_EXTENSION_LENGTH	256

static bool	multitextureSupported = false;
static bool	useMultitexture = true;
static int	maxTexelUnits = 1;

// hier die definitionen f�r den import der multitexturing extensions
PFNGLMULTITEXCOORD1FARBPROC		glMultiTexCoord1fARB	 = NULL;
PFNGLMULTITEXCOORD2FARBPROC		glMultiTexCoord2fARB	 = NULL;
PFNGLMULTITEXCOORD3FARBPROC		glMultiTexCoord3fARB	 = NULL;
PFNGLMULTITEXCOORD4FARBPROC		glMultiTexCoord4fARB	 = NULL;
PFNGLACTIVETEXTUREARBPROC		glActiveTextureARB		 = NULL;
PFNGLCLIENTACTIVETEXTUREARBPROC	glClientActiveTextureARB = NULL;	

#define SIZE		256
#define RESOLUTION	2

// Struktur zu "GL_T4F_C3F_V3F"
typedef struct 
{
	float texCoord[ 2 ];
	float texCoord2[ 2 ];
	float color[ 3 ];
	float color2[ 3 ];
	float vertex[ 3 ];
}INTERLEAVEDVERTEX;


INTERLEAVEDVERTEX	*pVertex;
int					nVertices;
float				*pTexCoordStream;
float				*pTexCoordStream2;
float				*pColorStream;
float				*pColorStream2;
float				*pVertexStream;

#ifdef BLENDTEXTURE
PCUTexture  blendMap;
PCUTexture  basisMap1;
PCUTexture  basisMap2;
#else
PCUTexture	fadeMap;
PCUTexture	detailMap;
#endif

CardinalSpline *colorSpline;

void height2color( float h, float *c )
{
	colorSpline->get( h*1.0f, c );
	c[0] *= 2.0f;
	c[1] *= 2.0f;
	c[2] *= 2.0f;
}

void createLandscapeVertexData()
{
	unsigned char terrain[ SIZE * SIZE ];
	
	FILE *f = fopen( "./data/landscape.raw", "rb" );
	fread( terrain, SIZE*SIZE, 1, f );
	fclose( f );
	
	pVertex = new INTERLEAVEDVERTEX[ SIZE * SIZE * 2 * 3 ];
	
	INTERLEAVEDVERTEX *p = pVertex;
	
	#define addVertex( x, y )						\
	{												\
	float height = (float)terrain[(x)+(y)*SIZE ];	\
	p->vertex[ 0 ] = (float)( x - SIZE/2 );			\
	p->vertex[ 1 ] = (float)( y - SIZE/2 );			\
	p->vertex[ 2 ] = height * 0.2f;					\
	p->texCoord[ 0 ] = (float)(x) / (float)SIZE;	\
	p->texCoord[ 1 ] = 1-(float)(y) / (float)SIZE;	\
	p->texCoord2[ 0 ] = (float)(x) / (float)32;		\
	p->texCoord2[ 1 ] = 1-(float)(y) / (float)32;	\
	height2color( height, p->color );				\
	p->color2[ 0 ] = 1.0f;							\
	p->color2[ 1 ] = 1.0f;							\
	p->color2[ 2 ] = 1.0f;							\
	p ++;											\
	nVertices ++;									\
	}

	// hier bauen wir die Vertexdaten aus unserer Heightmap !
	for ( int j = 0; j <= SIZE-RESOLUTION; j+=RESOLUTION )
		for ( int i = 0; i <= SIZE-RESOLUTION; i+=RESOLUTION )
		{
			// GL_TRIANGLE_STRIPS
			if ( j == (SIZE-RESOLUTION) )
				{ addVertex( i, j ); } else
				addVertex( i, j+RESOLUTION );
			addVertex( i, j );
		}
		
	// die Streaming Daten vorbereiten 
	pTexCoordStream	 = new float[ nVertices * 2 ];
	pColorStream	 = new float[ nVertices * 3 ];
	pTexCoordStream2 = new float[ nVertices * 2 ];
	pColorStream2	 = new float[ nVertices * 3 ];
	pVertexStream	 = new float[ nVertices * 3 ];
	
	p = pVertex;
	for ( int i = 0; i < nVertices; i++, p++ )
	{
		memcpy( &pTexCoordStream[ i * 2 ], &p->texCoord[ 0 ], 2 * sizeof( float ) );
		memcpy( &pColorStream[ i * 3 ], &p->color[ 0 ], 3 * sizeof( float ) );
		memcpy( &pTexCoordStream2[ i * 2 ], &p->texCoord2[ 0 ], 2 * sizeof( float ) );
		memcpy( &pColorStream2[ i * 3 ], &p->color2[ 0 ], 3 * sizeof( float ) );
		memcpy( &pVertexStream[ i * 3 ], &p->vertex[ 0 ], 3 * sizeof( float ) );
	}

	prepareClipper( pVertexStream, ceil( SIZE / RESOLUTION ), 0.2f, terrain );
}

void renderStream( float *pTexCoordStream, float *pColorStream )
{
	// Arrays anschalten
	glEnableClientState( GL_COLOR_ARRAY );
	checkOpenGLError();
	
	glEnableClientState( GL_VERTEX_ARRAY );
	checkOpenGLError();
	
	glEnableClientState( GL_TEXTURE_COORD_ARRAY );
	checkOpenGLError();
	
	// die Pointer auf die Arrays setzen
	glVertexPointer( 3, GL_FLOAT, 0, pVertexStream );
	checkOpenGLError();
	
	glTexCoordPointer( 2, GL_FLOAT, 0, pTexCoordStream );
	checkOpenGLError();
	
	glColorPointer( 3, GL_FLOAT, 0, pColorStream );
	checkOpenGLError();
	
	// und Zeichnen
	drawClipped();
	checkOpenGLError();
	
	glFlush();
	checkOpenGLError();
	
	glDisableClientState( GL_COLOR_ARRAY );
	checkOpenGLError();
	
	glDisableClientState( GL_VERTEX_ARRAY );
	checkOpenGLError();
	
	glDisableClientState( GL_TEXTURE_COORD_ARRAY );
	checkOpenGLError();
}

void renderStreamMultiTexture()
{
	// Arrays anschalten
	glEnableClientState( GL_COLOR_ARRAY );
	checkOpenGLError();
	
	glEnableClientState( GL_VERTEX_ARRAY );
	checkOpenGLError();
	
	glClientActiveTextureARB(GL_TEXTURE0_ARB);

	glEnableClientState( GL_TEXTURE_COORD_ARRAY );
	checkOpenGLError();
	
	glTexCoordPointer( 2, GL_FLOAT, 0, pTexCoordStream );
	checkOpenGLError();
	
	glClientActiveTextureARB(GL_TEXTURE1_ARB);

	glEnableClientState( GL_TEXTURE_COORD_ARRAY );
	checkOpenGLError();
	
	glTexCoordPointer( 2, GL_FLOAT, 0, pTexCoordStream2 );
	checkOpenGLError();

	glClientActiveTextureARB(GL_TEXTURE0_ARB);
	
	// die Pointer auf die Arrays setzen
	glVertexPointer( 3, GL_FLOAT, 0, pVertexStream );
	checkOpenGLError();
	
	glColorPointer( 3, GL_FLOAT, 0, pColorStream );
	checkOpenGLError();
	
	// und Zeichnen
	drawClipped();
	checkOpenGLError();
	
	glFlush();
	checkOpenGLError();
	
	glDisableClientState( GL_COLOR_ARRAY );
	checkOpenGLError();
	
	glDisableClientState( GL_VERTEX_ARRAY );
	checkOpenGLError();
	
	glDisableClientState( GL_TEXTURE_COORD_ARRAY );
	checkOpenGLError();
}

bool isInString(char *string, const char *search) {
	int pos=0;
	int maxpos=strlen(search)-1;
	int len=strlen(string);	
	char *other;
	for (int i=0; i<len; i++) {
		if ((i==0) || ((i>1) && string[i-1]=='\n')) {				// New Extension Begins Here!
			other=&string[i];			
			pos=0;													// Begin New Search
			while (string[i]!='\n') {								// Search Whole Extension-String
				if (string[i]==search[pos]) pos++;					// Next Position
				if ((pos>maxpos) && string[i+1]=='\n') return true; // We Have A Winner!
				i++;
			}			
		}
	}	
	return false;													// Sorry, Not Found!
}

bool initMultitexture( bool wantIt ) 
{
	char *extensions;	
	extensions = strdup( (char*)glGetString( GL_EXTENSIONS ) );
	for ( int i = 0; i < strlen( extensions ); i ++ )
		if ( extensions[ i ] == ' ' ) extensions[ i ] = '\n';

	if ( wantIt && 
		 strstr( extensions, "GL_ARB_multitexture" ) && 
		 strstr( extensions, "GL_EXT_texture_env_combine" ) )
	{	
		glGetIntegerv( GL_MAX_TEXTURE_UNITS_ARB, &maxTexelUnits );
		glMultiTexCoord1fARB	 = (PFNGLMULTITEXCOORD1FARBPROC)		wglGetProcAddress( "glMultiTexCoord1fARB" );
		glMultiTexCoord2fARB	 = (PFNGLMULTITEXCOORD2FARBPROC)		wglGetProcAddress( "glMultiTexCoord2fARB" );
		glMultiTexCoord3fARB	 = (PFNGLMULTITEXCOORD3FARBPROC)		wglGetProcAddress( "glMultiTexCoord3fARB" );
		glMultiTexCoord4fARB	 = (PFNGLMULTITEXCOORD4FARBPROC)		wglGetProcAddress( "glMultiTexCoord4fARB" );
		glActiveTextureARB		 = (PFNGLACTIVETEXTUREARBPROC)		wglGetProcAddress( "glActiveTextureARB" );
		glClientActiveTextureARB = (PFNGLCLIENTACTIVETEXTUREARBPROC)	wglGetProcAddress( "glClientActiveTextureARB" );		

		return true;
	}

	useMultitexture = false;
	return false;
}

void	init3DEngine()
{
	// hier bereiten wir die Farbberechnung vor
	colorSpline = new CardinalSpline( 3, 0.5f, 5 );

	// Farben gr�n, braun, weiss
	const float	color[ 5 ][ 3 ] =
	{
		{ 0.1f, 0.2f, 0.05f },
		{ 0.3f, 0.35f, 0.2f },
		{ 0.4f, 0.35f, 0.35f },
		{ 0.6f, 0.6f, 0.6f },
		{ 0.8f, 0.8f, 0.8f }
	};

	colorSpline->set( 0,   (float*)color[ 0 ] );
	colorSpline->set( 150, (float*)color[ 1 ] );
	colorSpline->set( 176, (float*)color[ 2 ] );
	colorSpline->set( 256, (float*)color[ 3 ] );
	colorSpline->set( 258, (float*)color[ 4 ] );
	colorSpline->prepare();

	// die landschaftsdaten
	createLandscapeVertexData();

	pfLockArrays   = (LOCKARRAYS_PROC)   wglGetProcAddress( "glLockArraysEXT" );
	
	pfUnlockArrays = (UNLOCKARRAYS_PROC) wglGetProcAddress( "glUnlockArraysEXT" );
	
	if ( !pfLockArrays || !pfUnlockArrays )
	{
		MessageBox( NULL, "Compiled Vertex Arrays werden vom Grafikkartentreiber nicht unterst�tzt !", "Achtung !", MB_OK );
	}

	// Texturen laden
#ifdef BLENDTEXTURE
	basisMap1.loadBMP( "./data/basis1.bmp" );
	basisMap2.loadBMP( "./data/basis2.bmp" );
	blendMap.loadTGA32Bit256x256( "./data/shadowblend.tga" );
#else
	fadeMap.loadBMP( "./data/shadow.bmp" );
	detailMap.loadBMP( "./data/detailmap.bmp" );
#endif
	skyboxInit();

	initMultitexture( true );

/*  NEBEL 
	glEnable( GL_FOG );
	glFogi( GL_FOG_MODE, GL_EXP2 );
	glFogf( GL_FOG_DENSITY, 0.01f );
	GLfloat fogColor[ 3 ] = { 1.0f, 1.0f, 1.0f };
	glFogfv( GL_FOG_COLOR, fogColor );
*/
}

static float	posX = 0, posY = 0, posZ = 70, lookAt = 0, distance = 0.0f;
static float	dirX, dirY, dirZ = -1.0f;
static float	lastTime = -1.0f;

void	draw3DEngine()
{
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	float time, elapsed;

	time = (float)GetTickCount();

	if ( lastTime == -1.0f )
		elapsed = 1.0f; else
	{
		elapsed = ( time - lastTime ) * 0.1f;
	}
	lastTime = time;

	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();
	gluPerspective( 45.0f, 1.33f, 0.01f, 2500.0f );

	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();

	// Tastaturabfrage
	dirX = sin( lookAt * 3.14592f / 180.0f );
	dirY = cos( lookAt * 3.14592f / 180.0f );

	extern bool	keys[ 256 ];
	if ( keys[ VK_UP ] )
	{
		posX += dirX * elapsed;
		posY += dirY * elapsed;
	}
	if ( keys[ VK_DOWN ] )
	{
		posX -= dirX * elapsed;
		posY -= dirY * elapsed;
	}
	if ( keys[ VK_LEFT ] )
	{
		lookAt -= elapsed;
	}
	if ( keys[ VK_RIGHT ] )
	{
		lookAt += elapsed;
	}
	if ( keys[ 'A' ] )
	{
		posZ += elapsed * 0.1f;
	}
	if ( keys[ 'Y' ] )
	{
		posZ -= elapsed * 0.1f;
	}
	if ( keys[ 'S' ] )
	{
		dirZ += elapsed * 0.1f;
	}
	if ( keys[ 'X' ] )
	{
		dirZ -= elapsed * 0.1f;
	}
	if ( keys[ 'D' ] )
	{
		distance += elapsed * 0.1f;
	}
	if ( keys[ 'C' ] )
	{
		distance -= elapsed * 0.1f;
	}
	distance = min( 100.0f, max( 0.0f, distance ) );

	gluLookAt( posX-distance*dirX, posY-distance*dirY, posZ-distance*dirZ, 
			   posX+dirX, posY+dirY, posZ+dirZ, 
			   0, 0, 1 );

	extern void buildFrustum();
	buildFrustum();


	glEnable( GL_CULL_FACE );
	glCullFace( GL_BACK );

	glDisable( GL_LIGHTING );
    glShadeModel( GL_SMOOTH );

	glEnable( GL_TEXTURE_2D );

#ifdef BLENDTEXTURE
		glDisable( GL_BLEND );	

		// alpha kanal f�llen, shadow map zeichnen
		blendMap.select();
		glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
		glDisable( GL_BLEND );	
		renderStream( pTexCoordStream, pColorStream2 );

		basisMap2.select();
		glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
		glEnable( GL_BLEND );	
		glBlendFunc( GL_DST_ALPHA, GL_SRC_COLOR );
		renderStream( pTexCoordStream2, pColorStream2 );

		basisMap1.select();
		glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
		glEnable( GL_BLEND );	
		glBlendFunc( GL_ONE_MINUS_DST_ALPHA, GL_DST_COLOR );
		renderStream( pTexCoordStream2, pColorStream2 );

#else

	if ( useMultitexture )
	{
		// texture unit #0		
		glActiveTextureARB(GL_TEXTURE0_ARB);
		glEnable(GL_TEXTURE_2D);

		fadeMap.select();
		glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE_EXT );
		glTexEnvf (GL_TEXTURE_ENV, GL_COMBINE_RGB_EXT, GL_MODULATE );	
		// texture unit #1 
		glActiveTextureARB(GL_TEXTURE1_ARB);
		glEnable(GL_TEXTURE_2D);

		detailMap.select();
		glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE_EXT );
		glTexEnvf (GL_TEXTURE_ENV, GL_COMBINE_RGB_EXT, GL_MODULATE );
		// wenn die landschaft heller sein soll:
		// glTexEnvf (GL_TEXTURE_ENV, GL_RGB_SCALE_EXT, 2 );

		renderStreamMultiTexture();
		
		glActiveTextureARB(GL_TEXTURE1_ARB);		
		glDisable(GL_TEXTURE_2D);
		glActiveTextureARB(GL_TEXTURE0_ARB);			
	} else
	{
		fadeMap.select();

		glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );

		renderStream( pTexCoordStream, pColorStream );

		detailMap.select();

		glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
		glEnable(GL_BLEND);	
		glBlendFunc( GL_ZERO, GL_SRC_COLOR );	

		// wenn die Landschaft heller sein soll:
		//glBlendFunc( GL_DST_COLOR, GL_SRC_COLOR );	
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );

		renderStream( pTexCoordStream2, pColorStream2 );
	}
#endif
	glDisable(GL_BLEND);	

	drawSkybox();
}

void	quit3DEngine()
{
	delete	pVertex;
	delete	pTexCoordStream;
	delete	pColorStream;
	delete	pVertexStream;
}