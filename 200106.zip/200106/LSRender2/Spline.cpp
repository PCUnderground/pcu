///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - Demo Projekt                            //
//                                                       //
//  Splineroutinen								         //
//                                                       //
///////////////////////////////////////////////////////////
#include <math.h>
#include <stdio.h>
#include <limits.h>
#include "spline.h"


CardinalSpline::CardinalSpline (unsigned int aDimension, float aTension, unsigned int keys)
///////////////////////////////////////////////////////////////////////////////////////////
{
    dimension = aDimension;
    tension   = aTension;
    nkeys     = keys;
    keypos    = 0;
    Keys      = new KeyPoint[nkeys];

    // Keypoint Liste initialisieren:
    for ( int i=0; i<nkeys; i++ )
    {
          Keys[i].values    = 0;
          Keys[i].tangents  = 0;
          Keys[i].frame     = ULONG_MAX;
    }
}


CardinalSpline::~CardinalSpline()
/////////////////////////////////
{
    // allozierten Speicher l�schen
    for ( int i=0; i<nkeys; i++ )
    {
        if ( Keys[i].values   ) delete Keys[i].values;
        if ( Keys[i].tangents ) delete Keys[i].tangents;
    }
    delete Keys;
}



void CardinalSpline::set (unsigned int frame, float *data)
//////////////////////////////////////////////////////////
{
    // einen Keypoint in die Key-Liste eintragen:
    if (  keypos == nkeys ) return;  // Liste voll?

    // Key-Daten an die naechste freie stelle eintragen:
    Keys[keypos].frame    = frame;
    Keys[keypos].values   = new float[dimension];
    Keys[keypos].tangents = new float[dimension];

    for ( int i=0; i<dimension; i++ )
      Keys[keypos].values[i]  = data[i];

    keypos++;
}


void CardinalSpline::swap (const unsigned int i, const unsigned int j)
//////////////////////////////////////////////////////////////////////
{
    // Hilfs-Routine fuer den Quicksort
    // -------------------------------
    KeyPoint temp = Keys[i];
    Keys[i]       = Keys[j];
    Keys[j]       = temp;
}


void CardinalSpline::quicksort (const unsigned int left, const unsigned int right)
//////////////////////////////////////////////////////////////////////////////////
{
    KeyPoint* v;
    unsigned int i,j;

    if ( right > left )
    {
        v = &Keys[right];
        i = left-1;
        j = right;

        for ( ;; )
        {
            while ( Keys[++i].frame < v->frame );
            while ( Keys[--j].frame > v->frame );
            if ( i>=j ) break;
            swap (i,j);
        }
        swap  (i,right);
        quicksort (left, i-1);
        quicksort (i+1, right);
    }
}


void CardinalSpline::prepare (void)
///////////////////////////////////
{
    // sortieren der KeyPoint Liste:
    quicksort (0, keypos-1);

    // Tangenten fuer alle Splinesegmente berechnen:
    for ( unsigned int i=1; i<(keypos-1); i++)
    {
        KeyPoint *prev = &Keys[i-1];
        KeyPoint *next = &Keys[i+1];
        KeyPoint *now  = &Keys[i];

        for ( unsigned int d=0; d<dimension; d++  )
          now->tangents[d] = tension * ( next->values[d] - prev->values[d]);
    }


    // Tangenten fuer den ersten und letzen Abschnitt berechnen
    for ( unsigned int d=0; d<dimension; d++ )
    {
        Keys[0].tangents[d]   = 0;
        Keys[keypos-1].tangents[d] = 0;
    }
}



void CardinalSpline::get (float x, float *data)
///////////////////////////////////////////////
{
    unsigned int frame = floor(x);

    // Suche nach dem Spline-Segment, in welches der Zeitpunkt X f�llt:
    KeyPoint * now  = 0;
    for ( unsigned int i=0; i<keypos-2; i++)
    {
        if (( Keys[i].frame <= frame) &&
           (Keys[i+1].frame > frame))
        {
            now = & Keys[i];
            break;
        }
    }

    // keinen KeyPoint gefunden? Dann liefern wir den letzen wert zur�ck
    if ( !now )
    {
        for ( unsigned int d=0; d<dimension; d++ )
            data[d]=Keys[keypos-1].values[d];
        return;
    }

    KeyPoint * next = now+1;

    // Zeitspanne vom jetzt-keypoint zum naechsten keypoint.
    float frame_delta = next->frame - now->frame;

    // Zeitabschnitt durch Laenge des Splinesegmentes teilen und
    // die zwei Potenzen berechnen
    float time1       = (float)(frame-now->frame)/frame_delta;
    float time2       = time1*time1;
    float time3       = time2*time1;

    // Berechnung der Hermite Basis-Funktionen
    float h1 =  2.0*time3 - 3.0*time2 +1.0;
    float h2 = -2.0*time3 + 3.0*time2;
    float h3 =      time3 - 2.0*time2 + time1;
    float h4 =      time3 -     time2;

    // Und jetzt alle Werte interpolieren
    for ( unsigned int d=0; d< dimension; d++ )
    {
        data[d] = (h1*now->values[d])   + (h2*next->values[d]) +
                  (h3*now->tangents[d]) + (h4*next->tangents[d]);
    }
}



