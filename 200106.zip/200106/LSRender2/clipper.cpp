////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Landschaftsrendering: Clipper Code	  		          //
//  (w)(c)2000 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////

#include	<windows.h>
#include	<math.h>
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	"clipper.h"

#define	DIVIDE		16

static int nQuads, lSize;
static float frustum[ 6 ][ 4 ];

typedef struct
{
	float	x, y, z;
}VERTEX3D;

typedef VERTEX3D BOX[ 8 ];

static BOX quadClip[ (256 / DIVIDE) * (256 / DIVIDE) ];

void	prepareClipper( float *pVertex, int size, float hScale, unsigned char *heightmap )
{
	// quadClip stufen bauen (brute force, nicht elegant !)
	int nQ     = nQuads = size / DIVIDE;
	lSize	   = size;
	int divide = DIVIDE;

	VERTEX3D *vertexData = (VERTEX3D*)pVertex;
	
	// alle sektoren !
	for ( int j = 0; j < divide; j++ )
		for ( int i = 0; i < divide; i++ )
		{
			VERTEX3D vmin, vmax;
			vmin = vmax = vertexData[ (( i * nQ ) + ( j * nQ ) * size ) * 2+1 ];

			// alle vertices des sektors !
			for ( int b = 0; b <= nQ+1; b++ )
				for ( int a = 0; a <= nQ+1; a++ )
				{
					int xx = min( size-1, i * nQ + a );
					int yy = min( size-1, j * nQ + b );

					VERTEX3D *v = &vertexData[ ( xx + yy * size ) * 2+1 ];

					vmin.x = min( vmin.x, v->x ); vmin.y = min( vmin.y, v->y );	
					vmin.z = min( vmin.z, v->z );
					vmax.x = max( vmax.x, v->x ); vmax.y = max( vmax.y, v->y );	
					vmax.z = max( vmax.z, v->z );

				}
			VERTEX3D *box = (VERTEX3D*)&quadClip[ i + j * divide ];
			box[ 0 ].x = vmin.x;	box[ 0 ].y = vmin.y;	box[ 0 ].z = vmin.z;
			box[ 1 ].x = vmax.x;	box[ 1 ].y = vmin.y;	box[ 1 ].z = vmin.z;
			box[ 2 ].x = vmin.x;	box[ 2 ].y = vmax.y;	box[ 2 ].z = vmin.z;
			box[ 3 ].x = vmax.x;	box[ 3 ].y = vmax.y;	box[ 3 ].z = vmin.z;
			box[ 4 ].x = vmin.x;	box[ 4 ].y = vmin.y;	box[ 4 ].z = vmax.z;
			box[ 5 ].x = vmax.x;	box[ 5 ].y = vmin.y;	box[ 5 ].z = vmax.z;
			box[ 6 ].x = vmin.x;	box[ 6 ].y = vmax.y;	box[ 6 ].z = vmax.z;
			box[ 7 ].x = vmax.x;	box[ 7 ].y = vmax.y;	box[ 7 ].z = vmax.z;
		}
}

void buildFrustum()
{
	float   proj[16];
	float   modl[16];
	float   clip[16];
	float   t;
	
	// projection matrix auslesen
	glGetFloatv( GL_PROJECTION_MATRIX, proj );
	
	// modelview matrix auslesen 
	glGetFloatv( GL_MODELVIEW_MATRIX, modl );

	// matrixmultiplikation: projection * modelview
	glMatrixMode( GL_PROJECTION );
	glPushMatrix();

	glMultMatrixf( modl );
	glGetFloatv( GL_PROJECTION_MATRIX, clip );

	glPopMatrix();

	// und ebenen gleichungen bauen !
	frustum[0][0] = clip[ 3] - clip[ 0];
	frustum[0][1] = clip[ 7] - clip[ 4];
	frustum[0][2] = clip[11] - clip[ 8];
	frustum[0][3] = clip[15] - clip[12];
	
	frustum[1][0] = clip[ 3] + clip[ 0];
	frustum[1][1] = clip[ 7] + clip[ 4];
	frustum[1][2] = clip[11] + clip[ 8];
	frustum[1][3] = clip[15] + clip[12];
	
	frustum[2][0] = clip[ 3] + clip[ 1];
	frustum[2][1] = clip[ 7] + clip[ 5];
	frustum[2][2] = clip[11] + clip[ 9];
	frustum[2][3] = clip[15] + clip[13];
	
	frustum[3][0] = clip[ 3] - clip[ 1];
	frustum[3][1] = clip[ 7] - clip[ 5];
	frustum[3][2] = clip[11] - clip[ 9];
	frustum[3][3] = clip[15] - clip[13];
	
	frustum[4][0] = clip[ 3] - clip[ 2];
	frustum[4][1] = clip[ 7] - clip[ 6];
	frustum[4][2] = clip[11] - clip[10];
	frustum[4][3] = clip[15] - clip[14];
	
	frustum[5][0] = clip[ 3] + clip[ 2];
	frustum[5][1] = clip[ 7] + clip[ 6];
	frustum[5][2] = clip[11] + clip[10];
	frustum[5][3] = clip[15] + clip[14];
}


int calcClipCode( VERTEX3D *v )
{
	int clipCode = 0;

	for ( register int i = 0, j = 1; i < 6; i++, j <<= 1 )
		if ( frustum[ i ][ 0 ] * v->x + frustum[ i ][ 1 ] * v->y + frustum[ i ][ 2 ] * v->z + frustum[ i ][ 3 ] <= 0.0f )
			clipCode |= j;
	
	return clipCode;
}

bool boxIntersectsFrustum( VERTEX3D *b )
{
	int clipAnd	= 255;
	int clipOr	= 0;

	for ( int i = 0; i < 8; i++ )
	{
		int clipCode = calcClipCode( (VERTEX3D*)&b[ i ] );

		clipAnd &= clipCode;
		clipOr	|= clipCode;
	}

	// trivial reject
	if ( clipAnd ) 
		return false;

	return true;
}

void	drawClipped()
{
	for ( int y = 0; y < DIVIDE; y++ )
		for ( int x = 0; x < DIVIDE; x++ )
		if ( boxIntersectsFrustum( (VERTEX3D*)&quadClip[ x + y * DIVIDE ] ) )
		{
			if ( x != DIVIDE - 1 )
				for ( int i = y * nQuads; i < (y+1) * nQuads; i++ )
					glDrawArrays( GL_TRIANGLE_STRIP, x * nQuads * 2 + 2 + i * lSize * 2, 2+nQuads * 2 ); else
				for ( int i = y * nQuads; i < (y+1) * nQuads; i++ )
					glDrawArrays( GL_TRIANGLE_STRIP, x * nQuads * 2 + 2 + i * lSize * 2, nQuads * 2 );
		}
}
