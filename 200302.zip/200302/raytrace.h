////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Echtzeit Raytracing: Raytracing Routinen              //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#ifndef RAYTRACE__H
#define RAYTRACE__H

#include	"vertex3dop.h"
#include	"RTObject.h"
#include	"RTCamera.h"
#include	"quadtree.h"

#define		IR(x)	((U32&)x)

extern U32				nPrimitives;
extern RTObject			*pPrimitives[ 100 ];

extern U32				nOmniLights;
extern RTLight			pOmniLights[ 4 ];

extern U32				displayBoundingBoxes;

void renderBoundingBoxes();
__forceinline void traceRay( RAY *ray );
__forceinline void traceRayDepth0( RAY *ray, const int x, const int y );
__forceinline void traceShadowRay( RAY *ray, RTObject **cache );
void	raytrace( RAY *ray, TRACEDPOINT *trace, const int depth = 0, const int x = 0, const int y = 0 );

#endif