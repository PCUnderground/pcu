////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Echtzeit Raytracing Beispielprogramm                  //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////

#include	<windows.h>			
#include	<stdio.h>			
#include	<stdlib.h>			
#include	<math.h>
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	"vertex3dop.h"

#include	"RTObject.h"
#include	"RTCamera.h"

#include	"quadtree.h"
#include	"raytrace.h"

#include	"texture.h"
#include	"keys.h"

#define SCENE2

#ifndef SCENE1
#define SCENE2
#endif

#define		IR(x)	((U32&)x)

VERTEX3D	VERTEX( const float _x, const float _y, const float _z )
{
	VERTEX3D a = { _x, _y, _z };
	return a;
}

// die virtuelle Kamera
RTCamera		camera;

// ein paar Statistik Parameter
int				nRaysTotal, 
				nShadowRays, 
				nFirstRays, 
				shadowCacheHit;

// die Objekte f�r die Szenen
RTSphere		*pSpheres[ 4 ];
RTBox			*boxes[ 8 ];
RTPlane			*plane1;

// erzeugt ein Box Primitiv und h�ngt es an die Liste der Primitive
void	createBox( RTBox **b, VERTEX3D _p, VERTEX3D _e, VERTEX3D _c )
{
	*b = new RTBox();
	reinterpret_cast<RTBox*>(*b)->setParameter( _p, _e );
	reinterpret_cast<RTObject*>(*b)->color = _c;
	pPrimitives[ nPrimitives ++ ] = reinterpret_cast<RTObject*>( *b );
}

void	init3DEngine()
{
    glShadeModel( GL_SMOOTH );

	glHint( GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST );

	glDisable( GL_POLYGON_SMOOTH );

	glDisable( GL_DEPTH_TEST );

	glDisable( GL_CULL_FACE );

	glClear( GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT );

	//
	// Die Lichtquellen
	//
	nOmniLights = 2;

	pOmniLights[ 0 ].pos = VERTEX( 9.0f, 9.0f, -5.0f );
	pOmniLights[ 0 ].color = VERTEX( 0.6f, 0.8f, 0.6f );
	pOmniLights[ 0 ].shadowCache = NULL;

	pOmniLights[ 1 ].pos = VERTEX( -9.0f, 9.0f, 9.0f );
	pOmniLights[ 1 ].color = VERTEX( 0.9f, 0.7f, 0.7f );
	pOmniLights[ 1 ].shadowCache = NULL;

	nPrimitives = 0;

	VERTEX3D centerP = { 0.0f, 0.0f, 0.0f };
	VERTEX3D normal = { 0.0f, 1.0f, 0.0f };
	plane1 = new RTPlane();
	plane1->setParameter( centerP, normal );
	reinterpret_cast<RTObject*>(plane1)->color = VERTEX( 0.2f, 0.2f, 0.5f );
	pPrimitives[ nPrimitives ++ ] = reinterpret_cast<RTObject*>( plane1 );

	int i;

#ifdef SCENE1
	for ( i = 0; i < 4; i++ )
	{
		pSpheres[ i ] = new RTSphere();
		reinterpret_cast<RTObject*>(pSpheres[ i ])->color = VERTEX( rand()/32768.0f, rand()/32768.0f, rand()/32768.0f );
		pPrimitives[ nPrimitives ++ ] = reinterpret_cast<RTObject*>(pSpheres[ i ]);
	}

	VERTEX3D boxCenter[ 6 ] =
	{
		{ 0.0f, 0.1f, 0.0f },
		{ 0.0f, 0.3f, 0.0f },
		{ -2.0f, 0.4f+1.0f, -2.0f },
		{ -2.0f, 0.4f+1.0f,  2.0f },
		{  2.0f, 0.4f+1.0f, -2.0f },
		{  2.0f, 0.4f+1.0f,  2.0f },
	};

	VERTEX3D boxExtent[ 6 ] =
	{
		{ 3.0f, 0.2f, 3.0f },
		{ 2.5f, 0.2f, 2.5f },
		{ 0.25f, 2.0f, 0.25f },
		{ 0.25f, 2.0f, 0.25f },
		{ 0.25f, 2.0f, 0.25f },
		{ 0.25f, 2.0f, 0.25f },
	};

	VERTEX3D boxColor[ 6 ] =
	{
		{ 1.0f, 1.0f, 1.0f },
		{ 1.0f, 1.0f, 1.0f },
		{ 1.0f, 1.0f, 1.0f },
		{ 1.0f, 1.0f, 1.0f },
		{ 1.0f, 1.0f, 1.0f },
		{ 1.0f, 1.0f, 1.0f },
	};

	for ( i = 0; i < 6; i++ )
	{
		createBox( &boxes[ i ], boxCenter[ i ], boxExtent[ i ], boxColor[ i ] );
	}
#endif
	
#ifdef SCENE2
	for ( i = 0; i < 8; i++ )
	{
		VERTEX3D center = { 0.0f, 2.0f, 0.0f };
		center.x += (i&1)?-1.0f:1.0f;
		center.y += (i&2)?-1.0f:1.0f;
		center.z += (i&4)?-1.0f:1.0f;
		VERTEX3D extent = { 0.25f, 0.25f, 0.25f };
		VERTEX3D color = { 1.0f, 1.0f, 1.0f };

		createBox( &boxes[ i ], center, extent, color );
	}
#endif

	initQuadtree();
	loadKeyTexture();
}

int count = 0;
static int first = 1;

float fps = 0.0f;
static int frame = 0, startTime;


void	draw3DEngine()
{
	if ( frame == 20 )
	{
		int time = GetTickCount() - startTime;

		fps = (float)frame / (float)time * 1000.0f;

		frame = 0;
		startTime += time;

		char buf[500];
		sprintf( buf, "F1 Help! fps %2.2f / rays total %d/shadow %d/first %d/shadowCacheHit %d", fps, nRaysTotal, nShadowRays, nFirstRays, shadowCacheHit );
		extern HWND hWnd;
		SetWindowText( hWnd, buf );
	}

	frame ++;
	extern bool keys[ 256 ];

	glClear( GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT );

	if ( keys[ VK_F1 ] )
	{
		extern HWND hWnd;
		MessageBox( hWnd, "PCU Realtime Raytracing\n(w)(c)2002 Carsten Dachsbacher\nvisit: www.dachsbacher.de/pcu", "About", MB_OK );
		keys[ VK_F1 ] = 0;
	}
	if ( keys[ 'F' ] )
	{
		displayFirstRays = 1 - displayFirstRays;
		keys[ 'F' ] = 0;
	}
	if ( keys[ 'B' ] )
	{
		displayBoundingBoxes = 1 - displayBoundingBoxes;
		keys[ 'B' ] = 0;
	}
	if ( keys[ VK_UP ] )
	{
		BLOCKSIZE *= 2;
		if ( BLOCKSIZE > 32 ) BLOCKSIZE = 32;
		keys[ VK_UP ] = 0;
		glClear( GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT );
	}
	if ( keys[ VK_DOWN ] )
	{
		BLOCKSIZE /= 2;
		if ( BLOCKSIZE < 2 ) BLOCKSIZE = 2;
		keys[ VK_DOWN ] = 0;
		glClear( GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT );
	}
	if ( keys[ 'H' ] )
	{
		virtualRes = min( 5, virtualRes + 1 );
		VIRTUAL_X_RES = virtualResolutions[ virtualRes ][ 0 ];
		VIRTUAL_Y_RES = virtualResolutions[ virtualRes ][ 1 ];
		extern void ReSizeGLScene( GLsizei width, GLsizei height );
		extern int windowX, windowY;
		ReSizeGLScene( windowX, windowY );
		keys[ 'H' ] = 0;
	}
	if ( keys[ 'L' ] )
	{
		virtualRes = max( 0, virtualRes - 1 );
		VIRTUAL_X_RES = virtualResolutions[ virtualRes ][ 0 ];
		VIRTUAL_Y_RES = virtualResolutions[ virtualRes ][ 1 ];
		extern void ReSizeGLScene( GLsizei width, GLsizei height );
		extern int windowX, windowY;
		ReSizeGLScene( windowX, windowY );
		keys[ 'L' ] = 0;
	}
	if ( keys[ 'X' ] )
	{
		if ( nOmniLights == 2 )
			nOmniLights = 1; else
			nOmniLights = 2;
		keys[ 'X' ] = 0;
	}




	{
		float time = (float)GetTickCount();
		float x = (float)cos( time / 3000.0f ) * 5.0f;
		float y = (float)sin( time / 3000.0f ) * 5.0f;

		// Animation der Kamera
		camera.FOV  = 45.0f;
#ifdef SCENE1
		camera.from = VERTEX( x*1.5f, 4.5f+x*0.5f, y*1.5f );
#else
		camera.from = VERTEX( x, 4.5f+x*0.5f, y );
#endif
		camera.to   = VERTEX( 0, 1, 0 );
		camera.up   = VERTEX( 0, -1.0f, 0.0f );
		camera.buildMatrix();

		// Objekt Animation
		time /= 2500.0f;

#ifdef SCENE1
		VERTEX3D pos = VERTEX( 0.0f, 1.0f, 0.0f );
		pSpheres[ 3 ]->setParameter( pos, 1.0f );
		reinterpret_cast<RTObject*>(pSpheres[ 3 ])->color = VERTEX( 0.3f, 0.3f, 0.5f );
		reinterpret_cast<RTObject*>(pSpheres[ 3 ])->reflection = 0.5f;
		reinterpret_cast<RTObject*>(pSpheres[ 3 ])->invReflection = 0.5f;

		for ( int i = 0; i < 3; i++ )
		{
			VERTEX3D pos;
			float ftime = time * 1.6f + i / 1.5f * 3.141592f;

			float radius = ( (float)sin( ftime * 4.0f - 1.5f ) * 0.75f + 3.0f ) * 1.0f;
			pos.x = (float)cos( ftime ) * radius;
			pos.z = (float)sin( ftime ) * radius;
			pos.y = 1;
			pSpheres[ i ]->setParameter( pos, 0.5f );
		}
#endif

#ifdef SCENE2
		for ( int i = 0; i < 8; i++ )
		{
			#define CUBEHEIGHT 1.3f
			#define CUBEDIST 0.75f
			VERTEX3D center = { 0.0f, CUBEHEIGHT, 0.0f };
			center.x += (i&1)?-CUBEDIST:CUBEDIST;
			center.y += (i&2)?-CUBEDIST:CUBEDIST;
			center.z += (i&4)?-CUBEDIST:CUBEDIST;
			float e = 0.25f + 0.75f * 0.5f + 0.75f * 0.5f * (float)sin( time * ( 1.0f + i*0.15123123f ) );
			VERTEX3D extent = { e, e, e };
			boxes[ i ]->setParameter( center, extent );
			reinterpret_cast<RTObject*>(boxes[ i ])->reflection = 0.5f;
			reinterpret_cast<RTObject*>(boxes[ i ])->invReflection = 0.5f;
		}
#endif
	}

	
	// L�schen der Hash Tabelle (Indizes der benutzten Eintr�ge wurden in trashedPoint gespeichert)
	// brute force: memset( traceHash, 0, sizeof(TRACEDPOINT*) * VIRTUAL_X_RES * VIRTUAL_Y_RES );
	clearQuadtree();

	shadowCacheHit = 
	nRaysTotal     = 
	nShadowRays    = 
	nFirstRays     = 0;

	//
	// Pro Frame Vorberechnungen f�r die Primitive
	//
	for ( U32 i = 0; i < nPrimitives; i++ )
		pPrimitives[ i ]->preparePerFrame( &camera );


	//
	// Erstes Abtasten des Bildes (ein Strahl pro Block)
	//
	S32 x, y;
	for ( y = 0; y < VIRTUAL_Y_RES; y += BLOCKSIZE )
		for ( x = 0; x < VIRTUAL_X_RES; x += BLOCKSIZE )
		{
			evaluate( x, y );
		}

	//
	// rekursives Abtasten bzw. Aufbau der zu zeichnenden Bl�cke
	//
	for ( y = 0; y < VIRTUAL_Y_RES-BLOCKSIZE; y += BLOCKSIZE )
		for ( x = 0; x < VIRTUAL_X_RES-BLOCKSIZE; x += BLOCKSIZE )
		{
			traceBlock( x, y, BLOCKSIZE );
		}

	renderQuadtree();
	renderBoundingBoxes();
	drawKeys();

}

void	quit3DEngine()
{
}


