////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Echtzeit Raytracing: Schnittpunktberechnung           //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#ifndef RTCAMERA__H
#define RTCAMERA__H

#include    <math.h>
#include	"vertex3dop.h"

class RTCamera
{
	private:
	public:
		VERTEX3D	from,
					to,
					up,
					right,	
					forward,
					right2, up2, forward2;

		FLOAT		FOV;
		FLOAT		frustumwidth;
		FLOAT		frustumheight;

		RTCamera() {};
		~RTCamera() {};

		void buildMatrix()
		{
			frustumwidth  = (float)tan( FOV / 180.0f * 3.141592f );
			frustumheight = (float)tan( FOV / 1.33f / 180.0f * 3.141592f );

			forward = to - from;
			~forward;

			right = forward ^ up;
			~right;

			up = forward ^ right;

			right2    = right * frustumwidth;
			up2       = up    * frustumheight;
			forward2  = forward - right2 - up2;
			right2   *= 2.0f / (float)VIRTUAL_X_RES;
			up2      *= 2.0f / (float)VIRTUAL_Y_RES;
		}

		inline VERTEX3D getRay( const int x, const int y )
		{
			return forward2 + right2 * (float)x + up2 * (float)y;
		}

		U32 projectVertex( const VERTEX3D &v, float *x2, float *y2 )
		{
			VERTEX3D	toVec = v - this->from;

			float x = toVec * this->right;
			float y = toVec * this->up;
			float z = toVec * this->forward;

			if ( z > 0 )
			{
				float iz = 1.0f / z;
				float fx = x * iz / this->frustumwidth;
				float fy = y * iz / this->frustumheight;

				extern int VIRTUAL_X_RES, VIRTUAL_Y_RES;

				*x2 = VIRTUAL_X_RES/2+(float)(VIRTUAL_X_RES/2) * fx;
				*y2 = VIRTUAL_Y_RES/2+(float)(VIRTUAL_Y_RES/2) * fy;

				return 1;
			} else
				return 0;
		}

};

#endif