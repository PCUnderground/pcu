///////////////////////////////////////////////////////////
//                                                       //
//  (w)(c) 2002 - Carsten Dachsbacher                    //
//                carsten@dachsbacher.de                 //
//                                                       //
//  Vector and Matrix Header File                        //
//                                                       //
//  Changed: 09-14-2002                                  //
//                                                       //
///////////////////////////////////////////////////////////
#ifndef VERTEX3DOP__H
#define VERTEX3DOP__H

#define U8		unsigned char
#define S8		signed char
#define U16		unsigned short
#define S16		signed short
#define S32		signed long
#define U32		unsigned long
#define FLOAT	float
#define BOOL	bool

typedef struct
{
	FLOAT	x, y, z;
}VERTEX3D;

#ifndef max
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif

#ifndef M_PI
#define M_PI 3.14159265359f
#endif

typedef float MATRIX44[ 16 ];

#define INLINE __forceinline

extern INLINE float	operator * ( const VERTEX3D &a, const VERTEX3D &b );

extern INLINE VERTEX3D	operator + ( const VERTEX3D &a, const VERTEX3D &b );

extern INLINE VERTEX3D	operator * ( const VERTEX3D &a, const float b );

extern INLINE VERTEX3D	operator - ( const VERTEX3D &a, const VERTEX3D &b );

extern INLINE void	operator += ( VERTEX3D &a, const VERTEX3D &b );

extern INLINE VERTEX3D	operator ^ ( const VERTEX3D &a, const VERTEX3D &b );

extern INLINE void	operator *= ( VERTEX3D &a, const float b );

extern INLINE float	operator ~ ( VERTEX3D &a );

extern VERTEX3D	operator * ( const MATRIX44 &matrix, const VERTEX3D &source );

extern void	InverseMatrixAnglePreserving( const MATRIX44 source, MATRIX44 dest );

#endif