////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Echtzeit Raytracing: Schnittpunktberechnung           //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include "RTObject.h"
#include "RTCamera.h"

void	RTPlane::setParameter( VERTEX3D _center, VERTEX3D _normal )
{
	this->center = _center;
	this->normal = _normal;
	~this->normal;

	this->D = this->center * this->normal;
};

void	RTPlane::preparePerFrame( RTCamera *camera )
{
	this->camPos = camera->from;
	this->projDistance = - ( camera->from * this->normal + this->D );
};

U32		RTPlane::get2DBoundingBoxHit( S32 x, S32 y )
{
	return 1;
};

U32		RTPlane::getFirstHit( VERTEX3D *r, FLOAT *t )
{
	float a = this->normal * *r;

	if ( IR( a ) == 0 )
		return 0;

	*t = this->projDistance / a;

	return 1;
}

U32		RTPlane::getIntersection( RAY *r, FLOAT *t )
{
	float a = this->normal * r->dir;

	if ( IR( a ) == 0 )
		return 0;

	*t = -( this->normal * r->from + this->D ) / a;

	return 1;
};

void	RTPlane::getNormal( VERTEX3D *pos, VERTEX3D *nrml )
{
	*nrml = this->normal;
};
