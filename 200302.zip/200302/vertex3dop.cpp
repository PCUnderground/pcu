///////////////////////////////////////////////////////////
//                                                       //
//  (w)(c) 2002 - Carsten Dachsbacher                    //
//                carsten@dachsbacher.de                 //
//                                                       //
//  Vector and Matrix Code                               //
//                                                       //
//  Changed: 09-14-2002                                  //
//                                                       //
///////////////////////////////////////////////////////////
#include <math.h>
#include "vertex3dop.h"

#define INLINE __forceinline

INLINE float	operator * ( const VERTEX3D &a, const VERTEX3D &b )
{
	return ( a.x * b.x + a.y * b.y + a.z * b.z );
}

INLINE VERTEX3D	operator + ( const VERTEX3D &a, const VERTEX3D &b )
{
	VERTEX3D result;

	result.x = a.x + b.x;
	result.y = a.y + b.y;
	result.z = a.z + b.z;

	return result;
}

INLINE VERTEX3D	operator * ( const VERTEX3D &a, const float b )
{
	VERTEX3D result;

	result.x = a.x * b;
	result.y = a.y * b;
	result.z = a.z * b;

	return result;
}

INLINE VERTEX3D	operator - ( const VERTEX3D &a, const VERTEX3D &b )
{
	VERTEX3D result;

	result.x = a.x - b.x;
	result.y = a.y - b.y;
	result.z = a.z - b.z;

	return result;
}

INLINE void	operator += ( VERTEX3D &a, const VERTEX3D &b )
{
	a.x += b.x;
	a.y += b.y;
	a.z += b.z;
}

INLINE VERTEX3D	operator ^ ( const VERTEX3D &a, const VERTEX3D &b )
{
	VERTEX3D result;

	result.x = a.y * b.z - b.y * a.z;
	result.y = a.z * b.x - b.z * a.x;
	result.z = a.x * b.y - b.x * a.y;

	return result;
}

INLINE void	operator *= ( VERTEX3D &a, const float b )
{
	a.x *= b;
	a.y *= b;
	a.z *= b;
}

INLINE float	operator ~ ( VERTEX3D &a )
{
	float faktor = a * a;

	float sqrtFactor;

	if ( faktor > 0 ) 
	{
		sqrtFactor = (float)sqrt( faktor );

		a *= 1.0f / sqrtFactor;
	}

	return sqrtFactor;
}

INLINE VERTEX3D	operator * ( const MATRIX44 &matrix, const VERTEX3D &source )
{
	VERTEX3D dest;

	dest.x = source.x * matrix[ 0 + 4 * 0 ] +
             source.y * matrix[ 0 + 4 * 1 ] +
             source.z * matrix[ 0 + 4 * 2 ] + matrix[ 0 + 4 * 3 ];
	dest.y = source.x * matrix[ 1 + 4 * 0 ] +
             source.y * matrix[ 1 + 4 * 1 ] +
             source.z * matrix[ 1 + 4 * 2 ] + matrix[ 1 + 4 * 3 ];
	dest.z = source.x * matrix[ 2 + 4 * 0 ] +
             source.y * matrix[ 2 + 4 * 1 ] +
             source.z * matrix[ 2 + 4 * 2 ] + matrix[ 2 + 4 * 3 ];

	return dest;
}

void	InverseMatrixAnglePreserving( const MATRIX44 source, MATRIX44 dest )
{
    FLOAT scale;

    scale = source[ 0 * 4 + 0 ] * source[ 0 * 4 + 0 ] +
            source[ 0 * 4 + 1 ] * source[ 0 * 4 + 1 ] +
            source[ 0 * 4 + 2 ] * source[ 0 * 4 + 2 ];

	if ( scale == 0 ) return;

    scale = (FLOAT)1.0 / scale;

    dest[ 0 * 4 + 0 ] = scale * source[ 0 * 4 + 0 ];
    dest[ 1 * 4 + 0 ] = scale * source[ 0 * 4 + 1 ];
    dest[ 2 * 4 + 0 ] = scale * source[ 0 * 4 + 2 ];
    dest[ 0 * 4 + 1 ] = scale * source[ 1 * 4 + 0 ];
    dest[ 1 * 4 + 1 ] = scale * source[ 1 * 4 + 1 ];
    dest[ 2 * 4 + 1 ] = scale * source[ 1 * 4 + 2 ];
    dest[ 0 * 4 + 2 ] = scale * source[ 2 * 4 + 0 ];
    dest[ 1 * 4 + 2 ] = scale * source[ 2 * 4 + 1 ];
    dest[ 2 * 4 + 2 ] = scale * source[ 2 * 4 + 2 ];

    dest[ 0 * 4 + 3 ] = - ( dest[ 0 * 4 + 0 ] * source[ 0 * 4 + 3 ] +
                            dest[ 0 * 4 + 1 ] * source[ 1 * 4 + 3 ] +
                            dest[ 0 * 4 + 2 ] * source[ 2 * 4 + 3 ] );
    dest[ 1 * 4 + 3 ] = - ( dest[ 1 * 4 + 0 ] * source[ 0 * 4 + 3 ] +
                            dest[ 1 * 4 + 1 ] * source[ 1 * 4 + 3 ] +
                            dest[ 1 * 4 + 2 ] * source[ 2 * 4 + 3 ] );
    dest[ 2 * 4 + 3 ] = - ( dest[ 2 * 4 + 0 ] * source[ 0 * 4 + 3 ] +
                            dest[ 2 * 4 + 1 ] * source[ 1 * 4 + 3 ] +
                            dest[ 2 * 4 + 2 ] * source[ 2 * 4 + 3 ] );

    dest[ 3 * 4 + 0 ] = dest[ 3 * 4 + 1] = dest[ 3 * 4 + 2 ] = (FLOAT)0.0;
    dest[ 3 * 4 + 3 ] = (FLOAT)1.0;

};

