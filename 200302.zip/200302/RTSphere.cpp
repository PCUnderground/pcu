////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Echtzeit Raytracing: Schnittpunktberechnung           //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include "RTObject.h"
#include "RTCamera.h"

void RTSphere::setParameter( VERTEX3D _position, FLOAT _radius ) 
{
	this->position = _position;
	this->radius   = _radius;

	invRadius = 1.0f / radius;
	radius2   = radius * radius;
	pos2      = position * position - radius;
	posdouble = position * 2.0f;
};

void RTSphere::preparePerFrame( RTCamera *camera )
{
	this->pos_from = this->position - camera->from;
	this->pos_from2 = this->pos_from * this->pos_from;

	constC = pos2 + camera->from * ( camera->from - posdouble ) * -4.0f;

	// 2d bounding box
	intersectViewingPlane = 0;
	minX = VIRTUAL_X_RES;
	minY = VIRTUAL_Y_RES;
	maxX = maxY = 0;

	float xp, yp, xr, yr, xr2, yr2;

	if ( camera->projectVertex( this->position, &xp, &yp ) &&
		 camera->projectVertex( this->position + camera->right * radius, &xr, &yr ) &&
		 camera->projectVertex( this->position + camera->up * radius, &xr2, &yr2 ) )
	{
		S32 sizeX = (S32)( (float)fabs( xr - xp ) * camera->frustumwidth );
		S32 sizeY = (S32)( (float)fabs( yr2 - yp ) );
		minX = (S32)xp - sizeX - 4;
		maxX = (S32)xp + sizeX + 4;
		minY = (S32)yp - sizeY - 4;
		maxY = (S32)yp + sizeY + 4;
	} else
		intersectViewingPlane = 1;

	if ( minX < 0 ) minX = 0;
	if ( minY < 0 ) minY = 0;
	if ( maxX >= VIRTUAL_X_RES ) maxX = VIRTUAL_X_RES-1;
	if ( maxY >= VIRTUAL_Y_RES ) maxY = VIRTUAL_Y_RES-1;
};

U32  RTSphere::get2DBoundingBoxHit( S32 x, S32 y ) 
{ 
	if ( intersectViewingPlane ||
		 ( minX <= x && x <= maxX &&
		   minY <= y && y <= maxY ) )
		   return 1;
	return 0;			
};

U32 RTSphere::getFirstHit( VERTEX3D *r, FLOAT *t )
{
	FLOAT	d = this->pos_from * *r;

	if ( IR( d ) > 0x80000000 ) return 0;

	float m2 = this->radius2 - ( this->pos_from2 - d * d );

	//if ( m2 < 0 ) return 0;
	if ( IR( m2 ) > 0x80000000 ) return 0;
	
	float q = (float)sqrt( m2 );

	*t = d - q;

	return 1;
};

U32 RTSphere::getIntersection( RAY *r, FLOAT *t )
{
	// die optimierte Variante
	VERTEX3D l = this->position - r->from;

	FLOAT	d = l * r->dir;

	//if ( d < 0 ) return 0;
	if ( IR( d ) > 0x80000000 ) return 0;

	float l2 = l * l;

	float m2 = this->radius2 - ( l2 - d * d );

	//if ( m2 < 0 ) return 0;
	if ( IR( m2 ) > 0x80000000 ) return 0;
	
	float q = (float)sqrt( m2 );

	float t1 = d - q; 
	float t2 = d + q;

	int c = 0;

	if ( IR( t1 ) <= 0x80000000 ) 
	{
		t[ 0 ] = t1;
		c ++;
	}
	if ( IR( t2 ) <= 0x80000000 ) 
		t[ c++ ] = t2;

	return c;
};

void RTSphere::getNormal( VERTEX3D *pos, VERTEX3D *nrml ) 
{
	*nrml = ( *pos - this->position ) * invRadius;
};
