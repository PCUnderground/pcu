////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Echtzeit Raytracing: Screenspace Quadtree             //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include	<windows.h>
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	"RTObject.h"
#include	"RTCamera.h"
#include	"quadtree.h"
#include	"raytrace.h"

int virtualResolutions[6][2] =
{
	{ 160, 120 }, { 320, 240 },
	{ 512, 384 }, { 640, 480 },
	{ 800, 600 }, { 1024, 768 }
};

int MAX_VIRTUAL_X_RES	 = virtualResolutions[ 5 ][ 0 ];
int MAX_VIRTUAL_Y_RES	 = virtualResolutions[ 5 ][ 1 ];
int MAX_VIRTUAL_RES		 = MAX_VIRTUAL_X_RES * MAX_VIRTUAL_Y_RES;

int virtualRes = 2;
int VIRTUAL_X_RES		 = virtualResolutions[ virtualRes ][ 0 ];
int VIRTUAL_Y_RES		 = virtualResolutions[ virtualRes ][ 1 ];
int BLOCKSIZE			 = 4;

U32 displayFirstRays     = 0;

TRACEDPOINT		*tracedPointPool;
TRACEDPOINT		*pool;
TRACEDPOINT		**traceHash;
U32				poolIndex;
U32				*indexTable;
U32				*trashedPoint, trashedIndex;

//
// OpenGL 
//
U32				nVertices;
U32				*pVertexArray, *ptrVertex;
VERTEX3D		*pColorArray;
U32				nBlockIndex;
U32				*pBlockIndex;


void initQuadtree()
{
	traceHash       = new TRACEDPOINT*[ MAX_VIRTUAL_RES ];
	tracedPointPool = new TRACEDPOINT[ MAX_VIRTUAL_RES ];
	indexTable      = new U32[ MAX_VIRTUAL_RES ];
	trashedPoint    = new U32[ MAX_VIRTUAL_RES ];
	trashedIndex    = 0;

	memset( traceHash, 0, sizeof(TRACEDPOINT*) * MAX_VIRTUAL_RES );

	pVertexArray = new U32[ 2 * MAX_VIRTUAL_RES ];
	pColorArray = new VERTEX3D[ MAX_VIRTUAL_RES ];
	pBlockIndex = new U32[ 4 * MAX_VIRTUAL_RES ];
}

void clearQuadtree()
{
	for ( U32 k = 0; k < trashedIndex; k++ )
		traceHash[ trashedPoint[ k ] ] = NULL;

	pool           = tracedPointPool;
	trashedIndex   = 0;
	poolIndex      = 0;
	trashedIndex   = 0;

	ptrVertex      = pVertexArray;
	nBlockIndex    = 0;
	nVertices      = 0;
}

void renderQuadtree()
{
	//
	// Rendern aller Bl�cke mit OpenGL
	//
	glVertexPointer( 2, GL_INT, 0, pVertexArray );
	glColorPointer( 3, GL_FLOAT, 0, pColorArray );

	glEnableClientState( GL_VERTEX_ARRAY );
	glEnableClientState( GL_COLOR_ARRAY );

	glDrawElements( GL_QUADS, nBlockIndex, GL_UNSIGNED_INT, pBlockIndex );

	glDisableClientState( GL_COLOR_ARRAY );

	//
	// Darstellen der Prim�rstrahlen
	//
	if ( displayFirstRays )
	{
		glPointSize( 1 );
		glColor3ub( 255, 255, 0 );
		glDrawElements( GL_POINTS, nBlockIndex, GL_UNSIGNED_INT, pBlockIndex );
	}

	glDisableClientState( GL_VERTEX_ARRAY );
}

__forceinline void evaluate( const int x, const int y )
{
	int o = x + y * VIRTUAL_X_RES;

	if ( traceHash[ o ] )
		return;

	// new entry
	TRACEDPOINT *n = pool++;

	extern RTCamera camera;

	RAY ray;
	ray.from		= camera.from;
	ray.dir			= camera.getRay( x, y );
	~ray.dir;
	ray.hit			= NULL;
	ray.distance	= 1e37f;
	ray.hitTest		= 0;

	extern int nFirstRays;
	nFirstRays ++;

	raytrace( &ray, n, 0, x, y );

	// vertex liste aufbauen
	//pVertexArray[ nVertices * 2 + 0 ] = x;
	//pVertexArray[ nVertices * 2 + 1 ] = y;
	*( ptrVertex ++ ) = x;
	*( ptrVertex ++ ) = y;
	pColorArray[ nVertices ] = n->lighting;
	indexTable[ o ] = nVertices;
	nVertices ++;


	traceHash[ o ] = n;
	trashedPoint[ trashedIndex ++ ] = o;
}

__forceinline void interpolate( const int x1, const int y1, const int x2, const int y2, const int xd, const int yd )
{
	int o = xd + yd * VIRTUAL_X_RES;

	if ( traceHash[ o ] )
		return;

	TRACEDPOINT *s1 = traceHash[ x1 + y1 * VIRTUAL_X_RES ];
	TRACEDPOINT *s2 = traceHash[ x2 + y2 * VIRTUAL_X_RES ];

	TRACEDPOINT *dst = pool ++;

	dst->flag     = s1->flag;
	dst->lighting = ( s1->lighting + s2->lighting ) * 0.5f;

	// vertex liste aufbauen
	*( ptrVertex ++ ) = xd;
	*( ptrVertex ++ ) = yd;
	pColorArray[ nVertices ] = dst->lighting;
	indexTable[ o ] = nVertices;
	nVertices ++;

	traceHash[ o ] = dst;
	trashedPoint[ trashedIndex ++ ] = o;
}

__forceinline void interpolate( TRACEDPOINT *s1, TRACEDPOINT *s2, const int xd, const int yd )
{
	int o = xd + yd * VIRTUAL_X_RES;

	if ( traceHash[ o ] )
		return;

	TRACEDPOINT *dst = pool ++;

	dst->flag     = s1->flag;
	dst->lighting = ( s1->lighting + s2->lighting ) * 0.5f;

	// vertex liste aufbauen
	*( ptrVertex ++ ) = xd;
	*( ptrVertex ++ ) = yd;
	pColorArray[ nVertices ] = dst->lighting;
	indexTable[ o ] = nVertices;
	nVertices ++;

	traceHash[ o ] = dst;
	trashedPoint[ trashedIndex ++ ] = o;
}

__forceinline void traceBlock( const int x, const int y, const int size )
{
	U32 ofs1 = x + y * VIRTUAL_X_RES;
	U32 ofs2 = ofs1 + size;
	U32 ofs3 = ofs1 + size * VIRTUAL_X_RES;
	U32 ofs4 = ofs3 + size;
	TRACEDPOINT *p1 = traceHash[ ofs1 ]; 
	TRACEDPOINT *p2 = traceHash[ ofs2 ]; 
	TRACEDPOINT *p3 = traceHash[ ofs3 ]; 
	TRACEDPOINT *p4 = traceHash[ ofs4 ]; 

	if ( size == 1 || ( p1->flag == p2->flag && p2->flag == p3->flag && p3->flag == p4->flag ) )
	{
		pBlockIndex[ nBlockIndex ++ ] = indexTable[ ofs1 ];
		pBlockIndex[ nBlockIndex ++ ] = indexTable[ ofs2 ];
		pBlockIndex[ nBlockIndex ++ ] = indexTable[ ofs4 ];
		pBlockIndex[ nBlockIndex ++ ] = indexTable[ ofs3 ];
		return;
	}

	U32 halfSize = size >> 1;

	if ( p1->flag != p2->flag )
		evaluate( x + halfSize, y ); else
		interpolate( p1, p2, x + halfSize, y );

	if ( p2->flag != p4->flag )
		evaluate( x + size, y + halfSize ); else
		interpolate( p2, p4, x + size, y + halfSize );

	if ( p3->flag != p4->flag )
		evaluate( x + halfSize, y + size ); else
		interpolate( p3, p4, x + halfSize, y + size );

	if ( p1->flag != p3->flag )
		evaluate( x, y + halfSize ); else
		interpolate( p1, p3, x, y + halfSize );

	evaluate( x + halfSize, y + halfSize );

	traceBlock( x, y, halfSize );
	traceBlock( x + halfSize, y, halfSize );
	traceBlock( x, y + halfSize, halfSize );
	traceBlock( x + halfSize, y + halfSize, halfSize );
}


