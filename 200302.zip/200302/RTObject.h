////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Echtzeit Raytracing: Schnittpunktberechnung           //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#ifndef RTOBJECT__H
#define RTOBJECT__H

#include	"vertex3dop.h"

//
// per ray precalculated data
//
extern int VIRTUAL_X_RES, VIRTUAL_Y_RES;

class RTCamera;
class RTObject;

typedef struct
{
	VERTEX3D	from;
	VERTEX3D	dir;
	FLOAT		distance;
	U32			hitTest;
	RTObject	*hit;
	U32         hitFlag;
}RAY;

typedef struct
{
	VERTEX3D	pos;			// position
	VERTEX3D	color;			// argb farbe
	RTObject	*shadowCache;   // index des objects im shadow cache
}RTLight;


// Zugriff auf den Inhalt eines Floats als Integer
#define IR(x)	((U32&)x)
#define SIR(x)	((S32&)x)

#define RAYAABB_EPSILON 0.00001f


//
// base class for raytracing primitives
//
class RTObject
{
	protected:
	public:
		FLOAT		reflection, invReflection;

		// 2d bounding box
		S32			minX, maxX, minY, maxY;
		U32			intersectViewingPlane;

		VERTEX3D	color;
		
		RTObject() : reflection( 0.0f ), invReflection( 1.0f ) {};
		~RTObject() {};

		virtual void preparePerFrame( RTCamera *camera ){};

		virtual U32  get2DBoundingBoxHit( S32 x, S32 y ) { return 1; };
		virtual U32  getFirstHit( VERTEX3D *r, FLOAT *t ){ return 0; };
		virtual U32  getIntersection( RAY *r, FLOAT *t ) { return 0; };

		virtual const U32	 getAdditionalSubdivideCriteria() { return 0; };

		virtual void getNormal( VERTEX3D *pos, VERTEX3D *nrml ) {};
};

//
// sphere class
//
class RTSphere:RTObject
{
	private:
		// initial parameters
		FLOAT		radius;
		VERTEX3D	position;
		FLOAT		radius2;
		FLOAT		invRadius;
			
		// per frame parameters
		VERTEX3D	pos_from;
		VERTEX3D	posdouble;
		FLOAT		pos2;
		FLOAT		constC;
		FLOAT		pos_from2;

		// world space parameter
		
		// bounding box
		VERTEX3D	aabb[ 8 ];

	protected:
	public:
		RTSphere() {};
		~RTSphere() {};
		
		void	setParameter( VERTEX3D _position, FLOAT _radius ); 
		void	preparePerFrame( RTCamera *camera );
		U32		get2DBoundingBoxHit( S32 x, S32 y );
		U32		getFirstHit( VERTEX3D *r, FLOAT *t );
		U32		getIntersection( RAY *r, FLOAT *t );
		void	getNormal( VERTEX3D *pos, VERTEX3D *nrml );
};



//
// axis aligned box class
//
class RTBox:RTObject
{
	private:
		// initial parameters
		VERTEX3D	center;
		VERTEX3D	extent;

		// per frame paramters
		VERTEX3D	camPos;
		VERTEX3D	intersection;
		VERTEX3D	normal;

		U32			whichPlane;

		FLOAT		div[ 3 ];

		VERTEX3D	aabb[ 8 ];
			
	protected:
	public:
		RTBox()	{};
		~RTBox() {};
		
		void	setParameter( VERTEX3D _center, VERTEX3D _extent );
		void	preparePerFrame( RTCamera *camera );
		U32		get2DBoundingBoxHit( S32 x, S32 y );
		U32		getFirstHit( VERTEX3D *r, FLOAT *t );
		U32		getIntersection( RAY *r, FLOAT *t );
		void	getNormal( VERTEX3D *pos, VERTEX3D *nrml );
		const U32		getAdditionalSubdivideCriteria();
};


//
// axis aligned box class
//
class RTPlane:RTObject
{
	private:
		// initial parameters
		VERTEX3D	center;
		VERTEX3D	normal;

		// additional paramters
		FLOAT		D;
		VERTEX3D	camPos;
		FLOAT		projDistance;
			
	protected:
	public:
		RTPlane()	{};
		~RTPlane() {};
		
		void	setParameter( VERTEX3D _center, VERTEX3D _normal );
		void	preparePerFrame( RTCamera *camera );
		U32		get2DBoundingBoxHit( S32 x, S32 y );
		U32		getFirstHit( VERTEX3D *r, FLOAT *t );
		U32		getIntersection( RAY *r, FLOAT *t );
		void	getNormal( VERTEX3D *pos, VERTEX3D *nrml );
};

#endif