////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Echtzeit Raytracing: Screenspace Quadtree             //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#ifndef QUADTREE__H
#define QUADTREE__H

#include "vertex3dop.h"
#include "RTObject.h"

typedef struct
{
	U32			flag;
	VERTEX3D	lighting;
}TRACEDPOINT;

extern int virtualResolutions[6][2];

extern int virtualRes;

extern int VIRTUAL_X_RES;
extern int VIRTUAL_Y_RES;
extern int BLOCKSIZE;

extern U32 displayFirstRays;
extern U32 displayBoundingBoxes;


void initQuadtree();
void clearQuadtree();
void renderQuadtree();

extern void evaluate( const int x, const int y );
extern void interpolate( const int x1, const int y1, const int x2, const int y2, const int xd, const int yd );
extern void	traceBlock( const int x, const int y, const int size );


#endif