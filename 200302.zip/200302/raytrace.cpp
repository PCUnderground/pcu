////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Echtzeit Raytracing: Raytracing Routinen              //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include	<windows.h>
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	"raytrace.h"

U32				nPrimitives;
RTObject		*pPrimitives[ 100 ];

U32				nOmniLights;
RTLight			pOmniLights[ 4 ];

U32				displayBoundingBoxes = 0;

void renderBoundingBoxes()
{
	if ( displayBoundingBoxes )
	{
		glColor3ub( 255, 255, 255 );
		for ( U32 i = 0; i < nPrimitives; i++ )
		{
			RTObject *o = pPrimitives[ i ];
			glBegin( GL_LINE_STRIP );
			glVertex2d( o->minX, o->minY );
			glVertex2d( o->maxX, o->minY );
			glVertex2d( o->maxX, o->maxY );
			glVertex2d( o->minX, o->maxY );
			glVertex2d( o->minX, o->minY );
			glEnd();
		}
	}
}

// normale Funktion zum Suchen des n�chsten Schnittpunktes
__forceinline void traceRay( RAY *ray )
{
	FLOAT	    dist[ 8 ];

	extern int nRaysTotal;
	nRaysTotal ++;

	RTObject	*noIntersection = ray->hit;

	ray->hit     = NULL;
	ray->hitFlag = 0;

	RTObject	**primitive = &pPrimitives[ 0 ];
	// alle Primitive
	for ( U32 i = 0; i < nPrimitives; i++, primitive ++ )
	{
		// dieses vielleicht auslassen ?
		if ( (*primitive) == noIntersection )
			continue;

		// schnittpunkt berechnen
		if ( (*primitive)->getIntersection( ray, (FLOAT*)&dist ) )
		{
			// kleinsten speichern
			if ( SIR( dist[ 0 ] ) > 0 && 
				 SIR( dist[ 0 ] ) < SIR( ray->distance ) )
			{
				SIR( ray->distance ) = SIR( dist[ 0 ] );
				ray->hitFlag = i + 1;
				ray->hit = (*primitive);
			}
		}
	}
}

// Spezielles Schnittpunktberechnen f�r First Hit Case !
__forceinline void traceRayDepth0( RAY *ray, const int x, const int y )
{
	extern int nRaysTotal;
	nRaysTotal ++;

	FLOAT	    dist[ 8 ];
	RTObject	*noIntersection = ray->hit;
	
	ray->hit     = NULL;
	ray->hitFlag = 0;

	RTObject	**primitive = &pPrimitives[ 0 ];
	for ( U32 i = 0; i < nPrimitives; i++, primitive ++ )
	{
		if ( (*primitive)->get2DBoundingBoxHit( x, y ) &&
			 (*primitive)->getFirstHit( &ray->dir, (FLOAT*)&dist ) )
			 //(*primitive)->getIntersection( ray, (FLOAT*)&dist ) )			 
		{
			if ( SIR( dist[ 0 ] ) > 0 && 
				 SIR( dist[ 0 ] ) < SIR( ray->distance ) )
			{
				SIR( ray->distance ) = SIR( dist[ 0 ] );
				ray->hitFlag = i + 1;
				ray->hit = (*primitive);
			}
		}
	}
}

// Spezielles Schnittpunktberechnen f�r Shadow Rays !
__forceinline void traceShadowRay( RAY *ray, RTObject **cache )
{
	extern int nRaysTotal;
	nRaysTotal ++;

	RTObject	*noIntersection = ray->hit;
	
	ray->hit = NULL;

	FLOAT	dist[ 8 ];

	// shadow cache test zuerst !
	if ( *cache != NULL )
	if ( (*cache)->getIntersection( ray, (FLOAT*)&dist ) )
	{
		if ( SIR( dist[ 0 ] ) > 0 && 
			 SIR( dist[ 0 ] ) < SIR( ray->distance ) )
		{
			extern int shadowCacheHit;
			shadowCacheHit ++;

			ray->hit = *cache;
			return;
		}
	}

	RTObject	**primitive = &pPrimitives[ 0 ];
	for ( U32 i = 0; i < nPrimitives; i++, primitive ++ )
	{
		if ( (*primitive) == noIntersection || (*primitive) == *cache )
			continue;

		if ( (*primitive)->getIntersection( ray, (FLOAT*)&dist ) )
		{
			if ( SIR( dist[ 0 ] ) > 0 && 
				 SIR( dist[ 0 ] ) < SIR( ray->distance ) )
			{
				ray->hit = *cache = *primitive;
				return;
			}
		}
	}
}


// Raytracing f�r einen Pixel, bzw. tiefere Rekursionsstufen
void	raytrace( RAY *ray, TRACEDPOINT *trace, const int depth, const int x, const int y )
{
	VERTEX3D  normal;

	trace->flag = 
	IR(trace->lighting.x) = 
	IR(trace->lighting.y) = 
	IR(trace->lighting.z) = 0;

	// maximale Tiefe
	if ( depth >= 2 )
	{
		ray->hit = 0;
		return;
	}

	if ( depth == 0 )
		traceRayDepth0( ray, x, y ); else
		traceRay( ray );		

	if ( ray->hit )
	{
		// calculate intersection location and normal !
		ray->from += ( ray->dir * ray->distance );

		ray->hit->getNormal( &ray->from, &normal );

		U32 surfaceCode = ( ray->hit->getAdditionalSubdivideCriteria() << 6 ) | (int)ray->hitFlag;

		// ambient light
		VERTEX3D lighting = ray->hit->color * 0.2f;

		RAY shadowRay, mirrorRay;

		// reflektierter Blickstrahl (f�r Specular Lighting und Spiegelung)
		FLOAT g = - ( normal * ray->dir );
		g += g;
		mirrorRay.dir = ( normal * g ) + ray->dir;
		~mirrorRay.dir;


		for ( U32 l = 0; l < nOmniLights; l ++ )
		{
			//
			// Shadow Test
			// 
			shadowRay.hit      = ray->hit;
			shadowRay.from     = ray->from;
			shadowRay.dir      = pOmniLights[ l ].pos - shadowRay.from;
			shadowRay.hitTest  = 1;

			shadowRay.distance = ~shadowRay.dir;

			FLOAT lambert = ( normal * shadowRay.dir );

			// r�ckseite eines primitivs ? >= liegt im schatten 
			if ( SIR( lambert ) <= 0 )
			{
				IR( lambert ) = 0;
				goto noShadowTestRequired;
			}

			// die getroffene oberfl�che wird automatisch beim n�chsten schnitttest �bergangen
			// ist gespeichert in shadowRay.hit

			extern int nShadowRays;
			nShadowRays ++;

			traceShadowRay( &shadowRay, &pOmniLights[ l ].shadowCache );

			if ( shadowRay.hit )
			{
				surfaceCode |= (1<<l)<<8;
			} else
			{
			noShadowTestRequired:
				// diffuse
				VERTEX3D diffuse = pOmniLights[ l ].color * lambert;
				lighting.x += diffuse.x * ray->hit->color.x;
				lighting.y += diffuse.y * ray->hit->color.y;
				lighting.z += diffuse.z * ray->hit->color.z;

				// specular
				FLOAT	specular = shadowRay.dir * mirrorRay.dir;

				if ( SIR( specular ) > 0 )
				{
					specular *= specular;
					specular *= specular;
					specular *= specular;
					lighting += pOmniLights[ l ].color * specular;
				}

			}
		}

		trace->flag |= surfaceCode << ( depth * 10 );
		trace->lighting = lighting;

		// Spiegelung berechnen ???
		if ( depth == 0 && IR( ray->hit->reflection ) )
		{
			TRACEDPOINT traceMirror;

			mirrorRay.from     = ray->from;
			mirrorRay.hit      = ray->hit;
			mirrorRay.distance = 1e37f;
			mirrorRay.hitTest  = 0;

			raytrace( &mirrorRay, &traceMirror, depth + 1 );

			if ( mirrorRay.hit )
			{
				trace->lighting      *= ray->hit->invReflection;
				traceMirror.lighting *= ray->hit->reflection; 
				trace->lighting      += traceMirror.lighting;

				// neue surface id
				trace->flag |= traceMirror.flag << (depth*10);
			}
		}
			
	}
}
