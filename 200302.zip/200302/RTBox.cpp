////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Echtzeit Raytracing: Schnittpunktberechnung           //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include "RTObject.h"
#include "RTCamera.h"

void RTBox::setParameter( VERTEX3D _center, VERTEX3D _extent ) 
{
	this->center = _center;
	this->extent = _extent;

	this->div[ 0 ] = 1.0f / _extent.x;
	this->div[ 1 ] = 1.0f / _extent.y;
	this->div[ 2 ] = 1.0f / _extent.z;

	VERTEX3D vmin = _center - _extent;
	VERTEX3D vmax = _center + _extent;

	aabb[ 0 ].x = vmin.x;	aabb[ 0 ].y = vmin.y;	aabb[ 0 ].z = vmin.z;
	aabb[ 1 ].x = vmax.x;	aabb[ 1 ].y = vmin.y;	aabb[ 1 ].z = vmin.z;
	aabb[ 2 ].x = vmin.x;	aabb[ 2 ].y = vmax.y;	aabb[ 2 ].z = vmin.z;
	aabb[ 3 ].x = vmax.x;	aabb[ 3 ].y = vmax.y;	aabb[ 3 ].z = vmin.z;
	aabb[ 4 ].x = vmin.x;	aabb[ 4 ].y = vmin.y;	aabb[ 4 ].z = vmax.z;
	aabb[ 5 ].x = vmax.x;	aabb[ 5 ].y = vmin.y;	aabb[ 5 ].z = vmax.z;
	aabb[ 6 ].x = vmin.x;	aabb[ 6 ].y = vmax.y;	aabb[ 6 ].z = vmax.z;
	aabb[ 7 ].x = vmax.x;	aabb[ 7 ].y = vmax.y;	aabb[ 7 ].z = vmax.z;
};

void RTBox::preparePerFrame( RTCamera *camera )
{
	intersectViewingPlane = 1;

	this->camPos = camera->from;

	intersectViewingPlane = 0;
	minX = VIRTUAL_X_RES;
	minY = VIRTUAL_Y_RES;
	maxX = maxY = 0;

	for ( int i = 0; i < 8; i++ )
	{
		S32 xp, yp;
		FLOAT fxp, fyp;
		if ( camera->projectVertex( aabb[ i ], &fxp, &fyp ) )
		{
			xp = (S32)fxp; yp = (S32)fyp;
			minX = min( xp, minX ); maxX = max( xp, maxX );
			minY = min( yp, minY ); maxY = max( yp, maxY );
		} else
		{
			intersectViewingPlane ++;
			return;
		}
	}
};

U32  RTBox::get2DBoundingBoxHit( S32 x, S32 y ) 
{ 
	if ( intersectViewingPlane ||
		 ( minX <= x && x <= maxX &&
		   minY <= y && y <= maxY ) )
		   return 1;
	return 0;			
};

U32 RTBox::getFirstHit( VERTEX3D *r, FLOAT *t )
{
	RAY ray;
	ray.from = this->camPos;
	ray.dir = *r;
	return getIntersection( &ray, t );
};

/*
 *	A method to compute a ray-AABB intersection.
 *	Original code by Andrew Woo, from "Graphics Gems", Academic Press, 1990
 *	Optimized code by Pierre Terdiman, 2000 (~20-30% faster on my Celeron 500)
 *	Epsilon value added by Klaus Hartmann. (discarding it saves a few cycles only)
 *  Modified for RTRT, added normal calculation - Carsten Dachsbacher
 *
*/
U32 RTBox::getIntersection( RAY *r, FLOAT *t )
{
	BOOL Inside = true;

	float MinB[ 3 ], MaxB[ 3 ], MaxT[ 3 ] = { -1.0f, -1.0f, -1.0f };

	*(VERTEX3D*)MinB = this->center - this->extent;
	*(VERTEX3D*)MaxB = this->center + this->extent;

	float *origin = (float*)&r->from;
	float *dir    = (float*)&r->dir;
	float *coord  = (float*)&this->intersection;

	for( U32 i = 0; i < 3; i++ )
	{
		if( origin[ i ] < MinB[ i ] )
		{
			coord[i]	= MinB[ i ];
			Inside		= false;

			if( IR( dir[ i ] ) )	
				MaxT[ i ] = ( MinB[ i ] - origin[ i ] ) / dir[ i ];
		}
		else if(origin[i] > MaxB[i])
		{
			coord[i]	= MaxB[i];
			Inside		= false;

			if( IR( dir[ i ] ) )	
				MaxT[ i ] = ( MaxB[ i ] - origin[ i ] ) / dir[ i ];
		}
	}

	whichPlane = 0;
	if( MaxT[ 1 ] > MaxT[ whichPlane ] ) whichPlane = 1;
	if( MaxT[ 2 ] > MaxT[ whichPlane ] ) whichPlane = 2;

	if( IR( MaxT[ whichPlane ] ) & 0x80000000 ) return 0;

	for( i = 0; i < 3; i++ )
	{
		if( i != whichPlane )
		{
			coord[ i ] = origin[ i ] + MaxT[ whichPlane ] * dir[ i ];

			if( coord[ i ] < MinB[ i ] - RAYAABB_EPSILON || 
				coord[ i ] > MaxB[ i ] + RAYAABB_EPSILON )
				return 0;
			
			((float*)&this->normal)[ i ] = 0.0f;
		} else
		{
			float *cen = (float*)&this->center;
			((float*)&this->normal)[ i ] = ( coord[ i ] - cen[ i ] ) * div[ i ];

		}
	}

	*t = MaxT[ whichPlane ];

	return 1;
};

void RTBox::getNormal( VERTEX3D *pos, VERTEX3D *nrml ) 
{
	*nrml = this->normal;
};

const U32	 RTBox::getAdditionalSubdivideCriteria() 
{ 
	return whichPlane; 
};
