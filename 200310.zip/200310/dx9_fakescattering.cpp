   //  
  // PC Underground: DX9 Part IV - Translucency
 // (w)(c)2003 Carsten Dachsbacher
//

#include <windows.h>
#include <d3dx9.h>
#include "resource.h"

//#define USE_PS20

const bool  DX9Fullscreen = FALSE;
const DWORD	DX9ScreenX    = 512;
const DWORD	DX9ScreenY    = 512;
const DWORD DX9Refresh    = 75;

const char windowTitle[] = "PCUvsD3D9 Translucency";

#define	RENDERTOSURFACE_WIDTH	512
#define	RENDERTOSURFACE_HEIGHT	512

HWND					gHWND      = NULL;
LPDIRECT3D9				pD3D       = NULL;
LPDIRECT3DDEVICE9		pD3DDevice = NULL;

LPDIRECT3DTEXTURE9      pDynamicTexture4  = NULL;
LPD3DXRENDERTOSURFACE   pRenderSurface4   = NULL;
LPDIRECT3DSURFACE9      pTextureSurface4  = NULL;
LPDIRECT3DTEXTURE9      pDynamicTexture3  = NULL;
LPD3DXRENDERTOSURFACE   pRenderSurface3   = NULL;
LPDIRECT3DSURFACE9      pTextureSurface3  = NULL;
LPDIRECT3DTEXTURE9      pDynamicTexture2  = NULL;
LPD3DXRENDERTOSURFACE   pRenderSurface2   = NULL;
LPDIRECT3DSURFACE9      pTextureSurface2  = NULL;
LPDIRECT3DTEXTURE9      pDynamicTexture1  = NULL;
LPD3DXRENDERTOSURFACE   pRenderSurface1   = NULL;
LPDIRECT3DSURFACE9      pTextureSurface1  = NULL;

LPDIRECT3DVERTEXSHADER9 pVertexShader      = NULL;
LPDIRECT3DVERTEXSHADER9 pVertexShaderDec13 = NULL;

LPDIRECT3DPIXELSHADER9  pPixelShader       = NULL;
LPDIRECT3DPIXELSHADER9  pPixelShaderSub13  = NULL;
LPDIRECT3DPIXELSHADER9  pPixelShaderDec13  = NULL;

LPDIRECT3DTEXTURE9			pTextureLUT    = NULL;

LPDIRECT3DVOLUMETEXTURE9    pRampTexture   = NULL;

#include <stdio.h>
#include "vertex3dop.h"
#include "obj.h"

  //
 // prototypes
//
int WINAPI WinMain( HINSTANCE hInst, HINSTANCE hPrevInst,
                    LPSTR lpCmdLine, int nCmdShow );

void	initialize3D();
void	shutdown3D();
void	render3D();

  //
 // WindowProc: Window Class Message Handler
//
LRESULT CALLBACK WindowProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
    switch( msg )
	{
        case WM_KEYDOWN:
			if ( wParam == VK_ESCAPE )
				PostQuitMessage(0);

	        break;

		case WM_CLOSE:
        case WM_DESTROY:
            PostQuitMessage(0);
	        break;

		default:
			return DefWindowProc( hWnd, msg, wParam, lParam );
	}

	return 0;
}

  //
 // WinMain: Register Window Class, Create Window and wait until program end
//
int WINAPI WinMain( HINSTANCE hInst,
                    HINSTANCE hPrevInst,
                    LPSTR     lpCmdLine,
                    int       nCmdShow )
{
	WNDCLASSEX wndClass;

	wndClass.lpszClassName = "PCUvsD3D9";
	wndClass.cbSize        = sizeof( WNDCLASSEX );
	wndClass.style         = CS_HREDRAW | CS_VREDRAW;
	wndClass.lpfnWndProc   = WindowProc;
	wndClass.cbClsExtra    = 0;
	wndClass.cbWndExtra    = 0;
	wndClass.hInstance     = hInst;
	wndClass.hIcon	       = LoadIcon( hInst, (LPCTSTR)IDI_PCUICON );
	wndClass.hCursor       = LoadCursor( NULL, IDC_ARROW );
	wndClass.hbrBackground = (HBRUSH)GetStockObject( BLACK_BRUSH );
    wndClass.hIconSm	   = NULL;
	wndClass.lpszMenuName  = NULL;

	if( RegisterClassEx( &wndClass) == 0 ) return E_FAIL;

	DWORD windowParam;

	if ( DX9Fullscreen )
		windowParam = WS_POPUP | WS_SYSMENU | WS_VISIBLE; else
		windowParam = WS_OVERLAPPEDWINDOW | WS_VISIBLE;

	gHWND = CreateWindowEx( NULL, "PCUvsD3D9", windowTitle,
							 windowParam, 0, 0, 
							 DX9ScreenX, DX9ScreenY, 
							 NULL, NULL, hInst, NULL );

	if( gHWND == NULL ) return E_FAIL;

    ShowWindow( gHWND, nCmdShow );
    UpdateWindow( gHWND );

	initialize3D();
  
	MSG msg;
	ZeroMemory( &msg, sizeof( msg ) );

	while( msg.message != WM_QUIT )
	{
		if( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) )
		{ 
			TranslateMessage( &msg );
			DispatchMessage ( &msg );
		} else
		    render3D();
	}

	shutdown3D();

    UnregisterClass( "PCUvsD3D9", wndClass.hInstance );

	return msg.wParam;
}


  //
 // error: Display error message and quit program
//
void error( char *msg = NULL )
{
	if ( msg )
		MessageBox( NULL, msg, "PCUvsDX9", MB_OK | MB_ICONEXCLAMATION ); else
		MessageBox( NULL, "Error occured !", "PCUvsDX9", MB_OK | MB_ICONEXCLAMATION );

	shutdown3D();

	exit( 1 );
}

OBJmodel *al;

//
// This function is used to calculate the color ramp texture
//
void makeScatteringLUT( float eta, float sigma_a, float sigma_s_, float *LUT )
{
	float F_dr = -1.440f / ( eta * eta ) + 0.710f / eta + 0.668f + 0.0636f * eta;
	float A = ( 1.0f + F_dr ) / ( 1.0f - F_dr );


	float sigma_t_ = sigma_a + sigma_s_;
	float D = 1.0f / ( 3.0f * sigma_t_ );

	float alpha_ = sigma_s_ + sigma_t_;
	float sigma_tr = sqrtf( 3.0f * sigma_a * sigma_t_ );
	float z_r = 1.0f / sigma_t_;
	float z_v = z_r + 4.0f * A * D;
	
	for ( int i = 0; i < 256; i++ )
	{
		float distW = (float)( 255 - i ) / 256.0f;

		float d = 1.0f / distW;
		 
		float expTerm = ( sigma_tr * d + 1.0f ) * expf( -sigma_tr * d ) / (sigma_t_*d*d*d);

		float scattered = alpha_ / ( 4.0f * 3.141592f ) * ( z_r * expTerm + z_v * expTerm );
		
		LUT[ i ] = scattered;

		if ( LUT[ i ] > 1.0f ) LUT[ i ] = 1.0f;
		if ( LUT[ i ] < 0.0f ) LUT[ i ] = 0.0f;
	}
}

void createRenderToTexture( int width, int height, LPDIRECT3DTEXTURE9 *pDynamicTexture, LPDIRECT3DSURFACE9 *pTextureSurface, LPD3DXRENDERTOSURFACE *pRenderSurface )
{
	D3DXCreateTexture( pD3DDevice, 
		                    width, 
		                    height, 
							1, 
							D3DUSAGE_RENDERTARGET, 
							D3DFMT_A8R8G8B8, 
							D3DPOOL_DEFAULT, 
							pDynamicTexture );

	//
	// create off-screen surface
	//

    D3DSURFACE_DESC desc;
    (*pDynamicTexture)->GetSurfaceLevel( 0, pTextureSurface );
    (*pTextureSurface)->GetDesc( &desc );

	D3DXCreateRenderToSurface( pD3DDevice, 
	                            desc.Width, 
	                            desc.Height, 
	                            desc.Format, 
	                            TRUE, 
	                            D3DFMT_D16, 
	                            pRenderSurface );

}

  //
 // initialize3D: initialize Direct3D stuff
//
void initialize3D( void )
{
	HRESULT			hr;
	D3DDISPLAYMODE	dm;

    pD3D = Direct3DCreate9( D3D_SDK_VERSION );

	if( pD3D == NULL ) error( "Error creating Direct3D Object" );

	if ( DX9Fullscreen )
	{
		// fullscreen
		//
		int nMaxModes = pD3D->GetAdapterModeCount( D3DADAPTER_DEFAULT, D3DFMT_X8R8G8B8 );

		bool foundMode = false;

		for( int m = 0; m < nMaxModes; m ++ )
		{
		  if ( FAILED( pD3D->EnumAdapterModes( D3DADAPTER_DEFAULT, 
											   D3DFMT_X8R8G8B8, m, &dm ) ) )
			 error( "Error enumerating adapter mode" );

		  if ( dm.Width  != DX9ScreenX || 
			   dm.Height != DX9ScreenY ||
			   dm.RefreshRate != DX9Refresh ||
			   dm.Format != D3DFMT_X8R8G8B8 )
			   continue;

		  foundMode = true;
		  break;
		}

		if ( foundMode == false )
		  error( "Not suitable graphic mode found !" );

		if ( FAILED( pD3D->CheckDeviceType( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL,
											D3DFMT_X8R8G8B8, D3DFMT_X8R8G8B8, FALSE ) ) )
		   error( "No hardware acceleration for this graphic mode !" );
	} else
	{
		// windowed
		//
		if( FAILED( pD3D->GetAdapterDisplayMode( D3DADAPTER_DEFAULT, &dm ) ) )
			error( "Error getting Adapter Display Mode" );
	}

	hr = pD3D->CheckDeviceFormat( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, 
								  dm.Format, D3DUSAGE_DEPTHSTENCIL,
								  D3DRTYPE_SURFACE, D3DFMT_D16 );

	if ( hr == D3DERR_NOTAVAILABLE ) error( "Desired Z-Buffer Format (16Bit) not available" );

	D3DCAPS9 caps;

	if( FAILED( pD3D->GetDeviceCaps( D3DADAPTER_DEFAULT, 
									 D3DDEVTYPE_HAL, &caps ) ) )
		error( "Error reading Device Caps" );
	
	DWORD flags = 0;

	if( caps.VertexProcessingCaps != 0 )
		flags |= D3DCREATE_HARDWARE_VERTEXPROCESSING;
	else
		flags |= D3DCREATE_SOFTWARE_VERTEXPROCESSING;

	D3DPRESENT_PARAMETERS pp;
	ZeroMemory( &pp, sizeof( pp ) );

	pp.BackBufferFormat       = dm.Format;
	pp.SwapEffect             = D3DSWAPEFFECT_DISCARD;
	pp.Windowed               = !DX9Fullscreen;
	pp.EnableAutoDepthStencil = TRUE;
	pp.AutoDepthStencilFormat = D3DFMT_D16;
	pp.BackBufferWidth        = DX9ScreenX;
    pp.BackBufferHeight       = DX9ScreenY;
    pp.BackBufferFormat       = D3DFMT_X8R8G8B8;

	if( FAILED( pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, gHWND,
									  flags, &pp, &pD3DDevice ) ) )
		error( "Error creating Direct3D device" );


	//
	// Init Demo Stuff
	//

	//
	// Material Parameters
	//
	D3DMATERIAL9 mat;

	ZeroMemory( &mat, sizeof( D3DMATERIAL9 ) );

	mat.Ambient.r  =
	mat.Ambient.g  =
	mat.Ambient.b  =
	mat.Ambient.a  = 0.0f;
	mat.Diffuse.r  = 0.0f;
	mat.Diffuse.g  = 0.0f;
	mat.Diffuse.b  = 0.0f;
	mat.Diffuse.a  = 1.0f;
	mat.Specular.r =
	mat.Specular.g = 
	mat.Specular.b = 
	mat.Specular.a = 1.0f;
	mat.Power      = 10.0f;

	pD3DDevice->SetMaterial( &mat );

	//
	// Light Sources
	//
	D3DLIGHT9 light;
	
	ZeroMemory( &light, sizeof( D3DLIGHT9 ) );

	// common light parameter
	light.Diffuse.r  = 0.0f;
	light.Diffuse.g  = 0.0f;
	light.Diffuse.b  = 0.0f;
	light.Specular.r = 1.0f;
	light.Specular.g = 1.0f;
	light.Specular.b = 1.0f;
	light.Range      = 100.0f;
	light.Attenuation0 = 0.0f;
	light.Attenuation2 = 0.0f;

	// directional light
	light.Type = D3DLIGHT_DIRECTIONAL;

	light.Direction = D3DXVECTOR3( 1.0f, -1.0f, 0.0f );

	pD3DDevice->SetLight( 0, &light );

	pD3DDevice->SetRenderState( D3DRS_LIGHTING, FALSE );
	pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

	pD3DDevice->SetRenderState( D3DRS_ZENABLE, TRUE );
	pD3DDevice->SetRenderState( D3DRS_ZFUNC, D3DCMP_LESSEQUAL );

	pD3DDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID );

	al = new OBJmodel();
	//al->readOBJ( "./data/deer.obj" );
	al->readOBJ( "./data/beethoven.obj" );
	//al->readOBJ( "./data/horse10k.obj" );
	//al->readOBJ( "./data/model3.obj" );

	al->scaleIsotropic();
	al->buildVertexBuffer( pD3DDevice, RENDER_SMOOTH_SHADED );

	//
	// Vertex/Pixel Shader
	//

#ifdef USE_PS20
	if ( caps.PixelShaderVersion < D3DVS_VERSION(2,0) )
		exit( 1 );
#else
	if ( caps.PixelShaderVersion < D3DVS_VERSION(1,0) )
		exit( 1 );
#endif

	if ( caps.VertexShaderVersion < D3DVS_VERSION(1,0) )
		exit( 1 );


    DWORD dwFlags = 0;
    LPD3DXBUFFER pCode;

	// Vertex Shader
    D3DXAssembleShaderFromFile( "depth_encode.vp", NULL, NULL, dwFlags, &pCode, NULL );
	pD3DDevice->CreateVertexShader( (DWORD*)pCode->GetBufferPointer(), &pVertexShader );
	pCode->Release();

	//
	// Vertex/Pixel Shader 2.0
	//
#ifdef USE_PS20

    D3DXAssembleShaderFromFile( "depth_subdecode20.ps", NULL, NULL, dwFlags, &pCode, NULL );
	pD3DDevice->CreatePixelShader( (DWORD*)pCode->GetBufferPointer(), &pPixelShader );
	pCode->Release();
#else
	//
	// Vertex/Pixel Shader 1.0
	//
    D3DXAssembleShaderFromFile( "depth_decode10.vp", NULL, NULL, dwFlags, &pCode, NULL );
	pD3DDevice->CreateVertexShader( (DWORD*)pCode->GetBufferPointer(), &pVertexShaderDec13 );
	pCode->Release();

    D3DXAssembleShaderFromFile( "depth_subtract10.ps", NULL, NULL, dwFlags, &pCode, NULL );
	pD3DDevice->CreatePixelShader( (DWORD*)pCode->GetBufferPointer(), &pPixelShaderSub13 );
	pCode->Release();

    D3DXAssembleShaderFromFile( "depth_decode10.ps", NULL, NULL, dwFlags, &pCode, NULL );
	pD3DDevice->CreatePixelShader( (DWORD*)pCode->GetBufferPointer(), &pPixelShaderDec13 );
	pCode->Release();
#endif

	//
	// make color look up table
	//
	pD3DDevice->CreateTexture(  256, 1, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &pTextureLUT, NULL );

	D3DLOCKED_RECT lockedRect;

	pTextureLUT->LockRect( 0, &lockedRect, NULL, 0 );

    unsigned char *pDst = (unsigned char *)lockedRect.pBits;

	float LUT_R[ 256 ];
	float LUT_G[ 256 ];
	float LUT_B[ 256 ];

	float eta = 1.3f;

	makeScatteringLUT( eta, 0.0014f, 0.70f, LUT_G );
	makeScatteringLUT( eta, 0.0025f, 1.22f, LUT_R );
	makeScatteringLUT( eta, 0.0142f, 1.90f, LUT_B );

    for( DWORD y = 0; y < 1; y++ )
    {
        unsigned char *pPixel = pDst;

        for( DWORD x = 0; x < 256; x++ )
        {
			int idx;
			
#ifdef USE_PS20
			idx = x;
#else
			idx = 255 - x;
#endif
			if ( idx == 0 )
			{
				*pPixel++ = 
				*pPixel++ = 
				*pPixel++ = 0;
				*pPixel++ = 255;
			} else
			{
				*pPixel++ = (unsigned char)( LUT_R[ idx ] * 255.0f );
				*pPixel++ = (unsigned char)( LUT_G[ idx ] * 255.0f );
				*pPixel++ = (unsigned char)( LUT_B[ idx ] * 255.0f );
				*pPixel++ = 255;
			}
        }
        pDst += lockedRect.Pitch;
    }
    pTextureLUT->UnlockRect(0);


	//
	// make 3D color ramp texture
	//
    hr = pD3DDevice->CreateVolumeTexture( 16, 16, 16, 1, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &pRampTexture, NULL );

	D3DLOCKED_BOX lockedBox;

	hr = pRampTexture->LockBox( 0, &lockedBox, NULL, 0 );

    for( UINT w=0; w<16; w++ )
    {
        BYTE* pSliceStart = (BYTE*)lockedBox.pBits;

        for( UINT v=0; v<16; v++ )
        {
            for( UINT u=0; u<16; u++ )
            {
				int r, g, b;
				
				r = u;
				g = v;
				b = w;

                ((DWORD*)lockedBox.pBits)[u] =  + (r<<16) + (g<<8) + (b);
            }
            lockedBox.pBits = (BYTE*)lockedBox.pBits + lockedBox.RowPitch;
        }
        lockedBox.pBits = pSliceStart + lockedBox.SlicePitch;
    }

	pRampTexture->UnlockBox( 0 );


	//
	// create dynamic render-to textures
	//
	createRenderToTexture( RENDERTOSURFACE_WIDTH, RENDERTOSURFACE_HEIGHT, &pDynamicTexture1, &pTextureSurface1, &pRenderSurface1 );
	createRenderToTexture( RENDERTOSURFACE_WIDTH, RENDERTOSURFACE_HEIGHT, &pDynamicTexture2, &pTextureSurface2, &pRenderSurface2 );
	createRenderToTexture( RENDERTOSURFACE_WIDTH, RENDERTOSURFACE_HEIGHT, &pDynamicTexture3, &pTextureSurface3, &pRenderSurface3 );
	createRenderToTexture( RENDERTOSURFACE_WIDTH, RENDERTOSURFACE_HEIGHT, &pDynamicTexture4, &pTextureSurface4, &pRenderSurface4 );
}

typedef struct
{
	float x, y, z, u, v, s, t, r, q;
}TEXTUREDVERTEX;

TEXTUREDVERTEX screenQuad[] =
{
	{ -1, -1, 0, 0, 1, 0, 1, 0, 1 },
	{ -1,  1, 0, 0, 0, 0, 0, 0, 0 },
	{  1, -1, 0, 1, 1, 1, 1, 1, 1 },
	{  1,  1, 0, 1, 0, 1, 0, 1, 0 },
};

float encodeScale = 1.0f;
float encode2L    = 16.0f;
float encode22L   = 16.0f * 16.0f;

void	renderScene()
{
	// set up matrices
	D3DXMATRIX mProjection;

	float zNear = 3.0f, zFar = 30.0f;

	D3DXMatrixPerspectiveFovLH( &mProjection, 45.0f, (float)DX9ScreenX/(float)DX9ScreenY, zNear, zFar );
	pD3DDevice->SetTransform( D3DTS_PROJECTION, &mProjection );

	float time = GetTickCount() * 0.02f;
    float rotateZ = 0.0f;
	float rotateY = 0.0f;
	float rotateX = time;
	
    D3DXMATRIX matWorld;
    D3DXMATRIX matTrans;
	D3DXMATRIX matRot;
	D3DXMATRIX matView;

    D3DXMatrixIdentity( &matView );
	
	// camera distance
    D3DXMatrixTranslation( &matTrans, 0.0f, 0.2f, 11.0f );

	// rotation matrix
	D3DXMatrixRotationYawPitchRoll( &matRot, D3DXToRadian( rotateX ),  D3DXToRadian( rotateY ), D3DXToRadian( rotateZ ) );

    matWorld = matRot * matTrans;
    pD3DDevice->SetTransform( D3DTS_WORLD, &matWorld );

	//
	// set shaders + constants
	//
    D3DXMATRIX modelViewProjection = matWorld * matView * mProjection;
	D3DXMatrixTranspose( &modelViewProjection, &modelViewProjection );

    // Load the combined model-view-projection matrix in registers c[0]-c[3]
    pD3DDevice->SetVertexShaderConstantF( 0, (float*)modelViewProjection, 4 );

	// prepare w-depth normalization
	float depthNormalize[ 4 ] =	{ 1.0f / ( zFar - zNear ),
								  -zNear / ( zFar - zNear ),
								  0.0f, 1.0f }; 

	pD3DDevice->SetVertexShaderConstantF( 10, depthNormalize, 1 );

	// prepare ramp scale (for 3d texture look up)
	float rampScale[ 4 ] = {	encodeScale,
								encode2L * encodeScale,
								encode22L * encodeScale,
								1.0f };

	pD3DDevice->SetVertexShaderConstantF( 20, rampScale, 1 );


	pD3DDevice->SetTexture( 0, NULL );
	pD3DDevice->SetTexture( 1, NULL );

	pD3DDevice->SetTexture( 0, pRampTexture );
	pD3DDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_POINT );
	pD3DDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_POINT );

	// render mesh
	al->drawModel( pD3DDevice );
}

// render screen aligned quad
void	renderScreenQuad()
{
    pD3DDevice->SetFVF( D3DFVF_XYZ|D3DFVF_TEX3 );

	pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );
	pD3DDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, screenQuad, sizeof( TEXTUREDVERTEX ) );
}


  //
 // render3D: render loop
//
void render3D()
{
	pD3DDevice->LightEnable( 0, FALSE );
    pD3DDevice->SetRenderState( D3DRS_SPECULARENABLE, FALSE );
	pD3DDevice->SetRenderState( D3DRS_LIGHTING, FALSE );
	
	pD3DDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, true );
	pD3DDevice->SetRenderState( D3DRS_SRCBLEND,			D3DBLEND_ONE );
	pD3DDevice->SetRenderState( D3DRS_DESTBLEND,		D3DBLEND_ONE );
	pD3DDevice->SetRenderState( D3DRS_BLENDOP,			D3DBLENDOP_ADD );

	pD3DDevice->SetRenderState( D3DRS_ZENABLE,		false );
	pD3DDevice->SetRenderState( D3DRS_ZWRITEENABLE,	false );
	pD3DDevice->SetRenderState( D3DRS_ZFUNC,		D3DCMP_ALWAYS );

    pD3DDevice->SetVertexShader( pVertexShader );

	//
	// pass 1: sum of backface depths
	//
	pRenderSurface1->BeginScene( pTextureSurface1, NULL );

    pD3DDevice->Clear( 0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
                       0x00000000, 0.0f, 0 );

	pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CW );
	renderScene();


    pRenderSurface1->EndScene( 0 );

	//
	// pass 2: sum of frontface depths
	//
	pRenderSurface2->BeginScene( pTextureSurface2, NULL );

    pD3DDevice->Clear( 0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
                       0x00000000, 1.0f, 0 );

	pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );
	renderScene();

    pRenderSurface2->EndScene( 0 );

	//
	// pass 3: specular highlights/local illumination
	//
	pRenderSurface3->BeginScene( pTextureSurface3, NULL );

    pD3DDevice->Clear( 0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
                       0x00000000, 1.0f, 0 );

    pD3DDevice->SetVertexShader( NULL );
	pD3DDevice->SetPixelShader ( NULL );

	pD3DDevice->SetRenderState ( D3DRS_ALPHABLENDENABLE, false );
	pD3DDevice->SetRenderState ( D3DRS_CULLMODE, D3DCULL_CCW );
	
	pD3DDevice->LightEnable    ( 0, true );
	pD3DDevice->SetRenderState ( D3DRS_LIGHTING, TRUE );
    pD3DDevice->SetRenderState ( D3DRS_SPECULARENABLE, TRUE );

	pD3DDevice->SetRenderState ( D3DRS_ZENABLE,		 true );
	pD3DDevice->SetRenderState ( D3DRS_ZWRITEENABLE, true );
	pD3DDevice->SetRenderState ( D3DRS_ZFUNC, D3DCMP_LESS );
	
	renderScene();
	
	pD3DDevice->LightEnable    ( 0, false );
    pD3DDevice->SetRenderState ( D3DRS_SPECULARENABLE, false );
	pD3DDevice->SetRenderState ( D3DRS_LIGHTING, false );

    pRenderSurface3->EndScene( 0 );

	//
	// pass 4a (pixel shader 2.0): calculate depth difference and color lookup
	//
#ifdef USE_PS20
    pD3DDevice->Clear( 0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
                       0x00303030, 1.0f, 0 );

    pD3DDevice->BeginScene();

	D3DXMATRIX matId;
    D3DXMatrixIdentity( &matId );

    pD3DDevice->SetTransform( D3DTS_WORLD, &matId );
    pD3DDevice->SetTransform( D3DTS_PROJECTION, &matId );

    pD3DDevice->SetVertexShader( NULL );
	pD3DDevice->SetPixelShader( pPixelShader );

	float decodeDotVector[4] = { 1.0f, 1.0f / encode2L, 1.0f / encode22L, 0.0f };

	float scale = 64.0f;
	
	decodeDotVector[ 0 ] *= scale;
	decodeDotVector[ 1 ] *= scale;
	decodeDotVector[ 2 ] *= scale;
	
	pD3DDevice->SetPixelShaderConstantF( 20, decodeDotVector, 1 );

    D3DXMatrixIdentity( &matId );

    pD3DDevice->SetTransform( D3DTS_WORLD, &matId );
    pD3DDevice->SetTransform( D3DTS_PROJECTION, &matId );

	pD3DDevice->SetTexture( 0, pDynamicTexture1 );
	pD3DDevice->SetTexture( 1, pDynamicTexture2 );
	pD3DDevice->SetTexture( 2, pDynamicTexture3 );

	pD3DDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_POINT );
	pD3DDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_POINT );
	pD3DDevice->SetSamplerState( 1, D3DSAMP_MINFILTER, D3DTEXF_POINT );
	pD3DDevice->SetSamplerState( 1, D3DSAMP_MAGFILTER, D3DTEXF_POINT );
	pD3DDevice->SetSamplerState( 2, D3DSAMP_MINFILTER, D3DTEXF_POINT );
	pD3DDevice->SetSamplerState( 2, D3DSAMP_MAGFILTER, D3DTEXF_POINT );

	pD3DDevice->SetTexture( 3, pTextureLUT );
	pD3DDevice->SetSamplerState( 3, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
	pD3DDevice->SetSamplerState( 3, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );
	
	pD3DDevice->SetSamplerState( 3, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	pD3DDevice->SetSamplerState( 3, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );

	renderScreenQuad();
#else
	//
	// pass 4b (pixel shader 1.0): calculate depth difference
	//
	pRenderSurface4->BeginScene( pTextureSurface4, NULL );

    pD3DDevice->Clear( 0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
                       0x00000000, 1.0f, 0 );

	D3DXMATRIX matId;
    D3DXMatrixIdentity( &matId );

    pD3DDevice->SetTransform( D3DTS_WORLD, &matId );
    pD3DDevice->SetTransform( D3DTS_PROJECTION, &matId );

    pD3DDevice->SetVertexShader( NULL );
	pD3DDevice->SetPixelShader( pPixelShaderSub13 );

	pD3DDevice->SetTexture( 0, pDynamicTexture1 );
	pD3DDevice->SetTexture( 1, pDynamicTexture2 );
	pD3DDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_POINT );
	pD3DDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_POINT );
	pD3DDevice->SetSamplerState( 1, D3DSAMP_MINFILTER, D3DTEXF_POINT );
	pD3DDevice->SetSamplerState( 1, D3DSAMP_MAGFILTER, D3DTEXF_POINT );

	renderScreenQuad();

    pRenderSurface4->EndScene( 0 );

	//
	// pass 5 (pixel shader 1.0): decode depth value and texture lookup
	//
    pD3DDevice->Clear( 0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
                       0x00303030, 1.0f, 0 );

    pD3DDevice->BeginScene();

	D3DXMatrixIdentity( &matId );

    pD3DDevice->SetVertexShader( pVertexShaderDec13 );
	pD3DDevice->SetPixelShader( pPixelShaderDec13 );

    pD3DDevice->SetVertexShaderConstantF( 0, (float*)matId, 4 );

	float decodeDotVector[4] = { 1.0f, 1.0f / encode2L, 1.0f / encode22L, 0.0f };

	float scale = 48.0f;
	float dofs =  0.004f + 0.50391f;
	
	decodeDotVector[ 0 ] *= scale;
	decodeDotVector[ 1 ] *= scale;
	decodeDotVector[ 2 ] *= scale;

	pD3DDevice->SetVertexShaderConstantF( 20, decodeDotVector, 1 );

	float differenceOffset[ 4 ] = { dofs, dofs, dofs, dofs };
	pD3DDevice->SetPixelShaderConstantF( 3, differenceOffset, 1 );


	pD3DDevice->SetTexture( 0, pDynamicTexture4 );
	pD3DDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_POINT );
	pD3DDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_POINT );

	pD3DDevice->SetTexture( 1, NULL );
	pD3DDevice->SetTexture( 2, pTextureLUT );
	pD3DDevice->SetSamplerState( 2, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
	pD3DDevice->SetSamplerState( 2, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );

	pD3DDevice->SetTexture( 3, pDynamicTexture3 );
	pD3DDevice->SetSamplerState( 3, D3DSAMP_MINFILTER, D3DTEXF_POINT );
	pD3DDevice->SetSamplerState( 3, D3DSAMP_MAGFILTER, D3DTEXF_POINT );

	renderScreenQuad();
#endif

	pD3DDevice->SetPixelShader( NULL );

    pD3DDevice->EndScene();

    pD3DDevice->Present( NULL, NULL, NULL, NULL );
}

  //
 // shutdown3D: free Direct3D ressources
//
void shutdown3D()
{
	if ( pTextureLUT != NULL )
		pTextureLUT->Release();

	if ( pDynamicTexture1 != NULL )	pDynamicTexture1->Release();
	if ( pRenderSurface1 != NULL )	pRenderSurface1->Release();
	if ( pTextureSurface1 != NULL )	pTextureSurface1->Release();
	if ( pDynamicTexture2 != NULL )	pDynamicTexture2->Release();
	if ( pRenderSurface2 != NULL )	pRenderSurface2->Release();
	if ( pTextureSurface2 != NULL )	pTextureSurface2->Release();
	if ( pDynamicTexture3 != NULL )	pDynamicTexture3->Release();
	if ( pRenderSurface3 != NULL )	pRenderSurface3->Release();
	if ( pTextureSurface3 != NULL )	pTextureSurface3->Release();
	if ( pDynamicTexture4 != NULL )	pDynamicTexture4->Release();
	if ( pRenderSurface4 != NULL )	pRenderSurface4->Release();
	if ( pTextureSurface4 != NULL )	pTextureSurface4->Release();

	if ( pVertexShader != NULL )
		pVertexShader->Release();

	if ( pVertexShaderDec13 != NULL )
		pVertexShaderDec13->Release();

	if ( pPixelShaderSub13 != NULL )
		pPixelShaderSub13->Release();

	if ( pPixelShader != NULL )
		pPixelShader->Release();

	if ( pPixelShaderDec13 != NULL )
		pPixelShaderDec13->Release();

	if ( pRampTexture != NULL )
		pRampTexture->Release();

	delete al;

    if( pD3DDevice != NULL )
        pD3DDevice->Release();

    if( pD3D != NULL )
        pD3D->Release();
}
