///////////////////////////////////////////////////////////
//                                                       //
//  (w)(c) 2002 - Carsten Dachsbacher                    //
//                carsten@dachsbacher.de                 //
//                                                       //
//  Vector and Matrix Header File                        //
//                                                       //
//  Changed: 09-14-2002                                  //
//                                                       //
///////////////////////////////////////////////////////////
#ifndef VERTEX3DOP__H
#define VERTEX3DOP__H

#include <math.h>

typedef struct
{
	float	x, y, z;
}VERTEX3D;

typedef float MATRIX44[ 16 ];

extern float	operator * ( const VERTEX3D &a, const VERTEX3D &b );

extern VERTEX3D	operator + ( const VERTEX3D &a, const VERTEX3D &b );

extern VERTEX3D	operator * ( const VERTEX3D &a, const float b );

extern VERTEX3D	operator - ( const VERTEX3D &a, const VERTEX3D &b );

extern void	operator += ( VERTEX3D &a, const VERTEX3D &b );

extern VERTEX3D	operator ^ ( const VERTEX3D &a, const VERTEX3D &b );

extern void	operator *= ( VERTEX3D &a, const float b );

extern void	operator ~ ( VERTEX3D &a );

extern VERTEX3D	operator * ( const MATRIX44 &matrix, const VERTEX3D &source );

extern void	InverseMatrixAnglePreserving( const MATRIX44 source, MATRIX44 dest );

#endif