#define FVF_MESHVERTEX ( D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_DIFFUSE | D3DFVF_TEX1 )

typedef struct
{
  float x, y, z;
  float nx, ny, nz;
  DWORD color;
  float u, v;
}MESHVERTEX;

					   
typedef struct
{
	DWORD		a, b, c;		// indices to vertices
	VERTEX3D	normal;			// normal of triangle
	float		area;			// area of triangle
}TRIFACE;

static unsigned int	nVertices    = 0, 
					nFaces       = 0;
static VERTEX3D		*pVertexList = NULL;
static TRIFACE		*pFaceList   = NULL;
static VERTEX3D		*pNormalList = NULL;

static void readTriangleMesh( char *filename )
{
	if ( filename == NULL )
	{
		nVertices = nFaces = 0;
		return;
	}

	FILE *f = fopen( filename, "rb" );
	fread( &nVertices, 4, 1, f );
	fread( &nFaces, 4, 1, f );

	pVertexList	  = new VERTEX3D[ nVertices ];
	pNormalList	  = new VERTEX3D[ nVertices ];
	pFaceList	  = new TRIFACE[ nFaces ];

	for ( DWORD i = 0; i < nVertices; i++ )
	{
		fread( &pVertexList[ i ].x, 1, 4, f );
		fread( &pVertexList[ i ].y, 1, 4, f );
		fread( &pVertexList[ i ].z, 1, 4, f );
	}

	for ( i = 0; i < nFaces; i++ )
	{
		fread( &pFaceList[ i ].a, 1, 4, f );
		fread( &pFaceList[ i ].b, 1, 4, f );
		fread( &pFaceList[ i ].c, 1, 4, f );
	}
	
	fclose( f );

	// Normalen berechnen
	for ( i = 0; i < nFaces; i++ )
	{
		VERTEX3D	*a1, *a2, *a3;
		VERTEX3D	a, b;

		a1 = &pVertexList[ pFaceList[ i ].a ];
		a2 = &pVertexList[ pFaceList[ i ].b ];
		a3 = &pVertexList[ pFaceList[ i ].c ];

		a = *a2 - *a1;
		b = *a3 - *a1;

		pFaceList[ i ].normal = a ^ b;

		pFaceList[ i ].area = (float)sqrt( pFaceList[ i ].normal * pFaceList[ i ].normal );

	}

	// Vertexnormalen
	for ( i = 0; i < nVertices; i++ )
		pNormalList[ i ].x =
		pNormalList[ i ].y =
		pNormalList[ i ].z = 0.0f;

	for ( i = 0; i < nFaces; i++ )
	{
		pNormalList[ pFaceList[ i ].a ] += pFaceList[ i ].normal;
		pNormalList[ pFaceList[ i ].b ] += pFaceList[ i ].normal;
		pNormalList[ pFaceList[ i ].c ] += pFaceList[ i ].normal;

		pFaceList[ i ].normal *= 1.0f / pFaceList[ i ].area;
	}

	for ( i = 0; i < nVertices; i++ )
	{
		~pNormalList[ i ];
	}
}

//
// Isotrope Skalierung der Koordinaten
//
static void	scaleIsotropic( VERTEX3D *pVertexList, unsigned int nVertices )
{
	// calculate bounding box of mesh
	float	xminv = 1e37f, xmaxv = -1e37f;
	float	yminv = 1e37f, ymaxv = -1e37f;
	float	zminv = 1e37f, zmaxv = -1e37f;

	for ( unsigned int i = 0; i < nVertices; i++ )
	{

		xminv = min( xminv, pVertexList[ i ].x );
		yminv = min( yminv, pVertexList[ i ].y );
		zminv = min( zminv, pVertexList[ i ].z );
		xmaxv = max( xmaxv, pVertexList[ i ].x );
		ymaxv = max( ymaxv, pVertexList[ i ].y );
		zmaxv = max( zmaxv, pVertexList[ i ].z );
	}

	float	xmove = -(float)0.5 * ( xminv + xmaxv );
	float	ymove = -(float)0.5 * ( yminv + ymaxv );
	float	zmove = -(float)0.5 * ( zminv + zmaxv );

	float	maxSize = (float)max( (float)fabs( xminv - xmaxv ), max( (float)fabs( yminv - ymaxv ), (float)fabs( zminv - zmaxv ) ) );

	float	scale = 10.0f / (float)maxSize;

	// translate and scale vertices
	for ( i = 0; i < nVertices; i++ )
	{
		pVertexList[ i ].x += xmove;
		pVertexList[ i ].y += ymove;
		pVertexList[ i ].z += zmove;
		pVertexList[ i ].x *= scale;
		pVertexList[ i ].y *= scale;
		pVertexList[ i ].z *= scale;
	}
}

DWORD normal2color( VERTEX3D n )
{
	DWORD color = 0xff000000;
	n.z *= n.z;
	color |= (int)( ( n.x * 0.5f + 0.5f ) * 255.0f ) << 16;
	color |= (int)( ( n.y * 0.5f + 0.5f ) * 255.0f ) << 8;
	color |= (int)( ( n.z * 0.5f + 0.5f ) * 255.0f ) << 0;

	return color;
}

void hsv2rgb( float hin, float s, float v,
			 float *rout, float *gout, float *bout)
{
	float h;
	float r=0,g=0,b=0;
	float f,p,q,t;
	int i;
	
	h = hin;
	{
		if(h == 360.)
			h = 0.0;
		h /= 60.;
		i = (int) h;
		f = h - i;
		p = v*(1-s);
		q = v*(1-(s*f));
		t = v*(1-s*(1-f));
		switch(i) {
		case 0:
			r = v;
			g = t;
			b = p;
			break;
		case 1:
			r = q;
			g = v;
			b = p;
			break;
		case 2:
			r = p;
			g = v;
			b = t;
			break;
		case 3:
			r = p;
			g = q;
			b = v;
			break;
		case 4:
			r = t;
			g = p;
			b = v;
			break;
		case 5:
			r = v;
			g = p;
			b = q;
			break;
		default:
			r = 1.0;
			g = 1.0;
			b = 1.0;
			break;
		}
	}
	*rout = r;
	*gout = g;
	*bout = b;
}

DWORD hsvColor( float w )
{
	float r, g, b;
	hsv2rgb( w * 360.0f, 1.0f, 1.0f, &r, &g, &b );

	DWORD color = 0xff000000;
	color |= (int)( r * 16.0f ) << 16;
	color |= (int)( g * 16.0f ) << 8;
	color |= (int)( b * 16.0f ) << 0;

	return color;
}