   //  
  // PC Underground: DX9 Part II (Textures)
 // (w)(c)2003 Carsten Dachsbacher
//

#include <windows.h>
#include <d3dx9.h>
#include "resource.h"

const bool  DX9Fullscreen = FALSE;
const DWORD	DX9ScreenX    = 800;
const DWORD	DX9ScreenY    = 600;
const DWORD DX9Refresh    = 75;

const char windowTitle[] = "PCUvsD3D9 Texture: 'F1' No Filter, 'F2' Bi-Linear, Mip Maps, 'F3' Tri-Linear, 'F4' Toggle Colored Mip Maps";

int filterMode    = 0;
int activeTexture = 0;

HWND              gHWND      = NULL;
LPDIRECT3D9       pD3D       = NULL;
LPDIRECT3DDEVICE9 pD3DDevice = NULL;

LPDIRECT3DVERTEXBUFFER9	pMeshVB         = NULL;
LPDIRECT3DTEXTURE9      pTexture        = NULL;
LPDIRECT3DTEXTURE9      pTextureColored = NULL;


DWORD lodColors[ 7 ] =
{
	0xFFFFFFFF, 0xFFFFFF00, 0xFF00FFFF, 0xFFFF00FF,
	0xFF00FF00, 0xFFFF0000, 0xFF0000FF
};

DWORD lodBlackAndWhite[ 7 ] =
{
	0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF,
	0xFFFFFFFF, 0xFFFFFFFF, 0xFF808080
};


#include <stdio.h>
#include "vertex3dop.h"
#include "example.h"

  //
 // prototypes
//
int WINAPI WinMain( HINSTANCE hInst, HINSTANCE hPrevInst,
                    LPSTR lpCmdLine, int nCmdShow );

void	initialize3D();
void	shutdown3D();
void	render3D();

  //
 // WindowProc: Window Class Message Handler
//
LRESULT CALLBACK WindowProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
    switch( msg )
	{
        case WM_KEYDOWN:
			if ( wParam == VK_ESCAPE )
				PostQuitMessage(0);

			if ( wParam == VK_F1 ) filterMode = 0;
			if ( wParam == VK_F2 ) filterMode = 1;
			if ( wParam == VK_F3 ) filterMode = 2;

			if ( wParam == VK_F4 ) activeTexture = 1 - activeTexture;
	        break;

		case WM_CLOSE:
        case WM_DESTROY:
            PostQuitMessage(0);
	        break;

		default:
			return DefWindowProc( hWnd, msg, wParam, lParam );
	}

	return 0;
}

  //
 // WinMain: Register Window Class, Create Window and wait until program end
//
int WINAPI WinMain( HINSTANCE hInst,
                    HINSTANCE hPrevInst,
                    LPSTR     lpCmdLine,
                    int       nCmdShow )
{
	WNDCLASSEX wndClass;

	wndClass.lpszClassName = "PCUvsD3D9";
	wndClass.cbSize        = sizeof( WNDCLASSEX );
	wndClass.style         = CS_HREDRAW | CS_VREDRAW;
	wndClass.lpfnWndProc   = WindowProc;
	wndClass.cbClsExtra    = 0;
	wndClass.cbWndExtra    = 0;
	wndClass.hInstance     = hInst;
	wndClass.hIcon	       = LoadIcon( hInst, (LPCTSTR)IDI_PCUICON );
	wndClass.hCursor       = LoadCursor( NULL, IDC_ARROW );
	wndClass.hbrBackground = (HBRUSH)GetStockObject( BLACK_BRUSH );
    wndClass.hIconSm	   = NULL;
	wndClass.lpszMenuName  = NULL;

	if( RegisterClassEx( &wndClass) == 0 ) return E_FAIL;

	DWORD windowParam;

	if ( DX9Fullscreen )
		windowParam = WS_POPUP | WS_SYSMENU | WS_VISIBLE; else
		windowParam = WS_OVERLAPPEDWINDOW | WS_VISIBLE;

	gHWND = CreateWindowEx( NULL, "PCUvsD3D9", windowTitle,
							 windowParam, 0, 0, 
							 DX9ScreenX, DX9ScreenY, 
							 NULL, NULL, hInst, NULL );

	if( gHWND == NULL ) return E_FAIL;

    ShowWindow( gHWND, nCmdShow );
    UpdateWindow( gHWND );

	initialize3D();
  
	MSG msg;
	ZeroMemory( &msg, sizeof( msg ) );

	while( msg.message != WM_QUIT )
	{
		if( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) )
		{ 
			TranslateMessage( &msg );
			DispatchMessage ( &msg );
		} else
		    render3D();
	}

	shutdown3D();

    UnregisterClass( "PCUvsD3D9", wndClass.hInstance );

	return msg.wParam;
}

// this function creates a checker texture (including colored mip maps, color table ptr as parameter)
void makeMipMappedChecker( LPDIRECT3DTEXTURE9 *pTexture, int size, DWORD *colorTable )
{
	D3DXCreateTexture( pD3DDevice, size, size, 0, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, pTexture );

	int x, y;

	D3DLOCKED_RECT lockedRect;

	int level = 0;

	// generate checker texture for each mip map level

	while ( size > 0 )
	{
		(*pTexture)->LockRect( level, &lockedRect, NULL, 0 );

		BYTE  *pDest = (BYTE*)lockedRect.pBits;

		for ( y = 0; y < size; y++ )
		{
			DWORD *pLine = (DWORD*)&pDest[ y * lockedRect.Pitch ];

			if ( size == 1 )
				for ( x = 0; x < size; x++ )
					*(pLine++) = colorTable[ level ]; else
				for ( x = 0; x < size; x++ )
					*(pLine++) = ( (x<(size/2))^(y<(size/2)) ) * colorTable[ level ];
		}

		(*pTexture)->UnlockRect( level );

		level ++;
		size >>= 1;
	}
}

  //
 // error: Display error message and quit program
//
void error( char *msg = NULL )
{
	if ( msg )
		MessageBox( NULL, msg, "PCUvsDX9", MB_OK | MB_ICONEXCLAMATION ); else
		MessageBox( NULL, "Error occured !", "PCUvsDX9", MB_OK | MB_ICONEXCLAMATION );

	shutdown3D();

	exit( 1 );
}

  //
 // initialize3D: initialize Direct3D stuff
//
void initialize3D( void )
{
	HRESULT			hr;
	D3DDISPLAYMODE	dm;

    pD3D = Direct3DCreate9( D3D_SDK_VERSION );

	if( pD3D == NULL ) error( "Error creating Direct3D Object" );

	if ( DX9Fullscreen )
	{
		// fullscreen
		//
		int nMaxModes = pD3D->GetAdapterModeCount( D3DADAPTER_DEFAULT, D3DFMT_X8R8G8B8 );

		bool foundMode = false;

		for( int m = 0; m < nMaxModes; m ++ )
		{
		  if ( FAILED( pD3D->EnumAdapterModes( D3DADAPTER_DEFAULT, 
											   D3DFMT_X8R8G8B8, m, &dm ) ) )
			 error( "Error enumerating adapter mode" );

		  if ( dm.Width  != DX9ScreenX || 
			   dm.Height != DX9ScreenY ||
			   dm.RefreshRate != DX9Refresh ||
			   dm.Format != D3DFMT_X8R8G8B8 )
			   continue;

		  foundMode = true;
		  break;
		}

		if ( foundMode == false )
		  error( "Not suitable graphic mode found !" );

		if ( FAILED( pD3D->CheckDeviceType( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL,
											D3DFMT_X8R8G8B8, D3DFMT_X8R8G8B8, FALSE ) ) )
		   error( "No hardware acceleration for this graphic mode !" );
	} else
	{
		// windowed
		//
		if( FAILED( pD3D->GetAdapterDisplayMode( D3DADAPTER_DEFAULT, &dm ) ) )
			error( "Error getting Adapter Display Mode" );
	}

	hr = pD3D->CheckDeviceFormat( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, 
								  dm.Format, D3DUSAGE_DEPTHSTENCIL,
								  D3DRTYPE_SURFACE, D3DFMT_D16 );

	if ( hr == D3DERR_NOTAVAILABLE ) error( "Desired Z-Buffer Format (16Bit) not available" );

	D3DCAPS9 caps;

	if( FAILED( pD3D->GetDeviceCaps( D3DADAPTER_DEFAULT, 
									 D3DDEVTYPE_HAL, &caps ) ) )
		error( "Error reading Device Caps" );
	
	DWORD flags = 0;

	if( caps.VertexProcessingCaps != 0 )
		flags |= D3DCREATE_HARDWARE_VERTEXPROCESSING;
	else
		flags |= D3DCREATE_SOFTWARE_VERTEXPROCESSING;

	D3DPRESENT_PARAMETERS pp;
	ZeroMemory( &pp, sizeof( pp ) );

	pp.BackBufferFormat       = dm.Format;
	pp.SwapEffect             = D3DSWAPEFFECT_DISCARD;
	pp.Windowed               = !DX9Fullscreen;
	pp.EnableAutoDepthStencil = TRUE;
	pp.AutoDepthStencilFormat = D3DFMT_D16;
	pp.BackBufferWidth        = DX9ScreenX;
    pp.BackBufferHeight       = DX9ScreenY;
    pp.BackBufferFormat       = D3DFMT_X8R8G8B8;

	if( FAILED( pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, gHWND,
									  flags, &pp, &pD3DDevice ) ) )
		error( "Error creating Direct3D device" );


	//
	// Init Demo Stuff
	//

	pD3DDevice->SetRenderState( D3DRS_LIGHTING, FALSE );

	//
	// Create Vertex Buffer
	//
	MESHVERTEX vertexData[] =
	{
		{ -16.0f, 0.0f,-16.0f, 0.0f, 1.0f, 0.0f, 0xffffffff,  0.0f, 32.0f },
		{ -16.0f, 0.0f, 16.0f, 0.0f, 1.0f, 0.0f, 0xffffffff,  0.0f,  0.0f },
		{  16.0f, 0.0f,-16.0f, 0.0f, 1.0f, 0.0f, 0xffffffff, 32.0f, 32.0f },
		{  16.0f, 0.0f, 16.0f, 0.0f, 1.0f, 0.0f, 0xffffffff, 32.0f,  0.0f }
	};

	hr = pD3DDevice->CreateVertexBuffer( 4 * sizeof( MESHVERTEX ), 
										 D3DUSAGE_DONOTCLIP|D3DUSAGE_WRITEONLY, 
										 FVF_MESHVERTEX, D3DPOOL_MANAGED, &pMeshVB, NULL );

	D3DVERTEXBUFFER_DESC desc;
	pMeshVB->GetDesc( &desc );

	MESHVERTEX *pData = NULL;

	hr = pMeshVB->Lock( 0, 0, (void**)&pData, 0 );

	for ( DWORD i = 0; i < 4; i++ )
		*(pData ++) = vertexData[ i ];

	pMeshVB->Unlock();

	//
	// Texture Generation
	//
	makeMipMappedChecker( &pTextureColored, 64, lodColors );
	makeMipMappedChecker( &pTexture, 64, lodBlackAndWhite );
}

  //
 // render3D: render loop
//
void render3D()
{
    pD3DDevice->Clear( 0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
                       0x00303030, 1.0f, 0 );

    pD3DDevice->BeginScene();

	// set up matrices
	D3DXMATRIX mProjection;
	D3DXMatrixPerspectiveFovLH( &mProjection, 45.0f, (float)DX9ScreenX/(float)DX9ScreenY, 0.1f, 100.0f );
	pD3DDevice->SetTransform( D3DTS_PROJECTION, &mProjection );

	float time = GetTickCount() * 0.03f;
    float rotateX = time * 0.525f;
	
    D3DXMATRIX matWorld;
    D3DXMATRIX matTrans;
	D3DXMATRIX matRot;

	// camera distance
    D3DXMatrixTranslation( &matTrans, 0.0f, -0.5f, 8.0f );

	// rotation matrix
	D3DXMatrixRotationYawPitchRoll( &matRot, D3DXToRadian( rotateX ),  D3DXToRadian( 0.0f ), D3DXToRadian( 0.0f ) );

    matWorld = matRot;

	D3DXMatrixRotationYawPitchRoll( &matRot, D3DXToRadian( 0.0f ),  D3DXToRadian( -10.0f ), D3DXToRadian( 0.0f ) );

    matWorld = matWorld * matRot * matTrans;
    
	pD3DDevice->SetTransform( D3DTS_WORLD, &matWorld );

	// set texture
	if ( activeTexture )
		pD3DDevice->SetTexture( 0, pTextureColored ); else
		pD3DDevice->SetTexture( 0, pTexture );
	
	float mipmapLODBias = 0.5f;
	pD3DDevice->SetSamplerState(0, D3DSAMP_MIPMAPLODBIAS, *( (LPDWORD)&mipmapLODBias ) );

	if ( filterMode == 0 )
	{
		pD3DDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_NONE );
		pD3DDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_NONE );
		pD3DDevice->SetSamplerState( 0, D3DSAMP_MIPFILTER, D3DTEXF_NONE );
	} else
	if ( filterMode == 1 )
	{
		pD3DDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
		pD3DDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
		pD3DDevice->SetSamplerState( 0, D3DSAMP_MIPFILTER, D3DTEXF_POINT );
	} else
	{
		pD3DDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
		pD3DDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
		pD3DDevice->SetSamplerState( 0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR );
	}

	// render mesh
	pD3DDevice->SetStreamSource( 0, pMeshVB, 0, sizeof( MESHVERTEX ) );
	pD3DDevice->SetFVF( FVF_MESHVERTEX );
	pD3DDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, 0, 2 );

    pD3DDevice->EndScene();

    pD3DDevice->Present( NULL, NULL, NULL, NULL );
}

  //
 // shutdown3D: free Direct3D ressources
//
void shutdown3D()
{
	if ( pMeshVB != NULL )
		pMeshVB->Release();

    if( pD3DDevice != NULL )
        pD3DDevice->Release();

    if( pD3D != NULL )
        pD3D->Release();
}

