////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//                                                        //
//  Cg Shader Beispiel zum Rendern von Fraktalgebirgen    //
//                                                        //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////

#include	<windows.h>			
#include	<stdio.h>			
#include	<math.h>
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	<Cg\cgGL.h>
#include	<assert.h>

#include	"glext.h"
#include	"texture.h"
#include	"keys.h"

cgContext     *CgContext					= NULL;
cgProgramIter *CgProgram					= NULL;
cgBindIter    *CgBindModelviewProjection	= NULL;
cgBindIter    *CgBindConstJulia				= NULL;


void	init3DEngine()
{
	// Allgemeine Renderstates
    glShadeModel( GL_SMOOTH );

	glHint( GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST );

	glDisable( GL_POLYGON_SMOOTH );

	glEnable( GL_DEPTH_TEST );
	glFrontFace( GL_CCW );
	glEnable( GL_CULL_FACE );

	loadKeyTexture();

	//
	// Cg Stuff
	//

	cgError errorCode;

	CgContext = cgCreateContext();
	assert( CgContext != NULL );
	
	errorCode = cgAddProgramFromFile( CgContext, "fractal.cg", cgVertexProfile, NULL ); 
	assert(errorCode == cgNoError);

	CgProgram = cgProgramByName( CgContext, "main" );
	assert(CgProgram != NULL);

	char *asmCode = (char*)cgGetProgramObjectCode( CgProgram );

	errorCode = cgGLLoadProgram( CgProgram, 1 );
	assert(errorCode == cgNoError);

	CgBindModelviewProjection = cgGetBindByName( CgProgram, "modelViewProjection" );
	CgBindConstJulia          = cgGetBindByName( CgProgram, "constJulia" );
}


void	draw3DEngine()
{
	extern void makeFancyBackGround();
	
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();
	
	extern int windowX, windowY;
	
	gluPerspective( 45.0f, (float)640 / (float)max( 1, 480), 0.1f, 5000.0f );
	
	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();

	gluLookAt( 5, 5, 5, 0, 0, 0, 0, 1, 0 );

    cgGLBindUniformStateMatrix( 
		CgProgram, 
		CgBindModelviewProjection,
		cgGLModelViewProjectionMatrix, 
		cgGLMatrixIdentity );

	// Julia Fraktal Animation:
    float constJulia[] = { 0.0f, 1.0f, 0.0f, 1.0f };

	float param1 = GetTickCount() * 0.001f;
	float param2 = GetTickCount() * 0.0007f;

	constJulia[ 0 ] = 0.5f * (float)cos( param1 ) + 0.25f * (float)cos( param2 );
    constJulia[ 1 ] = 0.5f * (float)sin( param1 ) + constJulia[ 0 ] * (float)sin( param2 );

    cgGLBindUniform4fv( CgProgram, CgBindConstJulia, constJulia );

	glDisable( GL_TEXTURE_2D );
	glDisable( GL_BLEND );
	glEnable ( GL_DEPTH_TEST );

	glDepthMask( GL_FALSE );
	makeFancyBackGround();
	glDepthMask( GL_TRUE );

    cgGLBindProgram( CgProgram );
	cgGLEnableProgramType( cgVertexProfile );


//	glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );

	#define STEP 0.02f
//	#define STEP 0.09f
	glColor4ub( 55, 255, 255, 255 );
	for ( float j = -2.0f; j < 2.0f; j += STEP )
	{
		glBegin( GL_TRIANGLE_STRIP );
		for ( float i = -2.0f; i < 2.0f; i += STEP )
		{
			glVertex3f( i, 0, j );
			glVertex3f( i, 0, j+STEP );
		}
		glEnd();
	}

    cgGLDisableProgramType( cgVertexProfile );

	glDisable ( GL_LIGHTING );
	glDisable ( GL_DEPTH_TEST );
	glEnable( GL_TEXTURE_2D );
	glEnable( GL_BLEND );
	glBlendFunc( GL_ONE, GL_ONE );
	drawKeys();

	glFlush();
}

void	quit3DEngine()
{
    if( CgBindConstJulia != NULL )
		cgFreeBindIter(CgBindConstJulia);
	
	if( CgBindModelviewProjection != NULL )
		cgFreeBindIter(CgBindModelviewProjection);

	cgFreeProgramIter( CgProgram );
	cgFreeContext( CgContext );
	cgCleanup();
        
}


