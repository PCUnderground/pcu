static PCUTexture *keyTexture;

void loadKeyTexture()
{
	keyTexture = new PCUTexture();
	keyTexture->loadBMP( "./data/keys.bmp" );
}

void drawKeys()
{
	keyTexture->select();

	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();

	glTranslatef( -1.0f, -1.0f, 0.0f );
	extern int windowX, windowY;
	glScalef( 2.0f / (float)windowX, 2.0f / (float)windowX, 1.0f );

	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();

	glDisable( GL_DEPTH_TEST );

	GLfloat material1a[] = { 1.0f, 1.0f, 1.0f, 1.0f };

	#define RENDERQUAD() \
			glBegin( GL_TRIANGLE_STRIP );\
				glTexCoord2f( 0, 0 );\
				glVertex3i( windowX-256, 0, 0 );\
				glTexCoord2f( 1, 0 );\
				glVertex3i( windowX, 0, 0 );\
				glTexCoord2f( 0, 1 );\
				glVertex3i( windowX-256, 256, 0 );\
				glTexCoord2f( 1, 1 );\
				glVertex3i( windowX, 256, 0 ); \
			glEnd();

	glEnable( GL_BLEND );
	glBlendFunc( GL_ONE, GL_ONE );

	glColor4ub( 255, 255, 255, 255 );

	RENDERQUAD();
}
