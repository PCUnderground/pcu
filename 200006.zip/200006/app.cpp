///////////////////////////////////////////////////////////
//                                                       //
// PC MAGAZIN - PC Underground                           //
//                                                       //
// Direct3DX Basisprogramm und QuakeModel Viewer         //
//                                                       //
// (c)2000                                               //
//                                                       //
///////////////////////////////////////////////////////////
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#define  D3D_OVERLOADS
#include <d3dx.h> 
#include <d3d.h>
#include <ddraw.h>

#include "QuakeModel.h"

// links
#pragma comment(lib, "d3dx.lib")
#pragma comment(lib, "ddraw.lib")

// Globale Variablen, inkl. D3DX und Matrizen
HWND				_hwnd(0);
LPD3DXCONTEXT		D3DXContext(0);
LPDIRECT3DDEVICE7	D3DDevice(0);
LPDIRECT3D7			D3D7(0);
LPDIRECTDRAW7		DDraw(0);

D3DXMATRIX			matView;
D3DXMATRIX			matPosition;
D3DXMATRIX			matProjection;

D3DLVERTEX			vTriangle[4];

// Rotationswinkel f�r Animation
float				RX=0, RY=0, RZ=0;
int					frame = 0;

D3DXMATRIX g_DDraw
(1.0f, 0.0f, 0.0f, 0.0f,
 0.0f, 1.0f, 0.0f, 0.0f,
 0.0f, 0.0f, 1.0f, 0.0f,
 0.0f, 0.0f, 0.0f, 1.0f);

#define     RELEASENULL(object) if (object) {object->Release();}

// Variablen des Quakemodels
QuakeModel				QModel;
QuakeModel				QWeapon;
LPDIRECTDRAWSURFACE7	QModelTexture;
LPDIRECTDRAWSURFACE7	QWeaponTexture;

long _stdcall mainproc(HWND hwnd, UINT message, WPARAM wParm, LPARAM lParm);


LPDIRECTDRAWSURFACE7 LoadTexture( char *file ) 
{
	D3DX_SURFACEFORMAT		sf = D3DX_SF_UNKNOWN;
	LPDIRECTDRAWSURFACE7	pTex;
	
	if( !file )
		return NULL;
	
	if( FAILED( D3DXCreateTextureFromFile( D3DDevice, 0, 0, 0, &sf, NULL, &pTex, NULL, file, D3DX_FT_LINEAR ) ) ) 
	{
		pTex = NULL;
	}

	return pTex;  
}


// the paint routine
BOOL draw( void ) 
{
	
	if ( SUCCEEDED(D3DDevice->BeginScene()) ) 
	{
		// Bildschirm l�schen		
		D3DXContext->Clear(D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER);
		
		// Objekt/Kameradrehung
		D3DXQUATERNION qR;
		D3DXMATRIX matPosition2;
		D3DXVECTOR3 vecPosition(0.0f, 0.0f, 0.0f);
		
		D3DXMatrixTranslation(&matView, 0.0f, 5.0f, -40.0f);
		
		D3DXQuaternionRotationYawPitchRoll(&qR, 0, D3DXToRadian( 90.0f ), 0 );
		D3DXMatrixAffineTransformation(&matPosition, 1.0f, NULL, &qR, &vecPosition);
		
		D3DXQuaternionRotationYawPitchRoll(&qR, RY, RX, RZ );
		D3DXMatrixAffineTransformation(&matPosition2, 1.0f, NULL, &qR, &vecPosition);
		
		D3DXMatrixMultiply(&matPosition, &matPosition2, &matPosition );
		
		D3DXMatrixMultiply(&matPosition, &matView, &matPosition );
		D3DXMatrixInverse(&matView, NULL, &matPosition);
		
		D3DDevice->SetTransform(D3DTRANSFORMSTATE_WORLD, g_DDraw);
		
		// Spiegelung ein der "planeGround" Ebene
		D3DXMATRIX mat;

		D3DXPLANE planeGround(0.0f, 0.0f, 1.0f, 24.0f);
		
		D3DXMatrixReflect(&mat, &planeGround);
		D3DXMatrixMultiply(&mat, &mat, &matView);
		
		D3DDevice->SetTransform(D3DTRANSFORMSTATE_VIEW, mat);
		
		// ... und das Modell gespiegelt Zeichnen
		int	ActFrame = (int)( frame/10.0f );

		D3DDevice->SetTexture( 0, QModelTexture );
		QModel.d3ddraw( ActFrame ); 
		D3DDevice->SetTexture( 0, QWeaponTexture );
		QWeapon.d3ddraw( ActFrame ); 
		
		// Jetzt die Spiegelung r�ckg�ngig machen
		D3DDevice->SetTransform(D3DTRANSFORMSTATE_VIEW, matView);
		
		// Polygon mit Farbverlauf transparent �ber das ganze Bild zeichnen
		D3DDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_DISABLE);
		D3DDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
		D3DDevice->SetRenderState(D3DRENDERSTATE_ZENABLE,D3DZB_FALSE);
		D3DDevice->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE, TRUE);
		
		D3DDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, D3DFVF_TLVERTEX, vTriangle, 4, 0 );
		D3DDevice->SetRenderState(D3DRENDERSTATE_ZENABLE,D3DZB_TRUE);
		D3DDevice->SetTextureStageState( 0, D3DTSS_COLOROP, D3DTOP_MODULATE );
		D3DDevice->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE, FALSE);
		
		// ... und das 3D Modell richtig zeichnen
		D3DDevice->SetTexture( 0, QModelTexture );
		QModel.d3ddraw( ActFrame ); 
		D3DDevice->SetTexture( 0, QWeaponTexture );
		QWeapon.d3ddraw( ActFrame ); 
		
		D3DDevice->EndScene();
	}
	
	HRESULT hr = D3DXContext->UpdateFrame( D3DX_UPDATE_NOVSYNC );
	return ( hr != DDERR_SURFACELOST || hr != DDERR_SURFACEBUSY );
}

int _stdcall WinMain( HINSTANCE hInst, HINSTANCE hPInst, char* pCmd, int nCmd ) {
	
	const int width  = 800;
	const int height = 600;
	
	// Fensterklasse
	WNDCLASSEX wc ={0};
	wc.cbSize = sizeof(wc);
	wc.lpfnWndProc = mainproc;
	wc.lpszClassName = "mainwindow";
	wc.hbrBackground = reinterpret_cast<HBRUSH>( GetStockObject(BLACK_BRUSH) );
	wc.hIcon = wc.hIconSm = LoadIcon( 0, IDI_WINLOGO );
	wc.hCursor = reinterpret_cast<HCURSOR>( NULL );
	wc.hInstance = hInst;
	if( !RegisterClassEx(&wc) )
		return -1;
	
	// Fenster erzeugen
	if( !(_hwnd=CreateWindow( wc.lpszClassName, "app", WS_POPUP, CW_USEDEFAULT, CW_USEDEFAULT, 1, 1, 0, 0, hInst, 0)) )
		return -1;
	
	// und anzeigen
	ShowWindow(_hwnd, nCmd);
	UpdateWindow(_hwnd);
	
	
	// D3DX Initialisieren
	if( FAILED(D3DXInitialize()) )
		return -1;
	
	// Und Context erzeugen
	if( FAILED( D3DXCreateContextEx( D3DX_DEFAULT, D3DX_CONTEXT_FULLSCREEN, _hwnd, NULL,  16, 0, D3DX_DEFAULT, 0, 1, width, height, D3DX_DEFAULT, &D3DXContext)) )
		return -1;
	
	// Die Daten aus dem Context holen
	D3DDevice	= D3DXContext->GetD3DDevice();
	D3D7		= D3DXContext->GetD3D();
	DDraw		= D3DXContext->GetDD();

	// Ein Quakemodell und eine Waffe laden
	QModel.load( "./models/hansolo/tris.md2" );
	QModel.d3dinit();
	QModelTexture = LoadTexture( "./models/hansolo/solo.bmp" );
	
	QWeapon.load( "./models/hansolo/weapon.md2" );
	QWeapon.d3dinit();
	QWeaponTexture = LoadTexture( "./models/hansolo/weapon.bmp" );

	/*QModel.load( "tris.md2" );
	QModel.d3dinit();
	QModelTexture = LoadTexture( "tris.bmp" );
	QWeapon.load( "w_railgun.md2" );
	QWeapon.d3dinit();
	QWeaponTexture = LoadTexture( "w_railgun.bmp" );*/

	// Renderstates setzen
	D3DDevice->SetRenderState(D3DRENDERSTATE_SRCBLEND, D3DBLEND_ONE);
	D3DDevice->SetRenderState(D3DRENDERSTATE_DESTBLEND, D3DBLEND_ONE);
	D3DDevice->SetRenderState(D3DRENDERSTATE_LIGHTING, FALSE);
	D3DDevice->SetRenderState(D3DRENDERSTATE_SHADEMODE, D3DSHADE_GOURAUD );
	
	D3DDevice->SetRenderState( D3DRENDERSTATE_CULLMODE, D3DCULL_NONE );
	
	D3DDevice->SetRenderState(D3DRENDERSTATE_ZENABLE,D3DZB_TRUE);
	D3DDevice->SetRenderState(D3DRENDERSTATE_CLIPPING,FALSE ); 
	D3DDevice->SetRenderState(D3DRENDERSTATE_LIGHTING,FALSE); 
	
    D3DDevice->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTFN_LINEAR);
    D3DDevice->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTFG_LINEAR);
    D3DDevice->SetTextureStageState(0, D3DTSS_MIPFILTER, D3DTFP_POINT);
    D3DDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
    D3DDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
    D3DDevice->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_DISABLE);
    D3DDevice->SetTextureStageState(1, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
	
    D3DXMatrixPerspectiveFov(&matProjection, D3DXToRadian( 45.0f ), 3.0f / 4.0f, 0.1f, 100.0f);

	// Die Daten f�r das schattierte Polygon vorbereiten
	vTriangle[0].x = 0;
	vTriangle[0].y = 0;
	vTriangle[0].z = 0;
	vTriangle[0].color = D3DXCOLOR( 0.1f, 0.1f, 0.2f, 0.5f );
	vTriangle[2].x = width;
	vTriangle[2].y = 0;
	vTriangle[2].z = 0;
	vTriangle[2].color = D3DXCOLOR( 0.1f, 0.1f, 0.2f, 0.5f );
	vTriangle[1].x = 0;
	vTriangle[1].y = height;
	vTriangle[1].z = 0;
	vTriangle[1].color = D3DXCOLOR( 0.3f, 0.3f, 0.6f, 0.5f );
	vTriangle[3].x = width;
	vTriangle[3].y = height;
	vTriangle[3].z = 0;
	vTriangle[3].color = D3DXCOLOR( 0.3f, 0.3f, 0.6f, 0.5f );

	// Hintergrundfarbe setzen
	D3DXContext->SetClearColor(D3DRGBA(0.0f,0.0f,0.0f,0));
	D3DXContext->Clear( D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER );
	

	// und im Windowmessage-Loop auf das Programmende warten
	MSG msg;
	PeekMessage( &msg, NULL, 0U, 0U, PM_NOREMOVE );
	while( WM_QUIT != msg.message  ) 
	{
		if(PeekMessage(&msg, 0, 0, 0, PM_REMOVE)) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else if( !draw() )
			PostQuitMessage(0);
	}
	
	// DirectX Daten freigeben
	RELEASENULL( D3D7 );
	RELEASENULL( D3DDevice );
	RELEASENULL(D3DXContext );

	// D3DX beenden
	D3DXUninitialize();
	
	UNREFERENCED_PARAMETER(hPInst);
	UNREFERENCED_PARAMETER(pCmd);
	return msg.wParam;
}

// Der Messagehandler des Hauptfensters
long _stdcall mainproc(HWND hwnd, UINT message, WPARAM wParm, LPARAM lParm) 
{
	
	switch( message ) {
		
    case WM_CREATE:
		SetTimer(hwnd, 1, 1, NULL );
		break;
	case WM_TIMER:
		// Animationsdaten aktualisieren
		RY -= 0.001f;
		frame ++; frame %= 400;
		break;
	case WM_SETCURSOR:
		SetCursor(NULL);
		break;
    case WM_DESTROY:
		KillTimer(hwnd, 1);
		PostQuitMessage(0);
		return 0;
	case WM_KEYDOWN:
        if( wParm == 0x1b )
			PostQuitMessage(0);
        return 0;
	}
	return DefWindowProc(hwnd, message, wParm, lParm);
}
