///////////////////////////////////////////////////////////
//                                                       //
// PC MAGAZIN - PC Underground                           //
//                                                       //
// Direct3DX Basisprogramm und QuakeModel Viewer         //
//                                                       //
///////////////////////////////////////////////////////////
#include <iostream.h>
#include <windows.h>
#include <commctrl.h>
#include <windowsx.h>

#include "QuakeModel.h"

// Konstruktor
QuakeModel::QuakeModel () 
{
	m_index_list = NULL;
	m_frame_list = NULL;
	m_iFrames = m_iVertices = m_iTriangles = 0;
	m_pVertices = NULL;
}

// Destruktor
QuakeModel::~QuakeModel () 
{
	
	if( m_frame_list != NULL ) 
	{
		for( int i = 0; i < m_iFrames; i++ )
			delete [] m_frame_list[i].vertex;
		delete [] m_frame_list;
	}
	
	if( m_pVertices )
		delete [] m_pVertices;
	
	if( m_index_list)
		delete [] m_index_list;
}


void QuakeModel::destroy (void) 
{
	
	if( m_frame_list != NULL ) {
		
		for( int i = 0; i < m_iFrames; i++ )
			delete [] m_frame_list[i].vertex;
		
		delete [] m_frame_list;
		m_frame_list = NULL;
	}
	
	if( m_index_list != NULL ) {
		delete [] m_index_list;
		m_index_list = NULL;
	}
}

// L�dt ein MD2 File
int QuakeModel::load( char *filename ) 
{
	FILE		*modelfile = NULL;
	char		g_skins[MAX_MD2SKINS][64];
	dstvert_t	base_st[MAX_VERTS];
	byte		buffer[MAX_VERTS*4+128];
	dmdl_t		modelheader;
	
	dtriangle_t     tri;
	daliasframe_t	*out;
	
	if( (modelfile = fopen (filename, "rb")) == NULL )
		return 0;
	
	// Den Header der Datei lesen
	fread( &modelheader, 1, sizeof(modelheader), modelfile );
	
	modelheader.framesize = (int)&((daliasframe_t *)0)->verts[modelheader.num_xyz];
	
	// Daten aus dem Header
	m_iFrames     = modelheader.num_frames;
	m_iVertices   = modelheader.num_xyz;
	m_iTriangles  = modelheader.num_tris;
	
	m_index_list = new make_index_list [modelheader.num_tris];
	m_frame_list = new make_frame_list [modelheader.num_frames];
	
	for( int i = 0; i < modelheader.num_frames; i++)
		m_frame_list[i].vertex = new make_vertex_list [modelheader.num_xyz];
	
	// Die Skin Informationen lesen
	fread( g_skins, 1, modelheader.num_skins * MAX_SKINNAME, modelfile );
	
	// Die Indizes des Polygonmeshes lesen
	fread( base_st, 1, modelheader.num_st * sizeof(base_st[0]), modelfile );
	
	int	max_tex_u = 0, max_tex_v = 0;

	for( i = 0; i < modelheader.num_tris; i++ ) 
	{
		// Die Vertices lesen
		fread( &tri, 1, sizeof(dtriangle_t), modelfile);
		
		(m_index_list)[i].a = tri.index_xyz[2];
		(m_index_list)[i].b = tri.index_xyz[1];
		(m_index_list)[i].c = tri.index_xyz[0];
	
		// Texturemapping Koordinaten
		(m_index_list)[i].a_s = base_st[tri.index_st[2]].s;
		(m_index_list)[i].a_t = base_st[tri.index_st[2]].t;
		(m_index_list)[i].b_s = base_st[tri.index_st[1]].s;
		(m_index_list)[i].b_t = base_st[tri.index_st[1]].t;
		(m_index_list)[i].c_s = base_st[tri.index_st[0]].s;
		(m_index_list)[i].c_t = base_st[tri.index_st[0]].t;
		max_tex_u = max( max_tex_u, base_st[tri.index_st[0]].s );
		max_tex_u = max( max_tex_u, base_st[tri.index_st[1]].s );
		max_tex_u = max( max_tex_u, base_st[tri.index_st[2]].s );
		max_tex_v = max( max_tex_v, base_st[tri.index_st[0]].t );
		max_tex_v = max( max_tex_v, base_st[tri.index_st[1]].t );
		max_tex_v = max( max_tex_v, base_st[tri.index_st[2]].t );
	}

	// Da in den MD2 Files die Texturekoordinaten auf Pixelbasis (also abh�ngig
	// von der Originalgr��e der Texture) angegeben werden, werden sie hier umgerechnet
	for ( i = 0; i < modelheader.num_tris; i++ ) 
	{
		m_index_list[ i ].a_s /= max_tex_u;
		m_index_list[ i ].b_s /= max_tex_u;
		m_index_list[ i ].c_s /= max_tex_u;
		m_index_list[ i ].a_t /= max_tex_v;
		m_index_list[ i ].b_t /= max_tex_v;
		m_index_list[ i ].c_t /= max_tex_v;
	}

	// Die Vertexdaten aller Animationsframes lesen
	for( i = 0; i < modelheader.num_frames; i++ ) 
	{
		out = (daliasframe_t *)buffer;
		fread( out, 1, modelheader.framesize, modelfile );
		
		for( int j = 0; j < modelheader.num_xyz; j++ ) 
		{
			(m_frame_list)[i].vertex[j].x = out->verts[j].v[0] * out->scale[0] + out->translate[0];
			(m_frame_list)[i].vertex[j].y = out->verts[j].v[1] * out->scale[1] + out->translate[1];
			(m_frame_list)[i].vertex[j].z = out->verts[j].v[2] * out->scale[2] + out->translate[2];
		}
	}
	
	fclose (modelfile);
	return 1;
}

// Diese Funktion bereitet die 3D Daten aus dem MD2 File f�r die Direct3D Ausgabe auf
int QuakeModel::d3dinit() 
{
	
	HRESULT hr;
	
	// F�r jede Animationsphase einen Vertexbuffer anlegen und f�llen:
	for ( int i = 0; i < getnumberFrames(); i++ )
	{
		D3DVERTEXBUFFERDESC vbdesc;
		
		vbdesc.dwSize = sizeof(vbdesc);
		vbdesc.dwCaps = 0;
		vbdesc.dwFVF = D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX1 | D3DFVF_TEXCOORDSIZE2(0);
		vbdesc.dwNumVertices = getnumberTriangles() * 3;
		
		if(FAILED(hr = D3D7->CreateVertexBuffer(&vbdesc, &pvbVertices[ i ], 0)))
			return hr;
		
		MODELVERTEX *pVertex;
		
		if(FAILED(hr = pvbVertices[i]->Lock(DDLOCK_WAIT | DDLOCK_WRITEONLY, (void **) &pVertex, NULL)))
			return hr;
		
		D3DXCOLOR	LightColor(1.0f, 1.0f, 1.0f, 1.0f );
		for( int j = 0; j < getnumberTriangles(); j++) 
		{
			
			pVertex->m_vecPos.x = m_frame_list[i].vertex[m_index_list[j].a].x;
			pVertex->m_vecPos.y = m_frame_list[i].vertex[m_index_list[j].a].y;
			pVertex->m_vecPos.z = m_frame_list[i].vertex[m_index_list[j].a].z;
			pVertex->m_vecTex.x = m_index_list[j].a_s;
			pVertex->m_vecTex.y = m_index_list[j].a_t;
			pVertex->m_dwDiffuse = LightColor;
			pVertex ++;
			
			pVertex->m_vecPos.x = m_frame_list[i].vertex[m_index_list[j].b].x;
			pVertex->m_vecPos.y = m_frame_list[i].vertex[m_index_list[j].b].y;
			pVertex->m_vecPos.z = m_frame_list[i].vertex[m_index_list[j].b].z;
			pVertex->m_vecTex.x = m_index_list[j].b_s;
			pVertex->m_vecTex.y = m_index_list[j].b_t;
			pVertex->m_dwDiffuse = LightColor;
			pVertex ++;
			
			pVertex->m_vecPos.x = m_frame_list[i].vertex[m_index_list[j].c].x;
			pVertex->m_vecPos.y = m_frame_list[i].vertex[m_index_list[j].c].y;
			pVertex->m_vecPos.z = m_frame_list[i].vertex[m_index_list[j].c].z;
			pVertex->m_vecTex.x = m_index_list[j].c_s;
			pVertex->m_vecTex.y = m_index_list[j].c_t;
			pVertex->m_dwDiffuse = LightColor;
			pVertex ++;
		}
		
		
		pvbVertices[i]->Unlock();
		pvbVertices[i]->Optimize( D3DDevice, 0 );
		
	}
	return 1;
}


// Diese Funktion zeichnet das Quakemodel
int QuakeModel::d3ddraw( int framenum ) 
{
	
	if( framenum >= getnumberFrames() )
		return 0;
	
	// Vertexbuffer ausgeben
	return D3DDevice->DrawPrimitiveVB(D3DPT_TRIANGLELIST, pvbVertices[ framenum ], 0, getnumberTriangles() * 3, 0 );
	
	/*  
	Direkt zeichnen
	
	  D3DXCOLOR	LightColor(1.0f, 1.0f, 1.0f, 1.0f );
	  
		MODELVERTEX	*pVertex = m_pVertices;
		
		  for( int i = 0; i < getnumberTriangles(); i++) 
		  {
		  
			pVertex->m_vecPos.x = m_frame_list[framenum].vertex[m_index_list[i].a].x;
			pVertex->m_vecPos.y = m_frame_list[framenum].vertex[m_index_list[i].a].y;
			pVertex->m_vecPos.z = m_frame_list[framenum].vertex[m_index_list[i].a].z;
			pVertex->m_vecTex.x = m_index_list[i].a_s;
			pVertex->m_vecTex.y = m_index_list[i].a_t;
			pVertex->m_dwDiffuse = LightColor;
			pVertex ++;
			
			  pVertex->m_vecPos.x = m_frame_list[framenum].vertex[m_index_list[i].b].x;
			  pVertex->m_vecPos.y = m_frame_list[framenum].vertex[m_index_list[i].b].y;
			  pVertex->m_vecPos.z = m_frame_list[framenum].vertex[m_index_list[i].b].z;
			  pVertex->m_vecTex.x = m_index_list[i].b_s;
			  pVertex->m_vecTex.y = m_index_list[i].b_t;
			  pVertex->m_dwDiffuse = LightColor;
			  pVertex ++;
			  
				pVertex->m_vecPos.x = m_frame_list[framenum].vertex[m_index_list[i].c].x;
				pVertex->m_vecPos.y = m_frame_list[framenum].vertex[m_index_list[i].c].y;
				pVertex->m_vecPos.z = m_frame_list[framenum].vertex[m_index_list[i].c].z;
				pVertex->m_vecTex.x = m_index_list[i].c_s;
				pVertex->m_vecTex.y = m_index_list[i].c_t;
				pVertex->m_dwDiffuse = LightColor;
				pVertex ++;
				}
				
	return D3DDevice->DrawPrimitive(D3DPT_TRIANGLELIST, D3DFVF_MODELVERTEX, m_pVertices, getnumberTriangles()*3, 0 );
	*/
}