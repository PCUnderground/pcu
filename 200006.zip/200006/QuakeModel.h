///////////////////////////////////////////////////////////
//                                                       //
// PC MAGAZIN - PC Underground                           //
//                                                       //
// Direct3DX Basisprogramm und QuakeModel Viewer         //
//                                                       //
///////////////////////////////////////////////////////////
#include <stdio.h>
#include <iostream.h>
#include <windows.h>
#include <commctrl.h>
#include <windowsx.h>
#include <math.h>
#include <d3dx.h>

#ifndef _QuakeModel_H
#define _QuakeModel_H

extern	LPDIRECT3DDEVICE7	D3DDevice;
extern	LPDIRECT3D7			D3D7;

// Die Definitionen der Strukturen stammen aus den original ID Software Sourcen !

#define MAX_TRIANGLES 4096
#define MAX_VERTS 2048
#define MAX_FRAMES 512
#define MAX_MD2SKINS 32
#define MAX_SKINNAME 64

typedef struct
{
  int a, b, c;
  float a_s, a_t,
      b_s, b_t,
      c_s, c_t;
} make_index_list;

typedef struct
{
  float x, y, z;
} make_vertex_list;

typedef struct
{
  make_vertex_list *vertex;
} make_frame_list;

typedef unsigned char byte;

typedef struct
{
  float v[3];
}vec3_t;

typedef struct
{
  short s;
  short t;
} dstvert_t;

typedef struct 
{
  short index_xyz[3];
  short index_st[3];
} dtriangle_t;


typedef struct
{
  byte v[3];
  byte lightnormalindex;
} dtrivertx_t;

typedef struct
{
  float scale[3];
  float translate[3];
  char name[16];
  dtrivertx_t verts[1];

} daliasframe_t;

typedef struct
{
  int ident;
  int version;

  int skinwidth;
  int skinheight;
  int framesize;

  int num_skins;
  int num_xyz;
  int num_st;
  int num_tris;
  int num_glcmds;
  int num_frames;

  int ofs_skins;
  int ofs_st;
  int ofs_tris;
  int ofs_frames;
  int ofs_glcmds; 
  int ofs_end;

} dmdl_t;

typedef struct
{
        vec3_t          v;
        int   lightnormalindex;
} trivert_t;

typedef struct
{
        vec3_t          mins, maxs;
        char            name[16];
        trivert_t       v[MAX_VERTS];
} frame_t;

// Der Modelvertex, wie wir ihn f�r D3D Vertexbuffers verwenden
typedef struct tagMODELVERTEX {
  D3DXVECTOR3   m_vecPos;
  D3DCOLOR      m_dwDiffuse;
  D3DXVECTOR2   m_vecTex;
} MODELVERTEX;

#define D3DFVF_MODELVERTEX ( D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX1 | D3DFVF_TEXCOORDSIZE2(0) )


class QuakeModel {

  make_index_list* m_index_list;
  make_frame_list* m_frame_list;
  long m_iFrames,  m_iVertices, m_iTriangles;

  MODELVERTEX*     m_pVertices;
  LPDIRECT3DVERTEXBUFFER7 pvbVertices[ MAX_FRAMES ];

public:
  QuakeModel();
  ~QuakeModel();

  int load( char [] );
  void destroy (void);

  int d3dinit();
  int d3ddraw( int );

  inline long getnumberFrames(void) { return (long)m_iFrames; }
  inline long getnumberVertices(void) { return (long)m_iVertices; }
  inline long getnumberTriangles(void) { return (long)m_iTriangles;} 
};

#endif