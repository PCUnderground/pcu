   //  
  // PC Underground: DirectDraw Overlays + Notify Icons
 // 2D Effect based on PCU Issue #5 ! - (w)(c)2003 Carsten Dachsbacher
//

#include <math.h>

#define M_PI 3.141592f

struct gridUV
{
	int u, v;
};

DWORD	screen[ SCREEN_X * SCREEN_Y ];
DWORD	*texture;
gridUV	grid[ ( SCREEN_X/8 + 1 ) * ( SCREEN_Y/8 + 1 ) ];

// Calculate a wobbling UV-grid 
void makeWobble( float time, gridUV *grid )
{
    long  tilesX = SCREEN_X >> 3;
    long  tilesY = SCREEN_Y >> 3;
	
    gridUV *data = grid;
	
    float so1 = sinf( time * 0.3f )        * 20.0f + 
				sinf( time * 1.23453264f ) * 8.0f;
    float so2 = sinf( time * 0.5232341f )  * 20.0f;
	
    for ( int y = 0; y <= tilesY + 1; y ++ )
    {
		for ( int x = 0; x <= tilesX; x ++ )
		{
			float i = (float)x * 3.0f;
			float j = (float)y * 3.0f;

			float ip = 6.0f * M_PI / 256.0f * i;
			float jp = 6.0f * M_PI / 256.0f * j;

			data->u = (int)( 65536.0f * ( so1 + 7.0f + i + sinf( so1 + jp * 2.0f ) * 8.0f ) );
			data->v = (int)( 65536.0f * ( so2 + 20.0f + j + sinf( so1 + jp ) * 6.0f +
				                          sinf( so2 + 2.0f * ip ) * 3.0f + 
								          (j-128)*(j-128)*(j-128) * 0.2f / 65536.0f ) );
			
			float spiral_faktor = 0.4f * sinf( time );
			float tiefen_faktor = ( 1.0f + sinf( time * 0.65f ) ) * 2.0f;

			float xtex = (float)( x - ( SCREEN_X / 16 ) ) * 0.5f;
			float ytex = (float)( y - ( SCREEN_Y / 16 ) ) * 0.5f;
			float z    = ( sqrtf( xtex * xtex + ytex * ytex + xtex * ytex ) ) * tiefen_faktor + 5.4f;

			float sint = sinf( spiral_faktor * z + time );
			float cost = cosf( spiral_faktor * z + time );

			data->u += (int)( 50.0f * 65536.0f * ( sint * xtex - cost * ytex ) / z ) + (128<<16);
			data->v += (int)( 50.0f * 65536.0f * ( cost * xtex + sint * ytex ) / z ) + (128<<16);
			
			data->u <<= 1;
			data->v <<= 1;
			data++;
		}
	}
}

// render 8x8 square pixel block with given texture coordinates and texture (with bilinear interpolation)
// texture coordinates are 16:16 fixpoint
void Render8x8BlockHQ( gridUV &a, gridUV &b, gridUV &c, gridUV &d, DWORD *dest, DWORD pixelsPerRow, DWORD *texture )
{
	int		dudx, dvdx;
	int		dudy_left,  dvdy_left;
	int		dudy_right, dvdy_right;
	int		u, v;
	gridUV	left, right;
	
	// vertical slope
	dudy_left  = ( b.u - a.u ) >> 3;
	dvdy_left  = ( b.v - a.v ) >> 3;
	dudy_right = ( d.u - c.u ) >> 3;
	dvdy_right = ( d.v - c.v ) >> 3;
	
	// vertical init
	left  = a;
	right = c;
	
	for ( int y = 0; y < 8; y++ )
	{
		// horizontal slope
		dudx = ( right.u - left.u ) >> 3;
		dvdx = ( right.v - left.v ) >> 3;
		
		u = left.u;
		v = left.v;
		
		for ( int x = 0; x < 8; x++ )
		{
			/* bilerp in c-code
			int ca = texture[ ((u>>16) & 0x00ff) | ((v>>8) & 0xff00)];
			int cb = texture[ (((u>>16)+1) & 0x00ff) | (((v>>8)) & 0xff00)];
			int cc = texture[ (((u>>16)) & 0x00ff) | (((v>>8)+256) & 0xff00)];
			int cd = texture[ (((u>>16)+1) & 0x00ff) | (((v>>8)+256) & 0xff00)];
			int fh = u & 0xffff;
			int fv = v & 0xffff;
		
			unsigned char k[ 3 ];
			for ( int i = 0; i < 3; i++ )
			{
				int a = ca & 0xff; ca >>= 8;
				int b = cb & 0xff; cb >>= 8;
				int c = cc & 0xff; cc >>= 8;
				int d = cd & 0xff; cd >>= 8;
				int top = a + ( ( ( b - a ) * fh ) >> 16 );
				int bot = c + ( ( ( d - c ) * fh ) >> 16 );
				k[ i ] = top + ( ( ( bot - top ) * fv ) >> 16 );
			}
		  
			int color = (k[ 2 ]<<16) | (k[ 1 ]<<8) | k[ 0 ];
			*/
			
			DWORD color;
			DWORD *pixel = &texture[ ((u>>16) & 0x00ff) | ((v>>8) & 0xff00)];
			
			int   fh = (u & 0xffff)>>9; fh += fh << 16;
			int   fv = (v & 0xffff)>>9; fv += fv << 16;
			
			__asm
			{
				pxor	mm7, mm7
				pxor	mm6, mm6
				pxor	mm5, mm5
				
				mov		esi, dword ptr [ pixel ]
				movd	mm0, dword ptr [ esi ]
				movd	mm1, dword ptr [ esi+4 ]
				movd	mm2, dword ptr [ esi+4*256 ]
				movd	mm3, dword ptr [ esi+4+4*256 ]
				
				punpcklbw	mm0, mm7
				punpcklbw	mm1, mm7
				punpcklbw	mm2, mm7
				punpcklbw	mm3, mm7
				
				movd	mm6, dword ptr [ fh ]
				movd	mm5, dword ptr [ fv ]
				psll	mm6, 32
				psll	mm5, 32
				movd	mm6, dword ptr [ fh ]
				movd	mm5, dword ptr [ fv ]
				
				psubsw	mm1, mm0
				psubsw	mm3, mm2
				
				pmullw	mm1, mm6
				pmullw	mm3, mm6
				psllw	mm0, 7
				psllw	mm2, 7
				
				paddsw	mm0, mm1
				paddsw	mm2, mm3
				
				psubsw	mm2, mm0
				psraw	mm2, 7
				pmullw	mm2, mm5
				paddsw	mm0, mm2
				
				psraw	mm0, 7
				packuswb	mm0, mm7
				
				movd	dword ptr [ color ], mm0
			}
			
			int p_out = color;
			int p_in  = *dest;
			
			p_in   &= 0xfefefe;
			p_in  >>= 1;
			p_out  &= 0xfefefe;
			p_out >>= 1;

			*(dest++) = p_in + p_out;

			u += dudx;
			v += dvdx;
		}
		
		// update destination pointer
		dest    += pixelsPerRow-8;
		
		// vertical slope add
		left.u  += dudy_left;
		left.v  += dvdy_left;
		right.u += dudy_right;
		right.v += dvdy_right;
	}

	__asm emms
}



// render 8x8 square pixel block with given texture coordinates and texture (with bilinear interpolation)
void Render8x8BlockFast( gridUV &a, gridUV &b, gridUV &c, gridUV &d, DWORD *dest, DWORD pixelsPerRow, DWORD *texture )
{
	int		dudx, dvdx;
	int		dudy_left,  dvdy_left;
	int		dudy_right, dvdy_right;
	int		u, v;
	gridUV	left, right;
	
	// vertical slope
	dudy_left  = ( b.u - a.u ) >> 3;
	dvdy_left  = ( b.v - a.v ) >> 3;
	dudy_right = ( d.u - c.u ) >> 3;
	dvdy_right = ( d.v - c.v ) >> 3;
	
	// vertical init
	left  = a;
	right = c;
	
	for ( int y = 0; y < 8; y++ )
	{
		// horizontal slope
		dudx = ( right.u - left.u ) >> 3;
		dvdx = ( right.v - left.v ) >> 3;
		
		u = left.u;
		v = left.v;
		
		for ( int x = 0; x < 8; x++ )
		{
			int p_out = texture[ ((u>>16) & 0x00ff) | ((v>>8) & 0xff00)];
			int p_in  = *dest;
			
			p_in   &= 0xfefefe;
			p_in  >>= 1;
			p_out  &= 0xfefefe;
			p_out >>= 1;

			*(dest++) = p_in + p_out;

			u += dudx;
			v += dvdx;
		}
		
		// update destination pointer
		dest    += pixelsPerRow-8;
		
		// vertical slope add
		left.u  += dudy_left;
		left.v  += dvdy_left;
		right.u += dudy_right;
		right.v += dvdy_right;
	}
}


// render screen with 8x8 grid
void RenderScreen8x8( gridUV *grid, DWORD *dest, DWORD *texture, DWORD tilesX, DWORD tilesY, DWORD pixelsPerRow, int bilerp )
{
	gridUV *curRow  = grid;
	gridUV *nextRow = &grid[ tilesX + 1 ];

	for ( DWORD y = 0; y < tilesY; y++ )
	{
		for ( DWORD x = 0; x < tilesX; x++ )
		{
			if ( bilerp )
				Render8x8BlockHQ( curRow[ x + 0 ], nextRow[ x + 0 ],
								  curRow[ x + 1 ], nextRow[ x + 1 ],
								  &dest[ x * 8 ], pixelsPerRow, texture ); else
				Render8x8BlockFast( curRow[ x + 0 ], nextRow[ x + 0 ],
									curRow[ x + 1 ], nextRow[ x + 1 ],
									&dest[ x * 8 ], pixelsPerRow, texture );
		}

		dest    += pixelsPerRow * 8;
		curRow   = nextRow;
		nextRow += tilesX + 1;
	}
}
