   //  
  // PC Underground: DirectDraw Overlays + Notify Icons
 // DirectDraw Init + Overlay Management - (w)(c)2003 Carsten Dachsbacher
//

#include <windows.h>
#include <initguid.h>
#include <ddraw.h>                                                                
#include <stdio.h>
#include "ddutil.h"
#include "overlay.h"

#define INIT_DDSTRUCT(s) { ZeroMemory( &s, sizeof( s ) ); s.dwSize = sizeof( s ); }
#define SAFE_RELEASE(p)  { if(p) { (p)->Release(); (p)=NULL; } }

LPDIRECTDRAW7        pDirectDraw       = NULL;
LPDIRECTDRAWSURFACE7 pDDSurfacePrimary = NULL;
LPDIRECTDRAWSURFACE7 pDDSurfaceOverlay = NULL;


// Overlay Formats
// 5 supported overlay formats:
#define NUM_OVERLAY_FORMATS 5

int overlayFormat;

const char *formatDescription[ NUM_OVERLAY_FORMATS ] =
{
	"RGB, 24 Bit (8:8:8)",
	"RGB, 16 Bit (5:6:5)",
	"RGB, 16 Bit (5:5:5)",
	"YUY2, FOURCC",
	"UYVY, FOURCC",
};

DDPIXELFORMAT listOverlayFormat[] = 
{   
	{ sizeof( DDPIXELFORMAT ), DDPF_RGB, 0, 32,  0x00FF0000, 0x0000FF00, 0x000000FF, 0 },
	{ sizeof( DDPIXELFORMAT ), DDPF_RGB, 0, 16,  0x0000F800, 0x000007E0, 0x0000001F, 0 },
	{ sizeof( DDPIXELFORMAT ), DDPF_RGB, 0, 16,  0x00007C00, 0x000003E0, 0x0000001F, 0 },
	{ sizeof( DDPIXELFORMAT ), DDPF_FOURCC, MAKEFOURCC( 'Y','U','Y','2' ), 0, 0, 0, 0, 0 },
	{ sizeof( DDPIXELFORMAT ), DDPF_FOURCC, MAKEFOURCC( 'U','Y','V','Y' ), 0, 0, 0, 0, 0 }
};


/*
 Y0 = (BYTE)(         0.29 * R + 0.59 * G + 0.14 * B );
 U  = (BYTE)( 128.0 - 0.14 * R - 0.29 * G + 0.43 * B );
 Y1 = (BYTE)(         0.29 * R + 0.59 * G + 0.14 * B );
 V  = (BYTE)( 128.0 + 0.36 * R - 0.29 * G - 0.07 * B );
*/

#include "2deffect.h"

void ddCleanUp()
{
	SAFE_RELEASE( pDDSurfaceOverlay );
	SAFE_RELEASE( pDDSurfacePrimary );
	SAFE_RELEASE( pDirectDraw );
}


// 
// erstellt eine "Primary Surface", die man f�r DirectDraw immer ben�tigt
//
HRESULT ddCreatePrimarySurface()
{
    DDSURFACEDESC2 ddsd;
    
    if ( !pDirectDraw ) 
		return E_FAIL;
    
	INIT_DDSTRUCT( ddsd );

    ddsd.dwFlags        = DDSD_CAPS;
    ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE;
    return pDirectDraw->CreateSurface( &ddsd, &pDDSurfacePrimary, NULL );
}


// 
// Initialisierung von Direct Draw
//
bool ddInitialize()
{
    if ( !FAILED( 
			DirectDrawCreateEx( NULL, (VOID**)&pDirectDraw, IID_IDirectDraw7, NULL ) ) )
	{
		if ( !FAILED(
				pDirectDraw->SetCooperativeLevel( NULL, DDSCL_NORMAL ) ) )
		{
			if ( !FAILED( ddCreatePrimarySurface() ) )
			{
				return true;
			}
		}
	}
    
    ddCleanUp();
    
    return false;
}



//
// diese Funktion zeigt exemplarisch, wie ein RGB Tripel in eine YUY2 oder UYVY 
// Darstellung konvertiert wird
//
unsigned int rgb2fourcc( int r, int g, int b, int fourcc )
{
    BYTE Y0, Y1, U, V;

    Y0 = Y1 = (BYTE)(          0.29f * r + 0.59f * g + 0.14f * b );
    U       = (BYTE)( 128.0f - 0.14f * r - 0.29f * g + 0.43f * b );
    V       = (BYTE)( 128.0f + 0.36f * r - 0.29f * g - 0.07f * b );
    
	unsigned int col;
	unsigned char *pSurf = (unsigned char*)&col;

    switch ( fourcc )
    {
    case MAKEFOURCC( 'Y','U','Y','2' ): 
        *(pSurf ++) = Y0;
        *(pSurf ++) = U;
        *(pSurf ++) = Y1;
        *(pSurf ++) = V;
        break;
    case MAKEFOURCC( 'U','Y','V','Y' ): 
        *(pSurf ++) = U;
        *(pSurf ++) = Y0;
        *(pSurf ++) = V;
        *(pSurf ++) = Y1;
        break;
    }               
	return col;
}


bool copyBitmap2Surface( LPDIRECTDRAWSURFACE7 pSurface, DWORD *bitmap )
{
    DDSURFACEDESC2 ddsd;
    DWORD          x, y;
    BYTE		   *pSurf;
    DWORD          bytesPerRow;
    
    if ( pSurface == NULL )
        return FALSE;
    
	const signed short dotY[]  = {  9798,  19235,   3736, 0 };
	const signed short dotU[]  = { -4784,  -9437,  14221, 0 };
//	const signed short dotV[]  = { 20218, -16941,  -3277, 0 };
	const signed short dotV[]  = { 20218, -14000,  -3277, 0 };
	const signed int   addUV[] = { 4194304, 4194304, 0, 0 };

    INIT_DDSTRUCT( ddsd );

    if ( FAILED( pSurface->Lock( NULL, &ddsd, DDLOCK_SURFACEMEMORYPTR | DDLOCK_WAIT, NULL ) ) )
		return false;

   
	pSurf        = (BYTE*)ddsd.lpSurface;
    bytesPerRow = ddsd.dwWidth * 2;
    
	DWORD *pixel;

	switch ( overlayFormat )
    {
		case 0: // RGBA, 32 Bit, 8:8:8
			pixel = bitmap;
			for( y = 0; y < ddsd.dwHeight; y++ )
			{
				memcpy( pSurf, pixel, sizeof( DWORD ) * ddsd.dwWidth );
				pSurf += ddsd.lPitch;
				pixel += SCREEN_X;
			}
			break;
		case 1: // RGB,  16 Bit, 5:6:5
			pixel = bitmap;
			for( y = 0; y < ddsd.dwHeight; y++ )
			{
				for ( x = 0; x < ddsd.dwWidth; x++ )
				{
					*(DWORD*)pSurf = ( (*pixel >> 8) & 0xf800 ) |
									 ( (*pixel >> 5) & 0x07e0 ) |
									 ( (*pixel >> 3) & 0x001f );
					pSurf += 2;
					pixel ++;
				}
				pSurf += ddsd.lPitch - bytesPerRow;
			}
			break;
		case 2: // RGB,  16 Bit, 5:5:5
			pixel = bitmap;
			for( y = 0; y < ddsd.dwHeight; y++ )
			{
				for ( x = 0; x < ddsd.dwWidth; x++ )
				{
					*(DWORD*)pSurf = ( (*pixel >> 9) & 0x7c00 ) |
									 ( (*pixel >> 6) & 0x03e0 ) |
									 ( (*pixel >> 3) & 0x001f );
					pSurf += 2;
					pixel ++;
				}
				pSurf += ddsd.lPitch - bytesPerRow;
			}
			break;
		case 3: // YUY2
			pixel = bitmap;
			for ( y = 0; y < ddsd.dwHeight; y ++ )
			{
				for ( x = 0; x < ddsd.dwWidth; x += 2 )
				{
					__asm
					{
						mov			esi, dword ptr [ pixel ]
						mov			edi, dword ptr [ pSurf ]
						pxor		mm7, mm7

 						movd		mm0, dword ptr [ esi ]
						movd		mm6, dword ptr [ esi + 4 ]
						punpcklbw	mm0, mm7	// farbe 1 unpack
						punpcklbw	mm6, mm7	// farbe 2 unpack

						movq		mm2, mm0	// farbe 1 unpacked f�r u
						movq		mm3, mm6	// farbe 2 unpacked f�r v

						movq		mm1, qword ptr [ dotY ]
						pmaddwd		mm0, mm1
						 pmaddwd	 mm6, mm1
						movq		mm1, mm0
						 movq		 mm7, mm6
						psrl		mm1, 32
						 psrl		 mm7, 32
						paddd		mm0, mm1
						 paddd		 mm6, mm7
						psrad		mm0, 15
						 psrad		 mm6, 15
						 psll		 mm6, 16

 						pmaddwd		mm2, qword ptr [ dotU ]
						pmaddwd		mm3, qword ptr [ dotV ]
						movq		mm4, mm2
						movq		mm5, mm3
						psrl		mm4, 32
						psrl		mm5, 32
						paddd		mm2, mm4
						paddd		mm3, mm5
						paddd		mm2, dword ptr [ addUV ]
						paddd		mm3, dword ptr [ addUV ]
						psrad		mm2, 15
						psrad		mm3, 15

						psll		mm2, 24
						psll		mm3, 8

						paddd		mm0, mm6
						paddd		mm0, mm2
						paddd		mm0, mm3
						movd		dword ptr [ edi ], mm0
					}
					pixel += 2;
					pSurf += 4;
				}

				pSurf += ddsd.lPitch - bytesPerRow;
			}
			break;
		case 4: // UYVY
			pixel = bitmap;
			for( y = 0; y < ddsd.dwHeight; y ++ )
			{
				for ( x = 0; x < ddsd.dwWidth; x += 2 )
				{
					__asm
					{
						mov			esi, dword ptr [ pixel ]
						mov			edi, dword ptr [ pSurf ]
						pxor		mm7, mm7

 						movd		mm0, dword ptr [ esi ]
						movd		mm6, dword ptr [ esi + 4 ]
						punpcklbw	mm0, mm7	// farbe 1 unpack
						punpcklbw	mm6, mm7	// farbe 2 unpack

						movq		mm2, mm0	// farbe 1 unpacked f�r u
						movq		mm3, mm6	// farbe 2 unpacked f�r v

						movq		mm1, qword ptr [ dotY ]
						pmaddwd		mm0, mm1
						 pmaddwd	 mm6, mm1
						movq		mm1, mm0
						 movq		 mm7, mm6
						psrl		mm1, 32
						 psrl		 mm7, 32
						paddd		mm0, mm1
						 paddd		 mm6, mm7
						psrad		mm0, 15
						 psrad		 mm6, 15
						psll		mm0, 8
						 psll		 mm6, 24

						pmaddwd		mm2, qword ptr [ dotU ]
						pmaddwd		mm3, qword ptr [ dotV ]
						movq		mm4, mm2
						movq		mm5, mm3
						psrl		mm4, 32
						psrl		mm5, 32
						paddd		mm2, mm4
						paddd		mm3, mm5
						paddd		mm2, dword ptr [ addUV ]
						paddd		mm3, dword ptr [ addUV ]
						psrad		mm2, 15
						psrad		mm3, 15

						psll		mm2, 16

						paddd		mm0, mm6
						paddd		mm2, mm3
						paddd		mm0, mm2
						movd		dword ptr [ edi ], mm0
					}
					pixel += 2;
					pSurf += 4;
				}

				pSurf += ddsd.lPitch - bytesPerRow;
			}
			break;
    }                       
	__asm emms    

    pSurface->Unlock( NULL );     
    
    return true;
}


//
// Diese Funktion stellt das Overlay mit entsprechenden Parametern (Gr��e, Color Keying etc.) dar
//
bool ddDisplayOverlay()
{
    DDOVERLAYFX ovfx;
    DDCAPS      ddCaps;
    DWORD       dwUpdateFlags;
    
    if( !pDirectDraw       || 
		!pDDSurfacePrimary || 
		!pDDSurfaceOverlay )
        return FALSE;
    
    INIT_DDSTRUCT( ddCaps );

    if ( FAILED( pDirectDraw->GetCaps( &ddCaps, NULL ) ) )
        return false;
    
	// Overlay m�ssen manchmal (HW bedingt) leicht gestreckt werden. Der Streckungsfaktor wird
	// skaliert um 1000 angegeben.
    DWORD stretchFactor = max( ddCaps.dwMinOverlayStretch, 1000 );
    
	// Overlay Gr��en Alignments
    DWORD alignDstSize = ddCaps.dwAlignSizeDest;
    DWORD alignSrcSize = ddCaps.dwAlignSizeSrc;
    
    INIT_DDSTRUCT( ovfx );

	// Source Rectangle (= das berechnete Bild)
	RECT rs = { 0, 1, SCREEN_X, SCREEN_Y };

    // Evtl. Beschr�nktungen des Alignment anwenden
    if ( ddCaps.dwCaps & DDCAPS_ALIGNSIZESRC && alignSrcSize )
        rs.right -= rs.right % alignSrcSize;
    
	// Destination Rectangle (= auf dem Bildschirm)
	RECT rd = { 0, 0, GetSystemMetrics( SM_CXSCREEN ), GetSystemMetrics( SM_CYSCREEN ) };
    //rd.right  = ( rs.right * stretchFactor + 999 ) / 1000;
    //rd.bottom = rs.bottom * stretchFactor / 1000;
    
    // Gr��en Alignment
    if ( ddCaps.dwCaps & DDCAPS_ALIGNSIZEDEST && alignDstSize )
        rd.right = ( ( rd.right + alignDstSize - 1 ) / alignDstSize ) * alignDstSize;


	// Color Keying
	DDCOLORKEY colorKey;

	colorKey.dwColorSpaceLowValue  =
	colorKey.dwColorSpaceHighValue = DDColorMatch( pDDSurfacePrimary, RGB(  0,   0,  0 ) );

	pDDSurfacePrimary->SetColorKey( DDCKEY_DESTOVERLAY, &colorKey );


	dwUpdateFlags = DDOVER_SHOW | DDOVER_DDFX;
    
	if ( ddCaps.dwCKeyCaps & DDCKEYCAPS_DESTOVERLAY )
		dwUpdateFlags |= DDOVER_KEYDEST;

	if ( FAILED( 
			pDDSurfaceOverlay->UpdateOverlay( &rs, pDDSurfacePrimary, &rd, dwUpdateFlags, &ovfx ) ) )
        return false;
    
    return true;
}




//
// �berpr�ft, ob die Grafikkarte Overlays unterst�tzt
//
bool ddSupportOverlays()
{
    DDCAPS  ddCaps;
    
    INIT_DDSTRUCT( ddCaps );

    if ( FAILED( pDirectDraw->GetCaps( &ddCaps, NULL ) ) )
        return false;
    
    if ( !( ddCaps.dwCaps & DDCAPS_OVERLAY ) )
        return false;
    
    return true;
}


//
// Erstellt die Overlay Surface
//
bool ddCreateOverlay()
{
    DDSURFACEDESC2 ddsdOverlay;
    HRESULT        res;

    if ( !pDirectDraw || !pDDSurfacePrimary )
        return false;
    
    INIT_DDSTRUCT( ddsdOverlay );
    
	ddsdOverlay.ddsCaps.dwCaps = 
		DDSCAPS_OVERLAY | 
		DDSCAPS_FLIP | 
		DDSCAPS_COMPLEX | 
		DDSCAPS_VIDEOMEMORY;

    ddsdOverlay.dwFlags = 
		DDSD_CAPS | 
		DDSD_HEIGHT |
		DDSD_WIDTH |
		DDSD_BACKBUFFERCOUNT |
		DDSD_PIXELFORMAT;

    ddsdOverlay.dwBackBufferCount = 1;
    ddsdOverlay.dwWidth  = SCREEN_X;
    ddsdOverlay.dwHeight = SCREEN_Y;

    // Verschiedene Surface Formate probieren, bis ein unterst�tztes gefunden wird !
	for ( overlayFormat = 0; overlayFormat < NUM_OVERLAY_FORMATS; overlayFormat++ )
	{
        ddsdOverlay.ddpfPixelFormat = listOverlayFormat[ overlayFormat ];

        if ( !FAILED( res = pDirectDraw->CreateSurface( &ddsdOverlay, &pDDSurfaceOverlay, NULL ) ) )
			break;
	}

	if ( overlayFormat == NUM_OVERLAY_FORMATS )
		return false;

    
	//
	// Texture f�r unseren Grafikeffekt laden

	unsigned char tex[ 256*256*3 ];

	memset( tex, 0xff, 256*256*3 );
	memset( screen, 0, SCREEN_X*SCREEN_Y * 4 );

	FILE *f = fopen( "./data/texture.raw", "rb" );

	fread( tex, 1, 256*256*3, f );

	fclose( f );

	texture = new DWORD[ 256 * 256 * 2 ];

	unsigned char *src = tex;
	DWORD *dst = texture;


	for ( int j = 0; j < 256; j++ )
		for ( int i = 0; i < 256; i++ )
		{
			int r, g, b;
			r = *(src++);
			g = *(src++);
			b = *(src++);
			*(dst++) = (r<<16)|(g<<8)|b;
		}

	memcpy( &texture[256*256], &texture[0], sizeof(int)*256*256 );
		
    return TRUE;
}

//
// Surfaces k�nnen zerst�rt werden. Dann m�ssen wir sie neu erzeugen
//
bool ddRestoreSurfaces()
{
    HRESULT res;
    
    if ( !pDDSurfacePrimary )
        if ( FAILED( ddCreatePrimarySurface() ) )
        {
            pDDSurfacePrimary = NULL;
            return false;
        }
    
    if( !pDDSurfaceOverlay )
        if ( !ddCreateOverlay() )
            return false;
        
    if ( FAILED( res = pDDSurfacePrimary->Restore() ) )
		// wenn sich der Darstellungsmodus ge�ndert hat, k�nnen wir nichts tun 
		// => Surfaces bleiben/werden zerst�rt
        if ( res == DDERR_WRONGMODE )
        {
			SAFE_RELEASE( pDDSurfaceOverlay );
			SAFE_RELEASE( pDDSurfacePrimary );
            return false;
        } else 
            return false;
    
    if ( FAILED( pDDSurfaceOverlay->Restore() ) )
        return false;
    
    if( !ddDisplayOverlay() )
        return false;
    
    return true;
}


//
// Diese Funktion wird vom Timer aufgerufen und �bernimmt die Animation und das
// Update der Overlay Surface
//
void CALLBACK callbackOverlay( HWND hwnd, UINT msg, UINT idEvent, DWORD time )
{
    if ( !pDDSurfaceOverlay )
        if ( !ddRestoreSurfaces() )
            return;

	makeWobble ( GetTickCount() / 8000.0f, grid );

	extern int toggleQuality;
	RenderScreen8x8( grid, screen, texture, SCREEN_X/8, SCREEN_Y/8, SCREEN_X, toggleQuality );


	LPDIRECTDRAWSURFACE7 dds;
	DDSCAPS2			 caps;
	
	ZeroMemory( &caps, sizeof( DDSCAPS2 ) );
    caps.dwCaps = DDSCAPS_BACKBUFFER;

    if ( FAILED( pDDSurfaceOverlay->GetAttachedSurface( &caps, &dds ) ) ) 
		return;

	copyBitmap2Surface( dds, screen );

	pDDSurfaceOverlay->Flip( NULL, DDFLIP_WAIT );
}






