   //  
  // PC Underground: DirectDraw Overlays + Notify Icons
 // Window Init + Notify Icon - (w)(c)2003 Carsten Dachsbacher
//

#ifndef _WIN32_IE
#define _WIN32_IE 0x0600
#endif

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <shellapi.h>
#include <shlwapi.h>

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>

#include "resource.h"
#include "overlay.h"

#define MAKEDLLVERULL(major, minor, build, qfe) \
        (((ULONGLONG)(major) << 48) | \
         ((ULONGLONG)(minor) << 32) | \
         ((ULONGLONG)(build) << 16) | \
         ((ULONGLONG)(  qfe) <<  0))

#define TRAY_ICON_ID	0x12345678			// ID f�r das Notify Icon
#define TWM_TRAYMSG		( WM_APP + 0x00 )  	// Message ID f�r das Notify Icon, die an den Windowhandler geschickt wird
#define TWM_SHOW		( WM_APP + 0x01 )	// About Box zeigen
#define TWM_HIDE		( WM_APP + 0x02 )	// About Box verstecken
#define TWM_QUIT		( WM_APP + 0x03 )	// Programm beenden
#define TWM_TOGGLEANIM	( WM_APP + 0x04 )	// Animation an/aus
#define TWM_TOGGLEQUAL	( WM_APP + 0x05 )	// Bilineare Interpolation an/aus

int		toggleAnimation = 1;
int		toggleQuality   = 1;

HINSTANCE		hInst;
NOTIFYICONDATA	niData;

// Kontext Men� des Tray Bar Icons bauen
void createContextMenu( HWND hWnd )
{
	HMENU hMenu = CreatePopupMenu();
	
	if ( hMenu )
	{
		if ( toggleAnimation )
			InsertMenu( hMenu, -1, MF_BYPOSITION, TWM_TOGGLEANIM, _T( "Animation Off" ) ); else
			InsertMenu( hMenu, -1, MF_BYPOSITION, TWM_TOGGLEANIM, _T( "Animation On" ) );

		if ( toggleQuality )
			InsertMenu( hMenu, -1, MF_BYPOSITION, TWM_TOGGLEQUAL, _T( "Bilinear Interpolation Off" ) ); else
			InsertMenu( hMenu, -1, MF_BYPOSITION, TWM_TOGGLEQUAL, _T( "Bilinear Interpolation On" ) );

		if( IsWindowVisible( hWnd ) )
			InsertMenu( hMenu, -1, MF_BYPOSITION, TWM_HIDE, _T( "Hide About" ) ); else
			InsertMenu( hMenu, -1, MF_BYPOSITION, TWM_SHOW, _T( "Show About" ) );

		InsertMenu( hMenu, -1, MF_BYPOSITION, TWM_QUIT, _T("Exit"));

		SetForegroundWindow( hWnd );

		// Pop-Up Menu: Die Nachrichten werden an das angegebene Fenster geschickt
		POINT mouse;
		GetCursorPos( &mouse );

		TrackPopupMenu( hMenu, TPM_CENTERALIGN | TPM_BOTTOMALIGN, mouse.x, mouse.y, 0, hWnd, NULL );

		DestroyMenu( hMenu );
	}
}

//
// Zur Abfrage der Version einer DLL, z.B. Shell32.dll, Comctl32.dll, Shdocvw.dll und Shlwapi.dll
// Diese Funktion stammt bis auf eine leichte Modifikation aus der MSDN Library
//
ULONGLONG GetDllVersion(LPCTSTR lpszDllName)
{
	ULONGLONG	versionDLL = 0;
	HINSTANCE   hinstDll;
	TCHAR       szText[MAX_PATH] = TEXT("Could not load DLL");
	
	//Load the DLL.
	hinstDll = LoadLibrary(lpszDllName);
	
	if(hinstDll)
	{
		DLLGETVERSIONPROC pDllGetVersion;
		
		/*
		You must get this function explicitly because the DLL might not implement 
		the function. Depending upon the DLL, the lack of implementation of the 
		function may be a version marker in itself.
		*/
		pDllGetVersion = (DLLGETVERSIONPROC)GetProcAddress(   hinstDll, 
			TEXT("DllGetVersion"));
		
		if(pDllGetVersion)
		{
			DLLVERSIONINFO    dvi;
			HRESULT           hr;
			
			ZeroMemory(&dvi, sizeof(dvi));
			dvi.cbSize = sizeof(dvi);
			
			hr = (*pDllGetVersion)(&dvi);
			
			if(SUCCEEDED(hr))
			{
				wsprintf(   szText, 
					TEXT("DLL Version = %d.%02d\nBuild# = %d\n"), 
					dvi.dwMajorVersion, 
					dvi.dwMinorVersion, 
					dvi.dwBuildNumber);

				versionDLL = MAKEDLLVERULL(dvi.dwMajorVersion, dvi.dwMinorVersion,0,0);
				
				switch(dvi.dwPlatformID)
				{
				case DLLVER_PLATFORM_WINDOWS:
					lstrcat(szText, TEXT("Platform is Windows"));
					break;
					
				case DLLVER_PLATFORM_NT:
					lstrcat(szText, TEXT("Platform is Windows NT"));
					break;
					
				default:
					lstrcat(szText, TEXT("Platform is not defined"));
					break;
				}
			} else
				lstrcpy( szText, 
					TEXT("DllGetVersion Failed - Cannot determine DLL version."));
		} else
			//If GetProcAddress failed, the DLL does not implement DllGetVersion.
			lstrcpy( szText, 
				TEXT("GetProcAddress Failed - The DLL does not implement DllGetVersion."));
		
		FreeLibrary(hinstDll);
	} else
		lstrcpy(szText, TEXT("Could not load the DLL"));
	
	//MessageBox(NULL, szText, lpszDllName, MB_OK | MB_ICONINFORMATION);
	return versionDLL;
}

void updateAboutBox( HWND hWnd )
{
	extern int overlayFormat;
	extern const char *formatDescription[];
	extern const int SCREEN_X;
	extern const int SCREEN_Y;
	char buf[ 512 ];
	sprintf( buf, "\toverlay format\t\t %s\n\toverlay resolution\t %dx%d", formatDescription[ overlayFormat ], SCREEN_X, SCREEN_Y );
	SetDlgItemText( hWnd, IDC_STATIC_STATS, buf );
}

// Message Handler
INT_PTR CALLBACK messageHandler( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
    static int timerID;
	int trayMsg;

	switch ( msg ) 
	{
	case TWM_TRAYMSG:
		switch( lParam )
		{
		case WM_LBUTTONDBLCLK:
			updateAboutBox( hWnd );
			ShowWindow( hWnd, SW_RESTORE );
			break;
		case WM_RBUTTONDOWN:
		case WM_CONTEXTMENU:
			createContextMenu( hWnd );
			break;
		}
		break;
	
	case WM_SYSCOMMAND:
		if ( wParam == SC_MINIMIZE )
		{
			ShowWindow( hWnd, SW_HIDE );
			return 1;
		}
		break;

	case WM_COMMAND:
		trayMsg = LOWORD( wParam );

		switch ( trayMsg )
		{
		case TWM_SHOW:
			updateAboutBox( hWnd );
			ShowWindow( hWnd, SW_RESTORE );
			break;

		case TWM_HIDE:
		case IDOK:
			ShowWindow( hWnd, SW_HIDE );
			break;

		case TWM_QUIT:
			DestroyWindow( hWnd );
			break;

		case TWM_TOGGLEANIM:
			toggleAnimation = 1 - toggleAnimation;

			if ( toggleAnimation )
				timerID = SetTimer( NULL, 0, 20, (TIMERPROC)callbackOverlay ); else
		        KillTimer( NULL, timerID );

			break;

		case TWM_TOGGLEQUAL:
			toggleQuality = 1 - toggleQuality;
			break;
		}
		return 1;

	case WM_INITDIALOG:
        timerID = SetTimer( NULL, 0, 20, (TIMERPROC)callbackOverlay );
		break;

	case WM_CLOSE:
        KillTimer( NULL, timerID );
		DestroyWindow( hWnd );
		break;

	case WM_DESTROY:
        KillTimer( NULL, timerID );

		niData.uFlags = 0;
		Shell_NotifyIcon( NIM_DELETE,&niData );
		PostQuitMessage( 0 );
		break;

	}
	return 0;
}

//	Fenster und Tray Icon initialisieren
bool initInstance( HINSTANCE _hInst, int cmdShow )
{
	hInst = _hInst;

	HWND hWnd = CreateDialog( _hInst, MAKEINTRESOURCE( IDD_DLG_DIALOG ), NULL, (DLGPROC)messageHandler );

	if ( !hWnd ) 
		return false;

	// Die NOTIFYICONDATA Struktur wird f�r das Icon in der Tray Bar ben�tigt
	ZeroMemory( &niData, sizeof( NOTIFYICONDATA ) );

	// Die Struktur h�ngt von der Version der Shell32.dll ab !
	ULONGLONG ullVersion = GetDllVersion( _T( "Shell32.dll" ) );

	if( ullVersion >= MAKEDLLVERULL( 5, 0, 0, 0 ) )
		niData.cbSize = sizeof( NOTIFYICONDATA ); else 
		niData.cbSize = sizeof( NOTIFYICONDATA ); //NOTIFYICONDATA_V2_SIZE;

	// Die Flags geben an, welche Eintr�ge der Struktur wird ausf�llen
	niData.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;

	// beliebige ID des Notify Icons
	niData.uID = TRAY_ICON_ID;

	// Wenn mit dem Tray Bar Icon etwas passiert, schicken wir die TWM_TRAYMSG Nachricht
	// an unser Fenster:
	niData.hWnd = hWnd;
    niData.uCallbackMessage = TWM_TRAYMSG;

	// Tooltip Text
    lstrcpyn( niData.szTip, _T( "PC Underground\nOverlay FX" ), sizeof( niData.szTip ) / sizeof( TCHAR ) );

	// Icon laden
	niData.hIcon = (HICON)LoadImage( hInst, MAKEINTRESOURCE( IDI_ICON_PCU ),
		IMAGE_ICON, GetSystemMetrics( SM_CXSMICON ),GetSystemMetrics( SM_CYSMICON ),
		LR_DEFAULTCOLOR );

	// und weg damit...
	Shell_NotifyIcon( NIM_ADD, &niData );

	// Icon Handle wird nicht mehr ben�tigt
	if( niData.hIcon && DestroyIcon( niData.hIcon ) )
		niData.hIcon = NULL;

	return true;
}


int APIENTRY WinMain( HINSTANCE hInst, HINSTANCE hPrevInst, LPTSTR cmdLine, int cmdShow)
{
	MSG msg;

	MessageBox( NULL, "Setzen Sie Ihre Hintergrundfarbe auf schwarz (R=G=B=0) und w�hlen Sie kein Hintergrundbild !", "Hinweis", MB_OK );

	if ( !initInstance( hInst, cmdShow ) ) 
		return false;

    if ( !ddInitialize() )
        return false;
    
    
    if ( !ddSupportOverlays() )
    {
        MessageBox( NULL, "Keine Overlay Hardwareunterst�tzung.", "PCU Overlay Demo", MB_OK );
        return false;
    }
    
    if ( !ddCreateOverlay() )
    {
        MessageBox( NULL, "Overlay konnte nicht erzeugt werden", "PCU Overlay Demo", MB_OK );
        return false;
    }
    
    if ( !ddDisplayOverlay() )
    {
        MessageBox( NULL, "Fehler beim Darstellen des Overlays.", "PCU Overlay Demo", MB_OK );
        return false;
    }

	while ( GetMessage( &msg, NULL, 0, 0 ) )
	{
		TranslateMessage( &msg );
		DispatchMessage ( &msg );
	}
	
	ddCleanUp();

	return msg.wParam;
}



