#ifndef __OVERLAY__H
#define __OVERLAY__H

#include <windows.h>

const int SCREEN_X = 320;
const int SCREEN_Y = 240;

bool ddInitialize();
bool ddSupportOverlays();
bool ddCreateOverlay();
bool ddDisplayOverlay();
void ddCleanUp();

extern void CALLBACK callbackOverlay( HWND hwnd, UINT msg, UINT idEvent, DWORD time );

#endif