////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//                                                        //
//  (w)(c)2001 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include	<windows.h>			
#include	<math.h>
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	"glext.h"
#include	"texture.h"
#include	"ms3d.h"

MS3DObject	*ms3d;

void	init3DEngine()
{
	ms3d = new MS3DObject();

	if ( !ms3d->loadObject( "./data/", "model.ms3d" ) )
	{
		exit( 1 );
	}
	ms3d->normalize();

	glEnable( GL_LIGHTING );
	glEnable( GL_LIGHT0 );

	GLfloat light_diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat light_ambient[] = { 0.1f, 0.1f, 0.1f, 1.0f };

	glLightfv( GL_LIGHT0, GL_AMBIENT, light_ambient );
	glLightfv( GL_LIGHT0, GL_DIFFUSE, light_diffuse );
	glLightfv( GL_LIGHT0, GL_SPECULAR, light_diffuse );

	GLfloat light_position[4] = { 30, 30, 30, 0 };

	glLightfv( GL_LIGHT0, GL_POSITION, light_position );

	glEnable( GL_NORMALIZE );
}

static float lastTime = -1.0f;

void	draw3DEngine()
{
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	glEnable( GL_DEPTH_TEST );
	glDepthFunc( GL_LEQUAL );
	glHint( GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST );

	float time, elapsed;

	time = (float)GetTickCount();

	if ( lastTime == -1.0f )
		elapsed = 1.0f; else
	{
		elapsed = ( time - lastTime ) * 0.1f;
	}
	lastTime = time;

	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();
	gluPerspective( 45.0f, 1.33f, 0.01f, 500.0f );

	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();

	gluLookAt(  sin( time * 0.0004345f ) * 0.2f + 2.0f, 
				sin( time * 0.0005f ) * 0.7f + 0.8f, 
				sin( time * 0.000533f ) * 0.2f + 0.3f,  
				0.0f, 0.0f, 0.0f, 
				0.0f, 1.0f, 0.0f );

	glScalef( 1.3f, 1.3f, 1.3f );

	glEnable( GL_CULL_FACE );
	glCullFace( GL_BACK );

	glEnable( GL_LIGHTING );
    glShadeModel( GL_SMOOTH );

	glEnable( GL_TEXTURE_2D );

	ms3d->renderObject();
}

void	quit3DEngine()
{
}