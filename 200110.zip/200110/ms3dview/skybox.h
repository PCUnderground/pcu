////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Landschaftsrendering: Skybox Code				      //
//  (w)(c)2000 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#ifndef SKYBOX__H
#define SKYBOX__H

void	skyboxInit();
void	drawSkybox();

#endif