////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//                                                        //
//  MS3D Header Definitionen, basierend auf dem           //
//  Milkshape 3D SDK                                      //
//  MS3D Klasse                                           //
//                                                        //
//  (w)(c)2001 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////

#ifndef MS3D__H
#define MS3D__H

#include <windows.h>
#include "texture.h"

#define SELECTED        1
#define HIDDEN          2
#define SELECTED2       4
#define DIRTY           8

#ifndef byte
typedef unsigned char byte;
#endif

#ifndef word
typedef unsigned short word;
#endif

typedef struct
{
    char    id[ 10 ]; // "MS3D000000"
    int     version;  // 3
} MS3D_HEADER;

typedef struct
{
    byte    flags;
    float   vertex[ 3 ];
    char    boneId;
    byte    refCount;
} MS3D_VERTEX;

typedef struct
{
    word    flags;
    word    vertexIndices[ 3 ];
    float   vertexNormals[ 3 ][ 3 ];
    float   s[ 3 ];
    float   t[ 3 ];
    byte    smoothingGroup;
    byte    groupIndex;
} MS3D_TRIANGLE;

typedef struct
{
    byte    flags;
    char    name[ 32 ];
    word    nTriangles;
    word    *triangleIndices;
    char    materialIndex;
} MS3D_GROUP;

typedef struct
{
    char    name[ 32 ];
    float   ambient[ 4 ];
    float   diffuse[ 4 ];
    float   specular[ 4 ];
    float   emissive[ 4 ];
    float   shininess;
    float   transparency;
    char    mode;
    char    texture[ 128 ];
    char    alphamap[ 128 ];

	PCUTexture *textureMap;
} MS3D_MATERIAL;

#define SAFEDELETE(p) { if ( p != NULL ) { delete p; p = NULL; } }

class MS3DObject
{
	private:
		word nVertices;
		word nTriangles;
		word nGroups;
		word nMaterials;

		MS3D_HEADER		header;
		MS3D_VERTEX		*pVertex;
		MS3D_TRIANGLE	*pTriangle;
		MS3D_GROUP		*pGroup;
		MS3D_MATERIAL	*pMaterial;

	public:
		MS3DObject() : nVertices(0), nTriangles(0), nGroups(0), nMaterials(0),
					   pVertex(NULL), pTriangle(NULL), pGroup(NULL), pMaterial(NULL) {};

		int	 loadObject( char *path, char *name );
		void normalize();
		void renderObject();

		~MS3DObject()
		{
			for ( int i = 0; i < nMaterials; i++ )
				SAFEDELETE( pMaterial[ i ].textureMap );

			for ( i = 0; i < nGroups; i++ )
				SAFEDELETE( pGroup[ i ].triangleIndices );

			SAFEDELETE( pVertex );
			SAFEDELETE( pTriangle );
			SAFEDELETE( pGroup );
			SAFEDELETE( pMaterial );
		};
};

#endif