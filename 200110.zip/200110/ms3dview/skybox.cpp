////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Landschaftsrendering: Skybox Code				      //
//  (w)(c)2000 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include	<windows.h>			
#include	<stdio.h>
#include	<assert.h>
#include	<gl\gl.h>			
#include	<gl\glu.h>			

#include	"texture.h"

PCUTexture	skyboxTexture[ 6 ];

void	skyboxInit()
{
	skyboxTexture[ 0 ].loadBMP( "./data/skybox1.bmp" );
	skyboxTexture[ 1 ].loadBMP( "./data/skybox2.bmp" );
	skyboxTexture[ 2 ].loadBMP( "./data/skybox3.bmp" );
	skyboxTexture[ 3 ].loadBMP( "./data/skybox4.bmp" );
	skyboxTexture[ 4 ].loadBMP( "./data/skybox_up.bmp" );
	skyboxTexture[ 5 ].loadBMP( "./data/skybox_bottom.bmp" );
}

void	drawSkybox()
{
	#define BOXSIZE		384.0f*4.0f
	#define BOXHEIGHT   256.0f*4.0f
	#define BOXSTART   -128.0f*4.0f
  
	typedef struct
	{
		GLfloat x, y, z;
	}SKYBOXVERTEX;
	SKYBOXVERTEX pBoxList[ 8 ] = 
	{
		{ -BOXSIZE,  BOXSIZE, BOXSTART },
		{  BOXSIZE,  BOXSIZE, BOXSTART },
		{  BOXSIZE, -BOXSIZE, BOXSTART },
		{ -BOXSIZE, -BOXSIZE, BOXSTART },
		{ -BOXSIZE,  BOXSIZE, BOXSTART + BOXHEIGHT },
		{  BOXSIZE,  BOXSIZE, BOXSTART + BOXHEIGHT },
		{  BOXSIZE, -BOXSIZE, BOXSTART + BOXHEIGHT },
		{ -BOXSIZE, -BOXSIZE, BOXSTART + BOXHEIGHT },
	};

	#define nIndices (4 * 6)
	WORD	pIndices[ nIndices ] = 
	{
		0, 1, 5, 4,
		1, 2, 6, 5,
		2, 3, 7, 6,
		3, 0, 4, 7,
		6, 7, 4, 5,
		1, 0, 3, 2
	};


	glColor3ub( 255, 255, 255 );

	for ( int i = 0; i < 6; i++ ) 
	{
		skyboxTexture[ i ].select();

		glBegin( GL_QUADS );

		glTexCoord2f( 0.0f + (1.0f / 256.0f), 0.0f + (1.0f / 256.0f) );
		glVertex3fv( (GLfloat*)&pBoxList[ pIndices[ i * 4 + 0 ] ] );

		glTexCoord2f( 1.0f - (1.0f / 256.0f), 0.0f + (1.0f / 256.0f) );
		glVertex3fv( (GLfloat*)&pBoxList[ pIndices[ i * 4 + 1 ] ] );

		glTexCoord2f( 1.0f - (1.0f / 256.0f), 1.0f - (1.0f / 256.0f) );
		glVertex3fv( (GLfloat*)&pBoxList[ pIndices[ i * 4 + 2 ] ] );

		glTexCoord2f( 0.0f + (1.0f / 256.0f), 1.0f - (1.0f / 256.0f) );
		glVertex3fv( (GLfloat*)&pBoxList[ pIndices[ i * 4 + 3 ] ] );

		glEnd();
	}

}

