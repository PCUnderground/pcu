#include "stdafx.h"
#include "msPlugInImpl.h"
#include "msLib.h"



BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}



cMsPlugIn*
CreatePlugIn ()
{
    return new cPlugIn ();
}



cPlugIn::cPlugIn ()
{
    strcpy (szTitle, "PC Underground MilkShape PlugIn...");
}



cPlugIn::~cPlugIn ()
{
}



int
cPlugIn::GetType ()
{
    return cMsPlugIn::eTypeExport;
}



const char*
cPlugIn::GetTitle ()
{
    return szTitle;
}


int cPlugIn::Execute (msModel *pModel)
{
    if (!pModel)
        return -1;

    if (msModel_GetMeshCount (pModel) == 0)
    {
        MessageBox ( NULL, "Kein Modell vorhanden", "PCU MilkShape 3D Plugin", MB_OK | MB_ICONWARNING);
        return 0;
    }


    int i, j;
    char szName[MS_MAX_NAME];

    char text[ 65536 ];
    strcpy( text, "Info:\n\n" );

    char buf[ 1024 ];

    sprintf( buf, "Frames:\t\t%d\n", msModel_GetTotalFrames (pModel));          strcat( text, buf );
    sprintf( buf, "akt. Frame:\t%d\n\n", msModel_GetFrame (pModel));                strcat( text, buf );
    sprintf( buf, "Meshes:\t\t%d\n", msModel_GetMeshCount (pModel));            strcat( text, buf );

    for (i = 0; i < msModel_GetMeshCount (pModel); i++)
    {
        msMesh *pMesh = msModel_GetMeshAt (pModel, i);
        msMesh_GetName (pMesh, szName, MS_MAX_NAME);

        sprintf( buf, "Vertices\t\t%d\n", msMesh_GetVertexCount (pMesh));       strcat( text, buf );
    
        sprintf( buf, "Triangles\t\t%d\n", msMesh_GetTriangleCount (pMesh));                strcat( text, buf );
    }

    sprintf( buf, "\nMaterials\t\t%d\n", msModel_GetMaterialCount (pModel));    strcat( text, buf );

    MessageBox( NULL, text, "PCU Modell Info", MB_OK );

    msModel_Destroy (pModel);

    return 0;
}
