//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
//
#define IDR_MAINFRAME                   101
#define IDC_ABOUTICON                   102
#define IDD_ABOUTBOX                    103
#define IDD_MAIN_DIALOG                 104
#define IDS_APP_TITLE                   105
#define IDM_FILE_NEW                    40001
#define IDM_ABOUT                       40005
#define IDM_FILE_EXIT                   40006
#define ID_PCU_1                        40024
#define ID_PCU_2                        40025
#define ID_PCU_3                        40026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40027
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
