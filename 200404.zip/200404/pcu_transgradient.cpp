   //  
  // PC Underground: Windows Programme Individualisieren
 // Gradient Pull-Down Menu + Per-Pixel Alpha Blending - (w)(c)2004 Carsten Dachsbacher
//
#include <windows.h>
#include <math.h>
#include <stdio.h>
#include "resource.h"

// Blending Flags f�r SetLayeredWindowAttributes und UpdateLayeredWindow

#ifndef WS_EX_LAYERED
#define WS_EX_LAYERED           0x00080000
#define LWA_COLORKEY            0x00000001
#define LWA_ALPHA               0x00000002
#endif
#define AC_SRC_ALPHA			0x00000001
#define ULW_ALPHA				0x00000002

LRESULT CALLBACK MainWindowProc    ( HWND, UINT, WPARAM, LPARAM );
LRESULT CALLBACK AboutWindowProc   ( HWND, UINT, WPARAM, LPARAM );
LRESULT CALLBACK SubClassWindowProc( HWND, UINT, WPARAM, LPARAM );
LRESULT CALLBACK HookCallWindowProc( int nCode,  WPARAM wParam, LPARAM lParam );

static HINSTANCE	hInstance;
static HWND			hEdit;
static HHOOK		hHookID = 0;

typedef BOOL (WINAPI *lpfnSetLayeredWindowAttributes)( HWND hWnd, COLORREF crKey, BYTE bAlpha, DWORD dwFlags );

typedef BOOL (WINAPI *lpfnUpdateLayeredWindow)( HWND hwnd, HDC hdcDst, POINT *pptDst, SIZE *psize, HDC hdcSrc, 
											    POINT *pptSrc, COLORREF crKey, BLENDFUNCTION *pblend, DWORD dwFlags );

lpfnUpdateLayeredWindow			pUpdateLayeredWindow;
lpfnSetLayeredWindowAttributes	pSetLayeredWindowAttributes;

//
// Win Main
//
int APIENTRY WinMain( HINSTANCE _hInstance, HINSTANCE hPrevInstance, 
					  LPSTR lpszCmdParam, int cmdShow )
{
	HWND hWnd;
	MSG  msg;
	
	hInstance = _hInstance;

	// herk�mmliche Fensterklasse
	WNDCLASS windowClass;
	windowClass.cbClsExtra		= 0;
	windowClass.cbWndExtra		= 0;
	windowClass.hbrBackground	= (HBRUSH)GetStockObject( NULL_BRUSH );
	windowClass.hCursor			= LoadCursor( NULL, IDC_ARROW );
	windowClass.hIcon			= LoadIcon( hInstance, MAKEINTRESOURCE( IDR_MAINFRAME ) );
	windowClass.hInstance		= hInstance;
	windowClass.lpfnWndProc		= (WNDPROC)MainWindowProc;
	windowClass.lpszClassName	= "PCU Demo";
	windowClass.lpszMenuName	= MAKEINTRESOURCE( IDR_MAINFRAME );
	windowClass.style			= CS_HREDRAW | CS_VREDRAW;
	RegisterClass( &windowClass );

	hWnd = CreateWindow( "PCU Demo", "PC Underground - Transparenz und Men� Demo", WS_OVERLAPPEDWINDOW,
						 CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, (HMENU)NULL,
						 hInstance, NULL );

	ShowWindow( hWnd, cmdShow );
	MoveWindow( hWnd, 200, 200, 600, 150, true );

	// Die Funktionsadressen der beiden neueren Funktionen aus der USER32.DLL holen:

	HMODULE modUSER32DLL;

	modUSER32DLL = GetModuleHandle("USER32.DLL");
	
	pSetLayeredWindowAttributes = 
		(lpfnSetLayeredWindowAttributes)GetProcAddress( modUSER32DLL, "SetLayeredWindowAttributes" );

	pUpdateLayeredWindow = 
		(lpfnUpdateLayeredWindow)GetProcAddress( modUSER32DLL, "UpdateLayeredWindow" );

	if ( !pSetLayeredWindowAttributes || !pUpdateLayeredWindow )
	{
		MessageBox( NULL, "Konnte Funktionsadressen nicht laden", "PC Underground Error", MB_OK );
		return false;
	}

	while( GetMessage( &msg, 0, 0, 0 ) ) 
	{
		TranslateMessage( &msg );
		DispatchMessage ( &msg );
	}

	return msg.wParam;
}

//
// Message Handler des Hauptfensters
//
LRESULT CALLBACK MainWindowProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch ( msg ) 
	{
		case WM_CREATE:
			hHookID = SetWindowsHookEx( WH_CALLWNDPROC, HookCallWindowProc,
									    0, GetWindowThreadProcessId( hWnd, 0 ) );

			hEdit = CreateWindowEx( WS_EX_CLIENTEDGE, "edit", NULL, 
				WS_CHILD | WS_VISIBLE | ES_MULTILINE | WS_HSCROLL | WS_VSCROLL,
				0, 0, 0, 0, hWnd, (HMENU)NULL, hInstance, NULL );

			return 0;

		case WM_COMMAND:
			switch ( LOWORD( wParam ) ) 
			{
				case IDM_ABOUT:
					DialogBox( hInstance, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)AboutWindowProc );
					break;
				case IDM_FILE_EXIT:
					PostQuitMessage( 0 );
					break;
				default:
				   return DefWindowProc( hWnd, msg, wParam, lParam );
			}
			return 0;

		case WM_SIZE:
			RECT r;
			
			GetClientRect( hWnd, &r );
			
			r.bottom -= r.top;

	 		MoveWindow( hEdit, r.left, r.top, r.right, r.bottom, true );

			return 0;

		case WM_DESTROY:
			
			if ( hHookID )
				UnhookWindowsHookEx( hHookID );

			PostQuitMessage( 0 );

			return 0;
	}

	return	DefWindowProc( hWnd, msg, wParam, lParam );
}

//
// Das ist der Message Handler f�r die "About Box" - er demonstriert das Per-Pixel Alpha Blending
//
LRESULT CALLBACK AboutWindowProc( HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam )
{
	HDC		dcScreen, dcMemory;
	RECT	rect;
	POINT	windowPos;
	SIZE	windowSize;
	HBITMAP	bmp;

	POINT	srcPointer = { 0, 0 };
	BLENDFUNCTION blendPixelFunction= { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };

	DWORD image[ 256 * 256 ];


	switch (message)
	{
		case WM_INITDIALOG:
			// Als erstes m�ssen wir dem Fenster wieder das WS_EX_LAYERED Attribut geben
			SetWindowLong( hDlg, GWL_EXSTYLE, GetWindowLong( hDlg, GWL_EXSTYLE ) | WS_EX_LAYERED );

			// Parameter des Fensters
			GetClientRect( hDlg, &rect );

			windowPos.x = rect.left;
			windowPos.y = rect.top;
			windowSize.cx = rect.right;
			windowSize.cy = rect.bottom;

			// Device Contexts erzeugen
			dcScreen = GetDC( NULL );
			dcMemory = CreateCompatibleDC( dcScreen );

			// Und ein Bitmap erzeugen, in das wir unser Fensterbild speichern
			bmp = CreateCompatibleBitmap( GetDC( GetDesktopWindow() ), rect.right, rect.bottom );

			SetBkMode   ( dcMemory, TRANSPARENT );
			SetBkColor  ( dcMemory, GetSysColor( COLOR_MENU ) );
			SelectObject( dcMemory, bmp );

			// Image laden, bearbeiten und in den Device Context schreiben
			{
				// erstmal ein Bitmap im Speicher anlegen, dazu brauchen wir als Beschreibung
				// einen Bitmap Infoheader
				BITMAPINFO   *bitmapinfo;
				int bisize = sizeof( BITMAPINFOHEADER );
				bitmapinfo = (BITMAPINFO *)malloc( bisize + 12 );
				ZeroMemory( &bitmapinfo->bmiHeader, bisize );

				bitmapinfo->bmiHeader.biSize        = bisize;
				bitmapinfo->bmiHeader.biWidth       = 256;
				bitmapinfo->bmiHeader.biHeight      = -256;
				bitmapinfo->bmiHeader.biPlanes      = 1;
				bitmapinfo->bmiHeader.biBitCount    = 32;
				bitmapinfo->bmiHeader.biCompression = BI_BITFIELDS;
				*((long*) bitmapinfo->bmiColors +0) = 0xff0000;
				*((long*) bitmapinfo->bmiColors +1) = 0x0ff00;
				*((long*) bitmapinfo->bmiColors +2) = 0x00fF;

				// Jetzt laden wir das Bild aus einem RAW-Image
				FILE *f = fopen( "./data/tw256.raw", "rb" );
				fread( image, 256*256*4, 1, f );
				fclose( f );

				// Und multiplizieren die RGB Kan�le mit dem Alpha Wert
				for ( int j = 0; j < 256; j++ )
					for ( int i = 0; i < 256; i++ )
					{
						int r, g, b, alpha;

						r = ( image[ i + j * 256 ] >> 0 ) & 255;
						g = ( image[ i + j * 256 ] >> 8 ) & 255;
						b = ( image[ i + j * 256 ] >> 16 ) & 255;
						alpha = 255 - ( ( image[ i + j * 256 ] >> 24 ) & 255 );

						r = ( r * alpha ) >> 8;
						g = ( g * alpha ) >> 8;
						b = ( b * alpha ) >> 8;

						image[ i + j * 256 ] =
							( r << 16 ) | ( g << 8 ) | ( b << 0 ) | ( alpha << 24 );
					}

				// Und ab in den Device Context
				SetDIBitsToDevice( dcMemory, 0, 0, 256, 256,
							 0, 0, 0, 256, image, bitmapinfo,
							 DIB_RGB_COLORS );
			}

			// und alles anschalten:
			pUpdateLayeredWindow(hDlg, dcScreen, &windowPos, &windowSize, dcMemory,
				&srcPointer, 0, &blendPixelFunction, ULW_ALPHA);

			// Und am Ende noch das Fenster Positionieren
			MoveWindow( hDlg, 200, 200, rect.right, rect.bottom, false );

			return true;

		case WM_COMMAND:
			switch ( LOWORD( wParam ) )
			{
				case IDOK:
				case IDCANCEL:
					EndDialog( hDlg, 0 );
					return true;
			}
			return true;

	}
    return false;
}

//
// Diese Window Procedure wird vor der eigentlichen Window Procedure aufgerufen
// Sie wird genutzt, um eine eigene Window-Procedure f�r jedes Pull-Down Menu Fenster
// zu installieren
//
LRESULT CALLBACK HookCallWindowProc( int nCode, WPARAM wParam, LPARAM lParam )
{
	// Message Parameter
	CWPSTRUCT cwps;

	LONG handle;
	CHAR szClass[ 128 ];

	if( nCode == HC_ACTION )
	{
		CopyMemory( &cwps, (void*)lParam, sizeof( CWPSTRUCT ) );

		switch( cwps.message )
		{
			case WM_CREATE:

				// Beim erzeugen nachsehen, obs ein Pull-Down Menu ist
				GetClassName( cwps.hwnd, szClass, 127 );

				if ( lstrcmpi( szClass, "#32768" ) == 0 )
				{
					// .. dann die neue Window Procedure einh�ngen
					handle = SetWindowLong( cwps.hwnd, GWL_WNDPROC, (LONG)SubClassWindowProc );
					SetProp( cwps.hwnd, "OldWindowProcedure", (HANDLE)handle );
				}
				break;
		}
	}

	return CallNextHookEx( (HHOOK)WH_CALLWNDPROC, nCode, wParam, lParam );
}



LRESULT CALLBACK SubClassWindowProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	WNDPROC oldWindowProc = (WNDPROC)GetProp(hWnd, "OldWindowProcedure");

	int		i;

	HDC		tempHDC, tempHDC2;
	RECT	rect;
	HBITMAP bitmap, bitmap2;

	switch( uMsg )
	{
	case WM_CREATE:
		// wenn das Menu auch transparent sein soll:
		//SetWindowLong( hWnd, GWL_EXSTYLE, GetWindowLong( hWnd, GWL_EXSTYLE ) | WS_EX_LAYERED );
		//pSetLayeredWindowAttributes( hWnd, 0, 200, LWA_ALPHA );
		break;

	// diese beiden Messages sind interessant, wenn die Auswahl im Menu sich �ndert
	case WM_KEYDOWN:
	case 0x1e5: 
		GetClientRect ( hWnd, &rect );
		InvalidateRect( hWnd, &rect, false );
		return CallWindowProc( oldWindowProc, hWnd, uMsg, wParam, lParam );

	// und hier zeichnen wir selbst ! Zumindest den Hintergrund ;-)
	case WM_PAINT:
		// gr��e des fensters
		GetClientRect( hWnd, &rect );

		tempHDC  = CreateCompatibleDC( NULL );
		bitmap   = CreateCompatibleBitmap( GetDC( GetDesktopWindow() ), rect.right, rect.bottom );

		tempHDC2 = CreateCompatibleDC( NULL );
		bitmap2  = CreateCompatibleBitmap( GetDC( GetDesktopWindow() ), rect.right, rect.bottom );


		SetBkMode   ( tempHDC, TRANSPARENT );
		SetBkColor  ( tempHDC, GetSysColor( COLOR_MENU ) );
		SelectObject( tempHDC, bitmap );

		SetBkMode   ( tempHDC2, TRANSPARENT );
		SetBkColor  ( tempHDC2, GetSysColor( COLOR_MENU ) );
		SelectObject( tempHDC2, bitmap2 );


		FillRect( tempHDC, &rect, (HBRUSH)GetSysColor(COLOR_MENU) );

		for ( i = rect.top; i < rect.bottom; i += 4 )
		{
			RECT line   = rect;
			line.top    = i;
			line.bottom = i + 4;

			int frac = (i << 16) / ( rect.bottom - rect.top );
			int r = ( (255<<16) + frac * (200-255) ) >> 16;
			int g = ( (255<<16) + frac * (235-255) ) >> 16;
			int b = ( (255<<16) + frac * (255-255) ) >> 16;
			HBRUSH brush = CreateSolidBrush( (r)|(g<<8)|(b<<16) );
			FillRect( tempHDC2, &line, brush );
			DeleteObject( brush );
		}

		CallWindowProc( oldWindowProc, hWnd, WM_PRINTCLIENT, (LPARAM)tempHDC, PRF_CLIENT | PRF_CHECKVISIBLE );

		TransparentBlt( tempHDC2, rect.left, rect.top, rect.right-rect.left, rect.bottom-rect.top, 
			            tempHDC,  rect.left, rect.top, rect.right-rect.left, rect.bottom-rect.top, GetSysColor(COLOR_MENU) );

		BitBlt( GetDC( hWnd ), rect.left, rect.top, rect.right-rect.left, rect.bottom-rect.top, tempHDC2, 0, 0, SRCCOPY );

		DeleteDC( tempHDC );
		DeleteDC( tempHDC2 );
		DeleteObject( bitmap );
		DeleteObject( bitmap2 );

		ValidateRect( hWnd, &rect );
		return 0;

	// Und wieder aufr�umen
	case WM_DESTROY:
		RemoveProp   ( hWnd, "OldWindowProcedure" );
		SetWindowLong( hWnd, GWL_WNDPROC, (LONG)oldWindowProc );
		break;
	
	default:
		break;
	}

	return CallWindowProc( oldWindowProc, hWnd, uMsg, wParam, lParam );
}



