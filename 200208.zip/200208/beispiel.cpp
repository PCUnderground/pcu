////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  OpenGL nVidia Texture Shader und Register Combiner    //
//  aka Pixel Shader								      //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include	<windows.h>			
#include	<math.h>
#include	<gl\gl.h>
#include	<gl\glu.h>
#include	<gl\glaux.h>
#include	"glext.h"
#include	"texture.h"
#include	"3DObject.h"

// wir verwenden nvparse !
// ACHTUNG: die mitgelieferte nvparse Bibliothek beinhaltet
// einen Bugfix (aber nur f�r PS1.0 Programme notwendig, der in
// der offiziellen Version von nVidia noch nicht enthalten ist
#define GLH_EXT_SINGLE_FILE
#include	"glh_extensions.h"
#include	"openglhelpers.h"
#include	"nvparse.h"

// Texturen die geladen werden
PCUTexture *ballTexture, *backgroundTexture;

// 3D Objekte die geladen werden
C3DObject	*objSphere;

GLuint		cubeMap, bumpMapTexture, deltaTexture;

unsigned char heightMap[ 256 * 256 ];
unsigned char deltaMap[ 256 * 256 * 2 ];
unsigned char bumpMap[ 256 * 256 * 2 ];
unsigned char deltaMap32[ 256 * 256 * 4 ];

// neue Bumpmap aus den Gr�n/Blau Werten basteln
void updateBumpMap()
{
	unsigned char *bumpy = bumpMap;
	unsigned char *bumpy32 = deltaMap32+1;

	for ( int i = 0; i < 256*256; i++ )
	{
		*(bumpy++) = *(bumpy32++);
		*(bumpy++) = *(bumpy32++);
		bumpy32+=2;
	}

	glTexImage2D( GL_TEXTURE_2D, 0, GL_DSDT_NV,  256,256, 0, GL_DSDT_NV,  GL_UNSIGNED_BYTE, bumpMap );
}


// BumpMap DSDT Texture und deltaTexture anlegen 
void createBumpMap()
{
	// Bumpmap
	glGenTextures( 1, (unsigned int*)&bumpMapTexture );

	glBindTexture( GL_TEXTURE_2D, bumpMapTexture );

	glTexParameterf( GL_TEXTURE_2D,GL_TEXTURE_WRAP_S, GL_TEXTURE_WRAP_S );
	glTexParameterf( GL_TEXTURE_2D,GL_TEXTURE_WRAP_T, GL_TEXTURE_WRAP_T );
	glTexParameterf( GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER, GL_LINEAR );
	glTexParameterf( GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER, GL_LINEAR );

	// delta Texture aus Heightmap berechnen:
	unsigned char delta[256*256*4];
	memset( delta, 0, 256*256*4 );

	for ( int j = 0; j < 256; j++ )
		for ( int i = 0; i < 256; i++ )
		{
			int dx = heightMap[ ((i+1)&255) + (j<<8) ] - heightMap[ (i&255) + (j<<8) ];
			int dy = heightMap[ (i&255) + (((j+1)&255)<<8) ] - heightMap[ (i&255) + (j<<8) ];

			dx <<= 1;
			dy <<= 1;
			dx += 64;
			dy += 64;

			delta[ ( i + j * 256 ) * 4 + 1 ] = dx;
			delta[ ( i + j * 256 ) * 4 + 2 ] = dy;
		}

	// deltaTexture anlegen
	glGenTextures( 1, (unsigned int*)&deltaTexture );

	glBindTexture( GL_TEXTURE_2D, deltaTexture );

	glTexParameterf( GL_TEXTURE_2D,GL_TEXTURE_WRAP_S, GL_TEXTURE_WRAP_S );
	glTexParameterf( GL_TEXTURE_2D,GL_TEXTURE_WRAP_T, GL_TEXTURE_WRAP_T );
	glTexParameterf( GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER, GL_LINEAR );
	glTexParameterf( GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER, GL_LINEAR );
	gluBuild2DMipmaps(GL_TEXTURE_2D, 4, 256, 256, GL_RGBA, GL_UNSIGNED_BYTE, delta );
}




void	init3DEngine()
{
	// Allgemeine Renderstates

	FILE *f = fopen( "./data/heightmap.raw", "rb" );
	fread( heightMap, 1, 256*256, f );
	fclose( f );

    glShadeModel( GL_SMOOTH );

	glHint( GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST );

	glDisable( GL_POLYGON_SMOOTH );

	glEnable( GL_DEPTH_TEST );
	glFrontFace( GL_CCW );
	glEnable( GL_CULL_FACE );
	glCullFace( GL_BACK );
	glDepthFunc( GL_LEQUAL );
	glDisable( GL_LINE_SMOOTH );

	// texturen laden
	ballTexture = new PCUTexture();
	ballTexture->loadBMP( "./data/blue.bmp" );

	backgroundTexture = new PCUTexture();
	backgroundTexture->loadBMP( "./data/background.bmp" );

	glClearDepth( 1.0f );

	// 3D Modelle laden
	objSphere = new C3DObject( "./data/kugel.3d" );

	createBumpMap();

	extern int initExtensions();
	if ( !initExtensions() )
	{
		MessageBox( NULL, "Ben�tigte OpenGL Extensions werden nicht unterst�tzt !", "Schade !", MB_OK );
		exit( 1 );
	}
}

static GLfloat lightPosition[] = { 5.0f, 5.0f, 5.0f, 1.0f };


void	draw3DEngine()
{
	// Texture Shader: 4 Units an !
	nvparse("!!TS1.0 texture_2d(); texture_2d(); texture_2d(); texture_2d(); " );

	// Register Combiner: 4 Units skalieren und addieren !
	nvparse(
		"!!RC1.0						\n"
		"const0= ( 0.7, 0.7, 0.7, 0.7 );\n"
		"{								\n"
		"  rgb                          \n"
		"  {                            \n"
		"    discard = tex0*const0;     \n"
		"    spare0 = tex1*const0;      \n"
		"    spare1 = sum();            \n"
		"  }                            \n"
		"}                              \n"
		"{                              \n"
		"  rgb                          \n"
		"  {                            \n"
		"    discard = spare1;          \n"
		"    spare0 = tex2*const0;      \n"
		"    spare1 = sum();            \n"
		"  }                            \n"
		"}                              \n"
		"{                              \n"
		"  rgb                          \n"
		"  {                            \n"
		"    discard = spare1;          \n"
		"    spare0 = tex3*const0;      \n"
		"    spare1 = sum();            \n"
		"  }                            \n"
		"}                              \n"
		"out.rgb = spare1;              \n"
		);

	glEnable( GL_TEXTURE_SHADER_NV );
	glEnable( GL_REGISTER_COMBINERS_NV );

	glActiveTextureARB(GL_TEXTURE3_ARB);
	glBindTexture( GL_TEXTURE_2D, deltaTexture );

	glActiveTextureARB(GL_TEXTURE2_ARB);
	glBindTexture( GL_TEXTURE_2D, deltaTexture );

	glActiveTextureARB(GL_TEXTURE1_ARB);
	glBindTexture( GL_TEXTURE_2D, deltaTexture );

	glActiveTextureARB(GL_TEXTURE0_ARB);
	glBindTexture( GL_TEXTURE_2D, deltaTexture );


	glViewport( 0, 0, 256, 256 );

	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();

	glTranslatef( -1.0f, -1.0f, 0.0f );
	glScalef( 1.0f / 256.0f, 1.0f / 256.0f, 1.0f );

	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();

	glDisable( GL_DEPTH_TEST );

	#define RENDERQUAD(xx, yy, xxx, yyy, xx1, yy1, xx2, yy2) \
			glBegin( GL_TRIANGLE_STRIP );\
				glMultiTexCoord2fARB( GL_TEXTURE0_ARB, xx, yy );\
				glMultiTexCoord2fARB( GL_TEXTURE1_ARB, xxx, yyy );\
				glMultiTexCoord2fARB( GL_TEXTURE2_ARB, xx1, yy1 );\
				glMultiTexCoord2fARB( GL_TEXTURE3_ARB, xx2, yy2 );\
				glVertex3f( 0.0f, 0.0f, 0.0f );\
				glMultiTexCoord2fARB( GL_TEXTURE0_ARB, xx+1, yy );\
				glMultiTexCoord2fARB( GL_TEXTURE1_ARB, xxx+1, yyy );\
				glMultiTexCoord2fARB( GL_TEXTURE2_ARB, xx1+1, yy1 );\
				glMultiTexCoord2fARB( GL_TEXTURE3_ARB, xx2+1, yy2 );\
				glVertex3f( 512.0f, 0.0f, 0.0f );\
				glMultiTexCoord2fARB( GL_TEXTURE0_ARB, xx, yy+1 );\
				glMultiTexCoord2fARB( GL_TEXTURE1_ARB, xxx, yyy+1 );\
				glMultiTexCoord2fARB( GL_TEXTURE2_ARB, xx1, yy1+1 );\
				glMultiTexCoord2fARB( GL_TEXTURE3_ARB, xx2, yy2+1 );\
				glVertex3f( 0.0f, 512.0f, 0.0f );\
				glMultiTexCoord2fARB( GL_TEXTURE0_ARB, xx+1, yy+1 );\
				glMultiTexCoord2fARB( GL_TEXTURE1_ARB, xxx+1, yyy+1 );\
				glMultiTexCoord2fARB( GL_TEXTURE2_ARB, xx1+1, yy1+1 );\
				glMultiTexCoord2fARB( GL_TEXTURE3_ARB, xx2+1, yy2+1 );\
				glVertex3f( 512.0f, 512.0f, 0.0f ); \
			glEnd();

	glDisable( GL_BLEND );

	// Vier Quads mit verschobenen Texturekoordinaten zeichnen !
	RENDERQUAD( GetTickCount() * 0.00005681f, GetTickCount() * 0.000082f,
				100-GetTickCount() * 0.00001223f, 100-GetTickCount() * 0.00006242f,
				GetTickCount() * 0.00005723f, 100-GetTickCount() * 0.00004244f,0,0 )

	glReadPixels( 0, 0, 256, 256, GL_RGBA, GL_UNSIGNED_BYTE, deltaMap32 );

	// Viewport wieder auf Fenstergr��e !
	extern int windowX, windowY;
	glViewport( 0, 0, windowX, windowY );

	nvparse( "!!TS1.0 texture_2d(); nop(); nop(); nop();" );

	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glDisable( GL_REGISTER_COMBINERS_NV );

	glActiveTextureARB(GL_TEXTURE0_ARB);
	backgroundTexture->select();

	RENDERQUAD( (float)sin(GetTickCount() * 0.0005681f)+1.0f, 0, 0, 0, 0, 0, 0, 0 );

	glActiveTextureARB(GL_TEXTURE0_ARB);
	glBindTexture( GL_TEXTURE_2D, bumpMapTexture );

	// neue DSDT Map berechnen
	updateBumpMap();
	
	glActiveTextureARB(GL_TEXTURE1_ARB);
	ballTexture->select();

#if 0
	// so sieht die Texture Shader Initialisierung ohne nvparse aus !

	glActiveTextureARB(GL_TEXTURE0_ARB);
	glTexEnvi( GL_TEXTURE_SHADER_NV, GL_SHADER_OPERATION_NV, GL_TEXTURE_2D );

	glActiveTextureARB(GL_TEXTURE1_ARB);
	glTexEnvi( GL_TEXTURE_SHADER_NV, GL_SHADER_OPERATION_NV, 
	  GL_OFFSET_TEXTURE_2D_NV );

	glTexEnvi( GL_TEXTURE_SHADER_NV, GL_PREVIOUS_TEXTURE_INPUT_NV,
	  GL_TEXTURE0_ARB );

	// Bump St�rke
	float mat2d[] = { 0.8f, 0.0f, 0.0f, 0.8f };

	glTexEnvfv( GL_TEXTURE_SHADER_NV, GL_OFFSET_TEXTURE_MATRIX_NV, mat2d );

	glEnable( GL_TEXTURE_SHADER_NV );
#endif
	glActiveTextureARB(GL_TEXTURE0_ARB);

	nvparse("!!TS1.0 texture_2d(); offset_2d( tex0, 0.8, 0.0, 0.0, 0.8 ); nop(); nop();" );
	glEnable( GL_TEXTURE_SHADER_NV );

	// View Parameter + Kugel zeichnen
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();

	extern int windowX, windowY;

	gluPerspective( 45.0f, (float)windowX / (float)max( 1, windowY ), 0.1f, 500.0f );

	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();
	glTranslatef( 0, 0, -50 );
	
	glEnable( GL_NORMALIZE );

	glRotatef( 20, 1, 0, 0 );

	glColor4ub( 255, 255, 255, 255 );
	glScalef( 30, 30, 30 );
	objSphere->drawObject();



	glFlush();
}

void	quit3DEngine()
{
}



