////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#ifndef _3DOBJECT__H
#define _3DOBJECT__H

#include	<windows.h>			
#include	<gl\gl.h>			
#include	<gl\glu.h>			

typedef struct
{
	GLfloat		x, y, z;
}VERTEX3D;

class C3DObject
{
	private:
		typedef struct
		{
			GLint		a, b, c;
			VERTEX3D	normal;
		}FACE;

		VERTEX3D	*pVertexList;
		VERTEX3D	*pNormalList;
		VERTEX3D	*pTexCoord;
		FACE		*pFaceList;

		int			nVertices,
					nFaces;

	public:
		C3DObject( char *file = NULL );
		~C3DObject();

		void		drawObject();
		void		drawObjectFog();
};

#endif