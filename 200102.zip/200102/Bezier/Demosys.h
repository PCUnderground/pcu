///////////////////////////////////////////////////////////
//                                                       //
// PC MAGAZIN - Demo Projekt                             //
//                                                       //
// Header File f�r die Grafikbibliothek                  //
//                                                       //
// Carsten Dachsbacher, Nils Pipenbrinck                 //
//                                                       //
///////////////////////////////////////////////////////////

#ifndef __demosys_h
#define __demosys_h

// Fenster-Modes
#define FENSTER     0
#define SKALIERBAR  1
#define VOLLBILD    2
#define DDVOLLBILD  3

// Metric des Fensters
#define SCREEN_X    400
#define SCREEN_Y    300

// Die Positionen der RGB Anteile
#define ROT_POS     16
#define GRUEN_POS   8
#define BLAU_POS    0

// Die Gr��e der Anteile in Bits
#define ROT_SIZE    8
#define GRUEN_SIZE  8
#define BLAU_SIZE   8

// Die AND-Maske f�r die RGB Anteile 
#define ROT_MASKE   ( ( 1 << ROT_SIZE ) - 1 ) << ROT_POS
#define GRUEN_MASKE ( ( 1 << GRUEN_SIZE ) - 1 ) << GRUEN_POS
#define BLAU_MASKE  ( ( 1 << BLAU_SIZE ) - 1 ) << BLAU_POS

// Darstellungsmodus des Fensters
extern int              Fenster_Modus;

// Das Window-Handle des Fensters. Wird u.A. zum initialisieren
// der Sound-Library gebraucht.
extern HWND             DemoHWND;

// 16 Bit Farb Tabellen
extern int              Rtab[256];  
extern int              Gtab[256];  
extern int              Btab[256];

// Status des Demo-Threads.
extern volatile BOOL    DemoRunning;     

// Funktionen der Grafik-Library
unsigned int  ColorCode     (int r, int g, int b);
void            BlitGraphic   (void *buf);
unsigned long   GetDemoTime   (void);

// Tabelle der gedrueckten Tasten:
extern unsigned char KeyStatus[];

// Externe Funktionen. Diese m�ssen vom Demo/Spiel implementiert
// sein.
BOOL demoinit (void);
void demomain (void);
void demoquit (void);


#endif
