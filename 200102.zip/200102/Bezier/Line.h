#ifndef __line_h
#define __line_h


int clip2d(int &px, int &py, int &qx, int &qy);
void LineDrawClipped (int x0, int y0, int x1, int y1, long c);
void SetClipRect (int x0, int y0, int x1, int y1);

#endif
