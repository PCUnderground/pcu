void	clearMatrix( MATRIX m )
{
	for( register int cm = 0; cm < 16; cm++ ) ((float*)&m[0][0])[ cm ] = 0.0f;
	((float*)&m[0][0])[ 15 ] = 1.0f;
}

void	setIdentMatrix( MATRIX m )
{
	clearMatrix( m );
	m[ 0 ][ 0 ] = 1.0f;
	m[ 1 ][ 1 ] = 1.0f;
	m[ 2 ][ 2 ] = 1.0f;
}

void	createRotationMatrix( MATRIX dest, float *rotate )
{
	clearMatrix( dest );

	float	sr, sp, sy, cr, cp, cy;
	
	sy = (float)sin( rotate[ 2 ] );
	cy = (float)cos( rotate[ 2 ] );
	sp = (float)sin( rotate[ 1 ] );
	cp = (float)cos( rotate[ 1 ] );
	sr = (float)sin( rotate[ 0 ] );
	cr = (float)cos( rotate[ 0 ] );

	dest[ 0 ][ 0 ] = cp*cy;
	dest[ 1 ][ 0 ] = cp*sy;
	dest[ 2 ][ 0 ] = -sp;
	dest[ 0 ][ 1 ] = sr*sp*cy+cr*-sy;
	dest[ 1 ][ 1 ] = sr*sp*sy+cr*cy;
	dest[ 2 ][ 1 ] = sr*cp;
	dest[ 0 ][ 2 ] = (cr*sp*cy+-sr*-sy);
	dest[ 1 ][ 2 ] = (cr*sp*sy+-sr*cy);
	dest[ 2 ][ 2 ] = cr*cp;
	dest[ 0 ][ 3 ] = 0.0;
	dest[ 1 ][ 3 ] = 0.0;
	dest[ 2 ][ 3 ] = 0.0;
}

void	mulMatrix( MATRIX c, MATRIX a, MATRIX b )
{
	MATRIX temp;

	clearMatrix( temp );

	temp[0][0] = a[0][0] * b[0][0] + a[0][1] * b[1][0] +
				a[0][2] * b[2][0];
	temp[0][1] = a[0][0] * b[0][1] + a[0][1] * b[1][1] +
				a[0][2] * b[2][1];
	temp[0][2] = a[0][0] * b[0][2] + a[0][1] * b[1][2] +
				a[0][2] * b[2][2];
	temp[0][3] = a[0][0] * b[0][3] + a[0][1] * b[1][3] +
				a[0][2] * b[2][3] + a[0][3];
	temp[1][0] = a[1][0] * b[0][0] + a[1][1] * b[1][0] +
				a[1][2] * b[2][0];
	temp[1][1] = a[1][0] * b[0][1] + a[1][1] * b[1][1] +
				a[1][2] * b[2][1];
	temp[1][2] = a[1][0] * b[0][2] + a[1][1] * b[1][2] +
				a[1][2] * b[2][2];
	temp[1][3] = a[1][0] * b[0][3] + a[1][1] * b[1][3] +
				a[1][2] * b[2][3] + a[1][3];
	temp[2][0] = a[2][0] * b[0][0] + a[2][1] * b[1][0] +
				a[2][2] * b[2][0];
	temp[2][1] = a[2][0] * b[0][1] + a[2][1] * b[1][1] +
				a[2][2] * b[2][1];
	temp[2][2] = a[2][0] * b[0][2] + a[2][1] * b[1][2] +
				a[2][2] * b[2][2];
	temp[2][3] = a[2][0] * b[0][3] + a[2][1] * b[1][3] +
				a[2][2] * b[2][3] + a[2][3];

   memcpy( c, temp, sizeof(MATRIX) );
}

void rotate( float *dest, MATRIX matrix, float *src )
{
	dest[0] = src[0]*matrix[0][0] + src[1]*matrix[0][1] + src[2]*matrix[0][2];
	dest[1] = src[0]*matrix[1][0] + src[1]*matrix[1][1] + src[2]*matrix[1][2];
	dest[2] = src[0]*matrix[2][0] + src[1]*matrix[2][1] + src[2]*matrix[2][2];
}

void invrotate( float *dest, MATRIX matrix, float *src )
{
	dest[0] = src[0]*matrix[0][0] + src[1]*matrix[1][0] + src[2]*matrix[2][0];
	dest[1] = src[0]*matrix[0][1] + src[1]*matrix[1][1] + src[2]*matrix[2][1];
	dest[2] = src[0]*matrix[0][2] + src[1]*matrix[1][2] + src[2]*matrix[2][2];
}
