////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//                                                        //
//  Implementation der MS3D Klasse                        //
//                                                        //
//  (w)(c)2001 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <gl\gl.h>			
#include <math.h>
#include <string.h>
#include "ms3d.h"
#include "texture.h"

#define M_PI 3.141592

#include "matrix.h"

int	MS3DObject::loadObject( char *path, char *name )
{
	FILE *f;
	char filename[ 256 ];

	strcpy( filename, path );
	strcat( filename, name );

	if( ( f = fopen( filename, "rb" ) ) == NULL )
	{
		MessageBox( NULL, "MS3D Datei konnte nicht ge�ffnet werden !", "MS3D Error", MB_OK );
		return 0;
	}

	//Read the header data in
	fread( &header.id, sizeof( char ), 10, f );
	fread( &header.version, 1, sizeof( int ), f );

	if( strncmp( header.id, "MS3D000000", 10 ) != 0 )
	{
		MessageBox( NULL, "Keine MS3D Datei !", "MS3D Error", MB_OK );
		return 0;
	}

	if( header.version != 3 && header.version != 4 )
	{
		MessageBox( NULL, "Falsche Version der MS3D Datei !", "MS3D Error", MB_OK );
		return 0;
	}

	// vertex daten lesen
	fread( &nVertices, sizeof( word ), 1, f );

	pVertex = new MS3D_VERTEX[ nVertices ];

	for ( int i = 0; i < nVertices; i ++ )
	{
		fread( &pVertex[ i ].flags,	   sizeof( byte ),  1, f );
		fread(  pVertex[ i ].vertex,   sizeof( float ), 3, f );
		fread( &pVertex[ i ].boneId,   sizeof( char ),  1, f );
		fread( &pVertex[ i ].refCount, sizeof( byte ),  1, f );
	}

	// triangle daten lesen

	fread( &nTriangles, sizeof( word ), 1, f );

	pTriangle = new MS3D_TRIANGLE[ nTriangles ];

	for ( i = 0; i < nTriangles; i ++ )
	{
		fread( &pTriangle[ i ].flags,			 sizeof( word ),  1, f );
		fread(  pTriangle[ i ].vertexIndices,	 sizeof( word ),  3, f );
		fread(  pTriangle[ i ].vertexNormals[0], sizeof( float ), 3, f );
		fread(  pTriangle[ i ].vertexNormals[1], sizeof( float ), 3, f );
		fread(  pTriangle[ i ].vertexNormals[2], sizeof( float ), 3, f );
		fread(  pTriangle[ i ].s,				 sizeof( float ), 3, f );
		fread(  pTriangle[ i ].t,				 sizeof( float ), 3, f );
		fread( &pTriangle[ i ].smoothingGroup,	 sizeof( byte ),  1, f );
		fread( &pTriangle[ i ].groupIndex,		 sizeof( byte ),  1, f );
	}

	// Triangle Groups lesen
	fread( &nGroups, sizeof( word ), 1, f );

	pGroup = new MS3D_GROUP[ nGroups ];

	for ( i = 0; i < nGroups; i ++ )
	{
		fread( &pGroup[ i ].flags,			 sizeof( byte ), 1,	 f );
		fread(  pGroup[ i ].name,			 sizeof( char ), 32, f );
		fread( &pGroup[ i ].nTriangles,	     sizeof( word ), 1,	 f );

		pGroup[ i ].triangleIndices = new word [ pGroup[ i ].nTriangles ];

		fread(  pGroup[ i ].triangleIndices, sizeof( word ), pGroup[ i ].nTriangles,f );
		fread( &pGroup[ i ].materialIndex,	 sizeof( char ), 1, f );
	}

	// Triangle Groups lesen
	fread( &nMaterials, sizeof( word ), 1, f );

	pMaterial = new MS3D_MATERIAL[ nMaterials ];

	for ( i = 0; i < nMaterials; i ++ )
	{
		fread( &pMaterial[ i ].name,		sizeof( char ),  32, f );
		fread( &pMaterial[ i ].ambient,		sizeof( float ), 4,	 f );
		fread( &pMaterial[ i ].diffuse,		sizeof( float ), 4,	 f );
		fread( &pMaterial[ i ].specular,	sizeof( float ), 4,	 f );
		fread( &pMaterial[ i ].emissive,	sizeof( float ), 4,	 f );
		fread( &pMaterial[ i ].shininess,	sizeof( float ), 1,	 f );
		fread( &pMaterial[ i ].transparency,sizeof( float ), 1,	 f );
		fread( &pMaterial[ i ].mode,		sizeof( char ),  1,	 f );
		fread( &pMaterial[ i ].texture,		sizeof( char ),  128,f );
		fread( &pMaterial[ i ].alphamap,	sizeof( char ),  128,f );

		if ( pMaterial[ i ].texture[ 0 ] != 0 )
		{
			pMaterial[ i ].textureMap = new PCUTexture();

			char buf[ 256 ];

			strcpy( buf, path );

			char *name = pMaterial[ i ].texture;
			if ( name[ 0 ] == '.' && name[ 1 ] == '\\' ) name += 2;

			char *ext = strchr( name, '.' );

			int	lengthPath = strlen( buf );
			int length = ext - name;

			strncat( buf, name, length );
			buf[ lengthPath + length ] = 0;

			strcat( buf, ".BMP" );
	
			pMaterial[ i ].textureMap->loadBMP( buf );
		} else
			pMaterial[ i ].textureMap = NULL;
	}

	fread( &fAnimationFPS, sizeof( float ), 1, f );
	fread( &fCurrentTime, sizeof( float ), 1, f );
	fread( &iTotalFrames, sizeof( int ), 1, f );
	fread( &nJoints, sizeof( word ), 1, f );

	pJoint = new MS3D_JOINT[ nJoints ];

	for ( i = 0; i < nJoints; i++ )
	{
		fread( &pJoint[ i ].flags, sizeof( byte ), 1, f );
		fread( &pJoint[ i ].name, sizeof( char ) * 32, 1, f );
		fread( &pJoint[ i ].parentName, sizeof( char ) * 32, 1, f );
		fread( &pJoint[ i ].rotation, sizeof( float ), 3, f );
		fread( &pJoint[ i ].position, sizeof( float ), 3, f );
		fread( &pJoint[ i ].nKeyFramesRot, sizeof( word ), 1, f );
		fread( &pJoint[ i ].nKeyFramesPos, sizeof( word ), 1, f );

		pJoint[ i ].keyFramesRot = new MS3D_KEYFRAME_ROT[ pJoint[ i ].nKeyFramesRot ];
		pJoint[ i ].keyFramesPos = new MS3D_KEYFRAME_POS[ pJoint[ i ].nKeyFramesPos ];

		fread( pJoint[ i ].keyFramesRot, sizeof( MS3D_KEYFRAME_ROT ), pJoint[ i ].nKeyFramesRot, f );
		fread( pJoint[ i ].keyFramesPos, sizeof( MS3D_KEYFRAME_POS ), pJoint[ i ].nKeyFramesPos, f );

		for ( int j = 0; j < pJoint[ i ].nKeyFramesRot; j++ )
			pJoint[ i ].keyFramesRot[ j ].time *= fAnimationFPS;
		for ( j = 0; j < pJoint[ i ].nKeyFramesPos; j++ )
			pJoint[ i ].keyFramesPos[ j ].time *= fAnimationFPS;
	}	

	pBone = new BONE[ nJoints ];

	if ( nJoints > 0 )
	{
		// Bones initialisieren
		for ( i = 0; i < nJoints; i++ )
		{
			MS3D_JOINT *bone = &pJoint[ i ];

			float vRot[ 3 ];
			vRot[0] = bone->rotation[ 0 ];
			vRot[1] = bone->rotation[ 1 ];
			vRot[2] = bone->rotation[ 2 ];

			createRotationMatrix( pBone[ i ].mRelative, vRot );
			pBone[ i ].mRelative[ 0 ][ 3 ] = bone->position[ 0 ];
			pBone[ i ].mRelative[ 1 ][ 3 ] = bone->position[ 1 ];
			pBone[ i ].mRelative[ 2 ][ 3 ] = bone->position[ 2 ];

			int nParentBone = -1;
			for ( int j = 0; j < nJoints; j++ )
				if ( strcmp( pJoint[ j ].name, bone->parentName ) == 0 )
				{
					nParentBone = j; break;
				}

			if ( nParentBone != -1 )
			{
				mulMatrix( pBone[ i ].mAbsolute, pBone[ nParentBone ].mAbsolute, pBone[ i ].mRelative );
			}
			else
			{
				memcpy( pBone[ i ].mAbsolute, pBone[ i ].mRelative, sizeof( MATRIX ) );
			}
			memcpy( pBone[ i ].mFinal, pBone[ i ].mAbsolute, sizeof( MATRIX ) );
		}

		for ( int j = 0; j < nVertices; j++)
		{
			MS3D_VERTEX *pV = &pVertex[ j ];
			if ( pV->boneId != -1 )
			{
				MATRIX *mAbsolute = &pBone[ pV->boneId ].mAbsolute;
				pV->vertex[0] -= (*mAbsolute)[ 0 ][ 3 ];
				pV->vertex[1] -= (*mAbsolute)[ 1 ][ 3 ];
				pV->vertex[2] -= (*mAbsolute)[ 2 ][ 3 ];
				
				float temp[ 3 ];

				invrotate( temp, *mAbsolute, pV->vertex );
				memcpy( pV->vertex, temp, sizeof( float ) * 3 );
			}
		}
	}

	return 1;
}

void MS3DObject::getExtends()
{
	float minVX = 1e37f, maxVX = -1e37f,
		  minVY = 1e37f, maxVY = -1e37f,
		  minVZ = 1e37f, maxVZ = -1e37f;

	for ( int i = 0; i < nVertices; i++ )
	{
		minVX = min( pVertex[ i ].animVertex[ 0 ], minVX );
		maxVX = max( pVertex[ i ].animVertex[ 0 ], maxVX );
		minVY = min( pVertex[ i ].animVertex[ 1 ], minVY );
		maxVY = max( pVertex[ i ].animVertex[ 1 ], maxVY );
		minVZ = min( pVertex[ i ].animVertex[ 2 ], minVZ );
		maxVZ = max( pVertex[ i ].animVertex[ 2 ], maxVZ );
	}

	moveX = -0.5f * ( maxVX + minVX );
	moveY = -0.5f * ( maxVY + minVY );
	moveZ = -0.5f * ( maxVZ + minVZ );
	float range = (float)max( fabs( minVX - maxVX ), max( fabs( minVY - maxVY ), fabs( minVZ - maxVZ ) ) );
	scale = 1.0f / range;
}

void MS3DObject::normalize()
{
	float minVX = 1e37f, maxVX = -1e37f,
		  minVY = 1e37f, maxVY = -1e37f,
		  minVZ = 1e37f, maxVZ = -1e37f;

	for ( int i = 0; i < nVertices; i++ )
	{
		minVX = min( pVertex[ i ].vertex[ 0 ], minVX );
		maxVX = max( pVertex[ i ].vertex[ 0 ], maxVX );
		minVY = min( pVertex[ i ].vertex[ 1 ], minVY );
		maxVY = max( pVertex[ i ].vertex[ 1 ], maxVY );
		minVZ = min( pVertex[ i ].vertex[ 2 ], minVZ );
		maxVZ = max( pVertex[ i ].vertex[ 2 ], maxVZ );
	}

	float moveX = -0.5f * ( maxVX + minVX );
	float moveY = -0.5f * ( maxVY + minVY );
	float moveZ = -0.5f * ( maxVZ + minVZ );
	float range = (float)max( fabs( minVX - maxVX ), max( fabs( minVY - maxVY ), fabs( minVZ - maxVZ ) ) );
	float scale = 1.0f / range;

	for ( i = 0; i < nVertices; i++ )
	{
		pVertex[ i ].vertex[ 0 ] = ( pVertex[ i ].vertex[ 0 ] + moveX ) * scale;
		pVertex[ i ].vertex[ 1 ] = ( pVertex[ i ].vertex[ 1 ] + moveY ) * scale;
		pVertex[ i ].vertex[ 2 ] = ( pVertex[ i ].vertex[ 2 ] + moveZ ) * scale;
	}
}

void MS3DObject::renderObject( bool currentFrame )
{
	if ( currentFrame )
	{
		for ( int i = 0; i < nVertices; i++ )
			if ( pVertex[ i ].boneId == -1 )
				memcpy( pVertex[ i ].animVertex, pVertex[ i ].vertex, sizeof( float ) * 3 ); else
			{
				rotate( pVertex[ i ].animVertex, pBone[ pVertex[ i ].boneId ].mFinal, 
							pVertex[ i ].vertex );
				pVertex[ i ].animVertex[ 0 ] += pBone[ pVertex[ i ].boneId ].mFinal[ 0 ][ 3 ];
				pVertex[ i ].animVertex[ 1 ] += pBone[ pVertex[ i ].boneId ].mFinal[ 1 ][ 3 ];
				pVertex[ i ].animVertex[ 2 ] += pBone[ pVertex[ i ].boneId ].mFinal[ 2 ][ 3 ];

			}

		///////////////
		// das ist eigentlich nur f�r den viewer interessant, dass die 
		// animation immer sch�n in der mitte ist !
		if ( firstFrame )
		{
			getExtends();
			firstFrame = 0;
		}
		for ( i = 0; i < nVertices; i++ )
		{
			pVertex[ i ].animVertex[ 0 ] = ( pVertex[ i ].animVertex[ 0 ] + moveX ) * scale;
			pVertex[ i ].animVertex[ 1 ] = ( pVertex[ i ].animVertex[ 1 ] + moveY ) * scale;
			pVertex[ i ].animVertex[ 2 ] = ( pVertex[ i ].animVertex[ 2 ] + moveZ ) * scale;
		}
		//
		///////////////
	}
	for ( int i = 0; i < nGroups; i++ )
	{
		// Materialparameter setzen
		int mat = pGroup[ i ].materialIndex;

		if ( mat != -1 )
		{
			glMaterialfv( GL_FRONT_AND_BACK, GL_AMBIENT, pMaterial[ mat ].ambient );
			glMaterialfv( GL_FRONT_AND_BACK, GL_DIFFUSE, pMaterial[ mat ].diffuse );
			glMaterialfv( GL_FRONT_AND_BACK, GL_SPECULAR, pMaterial[ mat ].specular );
			glMaterialfv( GL_FRONT_AND_BACK, GL_SHININESS, &pMaterial[ mat ].shininess );
			glMaterialfv( GL_FRONT_AND_BACK, GL_EMISSION, pMaterial[ mat ].emissive );

			if ( pMaterial[ mat ].textureMap )
				pMaterial[ mat ].textureMap->select();
		}

		glBegin( GL_TRIANGLES );

		for ( int j = 0; j < pGroup[ i ].nTriangles; j ++ )
		{
			const MS3D_TRIANGLE *tri= &pTriangle[ pGroup[ i ].triangleIndices[ j ] ];

			for ( int k = 0; k < 3; k ++ )
			{
				glNormal3fv  ( tri->vertexNormals[ k ]  );
				glTexCoord2f ( tri->s[ k ], tri->t[ k ] );

				// kein high performance, dass if hier zu plazieren ;)
				if ( currentFrame )
					glVertex3fv  ( pVertex[ tri->vertexIndices[ k ] ].animVertex ); else
					glVertex3fv  ( pVertex[ tri->vertexIndices[ k ] ].vertex );
			}
		}

		glEnd();
	}
}

void MS3DObject::setFrame( float frame )
{
	if ( frame > iTotalFrames )
		frame = 0;

	for ( int i = 0; i < nJoints; i++ )
	{
		MS3D_JOINT *bone = &pJoint[ i ];

		int nPositionKeyCount = bone->nKeyFramesPos;
		int nRotationKeyCount = bone->nKeyFramesRot;

		if ( nPositionKeyCount == 0 && nRotationKeyCount == 0 )
		{
			memcpy ( pBone[ i ].mFinal, pBone[ i ].mAbsolute, sizeof( MATRIX ) );
		} else
		{
			float vPos[ 3 ];
			float vRot[ 4 ];

			// die Animationskeys suchen

			MS3D_KEYFRAME_POS *pLastPositionKey = NULL, 
							  *pThisPositionKey = NULL;

			for ( int j = 0; j < nPositionKeyCount; j++ )
			{
				MS3D_KEYFRAME_POS *pPositionKey = &bone->keyFramesPos[ j ];

				if ( pPositionKey->time >= frame )
				{
					pThisPositionKey = pPositionKey;
					break;
				}
				pLastPositionKey = pPositionKey;
			}

			// Position interpolieren !
			if ( pLastPositionKey != NULL && pThisPositionKey != NULL )
			{
				float d = pThisPositionKey->time - pLastPositionKey->time;
				float s = ( frame - pLastPositionKey->time ) / d;
				vPos[ 0 ] = pLastPositionKey->position[ 0 ] + 
					( pThisPositionKey->position[ 0 ] - pLastPositionKey->position[ 0 ] )  * s;
				vPos[ 1 ] = pLastPositionKey->position[ 1 ] + 
					( pThisPositionKey->position[ 1 ] - pLastPositionKey->position[ 1 ] )  * s;
				vPos[ 2 ] = pLastPositionKey->position[ 2 ] + 
					( pThisPositionKey->position[ 2 ] - pLastPositionKey->position[ 2 ] )  * s;
			} else 
			if ( pLastPositionKey == NULL )
			{
				memcpy( vPos, pThisPositionKey->position, sizeof( float ) * 3 );
			} else 
			if ( pThisPositionKey == NULL )
			{
				memcpy( vPos, pLastPositionKey->position, sizeof( float ) * 3 );
			}

			// die Rotationskeys suchen !
			MATRIX m;

			MS3D_KEYFRAME_ROT *pLastRotationKey = NULL,
							  *pThisRotationKey = NULL;

			for ( j = 0; j < nRotationKeyCount; j++ )
			{
				MS3D_KEYFRAME_ROT *pRotationKey = &bone->keyFramesRot[ j ];

				if ( pRotationKey->time >= frame )
				{
					pThisRotationKey = pRotationKey;
					break;
				}
				pLastRotationKey = pRotationKey;
			}
			if ( pLastRotationKey != NULL && pThisRotationKey != NULL )
			{
				float d = pThisRotationKey->time - pLastRotationKey->time;
				float s = ( frame  - pLastRotationKey->time ) / d;

				vRot[ 0 ] = pLastRotationKey->rotation[ 0 ] + 
					( pThisRotationKey->rotation[ 0 ] - pLastRotationKey->rotation[ 0 ] ) * s;
				vRot[ 1 ] = pLastRotationKey->rotation[ 1 ] + 
					( pThisRotationKey->rotation[ 1 ] - pLastRotationKey->rotation[ 1 ] ) * s;
				vRot[ 2 ] = pLastRotationKey->rotation[ 2 ] + 
					( pThisRotationKey->rotation[ 2 ] - pLastRotationKey->rotation[ 2 ] ) * s;
			} else 
			if ( pLastRotationKey == NULL )
			{
				vRot[ 0 ] = pThisRotationKey->rotation[ 0 ];
				vRot[ 1 ] = pThisRotationKey->rotation[ 1 ];
				vRot[ 2 ] = pThisRotationKey->rotation[ 2 ];
			} else 
			if ( pThisRotationKey == NULL )
			{
				vRot[ 0 ] = pLastRotationKey->rotation[ 0 ];
				vRot[ 1 ] = pLastRotationKey->rotation[ 1 ];
				vRot[ 2 ] = pLastRotationKey->rotation[ 2 ];
			}

			createRotationMatrix( m, vRot );

			m[ 0 ][ 3 ] = vPos[ 0 ];
			m[ 1 ][ 3 ] = vPos[ 1 ];
			m[ 2 ][ 3 ] = vPos[ 2 ];

			mulMatrix( pBone[ i ].mRelativeFinal, pBone[ i ].mRelative, m );

			int nParentBone = -1;
			for ( j = 0; j < nJoints; j++ )
				if ( strcmp( pJoint[ j ].name, bone->parentName ) == 0 )
				{
					nParentBone = j; break;
				}

			if ( nParentBone == -1 )
			{
				memcpy( pBone[ i ].mFinal, pBone[ i ].mRelativeFinal, sizeof( MATRIX ) );
			} else
			{
				mulMatrix( pBone[ i ].mFinal, pBone[ nParentBone ].mFinal, pBone[ i ].mRelativeFinal );
			}
		}
	}
}
















