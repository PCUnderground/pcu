
// Resource-Id's
#define IDI_DEMO_ICON                   101
#define IDC_BLANK_CURSOR                102

#define ID_APP							100
#define idsAppName						1007
#define DLG_SCRNSAVECONFIGURE           2003
