///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - Demo Projekt                            //
//                                                       //
//  Beispielprogramm f�r die Anwendung von MIDAS         //
//                                                       //
///////////////////////////////////////////////////////////
#include <stdio.h>
#include "demo.h"

unsigned char text[ 20 * 14 ] =
		"                    "  \
		" HALLO              "  \
		" DIES IST EIN TEXT  "  \
		"                    "  \
		" AUF JETZT          "  \
		" LOS ZUM RULEN      "  \
		"                    "  \
		" GAME LAMING SUXX   "  \
		"                    "  \
		"                    "  \
		"                    "  \
		"                    "  \
		"                    ";

unsigned short *screen;

// Wird ben�tigt, um den Fenstertitel zu �ndern
extern HWND DemoHWND;

bitmaptype		zeichen;
unsigned short  *zpal;
unsigned char   *zbitmap;

BOOL demoinit (void)
{
    Fenster_Modus = FENSTER;

    // Speicher f�r das Bild reservieren
    screen = (unsigned short *)malloc( SCREEN_X * SCREEN_Y * 2 );
    if ( screen == NULL ) return 0;
    memset (screen, 0, SCREEN_X * SCREEN_Y * 2);

	// Hintergrundbild und Zahlen-Bild laden
    if ( bmp_load( "C:\CHARS.BMP", zeichen ) !=
         BMP_NOERROR ) return 0;

	bmp_make16bitpalette( zeichen );
    
    zbitmap = (unsigned char *)zeichen.cBitmap;

	zpal = (unsigned short*)zeichen.sColors;

    return TRUE;
}

void mputchar( int x, int y, char c )
{
	unsigned char p;

	if ( c == ' ' ) return;
	
	int n = c - 'A';

	int px = ( n % 10 ) * 16;

	int py = ( n / 10 ) * 18;

	int o = px + py * 320;
	int o2 = x + y * 320;
	for ( int j = 0; j < 16; j++ )
	{
		for ( int i = 0; i < 16; i++ )
		{
			p = zbitmap[ o ++ ];
			if ( p != 0 )
				screen[ o2 ] = zpal[ p ];
			o2 ++;
		}
		o += 320 - 16;
		o2 += 320 - 16;
	}
}



void demomain( void )
{
/*	FILE *f = fopen("xyz.aaa", "wb" );
	if ( f == NULL )
		Beep( 500, 100 );
	fclose(f );*/
//		Beep( 500, 100 );
    while ( DemoRunning )
    {
		memset( screen, 0, SCREEN_X * SCREEN_Y * 2 );

		int m = sin( GetDemoTime() / 120.0 ) * 10.0;
		for ( int j = 0; j < 14; j++ )
			for ( int i = 0; i < 20; i++ )
				mputchar( m + i * 16, j * 18, text[ i + j * 20 ] );
//		for ( int i = 0; i < 320*240; i++ )
//			screen[ i ] = rand();

		BlitGraphic( screen );
//		Beep( 500, 100 );
    }
}

void demoquit( void )
{
}

