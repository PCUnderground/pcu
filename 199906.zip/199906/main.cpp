////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground - Game Project            //
//                                                        //
//  Beispielprogramm f�r die Partikel- und Spriteroutinen //
//                                                        //
//  (w)(c)�99 Carsten Dachsbacher                         //
//                                                        //
////////////////////////////////////////////////////////////

#include "demo.h"
#include "sprite.h"
#include "fx.h"

bitmaptype bmp;
bitmaptype back;

SPRITE sprite;

#define ANIMSPRITES 5
#define ANIMSTEPS  64

SPRITE		*ship1;

unsigned short *screen;
unsigned short *background;

unsigned char	*bild;

BOOL demoinit (void)
{
	Fenster_Modus = FENSTER;//*0+DDVOLLBILD;

	screen = (unsigned short *)malloc( SCREEN_X * SCREEN_Y * sizeof( short ) );
	background = (unsigned short *)malloc( SCREEN_X * SCREEN_Y * sizeof( short ) );

	if ( bmp_load( "back2.bmp", back ) != BMP_NOERROR ) return 0;
	bmp_make16bitpalette( back );
	for ( int i = 0; i < SCREEN_X * SCREEN_Y; i++ )
	{
		background[ i ] = back.sColors[ back.cBitmap[ i ] ];
	}
	bmp_free( back );

	ship1 = (SPRITE*)malloc( sizeof( SPRITE ) * ANIMSTEPS * ANIMSPRITES );
	for ( int j = 0; j < ANIMSTEPS * ANIMSPRITES; j++ )
		ship1[ j ].data = NULL;

	InitParticleSystem();

	return TRUE;
}


extern HWND DemoHWND;

void demomain (void)
{
	// Verwendung von CreateRotationAnimation:
	// Dieser Routinen geben Sie die Adresse einer Liste auf "SPRITE",
	// die Anzahl der gew�nschten Rotationsphasen des Sprites und eine
	// "bitmaptype" Struktur. Die Routine geht davon aus, das der Sprite
	// das komplette Bitmap ausf�llt und erzeugt daraus die Bilder des
	// drehenden Sprites mithilfe von Bilinearer Interpolation
    if ( bmp_load( "ship100.BMP", bmp ) != BMP_NOERROR ) return;
	CreateRotationAnimation( &ship1[ 0 * ANIMSTEPS ], ANIMSTEPS, bmp );
	bmp_free( bmp );

    if ( bmp_load( "ship110.BMP", bmp ) != BMP_NOERROR ) return;
	CreateRotationAnimation( &ship1[ 1 * ANIMSTEPS ], ANIMSTEPS, bmp );
	bmp_free( bmp );

    if ( bmp_load( "ship101.BMP", bmp ) != BMP_NOERROR ) return;
	CreateRotationAnimation( &ship1[ 2 * ANIMSTEPS ], ANIMSTEPS, bmp );
	bmp_free( bmp );

    if ( bmp_load( "ship111.BMP", bmp ) != BMP_NOERROR ) return;
	CreateRotationAnimation( &ship1[ 3 * ANIMSTEPS ], ANIMSTEPS, bmp );
	bmp_free( bmp );

    if ( bmp_load( "ship1s1.BMP", bmp ) != BMP_NOERROR ) return;
	CreateRotationAnimation( &ship1[ 4 * ANIMSTEPS  ], ANIMSTEPS, bmp );
	bmp_free( bmp );

	int frame = 0;

	srand( 0 );

	// Eine Explosion als Begr�ssung 
	BigShipExplosion( 170, 75 );
	
	while ((DemoRunning) && (!KeyStatus[VK_ESCAPE]))
	{
		memcpy( screen, background, SCREEN_X * SCREEN_Y * 2 );

		// Raumschiffe zeichnen
		for ( int i = 0; i < 4; i++ )
			DrawSprite( screen, 275-160, 145-120 + i * 110, ship1[ i * ANIMSTEPS + (frame>>3) % ANIMSTEPS ] );

		DrawSprite( screen, 275-160 + 130, 145-120, ship1[ 4 * ANIMSTEPS + (frame>>3) % ANIMSTEPS ] );

		int nr = (frame % 400)/100;
		if ( nr == 2 )
			nr *= ( frame / 10 ) % 2;
		if ( nr == 3 )
		{
			nr *= ( frame / 10 ) % 2;
			if (!nr) nr=1;
		}
		DrawSprite( screen, 275-160 + 150, 145-120+150, ship1[ nr * ANIMSTEPS + (frame>>3) % ANIMSTEPS ] );

		frame ++;

		// Einen Rauchschweif bewegen
		float time = GetDemoTime() / 4500.0f * 3.14f;

		AddSmoke( 
			(int)( sin( time ) * 100.0f + 320.0f ),
			(int)( cos( time/2.0f ) * 100.0f + 240.0f ),
			5 );


		// Explosionen Queue abarbeiten
		HandleExplosion();

		// Bei Space eine Explosion starten
		if ( KeyStatus[VK_SPACE] )
			BigShipExplosion( 170, 75 );

		// Partikel zeichnen
		DrawExplosion( screen );
		DrawSmoke( screen );

		BlitGraphic( screen );
	}
}	


void demoquit (void)
{
	for ( int j = 0; j < ANIMSPRITES * ANIMSTEPS; j++ )
		FreeSprite( ship1[ j ] );

	free( screen );
	free( background );
}

