///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - PC Underground - Game Project           //
//                                                       //
//  Spriteroutinen, die mit RLE gepackten Spritedaten    //
//  arbeiten                                             //
//                                                       //
//  (w)(c)�99 Carsten Dachsbacher                        //
//                                                       //
///////////////////////////////////////////////////////////

#include <string.h>
#include <malloc.h>
#include "demo.h"
#include "sprite.h"

#define ASSEMBLER_SPRITEROUTINE

#define RAW		0
#define RLE		1
#define MSB		32768
#define NEWLINE	65535

void	GetSpriteRaw( unsigned short *image, int imagewidth, int x, int y, int dx, int dy, SPRITE &sprite )
{
	sprite.size_x	= dx;
	sprite.size_y	= dy;

	sprite.data		= (unsigned short *)malloc( sizeof( short ) * dx * dy );

	int offset = 0;

	for ( int j = y; j < y + dy; j++ )
		for ( int i = x; i < x + dx; i++ )
			sprite.data[ offset++ ] = image[ i + j * imagewidth ];

	sprite.type = RAW;
	sprite.size = dx * dy;
}

void	GetSpriteRLE( unsigned short *image, int imagewidth, int x, int y, int dx, int dy, SPRITE &sprite )
{
	sprite.size_x	= dx;
	sprite.size_y	= dy;

	unsigned short *temp = (unsigned short *)malloc( sizeof( short ) * dx * dy * 2 );
	unsigned short *raw  = (unsigned short *)malloc( sizeof( short ) * dx * dy );

	int offset = 0;		// Position innerhalb der gepackten Daten
	int position = 0;	// Position beim RLE Packen

	for ( int j = y; j < y + dy; j++ )
		for ( int i = x; i < x + dx; i++ )
			raw[ offset++ ] = image[ i + j * imagewidth ];

	offset = 0;

	int length = dx * dy;

	while ( position < length )
	{
		int count = 0;
		int newline = 0;

		if ( raw[ position ] == 0 )
		{
			while ( ( raw[ position ] == 0 ) && ( position < length ) && ( !newline ) ) 
			{
				if ( ( ( ( position + 1 ) % dx ) == 0 ) )
					newline = 1; 
				count ++;
				position ++;
			}
			temp[ offset ++ ] = count | MSB;
		} else
		{
			int npos = offset ++;

			while ( ( raw[ position ] != 0 ) && ( position < length ) && ( !newline ) )
			{
				if ( ( ( ( position + 1 ) % dx ) == 0 ) )
					newline = 1;
				temp[ offset ++ ] = raw[ position ];
				count ++;
				position ++;
			}
			temp[ npos ] = count;
		}

		if ( newline )
			temp[ offset ++ ] = NEWLINE;
	}

	sprite.data		= (unsigned short *)malloc( sizeof( short ) * offset );
	memcpy( sprite.data, temp, sizeof( short ) * offset );

	sprite.size = offset;
	sprite.type = RLE;

	free( temp );
	free( raw );
}

void	DrawSprite( unsigned short *screen, int x, int y, SPRITE &sprite )
{
	if ( sprite.data == NULL ) return;
	switch ( sprite.type )
	{
		case RAW:
			break;

		case RLE:
			// Feststellen, ob der Sprite geclipped werden mu�
			int clip_up = 0;
			int clip_down = 0;
			int clip_left = 0;
			int clip_right = 0;
			int clip = 0;

			// Rechte Seite
			if ( x >= SCREEN_X ) return; else
				if ( ( x + sprite.size_x ) >= SCREEN_X ) clip_right = SCREEN_X - x;
			// Linke Seite
			if ( x < 0 )
			{
				if ( -x > sprite.size_x ) return; else
					clip_left = - x;
			}
			// Obere Kante
			if ( y < 0 )
			{
				if ( -y > sprite.size_y ) return; else
					clip_up = - y;
			}
			// Untere Kante
			if ( y >= SCREEN_Y ) return; else
				if ( ( y + sprite.size_y ) >= SCREEN_Y ) clip_down = SCREEN_Y - y;

			clip = clip_up + clip_down + clip_left + clip_right;

			unsigned short *screenoffset = screen + x + y * SCREEN_X;
			int spriteoffset = 0;

			if ( clip )
			/*** Sprite mit Clipping zeichnen ***/
			{
				unsigned int data;
				int actual_y = y;

				// Obere Zeilen �berspringen
				while ( clip_up )
				{
					data = sprite.data[ spriteoffset ++ ];
					if ( data == NEWLINE )
					{
						screenoffset += SCREEN_X - sprite.size_x;
						actual_y ++;
						clip_up --;
					} else
					{
						if ( !( data & MSB ) )
							spriteoffset += data;

						screenoffset += data & ~(unsigned int)MSB;
					}
				}

				if ( clip_left )
				{
					int skipleft = clip_left;

					while ( spriteoffset < sprite.size )
					{
						data = sprite.data[ spriteoffset ++ ];
						if ( data == NEWLINE )
						{
							screenoffset += SCREEN_X - sprite.size_x;
							actual_y ++;
							if ( actual_y >= SCREEN_Y ) return;
							skipleft = clip_left;
						} else
							if ( data & MSB )
							{
								// Transparente Stelle
								screenoffset += data - (unsigned int)MSB;
								skipleft -= data - (unsigned int)MSB;
							} else
							{
								for ( unsigned int i = 0; i < data; i++ )
									if ( skipleft > 0 ) 
									{
										skipleft --; 
										screenoffset ++;
										spriteoffset ++;
									} else
										*screenoffset++ = sprite.data[ spriteoffset ++ ];
							}
					}
				} else
				if ( clip_right )
				{
					int to_draw = clip_right;

					while ( spriteoffset < sprite.size )
					{
						data = sprite.data[ spriteoffset ++ ];
						if ( data == NEWLINE )
						{
							screenoffset += SCREEN_X - sprite.size_x;
							actual_y ++;
							if ( actual_y >= SCREEN_Y ) return;
							to_draw = clip_right;
						} else
							if ( data & MSB )
							{
								// Transparente Stelle
								screenoffset += data - (unsigned int)MSB;
								to_draw -= data - (unsigned int)MSB;
							} else
							{
								for ( unsigned int i = 0; i < data; i++ )
									if ( to_draw > 0 ) 
									{
										to_draw --; 
										*screenoffset++ = sprite.data[ spriteoffset ++ ];
									} else
									{
										screenoffset ++;
										spriteoffset ++;
									}
							}
					}
				} else
				{
					while ( spriteoffset < sprite.size )
					{
						data = sprite.data[ spriteoffset ++ ];
						if ( data == NEWLINE )
						{
							screenoffset += SCREEN_X - sprite.size_x;
							actual_y ++;
							if ( actual_y >= SCREEN_Y ) return;
						} else
							if ( data & MSB )
							{
								// Transparente Stelle
								screenoffset += data - (unsigned int)MSB;
							} else
							{
								for ( unsigned int i = 0; i < data; i++ )
										*screenoffset++ = sprite.data[ spriteoffset ++ ];
							}
					}
				}

			} else
			/*** Sprite ohne Clipping zeichnen ***/
			{
#ifndef	ASSEMBLER_SPRITEROUTINE
				while ( spriteoffset < sprite.size )
				{
					unsigned int data = sprite.data[ spriteoffset ++ ];
					if ( data == NEWLINE )
					{
						// Sprung in die n�chste Zeile
						screenoffset += SCREEN_X - sprite.size_x;
					} else
						if ( data & MSB )
						{
							// Transparente Stelle
							screenoffset += data - (unsigned int)MSB;
						} else
						{
							// Bilddaten
							for ( int i = 0; i < data; i++ )
								*screenoffset++ = sprite.data[ spriteoffset ++ ];
						}
				}
#else
				/** Registerbelegung:
					EAX		Daten aus dem Sprite / Zwischenspeicher
					EBX		Zeiger auf Spritestruktur
					ECX		Z�hler
					EDX		Zeiger auf Ende der Spritedaten
					EDI		Zeiger auf Bildschirmspeicher
					ESI		Zeiger auf aktuelle Position in den Spritedaten
				**/
				__asm
				{
					mov		ebx, sprite

					  mov		eax, [ ebx + 8 ]			// sprite.size

					 mov		esi, [ ebx + 16 ]			// sprite.data

					 mov		edx, esi

					  add		eax, eax
					
					 add		edx, eax

					mov		edi, [ screenoffset ]

					while_loop:
					// Spritedaten auslesen
					sub		eax, eax
					mov		ax, [ esi ]
					add		esi, 2

					cmp		eax, NEWLINE
					jne		data
						// Neue Zeile
						mov		ecx, SCREEN_X
						sub		ecx, [ ebx + 0 ]		// sprite.size_x
						add		ecx, ecx
						add		edi, ecx
						jmp		go_on
					data:
						mov		ecx, eax
						and		eax, MSB
						jz		pixel
							// Transparente Stelle
							mov		eax, ecx
							sub		eax, MSB
							add		eax, eax
							add		edi, eax
							jmp		go_on
						pixel:
							// Ab hier gilt es "ecx" Pixel zu kopieren
							shr		ecx, 1

							jnc		keine_ungerade_anzahl_von_pixel
								mov		ax, [ esi ]
								mov		[ edi ], ax
								add		esi, 2
								add		edi, 2
						  keine_ungerade_anzahl_von_pixel:

							and		ecx, ecx
							jz		go_on

						  pixel_dword:
							mov		eax, [ esi ]
							mov		[ edi ], eax
							add		esi, 4
							add		edi, 4
							dec		ecx
							jnz		pixel_dword

				go_on:
					cmp		esi, edx
					jb		while_loop
				}
#endif
			}
			break;
	}
}

void	FreeSprite( SPRITE sprite )
{
	sprite.size_x = sprite.size_y = sprite.size = sprite.type = 0;
	if ( sprite.data != NULL ) free( sprite.data );
}

void	CreateRotationAnimation( SPRITE *sprite, int steps, bitmaptype bmp )
{
	int size = bmp.width;
	int imagewidth = bmp.bytesperline;
	float winkel;
	unsigned char *bild = bmp.cBitmap;

	unsigned short *temp = (unsigned short *)malloc( sizeof( short ) * imagewidth * bmp.height );
	
	for ( int w = 0; w < steps; w++ )
	{
		winkel = (float)w / (float)steps * 2.0f * 3.14159265359f;

		float cosinus = (float)cos( winkel );
		float sinus = (float)sin( winkel );

		for ( int y = 0; y < size; y ++ )
			for ( int x = 0; x < size; x++ )
			{
				float fx = x - (float)size / 2.0f;
				float fy = y - (float)size / 2.0f;

				float fx1 = (float)( cosinus * fx - sinus * fy );
				float fy1 = (float)( sinus * fx + cosinus * fy );
				
				fx1 += (float)size / 2.0f;
				fy1 += (float)size / 2.0f;
				
				int x1 = (int)( fx1 );
				int y1 = (int)( fy1 );
				
				float d_h, d_v;
			
				d_h = fx1 - x1;
				d_v = fy1 - y1;
				
				int r[ 4 ], g[ 4 ], b[ 4 ];
				int farbe[ 4 ];
				if ( ( x1 >= 0 ) && ( x1 < (size - 1) ) && ( y1 >= 0 ) && ( y1 < (size - 1) ) )
				{
					farbe[ 0 ] = bild[ x1 + y1 * imagewidth ];
					farbe[ 1 ] = bild[ x1 + 1 + y1 * imagewidth ];
					farbe[ 2 ] = bild[ x1 + ( y1 + 1 ) * imagewidth ];
					farbe[ 3 ] = bild[ x1 + 1 + ( y1 + 1 ) * imagewidth ];
				} else
				{
					farbe[ 0 ] = farbe[ 1 ] = farbe[ 2 ] = farbe[ 3 ] = -1;
				}
				for ( int i = 0; i < 4; i++ )
				{
					if ( farbe[ i ] == -1 )
					{
						r[ i ] = g[ i ] = b[ i ] = 0;
					} else
					{
						r[ i ] = bmp.cColors[ farbe[ i ] * 4 + 0 ];
						g[ i ] = bmp.cColors[ farbe[ i ] * 4 + 1 ];
						b[ i ] = bmp.cColors[ farbe[ i ] * 4 + 2 ];
					}
				}
				
				float r_oben, r_unten, rv;
				float g_oben, g_unten, gv;
				float b_oben, b_unten, bv;
				r_oben  = ( 1.0f - d_h ) * r[ 0 ] + d_h * r[ 1 ];
				r_unten = ( 1.0f - d_h ) * r[ 2 ] + d_h * r[ 3 ];
				rv		= ( 1.0f - d_v ) * r_oben + d_v * r_unten;
				
				g_oben  = ( 1.0f - d_h ) * g[ 0 ] + d_h * g[ 1 ];
				g_unten = ( 1.0f - d_h ) * g[ 2 ] + d_h * g[ 3 ];
				gv		= ( 1.0f - d_v ) * g_oben + d_v * g_unten;
				
				b_oben  = ( 1.0f - d_h ) * b[ 0 ] + d_h * b[ 1 ];
				b_unten = ( 1.0f - d_h ) * b[ 2 ] + d_h * b[ 3 ];
				bv		= ( 1.0f - d_v ) * b_oben + d_v * b_unten;
				
				int color = ColorCode( (int)rv, (int)gv, (int)bv );				
				
				temp[ x + y * imagewidth ] = color;
			}

		GetSpriteRLE( temp, imagewidth, 0, 0, size, size, sprite[ w ] );
	}

	free( temp );
}
