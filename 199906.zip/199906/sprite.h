///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - PC Underground - Game Project           //
//                                                       //
//  Spriteroutinen, die mit RLE gepackten Spritedaten    //
//  arbeiten                                             //
//                                                       //
//  (w)(c)�99 Carsten Dachsbacher                        //
//                                                       //
///////////////////////////////////////////////////////////

#ifndef __sprite_h
#define __sprite_h

typedef struct
{
	int				size_x, size_y;		// Gr��e des Sprites in x und y Richtung
	int				size;				// Gr��e des Sprites in Pixel
	int				type;				// 0 = Raw, 1 = RLE "gepackt"
	unsigned short	*data;				// Zeiger auf die Daten
}SPRITE;

void	GetSpriteRaw( unsigned short *image, int imagewidth, int x, int y, int dx, int dy, SPRITE &sprite );
void	GetSpriteRLE( unsigned short *image, int imagewidth, int x, int y, int dx, int dy, SPRITE &sprite );
void	DrawSprite( unsigned short *screen, int x, int y, SPRITE &sprite );
void	CreateRotationAnimation( SPRITE *sprite, int steps, bitmaptype bmp );
void	FreeSprite( SPRITE sprite );

#endif