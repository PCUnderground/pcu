///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - PC Underground - Game Project           //
//                                                       //
//  Partikelsystem f�r Rauch und Explosionen             //
//                                                       //
//  (w)(c)�99 Carsten Dachsbacher                        //
//                                                       //
///////////////////////////////////////////////////////////

#ifndef __fx_h
#define __fx_h

typedef struct
{
	int				life;				// Lebensdauer des Partikels
	int				x, y;				// Position
	int				dx, dy;				// Bewegung
	int				ddx, ddy;			// Bewegungs�nderung
}PARTICLE;

void	StartExplosion( int x, int y, int n );
void	DrawExplosion();

void	InitParticleSystem();

void	AddExplosion( int x, int y, int density, int type );
void	DrawExplosion( unsigned short *screen );
void	BigShipExplosion( int x, int y );
void	RocketExplosion( int x, int y );
void	HandleExplosion();

void	AddSmoke( int x, int y, int density );
void	DrawSmoke( unsigned short *screen );

#endif