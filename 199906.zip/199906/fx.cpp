///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - PC Underground - Game Project           //
//                                                       //
//  Partikelsystem f�r Rauch und Explosionen             //
//  Explosionen mit Warteschlangen                       //
//                                                       //
//  (w)(c)�99 Carsten Dachsbacher                        //
//                                                       //
///////////////////////////////////////////////////////////

#include "demo.h"
#include "fx.h"

#define ASSEMBLER_PARTICLE_ROUTINE
#define ASSEMBLER_FIXED_POINT

#define MAXPARTICLES	10000

#define	bitmask (((int)((1<<ROT_SIZE)-2)<<(int)ROT_POS)+ \
				 ((int)((1<<GRUEN_SIZE)-2)<<(int)GRUEN_POS)+ \
				 ((int)((1<<BLAU_SIZE)-2)<<(int)BLAU_POS))

int bitmask32 = (unsigned int)( ( bitmask << 16 ) | bitmask );

#define MAXQUEUE 32

typedef struct
{
	int		x, y, density, type, used;
	int		time;
}EXPLOSION_QUEUE;

PARTICLE			explosion_particle[ MAXPARTICLES ];			// Daten der Partikel
int					free_explosion_particle[ MAXPARTICLES ];	// Partikel-"Stack"
int					index_free_explosion = MAXPARTICLES;		// "Stackpointer"
int					explosion_particles = 0;
int					last_explosion_time = -1;

EXPLOSION_QUEUE		explosion_queue[ MAXQUEUE ];

PARTICLE			smoke_particle[ MAXPARTICLES ];
int					free_smoke_particle[ MAXPARTICLES ];
int					index_free_smoke = MAXPARTICLES;
int					smoke_particles = 0;
int					last_smoke_time = -1;

unsigned short remappalette[ 65536 ];

float rand1()
{
	return ( rand() / 16384.0f - 1.0f );
}

long imul16(long x, long y)
{
#ifdef ASSEMBLER_FIXED_POINT
	long result;

	__asm {
		mov eax, x
		imul y
		shrd eax, edx, 16
		mov result, eax
	}
	return result;
#else
	return (long)( ( (__int64)x * (__int64)y ) / (__int64)65536 );
#endif
}

long ceil16(long x)
{
    x +=  0xffff;
    return (x >> 16);
}

void	InitParticleSystem()
{
	index_free_smoke	= MAXPARTICLES;
	smoke_particles		= 0;

	for ( int i = 0; i < MAXPARTICLES; i++ )
	{
		free_smoke_particle[ i ] = i;
		smoke_particle[ i ].life = 0;
	}

	index_free_explosion	= MAXPARTICLES;
	explosion_particles		= 0;

	for ( i = 0; i < MAXPARTICLES; i++ )
	{
		free_explosion_particle[ i ] = i;
		explosion_particle[ i ].life = 0;
	}

	for ( i = 0; i < MAXQUEUE; i++ )
		explosion_queue[ i ].used = 0;

	// Palette f�r additives Shading
	for ( i = 0; i < 65536; i++ )
	{
		int r = ((i&ROT_MASKE)>>ROT_POS)*512;
		int g = ((i&GRUEN_MASKE)>>GRUEN_POS)*512;
		int b = ((i&BLAU_MASKE)>>BLAU_POS)*512;

		remappalette[ i ] = ColorCode( min( 255, r>>ROT_SIZE ), 
									   min( 255, g>>GRUEN_SIZE ), 
									   min( 255, b>>BLAU_SIZE ) );
	}
}

void	AddExplosion( int x, int y, int density, int type )
{
	float   phase;

	if ( type == 1 )
		phase	  = rand() / 32768.0f * 8.0f; else
		phase	  = 0;

	for ( int d = 0; d < density; d++ )
	{
		if ( index_free_explosion <= 0 ) return;

		int n = free_explosion_particle[ --index_free_explosion ];

		float	richtung1 = rand() / 32768.0f * 2.0f * 3.14f;
		float	speed1	  = rand() / 32768.0f * 0.5f + (float)sin( phase ) * 2.0f;
		float	richtung2 = rand() / 32768.0f * 2.0f * 3.14f;
		float	speed2	  = rand() / 32768.0f * 0.01f + (float)sin( phase ) * 0.04f;

		explosion_particle[ n ].x		= ( x << 16 ) + ( rand() - 16384 ) * 32;
		explosion_particle[ n ].y		= ( y << 16 ) + ( rand() - 16384 ) * 32;
		explosion_particle[ n ].dx		= (int)( sin( richtung1 ) * speed1 * 65536.0f );
		explosion_particle[ n ].dy		= (int)( cos( richtung1 ) * speed1 * 65536.0f );
		explosion_particle[ n ].ddx		= (int)( sin( richtung2 ) * speed2 * 65536.0f );
		explosion_particle[ n ].ddy		= (int)( cos( richtung2 ) * speed2 * 65536.0f );
		explosion_particle[ n ].life	= ( 128 + (int)( rand() / 32780.0f * 16.0f ) ) << 16;

		explosion_particles ++;
	}
}

void	BigShipExplosion( int x, int y )
{
	int time = GetDemoTime();

	for ( int n = 0; n < 8; n++ )
	{
		int i = 0;
		while ( ( i < MAXQUEUE ) && ( explosion_queue[ i ].used ) ) i++;

		if ( i == MAXQUEUE ) return; // Warteschlange voll

		explosion_queue[ i ].used = 1;	
		explosion_queue[ i ].x = x + (int)( rand1() * 16.0f );
		explosion_queue[ i ].y = y + (int)( rand1() * 16.0f );
		explosion_queue[ i ].density = 400 + 400 - n * 50;
		explosion_queue[ i ].type = n & 1;					
		explosion_queue[ i ].time = time + n * 250;
	}
}

void	RocketExplosion( int x, int y )
{
	int time = GetDemoTime();

	int i = 0;
	while ( ( i < MAXQUEUE ) && ( explosion_queue[ i ].used ) ) i++;

	if ( i == MAXQUEUE ) return; // Warteschlange voll

	explosion_queue[ i ].used = 1;	
	explosion_queue[ i ].x = x;
	explosion_queue[ i ].y = y;
	explosion_queue[ i ].density = 300;
	explosion_queue[ i ].type = 0;					
	explosion_queue[ i ].time = time;
}

void	HandleExplosion()
{
	int time = GetDemoTime();

	for ( int i = 0; i < MAXQUEUE; i++ )
	if ( ( explosion_queue[ i ].used ) &&
		 ( explosion_queue[ i ].time <= time ) )
	{
		explosion_queue[ i ].used = 0;
		AddExplosion( explosion_queue[ i ].x,
					  explosion_queue[ i ].y,
					  explosion_queue[ i ].density,
					  explosion_queue[ i ].type );
	}
}


void	DrawExplosion( unsigned short *screen )
{
	int i;
	int r, g, b, farbe, mask, life;
	int adress;

	int step;

	int	gtime = GetDemoTime();

	if ( last_explosion_time == -1 )
	{
		last_explosion_time = gtime; 
		step = 65536;
	}else
	{
		step = (int)( 65536.0f * ( gtime - last_explosion_time ) / 20.0f );
		last_explosion_time = gtime;
	}

	for ( i = 0; i < MAXPARTICLES; i++ )
		if ( explosion_particle[ i ].life > 0 )
		{
			int dead = 0;

			explosion_particle[ i ].x += imul16( explosion_particle[ i ].dx, step );
			explosion_particle[ i ].y += imul16( explosion_particle[ i ].dy, step );

			explosion_particle[ i ].dx += imul16( explosion_particle[ i ].ddx, step );
			explosion_particle[ i ].dy += imul16( explosion_particle[ i ].ddy, step );
			
			int x = ceil16( explosion_particle[ i ].x );
			int y = ceil16( explosion_particle[ i ].y );

			if ( x >= SCREEN_X - 6) dead = 1; else
				if ( x < 0 ) dead = 1; 
			if ( y >= SCREEN_Y - 6) dead = 1; else
				if ( y < 0 ) dead = 1; 
			
			explosion_particle[ i ].life -= imul16( 65536, step );

			if ( explosion_particle[ i ].life <= 0 )
				dead = 1;


			if ( dead )
			{
				explosion_particle[ i ].life = 0;
				free_explosion_particle[ index_free_explosion ++ ] = i;
			} else
			{
				mask = bitmask;

				life = ceil16( explosion_particle[ i ].life ) / 2;
				r = 16;
				g = 16;
				b = 16;
				if ( life > 48 ) b += life - 48; else b += life / 4;
				if ( life > 32 ) g += life - 16; else g += life / 2;
				r += life;
	
				farbe = ( Rtab[ r ] | Gtab[ g ] | Btab[ b ] ) & ~( 1 << (GRUEN_POS+1) );
				farbe &= mask;

#ifdef ASSEMBLER_PARTICLE_ROUTINE
				adress = (int)screen + ( x + y * SCREEN_X ) * 2;
				__asm
				{
					mov		esi, [ offset remappalette ]
					mov		edi, [ adress ]
	
					mov		edx, [ farbe ]		// 2 Pixel f�r die linken Ecken
					push	edx
					shl		edx, 16
					mov		eax, [ farbe ]
					shr		eax, 1
					and		eax, [ mask ]
					add		edx, eax
	
					call	do_2x2
					add		edi, SCREEN_X * 6
					call	do_2x2
					sub		edi, SCREEN_X * 6 - 4
	
					ror		edx, 16
					call	do_2x2
					add		edi, SCREEN_X * 6
					call	do_2x2
					sub		edi, SCREEN_X * 6 + 4
	
					pop		eax
					mov		edx, eax		 	// hellere Farbe
					shl		edx, 16
					add		edx, eax
	
					add		edi, SCREEN_X * 2
					call	do_2x2
					add		edi, 4
					call	do_2x2
	
					add		edi, SCREEN_X * 2 - 4
					call	do_2x2
					add		edi, 4
					call	do_2x2
	
			
				
		
					jmp		ende
	
				do_2x2:				
					push	ebp

					mov		eax, [ edi + SCREEN_X * 0 ]
						mov		ecx, [ edi + SCREEN_X * 2 ]
					and		eax, [ bitmask32 ]
						and		ecx, [ bitmask32 ]
					add		eax, edx
					rcr		eax, 1
						add		ecx, edx
						rcr		ecx, 1
	
					mov		ebx, eax
					and		ebx, 65535
					mov		bx, [ esi + ebx * 2 ]
					shr		eax, 16
					mov		[ edi + SCREEN_X * 0 ], bx
	
					mov		ebx, eax
					mov		bx, [ esi + ebx * 2 ]
					mov		[ edi + SCREEN_X * 0 + 2 ], bx
	
						mov		ebp, ecx
						and		ebp, 65535
						mov		bp, [ esi + ebp * 2 ]
						shr		ecx, 16
						mov		[ edi + SCREEN_X * 2 ], bp
	
						mov		ebp, ecx
						mov		bp, [ esi + ebp * 2 ]
						mov		[ edi + SCREEN_X * 2 + 2 ], bp
						
						pop		ebp

					ret

				ende:
				
				}
#else
				adress = (int)screen + ( x + y * SCREEN_X ) * 2;
				for ( int b = 0; b < 4; b++ )
				{
					for ( int a = 0; a < 4; a++ )
					{
						int back = *(unsigned short*)adress;
						back &= mask;
						*(unsigned short*)adress = remappalette[ (farbe + back)>>1 ]; 
						adress += 2;					
					}
					adress += SCREEN_X * 2 - 8;
				}
#endif
			}
		}
}


void	AddSmoke( int x, int y, int density )
{
	for ( int d = 0; d < density; d++ )
	{
		if ( index_free_smoke <= 0 ) return;
		
		int n = free_smoke_particle[ --index_free_smoke ];
		
		smoke_particle[ n ].x		= ( x << 16 ) + ( rand() - 16384 ) * 16;
		smoke_particle[ n ].y		= ( y << 16 ) + ( rand() - 16384 ) * 16;
		smoke_particle[ n ].dx		= ( rand() - 16384 );
		smoke_particle[ n ].dy		= ( rand() - 16384 );
		smoke_particle[ n ].ddx		= -( smoke_particle[ n ].dx >> 7 );
		smoke_particle[ n ].ddy		= -( smoke_particle[ n ].dy >> 7 );
		smoke_particle[ n ].life	= 32 << 16;
		
		smoke_particles ++;
	}
}

void	DrawSmoke( unsigned short *screen )
{
	int adress;

	int step;

	int	gtime = GetDemoTime();

	if ( last_smoke_time == -1 )
	{
		last_smoke_time = gtime; 
		step = 65536;
	}else
	{
		step = (int)( 65536.0f * ( gtime - last_smoke_time ) / 20.0f );
		last_smoke_time = gtime;
	}
	
	for ( int i = 0; i < MAXPARTICLES; i++ )
		if ( smoke_particle[ i ].life )
		{
			int dead = 0;
			
			smoke_particle[ i ].x += imul16( smoke_particle[ i ].dx, step);
			smoke_particle[ i ].y += imul16( smoke_particle[ i ].dy, step);
			
			smoke_particle[ i ].dx += imul16( smoke_particle[ i ].ddx, step);
			smoke_particle[ i ].dy += imul16( smoke_particle[ i ].ddy, step);
			
			int x = ceil16( smoke_particle[ i ].x );
			int y = ceil16( smoke_particle[ i ].y );
			
			if ( x >= SCREEN_X - 6) dead = 1; else
				if ( x < 0 ) dead = 1; 
				if ( y >= SCREEN_Y - 6) dead = 1; else
					if ( y < 0 ) dead = 1; 
					
					smoke_particle[ i ].life -= imul16( 65536, step );
					if ( smoke_particle[ i ].life <= 0 )
						dead = 1;
					
					if ( dead )
					{
						smoke_particle[ i ].life = 0;
						free_smoke_particle[ index_free_smoke ++ ] = i;
					} else
					{
						int mask = bitmask;
						
						int life = 16 + ( ceil16( smoke_particle[ i ].life ) >> 1 );
						int farbe = ( Rtab[ life ] | Gtab[ life ] | Btab[ life ] ) & ~( 1 << (GRUEN_POS+1) );
						farbe &= mask;

#ifdef ASSEMBLER_PARTICLE_ROUTINE
						adress = (int)screen + ( x + y * SCREEN_X ) * 2;
						__asm
						{
								mov		esi, [ offset remappalette ]
								mov		edi, [ adress ]
								
								mov		edx, [ farbe ]		// 2 Pixel f�r die linken Ecken
								push	edx
								shl		edx, 16
								mov		eax, [ farbe ]
								shr		eax, 1
								and		eax, [ mask ]
								add		edx, eax
								
								call	do_2x2
								add		edi, SCREEN_X * 6
								call	do_2x2
								sub		edi, SCREEN_X * 6 - 4
								
								ror		edx, 16
								call	do_2x2
								add		edi, SCREEN_X * 6
								call	do_2x2
								sub		edi, SCREEN_X * 6 + 4
								
								pop		eax
								mov		edx, eax		 	// hellere Farbe
								shl		edx, 16
								add		edx, eax
								
								add		edi, SCREEN_X * 2
								call	do_2x2
								add		edi, 4
								call	do_2x2
								
								add		edi, SCREEN_X * 2 - 4
								call	do_2x2
								add		edi, 4
								call	do_2x2
								
								
								
								
								jmp		ende
								
do_2x2:				
								push	ebp
								mov		eax, [ edi + SCREEN_X * 2 ]
								mov		ecx, [ edi + SCREEN_X * 4 ]
								and		eax, [ bitmask32 ]
								and		ecx, [ bitmask32 ]
								add		eax, edx
								rcr		eax, 1
								add		ecx, edx
								rcr		ecx, 1
								
								mov		ebx, eax
								and		ebx, 65535
								mov		bx, [ esi + ebx * 2 ]
								shr		eax, 16
								mov		[ edi + SCREEN_X * 2 ], bx
								
								mov		ebx, eax
								mov		bx, [ esi + ebx * 2 ]
								mov		[ edi + SCREEN_X * 2 + 2 ], bx
								
								mov		ebp, ecx
								and		ebp, 65535
								mov		bp, [ esi + ebp * 2 ]
								shr		ecx, 16
								mov		[ edi + SCREEN_X * 4 ], bp
								
								mov		ebp, ecx
								mov		bp, [ esi + ebp * 2 ]
								mov		[ edi + SCREEN_X * 4 + 2 ], bp
								pop		ebp
								ret
								
ende:
								
						}
#else
						adress = (int)screen + ( x + y * SCREEN_X ) * 2;
						for ( int j = 0; j < 4; j++ )
						{
							for ( int a = 0; a < 4; a++ )
							{
								int back = *(unsigned short*)adress;
								back &= mask;
								*(unsigned short*)adress = remappalette[ (farbe + back)>>1 ]; 
								adress += 2;					
							}
							adress += SCREEN_X * 2 - 8;
						}
#endif
				}
		}
}

