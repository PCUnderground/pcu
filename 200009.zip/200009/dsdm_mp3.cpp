// dsdm_mp3.cpp : Defines the entry point for the console application.
//

// includes
#include "stdafx.h"
#include <io.h>
#include <windows.h>
#include <mmsystem.h>
#include <amstream.h>
#include <dsound.h>

// link pragmas
#pragma comment(lib, "user32.lib" )
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "ole32.lib" ) 
#pragma comment(lib, "amstrmid.lib" ) 
#pragma comment(lib, "dsound.lib" )


// defines
#define SAFE_DELETE(p)  { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p)=NULL; } }

// file i/o subflags
#ifndef     _O_BINARY
  #define _O_BINARY 0x8000 // file mode is binary (untranslated) 
#endif
#ifndef     _O_RDONLY
  #define _O_RDONLY 0x0000 // open for reading only 
#endif




class CDSound;

class CDSBuffer {

  CDSound* _sout;
  LPDIRECTSOUNDBUFFER _dsbuf;
  DWORD    _size; 
  // flags:
  //   DSBCAPS_LOCDEFER             : microsoft garantiert uns die maximale playgeschwindigkeit f�r locdefer managed buffers
  //   DSBCAPS_CTRL3D               : 3d -> 3ed funktionalit�t
  //   DSBCAPS_ MUTE3DATMAXDISTANCE : 3d -> alle t�ne werden ausserhalb ihrer maximum distance gemuted
  DWORD   _flags;

  // playflags:
  //   DSBPLAY_TERMINATEBY_TIME     : 2d/3d -> der sound der noch am wenigsten gespielt wird, wird gemuted
  //   DSBPLAY_TERMINATEBY_DISTANCE : 3d -> sounds ausserhalb ihrer max. distance werden gemuted
  DWORD   _playflags;

public:
  CDSBuffer( CDSound* p ) : _sout( p ), _dsbuf(0), _size(0), _flags(DSBCAPS_LOCDEFER), _playflags(DSBPLAY_TERMINATEBY_TIME)  {}

  bool init( int size, int freq, int bpp, int chans );
  bool init( int size, WAVEFORMATEX& wfx );
  bool play( bool looped );

  bool write( DWORD amount, void* data );
};


class CDSound {

  friend class CDSBuffer;
  HWND _owner;

protected:
  
  LPDIRECTSOUND _ds;   // DirectSound object

public:
  CDSound( HWND hwnd = 0 );
  ~CDSound();
  bool  init();
};

// CDSBuffer
////////////////////////////////////////////////////////////////
//
// init buffer
bool CDSBuffer::init( int size, int freq, int bpp, int chans ) {

  // waveformat header auf unser gew�nschtes format setzen
  WAVEFORMATEX wfx = {0};
  wfx.wFormatTag      = WAVE_FORMAT_PCM; 
  wfx.nChannels       = chans; 
  wfx.nSamplesPerSec  = freq; 
  wfx.wBitsPerSample  = bpp; 
  wfx.nBlockAlign     = wfx.wBitsPerSample / 8 * wfx.nChannels;
  wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

  return init( size, wfx );
}

// init buffer
bool CDSBuffer::init( int size, WAVEFORMATEX& wfx ) {

  // size auf 4 alignen
  size += 3;
  size &= -4;

  // direct soundbuffer initialisieren
  DSBUFFERDESC dsbd = {0};
  dsbd.dwSize        = sizeof(DSBUFFERDESC);
  dsbd.dwFlags       = _flags; 
  dsbd.dwBufferBytes = size;
  dsbd.lpwfxFormat   = &wfx;

  // den directsound buffer anlegen
  if( FAILED( _sout->_ds->CreateSoundBuffer( &dsbd, &_dsbuf, NULL ) ) )
    return false;

  // und mal auf silence legen
  VOID *mem1, *mem2;
  DWORD sz1, sz2;
  if( FAILED( _dsbuf->Lock( 0, 0, &mem1, &sz1, &mem2, &sz2, DSBLOCK_ENTIREBUFFER ) ) )
    return false;

  memset( mem1, sz1, (BYTE)( wfx.wBitsPerSample == 8 ? 128 : 0 ) );
  memset( mem2, sz2, (BYTE)( wfx.wBitsPerSample == 8 ? 128 : 0 ) ); // unn�tig (DSBLOCK_ENTIREBUFFER), aber zum besseren verst�ndniss

  _dsbuf->Unlock( mem1, sz1, mem2, sz2);
  _size = size;
//  if( sz1 ) CopyMemory( mem1, pbWaveData, sz1 );
//  if( sz2 ) CopyMemory( mem2, pbWaveData+sz1, sz2 );
  return true;
}


bool CDSBuffer::write( DWORD amount, void* data ) {

  // buffer locken
  VOID *mem1, *mem2;
  DWORD sz1, sz2;
  if( FAILED( _dsbuf->Lock( 0, 0, &mem1, &sz1, &mem2, &sz2, DSBLOCK_ENTIREBUFFER ) ) )
    return false;

  // maximalbegrenzung
  if( sz1 > amount )
    sz1 = amount;
  amount -= sz1;
  if( sz2 > amount )
    sz2 = amount; 

  // daten im bufer kopieren
  if( sz1 ) memcpy( mem1, data, sz1 );
//  if( sz2 ) memcpy( mem2, data+sz1, sz2 ); // unn�tig (DSBLOCK_ENTIREBUFFER), aber zum besseren verst�ndniss

  _dsbuf->Unlock( mem1, sz1, mem2, sz2);
  return true;
}



// play buffer
bool CDSBuffer::play( bool looped ) {
  if( !_dsbuf || !_size )
    return false;
  return( 0 > _dsbuf->Play( 0, 1, _playflags | ((looped) ? DSBPLAY_LOOPING : 0 )) );
}


// CDSound
////////////////////////////////////////////////////////////////
//

CDSound::CDSound( HWND hwnd ) : _ds(NULL), _owner( hwnd ) {

  if( !_owner ) // hwnd festlegen
    _owner = ::GetForegroundWindow(); 
  if( !_owner )
    _owner = ::GetDesktopWindow();
}

CDSound::~CDSound() {
  SAFE_RELEASE( _ds ); // dsound wieder freigeben 
}



bool CDSound::init() {

  LPDIRECTSOUNDBUFFER primary(0);
      
  // COM sollte initialisiert sein!

  // IDirectSound interface von der prim�ren soundkarte
  if( FAILED( ::DirectSoundCreate( NULL, &_ds, NULL ) ) )
    return false;

  // coop level setzen 
  if( FAILED( _ds->SetCooperativeLevel( _owner, DSSCL_PRIORITY ) ) )
   return false;

  // prim�ren buffer holen
  DSBUFFERDESC dsbd = {0};
  dsbd.dwSize        = sizeof(DSBUFFERDESC);
  dsbd.dwFlags       = DSBCAPS_PRIMARYBUFFER;
  if( FAILED( _ds->CreateSoundBuffer( &dsbd, &primary, NULL ) ) )
    return false;

  // den prim�ren soundbuffer auf unser gew�nschtes format setzen
  WAVEFORMATEX wfx = {0};
  wfx.wFormatTag      = WAVE_FORMAT_PCM; 
  wfx.nChannels       = 2; 
  wfx.nSamplesPerSec  = 44100; 
  wfx.wBitsPerSample  = 16; 
  wfx.nBlockAlign     = wfx.wBitsPerSample / 8 * wfx.nChannels;
  wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;
  if( FAILED( primary->SetFormat(&wfx) ) )
    return false;

  SAFE_RELEASE( primary );

  return true;
}


HRESULT RenderStreamToDevice(IMultiMediaStream *pMMStream) {
  
  WAVEFORMATEX wfx;
  #define DATA_SIZE 8096
  PBYTE pBuffer = (PBYTE)LocalAlloc(LMEM_FIXED, DATA_SIZE);

  IMediaStream *pStream;
  IAudioStreamSample *pSample;
  IAudioMediaStream *pAudioStream;
  IAudioData *pAudioData;

  pMMStream->GetMediaStream(MSPID_PrimaryAudio, &pStream);
  pStream->QueryInterface(IID_IAudioMediaStream, (void **)&pAudioStream);
  pAudioStream->GetFormat(&wfx);
  CoCreateInstance(CLSID_AMAudioData, NULL, CLSCTX_INPROC_SERVER, IID_IAudioData, (void **)&pAudioData);
  pAudioData->SetBuffer(DATA_SIZE, pBuffer, 0); // IMemoryData -> SetBuffer
  pAudioData->SetFormat(&wfx);
  pAudioStream->CreateSample(pAudioData, 0, &pSample);
  HANDLE hEvent = CreateEvent(FALSE, NULL, NULL, FALSE);
  int iTimes;
  for (iTimes = 0; iTimes < 3; iTimes++) {
      DWORD dwStart = timeGetTime();
      for (; ; ) {
          HRESULT hr = pSample->Update(0, hEvent, NULL, 0); // Handle to an event that this method will trigger when the update is complete. 
          if (FAILED(hr) || MS_S_ENDOFSTREAM == hr) {
              break;
          }
          WaitForSingleObject(hEvent, INFINITE);
          DWORD dwTimeDiff = timeGetTime() - dwStart;
          if(0) { // (dwTimeDiff > 10000) {
              break;
          }
          DWORD dwLength;
          pAudioData->GetInfo(NULL, NULL, &dwLength);
//          sstream.write( dwLength, pbuffer );
      }
      pMMStream->Seek(0);
  }

  pAudioData->Release();
  pSample->Release();
  pStream->Release();
  pAudioStream->Release();
  LocalFree((HLOCAL)pBuffer);

  return S_OK;
}

HRESULT RenderFileToMMStream( WCHAR * pszFileName, IMultiMediaStream **ppMMStream ) {

  IAMMultiMediaStream *pAMStream;
  CoCreateInstance(CLSID_AMMultiMediaStream, NULL, CLSCTX_INPROC_SERVER, IID_IAMMultiMediaStream, (void **)&pAMStream);
  pAMStream->Initialize(STREAMTYPE_READ, AMMSF_NOGRAPHTHREAD, NULL);
  pAMStream->AddMediaStream(NULL, &MSPID_PrimaryAudio, 0, NULL);
  pAMStream->OpenFile(pszFileName, AMMSF_RUN);
  *ppMMStream = pAMStream;
  return S_OK;
}


// WAV fileformat
#define ID_RIFF 0x46464952
#define ID_WAVE 0x45564157
#define ID_FMT  0x20746D66
#define ID_DATA 0x61746164

typedef struct {
    DWORD   RIFFMagic;
    DWORD   FileLength;
    DWORD   FileType;
    DWORD   FormMagic;
    DWORD   FormLength;
    WORD    SampleFormat;
    WORD    NumChannels;
    DWORD   PlayRate;
    DWORD   BytesPerSec;
    WORD    Pad;
    WORD    BitsPerSample;
    DWORD   DataMagic;
    DWORD   DataLength;
} WAVHeader;

int _CRTAPI1 main( int argc, char *argv[] ) {

  int         handle;
  WAVHeader   Header;
  char*       pdata;

  CoInitialize(NULL);

  CDSound sound;
  CDSBuffer song( &sound );
  
  if( !sound.init() )  
    return -1;

  if( (handle = _open(argv[1], _O_RDONLY | _O_BINARY)) == -1 )
    return NULL;

  if( _read(handle,&Header,sizeof(Header)) != sizeof(Header) ) {
    _close(handle);
    return NULL;
  }

  if( Header.RIFFMagic != ID_RIFF || Header.FileType != ID_WAVE ||
      Header.FormMagic != ID_FMT || Header.DataMagic != ID_DATA ||
      Header.SampleFormat != 1 ) {
    _close(handle);
    return NULL;
  }

  if( (pdata = new char[Header.DataLength]) == NULL ) {
    _close(handle);
    return NULL;
  }

  if( (unsigned) _read(handle, pdata, Header.DataLength ) != Header.DataLength ) {
    delete [] pdata;
    _close(handle);
    return NULL;
  }

  _close(handle);

  if( !song.init( Header.DataLength, Header.PlayRate, Header.BitsPerSample, Header.NumChannels ) )
    return -1;

  song.write( Header.DataLength, pdata );

  song.play( true );

  for(;;) {
    Sleep( 5 );
  }

/*
  IMultiMediaStream *pMMStream;
  CoInitialize(NULL);
  WCHAR wszName[1024];
  MultiByteToWideChar(CP_ACP, 0, argv[1], -1, wszName, sizeof(wszName) / sizeof(wszName[0]));
  RenderFileToMMStream(wszName, &pMMStream);
  RenderStreamToDevice(pMMStream);
  pMMStream->Release();
*/
  CoUninitialize();
  return 0;
} 

