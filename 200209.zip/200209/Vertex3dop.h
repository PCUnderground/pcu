////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  (w)(c)2000 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#ifndef VERTEX3DOP__H
#define VERTEX3DOP__H

typedef float MATRIX44[ 16 ];

typedef struct
{
	float x, y, z;
}VERTEX3D;

extern float operator * ( const VERTEX3D &a, const VERTEX3D &b );
extern void	operator ~ ( VERTEX3D &a );
extern void operator *= ( VERTEX3D &a, const float b );

extern void	InverseMatrixAnglePreserving( const MATRIX44 source, MATRIX44 dest );

#endif