#include <stdio.h>

GLint maxTexelUnits;

#define MAX_EXTENSION_SPACE		10240
#define MAX_EXTENSION_LENGTH	256

bool isInString(char *string, const char *search) {
	int pos=0;
	int maxpos=strlen(search)-1;
	int len=strlen(string);	
	char *other;
	for (int i=0; i<len; i++) {
		if ((i==0) || ((i>1) && string[i-1]=='\n')) {				// New Extension Begins Here!
			other=&string[i];			
			pos=0;													// Begin New Search
			while (string[i]!='\n') {								// Search Whole Extension-String
				if (string[i]==search[pos]) pos++;					// Next Position
				if ((pos>maxpos) && string[i+1]=='\n') return true; // We Have A Winner!
				i++;
			}			
		}
	}	
	return false;													// Sorry, Not Found!
}

int initExtensions()
{
	char *extensions;	
	extensions = strdup( (char*)glGetString( GL_EXTENSIONS ) );
	int s = strlen( extensions );
	for ( unsigned int i = 0; i < strlen( extensions ); i ++ ) {

		if ( extensions[ i ] == ' ' ) extensions[ i ] = '\n';
	}

	FILE *f = fopen( "extension.txt", "wb" );
	fwrite( extensions, 1, s, f );
	fclose( f );

	if ( strstr( extensions, "GL_ARB_multitexture" ) && 
		 strstr( extensions, "GL_NV_texture_shader" ) && 
		 strstr( extensions, "GL_NV_register_combiners" )
       )
	{	
		glGetIntegerv( GL_MAX_TEXTURE_UNITS_ARB, &maxTexelUnits );
		glMultiTexCoord1fARB	 = (PFNGLMULTITEXCOORD1FARBPROC)		wglGetProcAddress( "glMultiTexCoord1fARB" );
		glMultiTexCoord2fARB	 = (PFNGLMULTITEXCOORD2FARBPROC)		wglGetProcAddress( "glMultiTexCoord2fARB" );
		glMultiTexCoord3fARB	 = (PFNGLMULTITEXCOORD3FARBPROC)		wglGetProcAddress( "glMultiTexCoord3fARB" );
		glMultiTexCoord4fARB	 = (PFNGLMULTITEXCOORD4FARBPROC)		wglGetProcAddress( "glMultiTexCoord4fARB" );
		glActiveTextureARB		 = (PFNGLACTIVETEXTUREARBPROC)		wglGetProcAddress( "glActiveTextureARB" );
		glClientActiveTextureARB = (PFNGLCLIENTACTIVETEXTUREARBPROC)	wglGetProcAddress( "glClientActiveTextureARB" );		
		glCompressedTexImage2DARB = (PFNGLCOMPRESSEDTEXIMAGE2DARBPROC)wglGetProcAddress( "glCompressedTexImage2DARB" );

		glMultiTexCoord2fvARB	 = (PFNGLMULTITEXCOORD2FVARBPROC)		wglGetProcAddress( "glMultiTexCoord2fvARB" );
		glMultiTexCoord3fvARB	 = (PFNGLMULTITEXCOORD3FVARBPROC)		wglGetProcAddress( "glMultiTexCoord3fvARB" );

		glCombinerStageParameterfvNV = (PFNGLCOMBINERSTAGEPARAMETERFVNVPROC)wglGetProcAddress( "glCombinerStageParameterfvNV" );
		glCombinerOutputNV = (PFNGLCOMBINEROUTPUTNVPROC)wglGetProcAddress( "glCombinerOutputNV" );
		glCombinerInputNV = (PFNGLCOMBINERINPUTNVPROC)wglGetProcAddress( "glCombinerInputNV" );
		glLoadProgramNV = (PFNGLLOADPROGRAMNVPROC)wglGetProcAddress( "glLoadProgramNV" );

		glProgramParameter4fvNV = (PFNGLPROGRAMPARAMETER4FVNVPROC)wglGetProcAddress( "glProgramParameter4fvNV" );
		glTrackMatrixNV = (PFNGLTRACKMATRIXNVPROC)wglGetProcAddress( "glTrackMatrixNV" );
		glFinalCombinerInputNV = (PFNGLFINALCOMBINERINPUTNVPROC)wglGetProcAddress( "glFinalCombinerInputNV" );
		glCombinerParameteriNV = (PFNGLCOMBINERPARAMETERINVPROC)wglGetProcAddress( "glCombinerParameteriNV" );

		glCombinerParameterfvNV = (PFNGLCOMBINERPARAMETERFVNVPROC)wglGetProcAddress( "glCombinerParameterfvNV" );

		return true;
	}

	if ( maxTexelUnits < 4 )
	{
		MessageBox( NULL, "Grafikkarte unterst�tzt nicht 4 Textures gleichzeitig !", "Schade", MB_OK );
		return false;
	}

	return false;
}

