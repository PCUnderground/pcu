///////////////////////////////////////////////////////////
//                                                       //
//  (w)(c) 2002 - Carsten Dachsbacher                    //
//                carsten@dachsbacher.de                 //
//                                                       //
//  Data Types Defines                                   //
//                                                       //
//  Changed: 09-14-2002                                  //
//                                                       //
///////////////////////////////////////////////////////////
#ifndef SYNDEFINES
#define SYNDEFINES

#include <math.h>
#include <stdlib.h>
#include <stdio.h>

#define U8		unsigned char
#define S8		signed char
#define U16		unsigned short
#define S16		signed short
#define S32		signed long
#define U32		unsigned long
#define FLOAT	float
#define BOOL	bool

typedef struct
{
	FLOAT	x, y, z;
}VERTEX3D;

#ifndef max
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif

#ifndef M_PI
#define M_PI 3.14159265359f
#endif

#endif