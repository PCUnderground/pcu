///////////////////////////////////////////////////////////
//                                                       //
//  (w)(c) 2002 - Carsten Dachsbacher                    //
//                carsten@dachsbacher.de                 //
//                                                       //
//  OpenGL Extension Handling                            //
//                                                       //
//  Changed: 09-14-2002                                  //
//                                                       //
///////////////////////////////////////////////////////////
#ifndef __OGLEXTENSION
#define __OGLEXTENSION

#include <windows.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include "glext.h"

extern bool	supportTextureCompressionS3;
extern bool	supportVAR;
extern bool	supportVertexProgram;
extern bool	supportPointParameters;
extern bool	supportCompiledVertexArray;
extern bool	supportMultiDrawArray;
extern bool	supportOcclusionQuery;
extern bool supportATI_vao;
extern bool supportATI_element_array;

extern int		maxTexelUnits;

// Compiled Vertex Arrays
extern PFNGLLOCKARRAYSEXTPROC			pfLockArrays;
extern PFNGLUNLOCKARRAYSEXTPROC			pfUnlockArrays;


// hier die definitionen f�r den import der multitexturing extensions
extern PFNGLMULTITEXCOORD1FARBPROC		glMultiTexCoord1fARB;
extern PFNGLMULTITEXCOORD2FARBPROC		glMultiTexCoord2fARB;
extern PFNGLMULTITEXCOORD3FARBPROC		glMultiTexCoord3fARB;
extern PFNGLMULTITEXCOORD4FARBPROC		glMultiTexCoord4fARB;
extern PFNGLACTIVETEXTUREARBPROC		glActiveTextureARB;
extern PFNGLCLIENTACTIVETEXTUREARBPROC	glClientActiveTextureARB;	
extern PFNGLCOMPRESSEDTEXIMAGE2DARBPROC	glCompressedTexImage2DARB;

// EXT_point_parameters
extern PFNGLPOINTPARAMETERFEXTPROC		glPointParameterfEXT;
extern PFNGLPOINTPARAMETERFVEXTPROC		glPointParameterfvEXT;

// GL_EXT_multi_draw_arrays
extern PFNGLMULTIDRAWARRAYSEXTPROC		glMultiDrawArraysEXT;
extern PFNGLMULTIDRAWELEMENTSEXTPROC	glMultiDrawElementsEXT;

// Vertex Array Range EXT
extern PFNGLFLUSHVERTEXARRAYRANGENVPROC	glFlushVertexArrayRangeNV;
extern PFNGLVERTEXARRAYRANGENVPROC		glVertexArrayRangeNV;

#ifdef _WIN32
typedef void* (APIENTRY * PFNWGLALLOCATEMEMORYNVPROC) (GLsizei size, 
               GLfloat readFrequency, GLfloat writeFrequency, GLfloat priority);
typedef void (APIENTRY * PFNWGLFREEMEMORYNVPROC) (void *pointer);
#else
typedef void* ( * PFNGLXALLOCATEMEMORYNVPROC) (GLsizei size, 
               GLfloat readFrequency, GLfloat writeFrequency, GLfloat priority);
typedef void ( * PFNGLXFREEMEMORYNVPROC) (void *pointer);
#endif 

extern PFNWGLALLOCATEMEMORYNVPROC		wglAllocateMemoryNV;
extern PFNWGLFREEMEMORYNVPROC			wglFreeMemoryNV;

// Occlusion Query
extern PFNGLBEGINOCCLUSIONQUERYNVPROC	glBeginOcclusionQueryNV;
extern PFNGLENDOCCLUSIONQUERYNVPROC		glEndOcclusionQueryNV;
extern PFNGLGETOCCLUSIONQUERYUIVNVPROC	glGetOcclusionQueryuivNV;
extern PFNGLGENOCCLUSIONQUERIESNVPROC	glGenOcclusionQueriesNV;

// Vertex Program
extern PFNGLBINDPROGRAMNVPROC				glBindProgramNV;
extern PFNGLDELETEPROGRAMSNVPROC			glDeleteProgramsNV;
extern PFNGLEXECUTEPROGRAMNVPROC			glExecuteProgramNV;
extern PFNGLGENPROGRAMSNVPROC				glGenProgramsNV;
extern PFNGLAREPROGRAMSRESIDENTNVPROC		glAreProgramsResidentNV;
extern PFNGLREQUESTRESIDENTPROGRAMSNVPROC	glRequestResidentProgramsNV;
extern PFNGLGETPROGRAMPARAMETERFVNVPROC		glGetProgramParameterfvNV;
extern PFNGLGETPROGRAMPARAMETERDVNVPROC		glGetProgramParameterdvNV;
extern PFNGLGETPROGRAMIVNVPROC				glGetProgramivNV;
extern PFNGLGETPROGRAMSTRINGNVPROC			glGetProgramStringNV;
extern PFNGLGETTRACKMATRIXIVNVPROC			glGetTrackMatrixivNV;
extern PFNGLGETVERTEXATTRIBDVNVPROC			glGetVertexAttribdvNV;
extern PFNGLGETVERTEXATTRIBFVNVPROC			glGetVertexAttribfvNV;
extern PFNGLGETVERTEXATTRIBIVNVPROC			glGetVertexAttribivNV;
extern PFNGLGETVERTEXATTRIBPOINTERVNVPROC	glGetVertexAttribPointervNV;
extern PFNGLISPROGRAMNVPROC					glIsProgramNV;
extern PFNGLLOADPROGRAMNVPROC				glLoadProgramNV;
extern PFNGLPROGRAMPARAMETER4FNVPROC		glProgramParameter4fNV;
extern PFNGLPROGRAMPARAMETER4DNVPROC		glProgramParameter4dNV;
extern PFNGLPROGRAMPARAMETER4DVNVPROC		glProgramParameter4dvNV;
extern PFNGLPROGRAMPARAMETER4FVNVPROC		glProgramParameter4fvNV;
extern PFNGLPROGRAMPARAMETERS4DVNVPROC		glProgramParameters4dvNV;
extern PFNGLPROGRAMPARAMETERS4FVNVPROC		glProgramParameters4fvNV;
extern PFNGLTRACKMATRIXNVPROC				glTrackMatrixNV;

// ATI Array Object
extern PFNGLNEWOBJECTBUFFERATIPROC            glNewObjectBufferATI;
extern PFNGLISOBJECTBUFFERATIPROC             glIsObjectBufferATI;
extern PFNGLUPDATEOBJECTBUFFERATIPROC         glUpdateObjectBufferATI;
extern PFNGLGETOBJECTBUFFERFVATIPROC          glGetObjectBufferfvATI;
extern PFNGLGETOBJECTBUFFERIVATIPROC          glGetObjectBufferivATI;
extern PFNGLFREEOBJECTBUFFERATIPROC           glFreeObjectBufferATI;
extern PFNGLARRAYOBJECTATIPROC                glArrayObjectATI;
extern PFNGLGETARRAYOBJECTFVATIPROC           glGetArrayObjectfvATI;
extern PFNGLGETARRAYOBJECTIVATIPROC           glGetArrayObjectivATI;
extern PFNGLVARIANTARRAYOBJECTATIPROC         glVariantArrayObjectATI;
extern PFNGLGETVARIANTARRAYOBJECTFVATIPROC    glGetVariantArrayObjectfvATI;
extern PFNGLGETVARIANTARRAYOBJECTIVATIPROC    glGetVariantArrayObjectivATI;

// ATI element arrays
extern PFNGLELEMENTPOINTERATIPROC             glElementPointerATI;
extern PFNGLDRAWELEMENTARRAYATIPROC           glDrawElementArrayATI;
extern PFNGLDRAWRANGEELEMENTARRAYATIPROC      glDrawRangeElementArrayATI;


extern void getOpenGLExtensions();

extern void setMaterial();

#endif