#include <windows.h>
#include <iostream.h>
#include	<stdio.h>
#include "nvtristrip.h"
#include "syndefines.h"
#include "vertex3dop.h"

PrimitiveGroup triangles;
PrimitiveGroup *strip = new PrimitiveGroup;

typedef struct
{
	unsigned int			a, b, c;		// indices to vertices
	VERTEX3D	normal;			// normal of triangle
	FLOAT		area;			// area of triangle
	int			normalCluster;	// cluster which face belongs to
}TRIFACE;

static unsigned int			nVertices    = 0, 
					nFaces       = 0;
static VERTEX3D		*pVertexList = NULL;
static TRIFACE		*pFaceList   = NULL;
static VERTEX3D		*pNormalList = NULL;

static void readTriangleMesh( char *filename )
{
	if ( filename == NULL )
	{
		nVertices = nFaces = 0;
	}

	FILE *f = fopen( filename, "rb" );
	fread( &nVertices, 4, 1, f );
	fread( &nFaces, 4, 1, f );

	pVertexList	= new VERTEX3D[ nVertices ];
	pNormalList	= new VERTEX3D[ nVertices ];
	pFaceList	= new TRIFACE[ nFaces ];

	for ( unsigned int i = 0; i < nVertices; i++ )
	{
		fread( &pVertexList[ i ].x, 1, 4, f );
		fread( &pVertexList[ i ].y, 1, 4, f );
		fread( &pVertexList[ i ].z, 1, 4, f );
	}

	for ( i = 0; i < nFaces; i++ )
	{
		fread( &pFaceList[ i ].a, 1, 4, f );
		fread( &pFaceList[ i ].b, 1, 4, f );
		fread( &pFaceList[ i ].c, 1, 4, f );
	}
	
	fclose( f );
}


void main()
{
	readTriangleMesh( "../HPRender/horse.cnd" );

	triangles.type = PT_LIST;
	triangles.numIndices = 0;
	triangles.indices = new unsigned int[ nFaces * 3 ];

	for ( int i = 0; i < nFaces; i++ )
	{
		triangles.indices[ triangles.numIndices ++ ] = pFaceList[ i ].a;
		triangles.indices[ triangles.numIndices ++ ] = pFaceList[ i ].b;
		triangles.indices[ triangles.numIndices ++ ] = pFaceList[ i ].c;
	}

	SetCacheSize( CACHESIZE_GEFORCE3 );
	SetStitchStrips( true );

	unsigned short nGroups;
	GenerateStrips( triangles.indices, triangles.numIndices, &strip, &nGroups );


	FILE *f = fopen( "horse.strip", "wb" );
	int b = strip->numIndices;
	fwrite( &b, 4, 1, f );
	for ( int l = 0; l < strip->numIndices; l++ )
	{
		unsigned short x = strip->indices[ l ];
		fwrite( &x, 2, 1, f );
	}
	fclose( f );

}

