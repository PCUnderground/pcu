///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - Demo Projekt                            //
//                                                       //
//                                                       //
//  Routinen zum erzeugen einfacher Sinus-Plasmen       //
//                                                       //
///////////////////////////////////////////////////////////
#include "demo.h"

static unsigned char *sintable;
static int           *wave;


void init_sineplasma (void)
{
    // vorberechnen der Sinus-Tabelle

    sintable = (unsigned char *) malloc (1024);
    wave     = (int *) malloc (4* sizeof (int));

    for ( int i=0; i<1024; i++)
        sintable[i] = 128+127*sin((float)i*3.14/512.0);

    for ( i=0; i<4; i++)
        wave[i]=0;
}



void done_sineplasma (void)
{
    free (sintable);
}


void make_sineplasma (float time, unsigned short *picture, unsigned short *palette,
                      int width, int height)
{
    int y, x;
    int speed_x[4];
    int speed_y[4];
    int workwave_x[4];
    int workwave_y[4];

    // Speed-Werte der Wellen vorberechnen
    speed_x[0] = 3000 * sin (time*1.0+1);
    speed_y[0] = 3000 * cos (time*1.1+2);
    speed_x[1] =  700 * sin (-time*1.2+3);
    speed_y[1] =  700 * cos (-time*1.3+4);
    speed_x[2] = 2300 * sin (time*1.4+5);
    speed_y[2] = 2300 * cos (time*1.5+6);
    speed_x[3] = 1700 * sin (time*1.6+7);
    speed_y[3] = 1700 * cos (time*1.7+8);

    register int i;
    for ( i=0; i<4; i++)
    {
    	wave[i]      += speed_x[i];
	workwave_y[i] = wave[i];
    }

    // Schleife �ber die h�he des bitmaps
    for ( y=0; y<height; y++)
    {
        for ( i=0; i<4; i++) workwave_x[i] = workwave_y[i];

        // Scanline zeichnen
        for ( x=0; x<width; x++)
        {
          *(picture++) = palette[(sintable[(workwave_x[0]>>8)&1023] +
                                  sintable[(workwave_x[1]>>8)&1023] +
                                  sintable[(workwave_x[2]>>8)&1023] +
                                  sintable[(workwave_x[3]>>8)&1023])>>2];

          for ( i=0; i<4; i++) workwave_x[i] += speed_x[i];
        }
        for ( i=0; i<4; i++) workwave_y[i] += speed_y[i];
    }
}


