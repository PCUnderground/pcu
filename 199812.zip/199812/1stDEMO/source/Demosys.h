///////////////////////////////////////////////////////////
//                                                       //
// PC MAGAZIN - Demo Projekt                             //
//                                                       //
// Header File f�r die Grafikbibliothek                  //
//                                                       //
// Carsten Dachsbacher, Nils Pipenbrinck                 //
//                                                       //
///////////////////////////////////////////////////////////

#ifndef __demosys_h
#define __demosys_h

// Fenster-Modes
#define FENSTER     0
#define SKALIERBAR  1
#define VOLLBILD    2

// Metric des Fensters
#define SCREEN_X    320
#define SCREEN_Y    240

// Die Positionen der RGB Anteile
#define ROT_POS     10
#define GRUEN_POS   5
#define BLAU_POS    0

// Die Gr��e der Anteile in Bits
#define ROT_SIZE    5
#define GRUEN_SIZE  6
#define BLAU_SIZE   5

// Die AND-Maske f�r die RGB Anteile 
#define ROT_MASKE   ( ( 1 << ROT_SIZE ) - 1 ) << ROT_POS
#define GRUEN_MASKE ( ( 1 << GRUEN_SIZE ) - 1 ) << GRUEN_POS
#define BLAU_MASKE  ( ( 1 << BLAU_SIZE ) - 1 ) << BLAU_POS

// Darstellungsmodus des Fensters
extern int              Fenster_Modus;   
// 16 Bit Farb Tabellen
extern int              Rtab[256];  
extern int              Gtab[256];  
extern int              Btab[256];  
// Status des Demo-Threads
extern volatile BOOL    DemoRunning;     

// Funktionen der Grafik-Library
unsigned short  ColorCode     (int r, int g, int b);
void            BlitGraphic   (void *buf);
unsigned long   GetDemoTime   (void);
int 			init_wave();

// Externe Funktionen
BOOL demoinit (void);
void demomain (void);
void demoquit (void);

#endif
