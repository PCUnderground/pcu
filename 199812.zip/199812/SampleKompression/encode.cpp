///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - Demo Projekt                            //
//                                                       //
//  Beispielprogramm, f�r Samplekonvertierung von        //
//  von 16 Bit linear nach 8 Bit logarithmisch           //
//                                                       //
///////////////////////////////////////////////////////////
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

FILE *in, *out;

unsigned short	*indata;
unsigned char	*outdata;
int				table[ 65536 ];

void main()
{
	// Konvertierungstabelle
	for ( int i = 0; i < 65536; i++ )
		table[ i ] = (int)( 255.0 * ( pow( 2.0, (double)i / 65536.0 ) - 1.0 ) );

	// Inputfile in 16 Bit, Raw-File ohne Dateiheader
	in = fopen( "ejay16us.raw", "rb" );
	if ( in == NULL ) exit( 1 );

	// Outputfile
	out = fopen( "ejayylaw.raw", "wb" );
	if ( out == NULL ) exit( 1 );

	fseek( in, 0, SEEK_END );
	int size = ftell( in ) / 2;
	fseek( in, 0, SEEK_SET );

	indata = (unsigned short*)malloc( sizeof(short) * size );
	outdata = (unsigned char*)malloc( size );
	if ( indata == NULL || outdata == NULL ) exit( 2 );

	fread( indata, 2, size, in );

	for ( i = 0; i < size; i++ )
	{
		outdata[ i ] = table[ indata[ i ] ];
	}

	fwrite( outdata, 1, size, out );

	fclose( in );
	fclose( out );
}