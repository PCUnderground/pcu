///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - Demo Projekt                            //
//                                                       //
//  Beispielprogramm f�r die Anwendung von MIDAS         //
//                                                       //
///////////////////////////////////////////////////////////
#include "midasdll.h"
#include "demo.h"

unsigned short *screen;

// Wird ben�tigt, um den Fenstertitel zu �ndern
extern HWND DemoHWND;

// Hier sind die Midasspezifischen Deklarationen
extern void InitMIDAS(void);
extern void CloseMIDAS(void);
extern void StartupMIDAS(void);
extern MIDASmodulePlayHandle PlayModule(MIDASmodule module);
extern MIDASmodule LoadModule(char *fileName);
extern void StopFreeModule(MIDASmodulePlayHandle playHandle, MIDASmodule module);

MIDASmodule				module;
MIDASmodulePlayHandle	playHandle;
MIDASmoduleInfo			info;
MIDASplayStatus			status;

// Hier die Variablen f�r unseren kleinen Module-Player
short			palette1[ 32 ][ 256 ];
bitmaptype		background;
unsigned char 	*back;
unsigned short  *back16;
short			palette2[ 32 ][ 256 ];
bitmaptype		zahlen;
unsigned char	*zahl;

BOOL demoinit (void)
{
    Fenster_Modus = FENSTER;

    // Speicher f�r das Bild reservieren
    screen = (unsigned short *)malloc( SCREEN_X * SCREEN_Y * 2 );
    if ( screen == NULL ) return 0;
    memset (screen, 0, SCREEN_X * SCREEN_Y * 2);

	// Hintergrundbild und Zahlen-Bild laden
    if ( bmp_load( "HINTERGRUND.BMP", background ) !=
         BMP_NOERROR ) return 0;
    if ( bmp_load( "ZAHLEN.BMP", zahlen ) !=
         BMP_NOERROR ) return 0;

	bmp_make16bitpalette( background );
	bmp_make16bitpalette( zahlen );
    
	back = (unsigned char *)background.cBitmap;
    zahl = (unsigned char *)zahlen.cBitmap;

	// Hintergrundbild einmalig in Hicolor Umwandeln
	back16 = (unsigned short *)malloc( 320 * 240 * sizeof( short ) );
	if ( back16 == NULL ) return FALSE;
	for ( int ofs = 0; ofs < SCREEN_X * SCREEN_Y; ofs ++ )
		back16[ ofs ] = background.sColors[ back[ ofs ] ];

	// MIDAS starten, initialisieren und Module laden
	StartupMIDAS();
	InitMIDAS();
	module = LoadModule( "test.s3m" );

    return TRUE;
}


// Gibt eine Zahl aus
void write_single( int x, int y, int v )
{
	int i, j;
	int ofs = x + y * SCREEN_X;

	for ( j = 0; j < 14; j++ )
	{
		for ( i = 0; i < 10; i++ )
		{
			int p = zahl[ i + (j + v * 14) * 320 ];
			if ( p != 16 ) screen[ ofs ] = zahlen.sColors[ p ];
			ofs ++;
		}
		ofs += SCREEN_X - 10;
	}
}

// max. 3-stellige Zahl ausgeben. x ist rechtsb�ndige Koordinate
void write_number( int x, int y, int v )
{
	write_single( x - 10, y, v % 10 );
	v /= 10; if ( v > 0 ) write_single( x - 20, y, v % 10 );
	v /= 10; if ( v > 0 ) write_single( x - 30, y, v % 10 );
}

void demomain( void )
{
	// Modulenamen in den Fenstertitel !
	MIDASgetModuleInfo( module, &info );

	char text[128];
	strcpy( text, "PC Underground: \"" );
	strcat( text, info.songName );
	strcat( text, "\"" );
	SetWindowText( DemoHWND, text );

	// Abspielen starten
	playHandle = PlayModule( module );

	// Hintergrundbild komplett kopieren
	memcpy( screen, back16, 320 * 240 * 2 );

    while ( DemoRunning )
    {
		// Nur den Teil des Hintergrundbildes der �berschrieben wird kopieren
		for ( int i = 125; i < 125+56; i++ )
			memcpy( screen + i * 320 + 208, back16 + i * 320 + 208, 30 * 2 );

		// Informationen holen
		MIDASgetPlayStatus( playHandle, &status );

		// Und darstellen
		write_number( 238, 125, status.position );
		write_number( 238, 146, status.pattern );
		write_number( 238, 167, status.row );
		
		BlitGraphic( screen );

		// L��t den Demotask 50ms warten
		// Dies erm�glichst es den Player im Hintergrund laufen zu lassen
		Sleep( 50 );
    }
}

void demoquit( void )
{
	// Ausgabe beenden und MIDAS beenden
	StopFreeModule( playHandle, module );
	CloseMIDAS();
}

