////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  P-Buffer Beispielprogramm: einfache Shadow Maps       //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////

#include	<windows.h>			
#include	<math.h>
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	"glext.h"
#include	"texture.h"
#include	"p_buffer.h"
#include	"oglExtension.h"
#include	"hprender.h"

// HDC und HGLRC des OpenGL Fensters
extern HDC		hDC;
extern HGLRC	hRC;

PCUTexture *texSpot;

#include "keys.h"

// Pointer auf die P-Buffer Klasse
CPBuffer *pBuffer;

// Prototypes
void	renderPlane();
void	renderModel();

void	init3DEngine()
{
    glShadeModel( GL_SMOOTH );

	glHint( GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST );

	glDisable( GL_POLYGON_SMOOTH );

	glEnable( GL_DEPTH_TEST );
	glFrontFace( GL_CCW );
	glEnable( GL_CULL_FACE );

	// Lichtquelle zur Beleuchtung der 3D Modelle
	glEnable( GL_LIGHT0 );

	GLfloat light_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat light_diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat light_ambient[] = { 0.0f, 0.0f, 0.0f, 1.0f };

	glLightfv( GL_LIGHT0, GL_AMBIENT, light_ambient );
	glLightfv( GL_LIGHT0, GL_DIFFUSE, light_diffuse );
	glLightfv( GL_LIGHT0, GL_SPECULAR, light_specular );

	glLightf( GL_LIGHT0, GL_SPOT_EXPONENT, 18 );

	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);

	setMaterial();

	glEnable( GL_TEXTURE_2D );
	glDisable( GL_BLEND );

	loadKeyTexture();

	// ben�tigte Extensions initialisieren
	getOpenGLExtensions();

	// P-Buffer anlegen
	extern HDC hDC;
	pBuffer = new CPBuffer( 256, 256, hDC );
//	pBuffer = new CPBuffer( 512, 512, hDC );
//	pBuffer = new CPBuffer( 1024, 1024, hDC );

	if ( !pBuffer->exist() )
		exit( 1 );

	//
	// P-Buffer Kontext !
	//
	if ( !pBuffer->makeCurrent() )
	{
		MessageBox( NULL, "P-Buffer Kontext konnte nicht aktiviert werden !", "PCU", MB_OK );
		exit( 1 );
	}

	glClearColor( 1.0f, 1.0f, 1.0f, 1.0f );

	glDisable( GL_POLYGON_SMOOTH );
	glEnable( GL_DEPTH_TEST );
	glFrontFace( GL_CCW );
	glEnable( GL_CULL_FACE );
	glDisable( GL_LIGHTING );
	glDisable( GL_BLEND );
	glDisable( GL_TEXTURE_2D );
	glColor3ub( 0, 0, 0 );

	texSpot = new PCUTexture();
	texSpot->loadBMP( "./data/spot.bmp" );

	init3DModel( "./data/bunny" );
}

static GLfloat lightPosition[] = { 2.0f, 3.0f, 2.0f, 1.0f };
static GLfloat lightDirection[] = { 2.0f, -4.0f, 2.0f, 1.0f };

#define SPOT_ANGLE	80.0f

//
// Texture Koordinaten Generierung einstellen f�r die Shadow Map
//
void	setupShadowDepth()
{
	static float genS[] = { 1.0f, 0.0f, 0.0f, 0.0f };
	static float genT[] = { 0.0f, 1.0f, 0.0f, 0.0f };
	static float genR[] = { 0.0f, 0.0f, 1.0f, 0.0f };
	static float genQ[] = { 0.0f, 0.0f, 0.0f, 1.0f };
	

	glEnable( GL_TEXTURE_2D );
	glEnable( GL_TEXTURE_GEN_S );
	glEnable( GL_TEXTURE_GEN_T );
	glEnable( GL_TEXTURE_GEN_R );
	glEnable( GL_TEXTURE_GEN_Q );
	glTexGeni( GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR );
	glTexGeni( GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR );
	glTexGeni( GL_R, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR );
	glTexGeni( GL_Q, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR );
	glTexGenfv( GL_S, GL_EYE_PLANE, genS );
	glTexGenfv( GL_T, GL_EYE_PLANE, genT );
	glTexGenfv( GL_R, GL_EYE_PLANE, genR );
	glTexGenfv( GL_Q, GL_EYE_PLANE, genQ );

	glMatrixMode( GL_TEXTURE );
	glLoadIdentity();
	glTranslatef( 0.5f, 0.5f, 0.5f );
	glScalef( 0.5f, 0.5f, 0.5f );
	gluPerspective( SPOT_ANGLE, 1.0f, 1.0f, 500.0f );

	gluLookAt(
		lightPosition[ 0 ],
		lightPosition[ 1 ],
		lightPosition[ 2 ],
		0, 0, 0,
		0, 1, 0 );

	glMatrixMode( GL_MODELVIEW );			
}

//
// Texture Koordinaten Generierung deaktivieren
//
void	clearShadowDepth()
{
	glMatrixMode( GL_TEXTURE );
	glLoadIdentity();

	glDisable( GL_TEXTURE_2D );

	glDisable( GL_TEXTURE_GEN_S );
	glDisable( GL_TEXTURE_GEN_T );
	glDisable( GL_TEXTURE_GEN_R );
	glDisable( GL_TEXTURE_GEN_Q );

	glMatrixMode( GL_MODELVIEW );
}

//
// Zeichnet ein texturiertes Quad �ber den ganzen Viewport, sichert Matrizen
//
void screenRect()
{
	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();
	glLoadIdentity();

	glMatrixMode( GL_PROJECTION );
	glPushMatrix();
	glLoadIdentity();

	glBegin( GL_TRIANGLE_STRIP );
		glTexCoord2f( 0,  1 );
		glVertex2i( -1,  1 );
		glTexCoord2f( 0,  0 );
		glVertex2i( -1, -1 );
		glTexCoord2f( 1,  1 );
		glVertex2i(  1,  1 );
		glTexCoord2f( 1,  0 );
		glVertex2i(  1, -1 );
	glEnd();

	glPopMatrix();
	glMatrixMode( GL_MODELVIEW );
	glPopMatrix();
}

//
// Render Callback
//
void	draw3DEngine()
{
	float time = GetTickCount() * 0.001f;
	lightPosition[ 0 ] = (float)cos( time ) * 2.0f;
	lightPosition[ 1 ] = (float)sin( time * 0.123f ) * 1.0f + 3.0f;
	lightPosition[ 2 ] = (float)sin( time ) * 2.0f;

	lightDirection[ 0 ] = -lightPosition[ 0 ];
	lightDirection[ 1 ] = -lightPosition[ 1 ];
	lightDirection[ 2 ] = -lightPosition[ 2 ];

	extern bool keys[ 256 ];

	  //
	 // P-Buffer
	//
	if ( !pBuffer->makeCurrent() )
	{
		MessageBox( NULL, "P-Buffer Kontext konnte nicht aktiviert werden !", "PCU", MB_OK );
		exit( 1 );
	}

	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	// kein Z-Buffering
	glDepthMask( 0 );

	// Helligkeitsverlauf
	texSpot->select();
	glTexEnvi( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE );
	glEnable( GL_TEXTURE_2D );
	screenRect();
	glDisable( GL_TEXTURE_2D );

	glMatrixMode( GL_PROJECTION );
	glPushMatrix();
	glLoadIdentity();
	gluPerspective( SPOT_ANGLE, 1.0f, 1.0f, 500.0f );

	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();

	glLoadIdentity();

	gluLookAt( 
		lightPosition[ 0 ], 
		lightPosition[ 1 ], 
		lightPosition[ 2 ], 
		0, 0, 0, 
		0, 1, 0 );


	// Schatten werfende Objekte
	renderModel();

	  //
	 // Frame Buffer
	//

	if( !wglMakeCurrent( hDC, hRC ) )
	{
		MessageBox( NULL, "OpenGL Fenster Kontext konnte nicht aktiviert werden !", "PCU", MB_OK );
		exit( 1 );
	}

    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();
	extern int windowX, windowY;
	gluPerspective( 45.0f, (float)windowX / (float)max( 1, windowY ), 0.1f, 500.0f );

	glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();
	glTranslatef( 0, 0, -10 );
	glRotatef( 20, 1, 0, 0 );
	glRotatef( GetTickCount() * 0.02f, 0, 1, 0 );

	//
	// f�r den P-Buffer reservierte Texture ID binden
	//
	glBindTexture( GL_TEXTURE_2D, pBuffer->getTexID() );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
	glTexEnvi( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE );

	//
	// und P-Buffer anh�ngen
	//
	if ( !pBuffer->bind() )
	{
		MessageBox( NULL, "P-Buffer konnte nicht an Texture gebunden werden !", "PCU", MB_OK );
		exit( 1 );
	}

	//
	// und damit rendern
	//
	
	glDisable( GL_BLEND );
	glEnable( GL_DEPTH_TEST );
	glEnable( GL_TEXTURE_2D );

	// Ebene mit Shadow Map zeichnen
	glColor4ub( 255, 255, 255, 255 );
	setupShadowDepth();
	renderPlane();
	clearShadowDepth();

	// Objekt zeichnen
	glLightfv( GL_LIGHT0, GL_POSITION, lightPosition );
	glLightfv( GL_LIGHT0, GL_SPOT_DIRECTION, lightDirection );

	glDisable( GL_TEXTURE_2D );
	renderModel();


	// Lichtquelle zeichnen
	//
	glDisable( GL_LIGHTING );
	glPointSize( 8 );
	glColor3ub( 255, 255, 0 );
	glBegin( GL_POINTS );
	glVertex3fv( lightPosition );
	glEnd();
	glEnable( GL_LIGHTING );

	glEnable( GL_TEXTURE_2D );

	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();
	glLoadIdentity();
	glTranslatef( -1.0f, -1.0f, 0.0f );
	extern int windowX, windowY;
	glScalef( 2.0f / (float)windowX, 2.0f / (float)windowY, 1.0f );

	glMatrixMode( GL_PROJECTION );
	glPushMatrix();
	glLoadIdentity();

	glBegin( GL_TRIANGLE_STRIP );
		glTexCoord2f( 0,  1 );
		glVertex2i( 0,  windowY-128+128 );
		glTexCoord2f( 0,  0 );
		glVertex2i( 0, windowY-128+0 );
		glTexCoord2f( 1,  1 );
		glVertex2i(  128,  windowY-128+128 );
		glTexCoord2f( 1,  0 );
		glVertex2i(  128, windowY-128+0 );
	glEnd();

	glPopMatrix();
	glMatrixMode( GL_MODELVIEW );
	glPopMatrix();

	//
	// P-Buffer von der Texture abkoppeln
	//
	if ( !pBuffer->release() )
	{
		MessageBox( NULL, "P-Buffer konnte nicht von Texture gel�st werden !", "PCU", MB_OK );
		exit( 1 );
	}

	drawKeys();

	glFlush();
}

void	quit3DEngine()
{
	delete pBuffer;

	wglMakeCurrent( hDC, hRC );
}


void renderModel()
{
	glPushMatrix();

	glEnable( GL_NORMALIZE );

	glRotatef( -(float)GetTickCount() * 0.01f, 0, 1, 0 );
	glScalef( 4.0f, 4.0f, 4.0f );

	render3DModel();

	glPopMatrix();
}

void renderPlane()
{
	glBegin( GL_QUADS );
	const float height = -1.0f;
	glNormal3f( 0.0f, 1.0f, 0.0f );
	glVertex3f( -10.0f, height, -10.0f );
	glVertex3f( -10.0f, height, 10.0f );
	glVertex3f( 10.0f, height, 10.0f );
	glVertex3f( 10.0f, height, -10.0f );
	glEnd();
}