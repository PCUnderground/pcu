////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  P-Buffer Klasse                                       //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////

#include <windows.h>
#include <gl\gl.h>			
#include <gl\glu.h>
			
#include "wglext.h"
#include "p_buffer.h"
#include "oglExtension.h"

//
// P-Buffer Konstruktor: anlegen des P-Buffers
//
CPBuffer::CPBuffer( int _x, int _y, HDC _hDC ) : sizeX(_x), sizeY(_y), hPBuffer(NULL), exists(0)
{
	// erstmal Texture ID anfordern, die dann mit dem P-Buffer gebunden wird
	glGenTextures( 1, &textureID );
	glBindTexture( GL_TEXTURE_2D, textureID );
	glTexImage2D( GL_TEXTURE_2D, 0, GL_RGB, _x, _y, 0, GL_RGB, GL_FLOAT, 0 );
	glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR );
	glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR );

	// mit automatischen MIPMAPs (optional)
	/*
	if ( supportGL_SGIS_generate_mipmap )
	{
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST );
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
		glTexParameteri( GL_TEXTURE_2D, GL_GENERATE_MIPMAP_SGIS, GL_TRUE );
	}
	*/

	// die Pixelformat Attribute des P-Buffers:
	//
	int pfAttribute[] =
	{
		// Verwendung von OpenGL
		WGL_SUPPORT_OPENGL_ARB,  TRUE,
		WGL_DRAW_TO_PBUFFER_ARB, TRUE,

		// P-Buffer als Texture verwendbar
		WGL_BIND_TO_TEXTURE_RGBA_ARB, TRUE,

		// RGBA 8888 Format
		WGL_RED_BITS_ARB,   8,
		WGL_GREEN_BITS_ARB, 8,
		WGL_BLUE_BITS_ARB,  8,
		WGL_ALPHA_BITS_ARB, 8,

		// >16 Bit Z-Buffer
		WGL_DEPTH_BITS_ARB, 16,

		// kein Double Buffer
		WGL_DOUBLE_BUFFER_ARB, FALSE, 
		0
	};

	// und anfragen
	//
	unsigned int nFormat = 0;
	  signed int pixelFormat;
	wglChoosePixelFormatARB( _hDC, pfAttribute, NULL, 1, &pixelFormat, &nFormat );

	if ( nFormat == 0 )
	{
		MessageBox( NULL, "Kein passendes Pixel Format gefunden !",	"PCU", MB_OK );
		return;
	}

	// die P-Buffer Attribute, damit man ihn als Texture verwenden kann:
	//
	int pbAttribute[] =
	{
		WGL_TEXTURE_FORMAT_ARB, WGL_TEXTURE_RGBA_ARB, 
		WGL_TEXTURE_TARGET_ARB, WGL_TEXTURE_2D_ARB,
		WGL_MIPMAP_TEXTURE_ARB, GL_TRUE, 0

	};

	// und Anlegen !
	//
	hPBuffer = wglCreatePbufferARB( _hDC, pixelFormat, sizeX, sizeY, pbAttribute );
	hDC      = wglGetPbufferDCARB( hPBuffer );
	hRC      = wglCreateContext( hDC );

	if( !hPBuffer )
	{
		MessageBox( NULL, "P-Buffer konnte nicht angelegt werden !", "PCU", MB_OK );
		return;
	}

	int __x, __y;

	wglQueryPbufferARB( hPBuffer, WGL_PBUFFER_WIDTH_ARB,  &__x );
	wglQueryPbufferARB( hPBuffer, WGL_PBUFFER_HEIGHT_ARB, &__y );

	if( !( __x == sizeX && __y == sizeY ) )
	{
		MessageBox( NULL, "Gr��e des P-Buffers entspricht nicht der gew�nschten !", "PCU", MB_OK );
		return;
	}

	exists = 1;
}

CPBuffer::~CPBuffer()
{
	// entkoppeln und zerst�ren
	release();

	wglDeleteContext( hRC );
	wglReleasePbufferDCARB( hPBuffer, hDC );
	wglDestroyPbufferARB( hPBuffer );
}


int CPBuffer::bind()
{
	if ( !exists ) return 0;

	if( !wglBindTexImageARB( hPBuffer, WGL_FRONT_LEFT_ARB ) )
		return 0;

	return 1;
}

int CPBuffer::release()
{
	if ( !exists ) return 0;

	if( !wglReleaseTexImageARB( hPBuffer, WGL_FRONT_LEFT_ARB ) )
		return 0;

	return 1;
}

int CPBuffer::makeCurrent()
{
	if ( !exists ) return 0;

	if( !wglMakeCurrent( hDC, hRC ) )
        return 0;

	return 1;
}



