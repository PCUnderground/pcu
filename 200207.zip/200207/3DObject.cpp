////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Volumetrische Nebel                                   //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include	<windows.h>			
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	<math.h>
#include	<stdio.h>
#include	<assert.h>
#include	"3DObject.h"

C3DObject::C3DObject( char *file )
{
	if ( file == NULL )
	{
		nVertices = nFaces = 0;
	}

	FILE *f = fopen( file, "rt" );
	assert( f );

	fscanf( f, "%d %d", &nVertices, &nFaces );

	pVertexList	= new VERTEX3D[ nVertices ];
	assert( pVertexList );
	pFogList    = new float[ nVertices * 4 ];
	pNormalList	= new VERTEX3D[ nVertices ];
	assert( pNormalList );
	pFaceList	= new FACE[ nFaces ];
	assert( pFaceList );

	for ( int i = 0; i < nVertices; i++ )
		fscanf( f, "%f %f %f", &pVertexList[ i ].x, &pVertexList[ i ].y, &pVertexList[ i ].z );

	for ( i = 0; i < nFaces; i++ )
		fscanf( f, "%d %d %d", &pFaceList[ i ].a, &pFaceList[ i ].b, &pFaceList[ i ].c );

	fclose( f );

	// Normalen berechnen
	for ( i = 0; i < nFaces; i++ )
	{
		VERTEX3D	*a1, *a2, *a3;
		VERTEX3D	a, b;

		a1 = &pVertexList[ pFaceList[ i ].a ];
		a2 = &pVertexList[ pFaceList[ i ].b ];
		a3 = &pVertexList[ pFaceList[ i ].c ];

		a.x = a2->x - a1->x;
		a.y = a2->y - a1->y;
		a.z = a2->z - a1->z;
		b.x = a3->x - a1->x;
		b.y = a3->y - a1->y;
		b.z = a3->z - a1->z;

		pFaceList[ i ].normal.x = a.y * b.z - b.y * a.z;
		pFaceList[ i ].normal.y = a.z * b.x - b.z * a.x;
		pFaceList[ i ].normal.z = a.x * b.y - b.x * a.y;
	}

	// Vertexnormalen
	for ( i = 0; i < nVertices; i++ )
		pNormalList[ i ].x =
		pNormalList[ i ].y =
		pNormalList[ i ].z = 0.0f;

	for ( i = 0; i < nFaces; i++ )
	{
		pNormalList[ pFaceList[ i ].a ].x += pFaceList[ i ].normal.x;
		pNormalList[ pFaceList[ i ].a ].y += pFaceList[ i ].normal.y;
		pNormalList[ pFaceList[ i ].a ].z += pFaceList[ i ].normal.z;
		pNormalList[ pFaceList[ i ].b ].x += pFaceList[ i ].normal.x;
		pNormalList[ pFaceList[ i ].b ].y += pFaceList[ i ].normal.y;
		pNormalList[ pFaceList[ i ].b ].z += pFaceList[ i ].normal.z;
		pNormalList[ pFaceList[ i ].c ].x += pFaceList[ i ].normal.x;
		pNormalList[ pFaceList[ i ].c ].y += pFaceList[ i ].normal.y;
		pNormalList[ pFaceList[ i ].c ].z += pFaceList[ i ].normal.z;
	}
}

C3DObject::~C3DObject()
{
	delete pVertexList;
	delete pNormalList;
	delete pFaceList;
}

typedef struct
{
    float   ambient[ 4 ];
    float   diffuse[ 4 ];
    float   specular[ 4 ];
    float   emissive[ 4 ];
    float   shininess;
    float   transparency;
}MATERIAL;

MATERIAL materialShiny = 
{
	{ 0.0f, 0.0f, 0.0f, 1.0f },
	{ 0.0f, 0.0f, 0.0f, 1.0f },
	{ 0.8f, 0.8f, 0.8f, 1.0f },
	{ 0.0f, 0.0f, 0.0f, 0.0f },
	180.0f,
	0.0f
};

void	C3DObject::drawObject()
{
    glEnable(GL_COLOR_MATERIAL);

    glColorMaterial(GL_FRONT_AND_BACK,GL_DIFFUSE);
	glMaterialfv( GL_FRONT_AND_BACK, GL_AMBIENT, materialShiny.ambient );
	glMaterialfv( GL_FRONT_AND_BACK, GL_DIFFUSE, materialShiny.diffuse );

    glColorMaterial(GL_FRONT_AND_BACK,GL_SPECULAR);
	glMaterialfv( GL_FRONT_AND_BACK, GL_SPECULAR, materialShiny.specular );
	glMaterialfv( GL_FRONT_AND_BACK, GL_SHININESS, &materialShiny.shininess );
	glMaterialfv( GL_FRONT_AND_BACK, GL_EMISSION, materialShiny.emissive );

	// Zeichnen
	glBegin( GL_TRIANGLES );

	for ( int i = 0; i < nFaces; i++ )
	{
		glNormal3fv( (GLfloat*)&pFaceList[ i ].normal );

		glVertex3fv( (GLfloat*)&pVertexList[ pFaceList[ i ].a ] );
		glVertex3fv( (GLfloat*)&pVertexList[ pFaceList[ i ].b ] );
		glVertex3fv( (GLfloat*)&pVertexList[ pFaceList[ i ].c ] );
	}

	glEnd();
}

#include "vertex3dop.h"
#include "fogvolumes.h"

void	C3DObject::drawObjectFog()
{
    glDisable( GL_COLOR_MATERIAL );

	VERTEX3D minBox = { -150.0f, 0.0f, -150.0f };
	VERTEX3D maxBox = { 150.0f, 8.0f, 150.0f };

	RAY3D	 ray;

	glDisable( GL_TEXTURE_2D );
	glDisable( GL_LIGHTING );
	
	glEnable( GL_BLEND );
	glBlendFunc( GL_ONE, GL_ONE );

	glShadeModel( GL_SMOOTH );
	
	MATRIX44 modelView, invModelView;

	// Modelview Matrix holen...
	glGetFloatv( GL_MODELVIEW_MATRIX, modelView );

	// ... invertieren
	InverseMatrixAnglePreserving( modelView, invModelView );


	// Nebel berechnen !
	VERTEX3D camPos = { 0, 0, 70 };
	ray.from = invModelView * camPos;

	float *pFog = pFogList;
	GLfloat fogColor[] = { 0.7f, 0.7f, 0.5f };

	for ( int i = 0; i < nVertices; i++ )
	{
		ray.d = pVertexList[ i ] - ray.from;
		~ray.d;

		float	tmin, tmax;
		float	fog = 0;

		float radius = 20.0f;
		VERTEX3D center = { 0, 0, 0 };

		if ( boxIntersection( ray, &tmin, &tmax, minBox, maxBox, pVertexList[ i ] ) )
		{
			fog = distanceInFog( ray, tmin, tmax, pVertexList[ i ] );
		}

		// und/oder
/*		if ( sphereIntersection( ray, &tmin, &tmax, center, radius ) )
		{
			fog += distanceInFog( ray, tmin, tmax, pVertexList[ i ] );
		}
*/

		// linear
		fog *= 0.05f;

		// oder:

		// exponentiell
		//fog = exp( fog * 0.03f ) - 1;
		//fog = exp( fog * 0.04f *fog * 0.04f ) - 1;

		*(pFog++) = fog * fogColor[ 0 ];
		*(pFog++) = fog * fogColor[ 1 ];
		*(pFog++) = fog * fogColor[ 2 ];
		*(pFog++) = fog;
	}

	glBegin( GL_TRIANGLES );
	for ( i = 0; i < nFaces; i++ )
	{
		glColor4fv( (GLfloat*)&pFogList[ pFaceList[ i ].a * 4 ] );
		glVertex3fv( (GLfloat*)&pVertexList[ pFaceList[ i ].a ] );

		glColor4fv( (GLfloat*)&pFogList[ pFaceList[ i ].b * 4 ] );
		glVertex3fv( (GLfloat*)&pVertexList[ pFaceList[ i ].b ] );

		glColor4fv( (GLfloat*)&pFogList[ pFaceList[ i ].c * 4 ] );
		glVertex3fv( (GLfloat*)&pVertexList[ pFaceList[ i ].c ] );
	}

	glEnd();
}



