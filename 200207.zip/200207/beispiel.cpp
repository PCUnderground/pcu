////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Volumetrische Nebel                                   //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include	<windows.h>			
#include	<math.h>
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	"glext.h"
#include	"texture.h"
#include	"3DObject.h"

// Texturen die geladen werden
PCUTexture *floorTexture;
PCUTexture *stoneTexture;

// 3D Objekte die geladen werden
C3DObject	*objFloor;
C3DObject	*objTemple;

void	init3DEngine()
{
	// Allgemeine Renderstates

    glShadeModel( GL_SMOOTH );

	glHint( GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST );

	glDisable( GL_POLYGON_SMOOTH );

	glEnable( GL_DEPTH_TEST );
	glFrontFace( GL_CCW );
	glEnable( GL_CULL_FACE );
	glCullFace( GL_BACK );
	glDepthFunc( GL_LEQUAL );
	glDisable( GL_LINE_SMOOTH );

	// texturen laden
	floorTexture = new PCUTexture();
	floorTexture->loadBMP( "./data/boden.bmp" );

	stoneTexture = new PCUTexture();
	stoneTexture->loadBMP( "./data/stone.bmp" );

	glClearDepth( 1.0f );

	// Lichtquelle zur Beleuchtung der 3D Modelle
	glEnable( GL_LIGHT0 );

	GLfloat light_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat light_diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat light_ambient[] = { 0.0f, 0.0f, 0.0f, 1.0f };

	glLightfv( GL_LIGHT0, GL_AMBIENT, light_ambient );
	glLightfv( GL_LIGHT0, GL_DIFFUSE, light_diffuse );
	glLightfv( GL_LIGHT0, GL_SPECULAR, light_specular );

	glLightf( GL_LIGHT0, GL_SPOT_EXPONENT, 18 );

	// 3D Modelle laden
	objFloor  = new C3DObject( "./data/kiste3.3d" );
	objTemple = new C3DObject( "./data/stonehenge.3d" );
}

static GLfloat lightPosition[] = { 5.0f, 5.0f, 5.0f, 1.0f };

  //
 // 3D Szene zeichnen
//
void drawScene( int fog )
{
	glPushMatrix();

	glColor4ub( 255, 255, 255, 255 );

	floorTexture->select();

	// Texturekoordinaten generieren lassen
	glTexGeni( GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR );
	glTexGeni( GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR );

	GLfloat paramS[] = { 1.0f, 0.5f, 0.0f, 0.0f };
	GLfloat paramT[] = { 0.0f, 0.5f, 1.0f, 0.0f };

	glTexGenfv( GL_S, GL_OBJECT_PLANE, paramS );
	glTexGenfv( GL_T, GL_OBJECT_PLANE, paramT );
	
	if ( !fog )
	{
		glEnable( GL_TEXTURE_GEN_S );
		glEnable( GL_TEXTURE_GEN_T );
	} else
	{
		glDisable( GL_TEXTURE_GEN_S );
		glDisable( GL_TEXTURE_GEN_T );
	}

	glMatrixMode( GL_TEXTURE );
	glScalef( 0.033f, 0.033f, 0.033f );
	glMatrixMode( GL_MODELVIEW );

	if ( fog )
		objFloor->drawObjectFog(); else
		objFloor->drawObject();

	stoneTexture->select();

	GLfloat paramS2[] = { 1.3f, 1.3f, 0.0f, 0.0f };
	GLfloat paramT2[] = { 0.0f, -1.3f, 1.4f, 0.0f };

	glTexGenfv( GL_S, GL_OBJECT_PLANE, paramS2 );
	glTexGenfv( GL_T, GL_OBJECT_PLANE, paramT2 );
	
	// Tempel zeichnen
	if ( fog )
		objTemple->drawObjectFog(); else
		objTemple->drawObject();

	glMatrixMode( GL_TEXTURE );
	glLoadIdentity();
	glMatrixMode( GL_MODELVIEW );

	glDisable( GL_TEXTURE_GEN_S );
	glDisable( GL_TEXTURE_GEN_T );
	glDisable( GL_BLEND );

	glPopMatrix();
}

void	draw3DEngine()
{
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();

	extern int windowX, windowY;

	gluPerspective( 45.0f, (float)windowX / (float)max( 1, windowY ), 0.1f, 500.0f );

	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();
	glTranslatef( 0, 0, -70 );
	
	glEnable( GL_NORMALIZE );
	glDisable( GL_BLEND );

	// "Animation"
	glRotatef( 20, 1, 0, 0 );
	glRotatef( GetTickCount() * 0.02f, 0, 1, 0 );

	glCullFace( GL_BACK );
	
	glEnable( GL_TEXTURE_2D );
	glEnable( GL_LIGHTING );
	glDisable( GL_BLEND );
	drawScene( false );

	glDisable( GL_LIGHTING );

	drawScene( true );

	glFlush();
}

void	quit3DEngine()
{
}

