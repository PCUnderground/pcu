////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Volumetrische Nebel                                   //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
typedef struct
{
	VERTEX3D	from, d;
}RAY3D;

bool	sphereIntersection( RAY3D &r, FLOAT *tmin, FLOAT *tmax, VERTEX3D center, float radius )
{
	VERTEX3D delta = r.from - center;

	float a, b, c;

	a = r.d * r.d;
	b = r.d * delta * 2.0f;

	c = center * center + 
		r.from * r.from - 
		2.0f * ( center * r.from ) - 
		radius * radius;

	float d;
	d = b * b - (FLOAT)4.0 * a * c;

	if ( d <= 0.0 ) return 0;

	d = (float)sqrt( d );

	a = 1.0f / (2.0f * a);

	float t1 = ( - b + d ) * a;
	float t2 = ( - b - d ) * a;

	*tmin = min( t1, t2 );
	*tmax = max( t1, t2 );
	return 1;
}

bool	SlabMinMaxT( RAY3D	&ray, FLOAT *tmin, FLOAT *tmax, VERTEX3D minB, VERTEX3D maxB )
{
    float t1, t2;
    float minx, maxx, miny, maxy, minz, maxz;

    if (fabs(ray.d.x) < 0.001) 
	{
		if (minB.x < ray.from.x && maxB.x > ray.from.x) 
		{
		    minx = -1e37f;
			maxx = 1e37f;
		} else
		    return 0;
    } else 
	{
		t1 = (minB.x - ray.from.x) / ray.d.x;
		t2 = (maxB.x - ray.from.x) / ray.d.x;
		if (t1 < t2) 
		{
			minx = t1;
			maxx = t2;
		} else 
		{
		    minx = t2;
			maxx = t1;
		}
		if (maxx < 0)
			return 0;
    }

    if (fabs(ray.d.y) < 0.001) 
	{
		if (minB.y < ray.from.y && maxB.y > ray.from.y) 
		{
			miny = -1e37f;
			maxy = 1e37f;
		} else
			return 0;
    } else 
	{
		t1 = (minB.y - ray.from.y) / ray.d.y;
		t2 = (maxB.y - ray.from.y) / ray.d.y;
		if (t1 < t2) 
		{
			miny = t1;
			maxy = t2;
		} else 
		{
		    miny = t2;
			maxy = t1;
		}
		if (maxy < 0)
			return 0;
    }

    if (fabs(ray.d.z) < 0.001) 
	{
		if (minB.z < ray.from.z && maxB.z > ray.from.z) 
		{
			minz = -1e37f;
			maxz = 1e37f;
		} else
			return 0;
    } else 
	{
		t1 = (minB.z - ray.from.z) / ray.d.z;
		t2 = (maxB.z - ray.from.z) / ray.d.z;
		if (t1 < t2) 
		{
		    minz = t1;
			maxz = t2;
		} else 
		{
			minz = t2;
		    maxz = t1;
		}
		if (maxz < 0)
		    return 0;
    }
	*tmin = max( minx, max( miny, minz ) );
	*tmax = min( maxx, min( maxy, maxz ) );
	
	if ( *tmin < *tmax )
		return 1;
	
	return 0;
}

bool	boxIntersection( RAY3D	&ray, FLOAT *tmin, FLOAT *tmax, VERTEX3D minB, VERTEX3D maxB, VERTEX3D v )
{
	// Trivial Reject !
	if ( ( v.x > maxB.x && ray.from.x > maxB.x ) ||
		 ( v.x < minB.x && ray.from.x < minB.x ) ||
	     ( v.y > maxB.y && ray.from.y > maxB.y ) ||
		 ( v.y < minB.y && ray.from.y < minB.y ) ||
	     ( v.z > maxB.z && ray.from.z > maxB.z ) ||
		 ( v.z < minB.z && ray.from.z < minB.z ) )
		return false;

	if ( SlabMinMaxT( ray, tmin, tmax, minB, maxB ) )
		return true;

	return false;
}

float	distanceInFog( RAY3D ray, float tmin, float tmax, VERTEX3D v )
{
	float tv = 1e37f;
	if ( ray.d.x != 0 )
		tv = ( v.x - ray.from.x ) / ray.d.x; else
	if ( ray.d.y != 0 )
		tv = ( v.y - ray.from.y ) / ray.d.y; else
	if ( ray.d.z != 0 )
		tv = ( v.z - ray.from.z ) / ray.d.z;

	// Kamera blickt von der Box weg
	if ( tmax < 0 )
		return 0;

	// Fog Volume erst hinter dem Vertex !
	if ( tmin > tv )
		return 0;

	// Vertex befindet sich IM Fog Volume
	if ( tv > tmin && tv < tmax )
	{
		// Kamera auch im Fog Volume ?
		if ( tmin < 0 )
			return tv; else
			return tv - tmin;
	} else
	{
		// Fog Volume befindet sich zw. Kamera und Vertex
		return tmax - tmin;
	}
}

