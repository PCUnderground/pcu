///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - Demo Projekt                            //
//                                                       //
//  Movelist-Tunneleffekt                                //
//                                                       //
//  Carsten Dachsbacher                                  //
//                                                       //
///////////////////////////////////////////////////////////
#include "demo.h"

#define ASSEMBLER_LOOP
//#define MOTIONBLUR

// F�r Motionblur
#define	bitmask (((int)((1<<ROT_SIZE)-2)<<(int)ROT_POS)+ \
				 ((int)((1<<GRUEN_SIZE)-2)<<(int)GRUEN_POS)+ \
				 ((int)((1<<BLAU_SIZE)-2)<<(int)BLAU_POS))
int				bitmask2 = ( bitmask << 16 ) | bitmask;

short int		screen[ SCREEN_X * SCREEN_Y + 4 ];
short			palette[ 32 ][ 256 ];
bitmaptype		bmpheader;
unsigned char	*bmp;

// Die Movelist Tabellen
unsigned char   atab[ SCREEN_X * SCREEN_Y ];
unsigned char	ztab[ SCREEN_X * SCREEN_Y ];
unsigned char   stab[ SCREEN_X * SCREEN_Y ];

// Spezielle Tabellen, um die Assemblerroutinen zu beschleunigen
#ifdef ASSEMBLER_LOOP
void			*screenp = (void*)&screen;
unsigned char	*all_in_one;
unsigned char   *bmp2;
#endif

BOOL demoinit( void )
{
    int x,y;
    double temp;

	Fenster_Modus = FENSTER;

    // BMP-File einlesen
    if ( bmp_load( "TUNNEL2.BMP", bmpheader ) !=
         BMP_NOERROR ) return 0;
    bmp = (unsigned char *)bmpheader.cBitmap;

    // Shading Tabelle (f�r das Bild) erstellen
    for ( int level = 0; level < 32; level ++ )
        for ( int i = 0; i < 256; i++ )
        {
            int r = bmpheader.cColors[ i * 4 ];
            int g = bmpheader.cColors[ i * 4 + 1 ];
            int b = bmpheader.cColors[ i * 4 + 2 ];
            r = ( r * level ) / 12;
            g = ( g * level ) / 12;
            b = ( b * level ) / 12;
            palette[ level ][ i ] = ColorCode( r, g, b );
        }

	double d = 512; // Abstand des Betrachters vom Tunnel
	double r = 128;  // Radius des Tunnels

	// ArcTan Tabelle
	int offset = 0;
    for ( y = -SCREEN_Y/2; y < SCREEN_Y/2; y++ )
        for ( x = -SCREEN_X/2; x < SCREEN_X/2; x++ ) 
		{
            if (x) 
			{
                temp = atan( (double)y / (double)x );
                temp = 256.0 * temp / 6.28318630718;

                if ( x <= 0 && y <= 0 ) temp ++;
                if ( x >  0 && y >  0 ) temp ++;
                if ( x >= 0 ) temp += 128;
                
				atab[ offset ++ ] = temp;
            } else
				atab[ offset ++ ] = temp;
        }

	// Z-Tabelle
	offset = 0;
	for ( y = -SCREEN_Y/2; y < SCREEN_Y/2; y++ )
        for ( x = -SCREEN_X/2; x < SCREEN_X/2; x++ ) 
		{
            if (x) 
			{
                temp = cos( atan( (double)y / (double)x ) );
                temp *= d * r / 8.0;
				if ( temp == 0 ) temp ++;

                temp = fabs( temp / (double)x ) + 64.0;

                ztab[ offset ++ ] = temp;
            } else 
                ztab[ offset ++ ] = temp;
        }

	// Shading-Tabelle (f�r den Tunnel)
	offset = 0;
    for ( y = 0; y < SCREEN_Y; y++ )
        for ( x = 0; x < SCREEN_X; x++ )
        {
			double xdist = SCREEN_X / 2 - x;
			double ydist = SCREEN_Y / 2 - y;

			xdist *= xdist;
			ydist *= ydist;

			d = 255.0 - sqrt( xdist + ydist );
			d *= d * d * d * d;
			d /= SCREEN_X * SCREEN_Y * 180.0 * 180.0;

			d = min( 255, max( 0, d ) );
			d = ( 63 - d * 63.0 / 256.0 ) / 2.0 + rand()/8192.0;

			stab[ offset ++ ] = d / 2.0;
        }

#ifdef ASSEMBLER_LOOP
	all_in_one = (unsigned char*)malloc( 128000 * 3 );
	if ( all_in_one == NULL ) return 0;

	memcpy( all_in_one         , atab, SCREEN_X * SCREEN_Y );
	memcpy( all_in_one + 128000, ztab, SCREEN_X * SCREEN_Y );
	memcpy( all_in_one + 256000, stab, SCREEN_X * SCREEN_Y );

	// Texture in einen auf 64kb "alignten" Speicherbereich kopieren,
	// d.h. bei dem Pointer auf die Texture sollen die untersten 16 Bit
	// leer sein. Dies erm�glicht eine schnellere Adressierung in Assembler
	bmp2 = (unsigned char*)malloc( 256*256*2 );
	bmp2 = (unsigned char*)( ((int)bmp2+65536)&~65535 );
	memcpy( bmp2, bmp, 256*256 );
#endif

    return 1;
}

void demomain( void )
{
	int i,j;
	unsigned char xmove = 0;
	unsigned char ymove = 0;

    while ( DemoRunning )
    {
		xmove ++;
		ymove ++;

		register int n = 0;

		register int dest = 0;
 
		// Tunnelbild berechnen
#ifndef ASSEMBLER_LOOP
		for ( n = 0; n < SCREEN_X * SCREEN_Y; n++ )
		{
			register int xpos = ( atab[ n ] + xmove ) & 0xff;

			register int ypos = ( ztab[ n ] + ymove ) & 0xff;
			
			screen[ n ] = palette[ stab[ n ]  ][ bmp[ (ypos << 8) + xpos ] ];
		}
#else
		__asm 
		{
			mov edi, screenp
			mov esi, all_in_one
			mov ebx, bmp2

			mov ecx, SCREEN_X * SCREEN_Y / 2
			mov edx, ebx
			
			// In dieser Schleife werden pro Durchlauf zwei Pixel gezeichnet.
			// Dies erm�glicht optimale Ausnutzung der 2 Pipelines eines Pentiums
			// und Schreibbefehle mit 32 Bit
			// Vorziehen von ein paar Befehlen, die am Ende der Schleife stehen,
			// aber am Anfang ben�tigt werden
			mov bh, byte ptr [ esi + 128000 ]		// Texture y-Koordinate 1. Pixel
			add bh, ymove
			mov dh, byte ptr [ esi + 128000 + 1 ]	// Texture y-Koordinate 2. Pixel
			add dh, ymove
		pixelloop: // 2.p = Berechnung des 2. Pixels, vz = Vorgezogen
			mov bl, byte ptr [ esi ]

			push ecx

			/*2.p*/mov dl, byte ptr [ esi+1 ]
			
			inc esi
			add bl, xmove
			
			/*2.p*/add dl, xmove
			sub ecx, ecx
			/*2.p*/sub eax, eax

			mov ch, byte ptr [ esi + 256000 - 1 ]
			mov cl, byte ptr [ ebx ]

			/*2.p*/mov ah, byte ptr [ esi + 256000+1 - 1 ]
			/*2.p*/mov al, byte ptr [ edx ]


					
			/*vz*/mov bh, byte ptr [ esi + 128000 ]
			/*2.p*//*vz*/mov dh, byte ptr [ esi + 128000+1 ]
		
			lea ecx, [ ecx * 2 + palette ]
			/*2.p*/lea eax, [ eax * 2 + palette ]

			/*vz*/add bh, ymove

			inc esi
			/*2.p*//*vz*/add dh, ymove

			mov ecx, [ ecx ]
			/*2.p*/mov eax, [ eax ]

			shl eax, 16
			mov ax, cx

			/* Motionblur f�r 2 Pixel mit rcr Trick */
#ifdef MOTIONBLUR
			mov ecx, [ edi ]
			and eax, bitmask2
			and ecx, bitmask2
			add eax, ecx
			rcr eax, 1
#endif
			mov [ edi ], eax

			pop ecx

			add edi, 4

			dec ecx
			jnz pixelloop
		}
#endif

        BlitGraphic( screen );
    }
}
	