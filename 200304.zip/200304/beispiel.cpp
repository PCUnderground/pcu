////////////////////////////////////////////////////////////
//                                                        //
//  PC Underground - Demo & Graphic Programming           //
//  Per Pixel Lighting mit ARB Vertex/Fragment Programs   //
//  oder GL_EXT_texture_env_dot3                          //
//  (w)(c)2003 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////

#include	<windows.h>			
#include	<sys\stat.h>
#include	<math.h>
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	"glext.h"
#include	"texture.h"
#include	"oglExtension.h"
#include	"hprender.h"
#include	"vertex3dop.h"

// das hier w�hlen, wenn f�r fragment programs 
// kompiliert werden soll...
#define USE_FRAGMENT_PROGRAM

PCUTexture	*texBumpmap, *texGlossmap, *texBasemap;

#include "keys.h"

// Prototypes
void		renderBox();

GLuint		vpVertexProgramID   = 0;
GLuint		vpFragmentProgramID = 0;

unsigned char *readShaderFile( char *name )
{
    FILE *f = fopen( name, "rt" );

    if( f == NULL ) return NULL;

	fseek( f, 0, SEEK_END );
	int fsize = ftell( f );
	fseek( f, 0, SEEK_SET );

    unsigned char *shader = new unsigned char[ fsize ];

	int s = fread( shader, 1, fsize, f );

    shader[ s ] = 0;

	fclose( f );

	return shader;
}

void setupVP()
{
	if ( !supportARB_vertex_program )
		return;

    glGenProgramsARB( 1, &vpVertexProgramID );
    glBindProgramARB( GL_VERTEX_PROGRAM_ARB, vpVertexProgramID );

#ifdef USE_FRAGMENT_PROGRAM
    unsigned char *shaderASM = readShaderFile( "./programs/phong.vp" );
#else
    unsigned char *shaderASM = readShaderFile( "./programs/envdot3.vp" );
#endif

    glProgramStringARB( GL_VERTEX_PROGRAM_ARB, GL_PROGRAM_FORMAT_ASCII_ARB,
                        strlen( (char*)shaderASM ), shaderASM );

	int ep;
	glGetIntegerv( GL_PROGRAM_ERROR_POSITION_ARB, (int*)&ep );

	if ( ep != -1 )
	{
		char buf[ 512 ];
		sprintf( buf, "error in vertex program at offset %d.\nprogram will exit...", ep );
		MessageBox( NULL, buf, "[error]", MB_OK );
		exit( 1 );
	}

    delete shaderASM;
}

void setupFP()
{
	if ( !supportARB_fragment_program )
		return;

    glGenProgramsARB( 1, &vpFragmentProgramID );
    glBindProgramARB( GL_FRAGMENT_PROGRAM_ARB, vpFragmentProgramID );

    unsigned char *shaderASM = readShaderFile( "./programs/phong.fp" );

    glProgramStringARB( GL_FRAGMENT_PROGRAM_ARB, GL_PROGRAM_FORMAT_ASCII_ARB,
                        strlen( (char*)shaderASM ), shaderASM );

	int ep;
	glGetIntegerv( GL_PROGRAM_ERROR_POSITION_ARB, (int*)&ep );

	if ( ep != -1 )
	{
		char buf[ 512 ];
		sprintf( buf, "error in fragment program at offset %d.\nprogram will exit...", ep );
		MessageBox( NULL, buf, "[error]", MB_OK );
		exit( 1 );
	}

    delete shaderASM;
}


void	init3DEngine()
{
    glShadeModel( GL_SMOOTH );

	glHint( GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST );

	glDisable( GL_POLYGON_SMOOTH );

	glEnable( GL_DEPTH_TEST );
	glFrontFace( GL_CCW );
	glEnable( GL_CULL_FACE );
	glDisable( GL_LIGHTING );

	// Lichtquelle zur Beleuchtung der 3D Modelle
#ifdef USE_FRAGMENT_PROGRAM
	loadKeyTexture( "./data/keys2.bmp" );
#else
	loadKeyTexture( "./data/keys1.bmp" );
#endif

	// ben�tigte Extensions initialisieren
	getOpenGLExtensions();

	// ... und �berpr�fen, ob alles da ist:
	if ( !supportARB_vertex_program )
	{
		MessageBox( NULL, "ARB_vertex_program Extension wird nicht unterst�tzt !", "[ERROR]", MB_OK );
		exit(1);
	}
#ifdef USE_FRAGMENT_PROGRAM
	if ( !supportARB_fragment_program )
	{
		MessageBox( NULL, "ARB_fragment_program Extension wird nicht unterst�tzt !", "[ERROR]", MB_OK );
		exit(1);
	}
#else
	if ( !supportGL_EXT_texture_env_dot3 )
	{
		MessageBox( NULL, "GL_EXT_texture_env_dot3 Extension wird nicht unterst�tzt !", "[ERROR]", MB_OK );
		exit(1);
	}
#endif


	texBumpmap = new PCUTexture();
	texBumpmap->loadBMP( "./data/mbumpmap.bmp" );
	glTexParameterf( GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR );

	texGlossmap = new PCUTexture();
	texGlossmap->loadBMP( "./data/mglossmap.bmp" );
	glTexParameterf( GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR );

	texBasemap = new PCUTexture();
	texBasemap->loadBMP( "./data/mbasemap.bmp" );
	glTexParameterf( GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR );

	init3DModel( "./data/tric" );

	setupVP();
#ifdef USE_FRAGMENT_PROGRAM
	setupFP();
#endif
}

VERTEX3D lightPosition, cameraPosition;

//
// Rendern der Szene mit Fragment Programs
//
#ifdef USE_FRAGMENT_PROGRAM

void renderScene()
{
	glActiveTextureARB( GL_TEXTURE0_ARB );
	texBasemap->select();

	glActiveTextureARB( GL_TEXTURE1_ARB );
	texBumpmap->select();

	glActiveTextureARB( GL_TEXTURE2_ARB );
	texGlossmap->select();

	glEnable( GL_FRAGMENT_PROGRAM_ARB );

    glProgramEnvParameter4fARB( GL_FRAGMENT_PROGRAM_ARB, 0,  0.1f,  0.1f,  0.1f,  1.0f );
    glProgramEnvParameter4fARB( GL_FRAGMENT_PROGRAM_ARB, 1,  1.0f,  1.0f,  1.0f,  1.0f );
    glProgramEnvParameter4fARB( GL_FRAGMENT_PROGRAM_ARB, 2,  2.0f,  2.0f,  2.0f,  1.0f );
    glProgramEnvParameter4fARB( GL_FRAGMENT_PROGRAM_ARB, 3, 24.0f,  0.0f,  0.0f,  0.0f );

	//
	// in dieser Szene ist Object Space gleich World Space
	// darum kann man sich die Transformation der Kamera und Lichtposition
	// in den Object Space sparen !
	//
    glProgramEnvParameter4fARB( GL_VERTEX_PROGRAM_ARB, 1, lightPosition.x, lightPosition.y, lightPosition.z, 1.0f );
    glProgramEnvParameter4fARB( GL_VERTEX_PROGRAM_ARB, 2, cameraPosition.x, cameraPosition.y, cameraPosition.z, 1.0f );

	glEnable( GL_VERTEX_PROGRAM_ARB );

	renderBox();

	renderWithTangentSpace();

	glDisable( GL_VERTEX_PROGRAM_ARB );

	glDisable( GL_FRAGMENT_PROGRAM_ARB );
}

#endif

//
// Rendern der Szene mit der GL_EXT_texture_env_dot3
// Extension => diffuses Bumpmapping
//
void renderSceneWOFP()
{
	glDisable( GL_FRAGMENT_PROGRAM_ARB );

	glActiveTextureARB( GL_TEXTURE0_ARB );
	glEnable( GL_TEXTURE_2D );
	texBumpmap->select();

	glTexEnvi( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE_EXT );
	glTexEnvi( GL_TEXTURE_ENV, GL_COMBINE_RGB_EXT,  GL_DOT3_RGBA_EXT );

	glTexEnvi( GL_TEXTURE_ENV, GL_SOURCE0_RGB_EXT,  GL_PREVIOUS_EXT );
	glTexEnvi( GL_TEXTURE_ENV, GL_OPERAND0_RGB_EXT, GL_SRC_COLOR );

	glTexEnvi( GL_TEXTURE_ENV, GL_SOURCE1_RGB_EXT,  GL_TEXTURE );
	glTexEnvi( GL_TEXTURE_ENV, GL_OPERAND1_RGB_EXT, GL_SRC_COLOR );

	glActiveTextureARB( GL_TEXTURE1_ARB );
	glEnable( GL_TEXTURE_2D );
	texBasemap->select();
	glTexEnvi( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

    glProgramEnvParameter4fARB( GL_VERTEX_PROGRAM_ARB, 1, lightPosition.x, lightPosition.y, lightPosition.z, 1.0f );

	glEnable( GL_VERTEX_PROGRAM_ARB );

	renderBox();

	renderWithTangentSpace();

	glActiveTextureARB( GL_TEXTURE0_ARB );
	glTexEnvi( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

	glDisable( GL_VERTEX_PROGRAM_ARB );
}

// Lichtquelle durch einen Punkt darstellen
void renderLightPosition( VERTEX3D lightPosition )
{
	glActiveTextureARB( GL_TEXTURE2_ARB );
	glDisable( GL_TEXTURE_2D );
	glActiveTextureARB( GL_TEXTURE1_ARB );
	glDisable( GL_TEXTURE_2D );
	glActiveTextureARB( GL_TEXTURE0_ARB );
	glDisable( GL_TEXTURE_2D );
	glColor3ub( 255, 255, 155 );
	glPointSize( 8 );
	glBegin( GL_POINTS );
	glVertex3fv( (GLfloat*)&lightPosition );
	glEnd();
}


//
// Render Callback
//
static int toggleSecondLight = 1;

void	draw3DEngine()
{
	extern bool	keys[ 256 ];

	if ( keys[ 'L' ] )
	{
		toggleSecondLight = 1 - toggleSecondLight;
		keys[ 'L' ] = 0;
	}

	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	glDisable( GL_BLEND );
	glEnable( GL_DEPTH_TEST );
	glDisable( GL_TEXTURE_2D );

	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();

	extern int windowX, windowY;
	gluPerspective( 90.0f, (float)windowX / (float)windowY, 0.1f, 500.0f );

	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();

	float angle = GetTickCount() / 3000.0f;

	cameraPosition.x = 4.0f * (float)cos( angle );
	cameraPosition.y = 2.0f;
	cameraPosition.z = 4.0f * (float)sin( angle );

	gluLookAt(
		cameraPosition.x,
		cameraPosition.y,
		cameraPosition.z,
		0.0f, 0.0f, 0.0f,
		0.0f, 1.0f, 0.0f );

	glDepthFunc( GL_LEQUAL );

	//
	// Zwei Lichtquellen durch additives Blending
	//
	float time = GetTickCount() * 0.001f;

	lightPosition.x = (float)cos( time ) * 3.0f;
	lightPosition.y = (float)sin( time * 1.231 ) * 0.0f + 1.0f;
	lightPosition.z = (float)sin( time ) * 3.0f;

#ifdef USE_FRAGMENT_PROGRAM
	renderScene();
#else
	renderSceneWOFP();
#endif

	renderLightPosition( lightPosition );

	if ( toggleSecondLight )
	{
		glEnable( GL_BLEND );
		glBlendFunc( GL_ONE, GL_ONE );
		time *= 1.452f;
		lightPosition.x = (float)cos( time ) * 3.0f;
		lightPosition.y = (float)sin( time * 1.231 ) * 1.0f + 1.0f;
		lightPosition.z = (float)sin( time ) * 3.0f;

	#ifdef USE_FRAGMENT_PROGRAM
		renderScene();
	#else
		renderSceneWOFP();
	#endif

		glDisable( GL_BLEND );

		renderLightPosition( lightPosition );
	}

	glEnable( GL_TEXTURE_2D );
	drawKeys();

	glFlush();
}

void	quit3DEngine()
{
}

//
// so zeichnen Menschen einen W�rfel, die keine Lust haben
// eine Vertex und Attribut Liste f�r alle Seiten zu tippen
//

VERTEX3D _v[] = 
{
	{ -4.0f, -40.0f, -4.0f },
	{ -4.0f, -40.0f,  4.0f },
	{  4.0f, -40.0f,  4.0f },
	{  4.0f, -40.0f, -4.0f },
};

VERTEX3D _n[] = 
{
	{ 0.0f, 1.0f, 0.0f },
	{ 0.0f, 1.0f, 0.0f },
	{ 0.0f, 1.0f, 0.0f },
	{ 0.0f, 1.0f, 0.0f },
};

VERTEX3D _bi[] = 
{
	{ -1.0f, 0.0f, 0.0f },
	{ -1.0f, 0.0f, 0.0f },
	{ -1.0f, 0.0f, 0.0f },
	{ -1.0f, 0.0f, 0.0f },
};

VERTEX3D _ta[] = 
{
	{ 0.0f, 0.0f, 1.0f },
	{ 0.0f, 0.0f, 1.0f },
	{ 0.0f, 0.0f, 1.0f },
	{ 0.0f, 0.0f, 1.0f },
};

VERTEX3D _tex[] = 
{
	{ -1.0f, -1.0f, 1.0f },
	{ -1.0f,  1.0f, 1.0f },
	{  1.0f,  1.0f, 1.0f },
	{  1.0f, -1.0f, 1.0f },
};

int swizzleTab[6][4] =
{
	{ 0, 1, 2, 1 },
	{ 0, 2, 1, -1 },
	{ 1, 0, 2, -1 },
	{ 1, 2, 0, 1 },
	{ 2, 0, 1, 1 },
	{ 2, 1, 0, -1 }
};

VERTEX3D swizzleVector( VERTEX3D v, int swizzle )
{
	VERTEX3D r;
	((float*)&r)[0] = ((float*)&v)[swizzleTab[swizzle][0]];
	((float*)&r)[1] = ((float*)&v)[swizzleTab[swizzle][1]];
	((float*)&r)[2] = ((float*)&v)[swizzleTab[swizzle][2]];
	r *= (float)swizzleTab[ swizzle ][ 3 ];
	return r;
}

void renderSingleQuad( int swizzle )
{
	for ( float b = -4.0f; b <= 4.0f; b += 0.5f )
		for ( float a = -4.0f; a <= 4.0f; a += 0.5f )
			for ( int i = 0; i < 4; i++ )
			{
				// lightpos to tangent space
				VERTEX3D vpos = { b, -1.7f, a };
				vpos += (_v[ i ] * (1.0f/16.0f));

				glMultiTexCoord2fARB(  GL_TEXTURE0_ARB, vpos.x * 0.2f, vpos.z * 0.2f );

				VERTEX3D bi = swizzleVector( _bi[i], swizzle );
				VERTEX3D ta = swizzleVector( _ta[i], swizzle );
				VERTEX3D n  = swizzleVector( _n[i],  swizzle );
				VERTEX3D v  = swizzleVector( vpos,   swizzle );

				glMultiTexCoord3fvARB( GL_TEXTURE1_ARB, (GLfloat*)&bi );
				glMultiTexCoord3fvARB( GL_TEXTURE2_ARB, (GLfloat*)&ta );
				glNormal3fv( (GLfloat*)&n );

				glVertex3fv( (GLfloat*)&v );
			}
}

void renderBox()
{
	glBegin( GL_QUADS );

	for ( int i = 0; i < 6; i++ )
		renderSingleQuad( i );

	glEnd();
}
