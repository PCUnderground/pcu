////////////////////////////////////////////////////////////
//                                                        //
//  PC Underground - Demo & Graphic Programming           //
//  Einfaches Rendering mit Tangent Spaces                //
//  (w)(c)2003 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include	<windows.h>			
#include	<stdio.h>			
#include	<stdlib.h>			
#include	<math.h>
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	"texture.h"
#include	"oglextension.h"
#include	"vertex3dop.h"
#include	"hprender.h"

// renderMode == RM_SHAREDVERTEX oder RM_TRIANGLESTRIP
U32 renderMode = RM_TRIANGLESTRIP;

//
// einfache Shared Vertex Datenstrukturen und simples Fileformat
//
typedef struct
{
	U32			a, b, c;		// indices to vertices
	VERTEX3D	normal;			// normal of triangle
	FLOAT		area;			// area of triangle
}TRIFACE;

static unsigned int	nVertices    = 0, 
					nFaces       = 0;
static VERTEX3D		*pVertexList = NULL;
static TRIFACE		*pFaceList   = NULL;
static float		*pTexCoordList = NULL;
static VERTEX3D		*pNormalList = NULL;
static VERTEX3D		*pTangentList = NULL;
static VERTEX3D		*pBinormalList = NULL;

//
// Isotrope Skalierung der Koordinaten
//
static void	scaleIsotropic( VERTEX3D *pVertexList, unsigned int nVertices )
{
	// calculate bounding box of mesh
	FLOAT	xminv = 1e37f, xmaxv = -1e37f;
	FLOAT	yminv = 1e37f, ymaxv = -1e37f;
	FLOAT	zminv = 1e37f, zmaxv = -1e37f;

	for ( unsigned int i = 0; i < nVertices; i++ )
	{

		xminv = min( xminv, pVertexList[ i ].x );
		yminv = min( yminv, pVertexList[ i ].y );
		zminv = min( zminv, pVertexList[ i ].z );
		xmaxv = max( xmaxv, pVertexList[ i ].x );
		ymaxv = max( ymaxv, pVertexList[ i ].y );
		zmaxv = max( zmaxv, pVertexList[ i ].z );
	}

	FLOAT	xmove = -(FLOAT)0.5 * ( xminv + xmaxv );
	FLOAT	ymove = -(FLOAT)0.5 * ( yminv + ymaxv );
	FLOAT	zmove = -(FLOAT)0.5 * ( zminv + zmaxv );

	FLOAT	maxSize = (FLOAT)max( (FLOAT)fabs( xminv - xmaxv ), max( (FLOAT)fabs( yminv - ymaxv ), (FLOAT)fabs( zminv - zmaxv ) ) );

	FLOAT	scale = (FLOAT)4.5 / (FLOAT)maxSize;

	// translate and scale vertices
	for ( i = 0; i < nVertices; i++ )
	{
		pVertexList[ i ].x += xmove;
		pVertexList[ i ].y += ymove;
		pVertexList[ i ].z += zmove;
		pVertexList[ i ].x *= scale;
		pVertexList[ i ].y *= scale;
		pVertexList[ i ].z *= scale;
	}
}

static void readTriangleMesh( char *filename )
{
	if ( filename == NULL )
	{
		nVertices = nFaces = 0;
	}

	FILE *f = fopen( filename, "rb" );
	fread( &nVertices, 4, 1, f );
	fread( &nFaces, 4, 1, f );

	pVertexList		= new VERTEX3D[ nVertices ];
	pNormalList		= new VERTEX3D[ nVertices ];
	pTangentList	= new VERTEX3D[ nVertices ];
	pBinormalList	= new VERTEX3D[ nVertices ];
	pTexCoordList	= new float[ nVertices * 2 ];
	pFaceList	= new TRIFACE[ nFaces ];

	for ( unsigned int i = 0; i < nVertices; i++ )
	{
		fread( &pVertexList[ i ].x, 1, 4, f );
		fread( &pVertexList[ i ].y, 1, 4, f );
		fread( &pVertexList[ i ].z, 1, 4, f );
	}

	for ( i = 0; i < nFaces; i++ )
	{
		fread( &pFaceList[ i ].a, 1, 4, f );
		fread( &pFaceList[ i ].b, 1, 4, f );
		fread( &pFaceList[ i ].c, 1, 4, f );
	}
	
	fclose( f );

	// Normalen berechnen
	for ( i = 0; i < nFaces; i++ )
	{
		VERTEX3D	*a1, *a2, *a3;
		VERTEX3D	a, b;

		a1 = &pVertexList[ pFaceList[ i ].a ];
		a2 = &pVertexList[ pFaceList[ i ].b ];
		a3 = &pVertexList[ pFaceList[ i ].c ];

		a = *a2 - *a1;
		b = *a3 - *a1;

		pFaceList[ i ].normal = a ^ b;

		pFaceList[ i ].area = (float)sqrt( pFaceList[ i ].normal * pFaceList[ i ].normal );

	}

	// Vertexnormalen
	for ( i = 0; i < nVertices; i++ )
		pNormalList[ i ].x =
		pNormalList[ i ].y =
		pNormalList[ i ].z = 0.0f;

	for ( i = 0; i < nFaces; i++ )
	{
		pNormalList[ pFaceList[ i ].a ] += pFaceList[ i ].normal;
		pNormalList[ pFaceList[ i ].b ] += pFaceList[ i ].normal;
		pNormalList[ pFaceList[ i ].c ] += pFaceList[ i ].normal;

		pFaceList[ i ].normal *= 1.0f / pFaceList[ i ].area;
	}

	scaleIsotropic( pVertexList, nVertices );

	//
	// Tangent Spaces und Texture Koordinaten berechnen !
	//
	for ( i = 0; i < nVertices; i++ )
	{
		~pNormalList[ i ];

		VERTEX3D bi, n;

		n = pNormalList[ i ];

		VERTEX3D up = { 0.0f, 0.0f, -1.0f };
		
		pBinormalList[ i ] = n ^ up;
		pTangentList[ i ] = bi ^ n;

		~pBinormalList[ i ];
		~pTangentList[ i ];

		VERTEX3D p = pVertexList[ i ];

		pTexCoordList[ i * 2 + 0 ] = p.x;
		pTexCoordList[ i * 2 + 1 ] = (float)atan2( p.y, p.z );
	}
}


unsigned int *pIndexList;
unsigned int nStripIndices;
unsigned int *pStripIndices;


void	init3DModel( char *triangleMesh )
{
	//
	// Dreiecksnetz laden
	//
	char buf[ 512 ];
	sprintf( buf, "%s.cnd", triangleMesh );
	readTriangleMesh( buf );

	scaleIsotropic( pVertexList, nVertices );

	//
	// Triangle Strips laden
	//
	sprintf( buf, "%s.strip", triangleMesh );
	FILE *f = fopen( buf, "rb" );
	if ( f != NULL )
	{
		fread( &nStripIndices, 4, 1, f );
		pStripIndices = new unsigned int[ nStripIndices ];
		for ( U32 n = 0; n < nStripIndices; n++ )
		{
			unsigned short t;
			fread( &t, 2, 1, f );
			pStripIndices[ n ] = t;
		}
		fclose( f );
	} else
		if ( renderMode == RM_TRIANGLESTRIP )
			renderMode = RM_SHAREDVERTEX;

	//
	// Indexliste bauen
	//
	pIndexList = new unsigned int [ nFaces * 3 ];

	int c = 0;
	for ( U32 i = 0; i < nFaces; i++ )
	{
		pIndexList[ c ++ ] = pFaceList[ i ].a;
		pIndexList[ c ++ ] = pFaceList[ i ].b;
		pIndexList[ c ++ ] = pFaceList[ i ].c;
	}

	getOpenGLExtensions();

	if ( supportCompiledVertexArray )
		(*pfLockArrays)( 0, nVertices );
}

void	delete3DModel()
{
	if ( supportCompiledVertexArray )
		(*pfUnlockArrays)();
}


void renderWithTangentSpace()
{
	glClientActiveTextureARB( GL_TEXTURE2_ARB );
	glEnableClientState( GL_TEXTURE_COORD_ARRAY );
	glTexCoordPointer( 3, GL_FLOAT, 0, pTangentList );

	glClientActiveTextureARB( GL_TEXTURE1_ARB );
	glEnableClientState( GL_TEXTURE_COORD_ARRAY );
	glTexCoordPointer( 3, GL_FLOAT, 0, pBinormalList );

	glClientActiveTextureARB( GL_TEXTURE0_ARB );
	glEnableClientState( GL_TEXTURE_COORD_ARRAY );
	glTexCoordPointer( 2, GL_FLOAT, 0, pTexCoordList );

	glNormalPointer( GL_FLOAT, 0, pNormalList );
	glVertexPointer( 3, GL_FLOAT, 0, pVertexList );

	glEnableClientState( GL_VERTEX_ARRAY );
	glEnableClientState( GL_NORMAL_ARRAY );

	if ( renderMode == RM_TRIANGLESTRIP )
		glDrawElements( GL_TRIANGLE_STRIP, nStripIndices, GL_UNSIGNED_INT, pStripIndices ); else
		glDrawElements( GL_TRIANGLES, nFaces * 3, GL_UNSIGNED_INT, pIndexList );

	glClientActiveTextureARB( GL_TEXTURE2_ARB );
	glDisableClientState( GL_TEXTURE_COORD_ARRAY );

	glClientActiveTextureARB( GL_TEXTURE1_ARB );
	glDisableClientState( GL_TEXTURE_COORD_ARRAY );
	
	glClientActiveTextureARB( GL_TEXTURE0_ARB );
	glDisableClientState( GL_TEXTURE_COORD_ARRAY );
	
	glDisableClientState( GL_VERTEX_ARRAY );
	glDisableClientState( GL_NORMAL_ARRAY );
}
