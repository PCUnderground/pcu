////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#ifndef _HPRENDER__H
#define _HPRENDER__H

#include "syndefines.h"

// Rendermodi
#define RM_SHAREDVERTEX  0
#define RM_TRIANGLESTRIP 1

// allgemein: renderMode == RM_SHAREDVERTEX oder RM_TRIANGLESTRIP
extern U32 renderMode;

extern void	init3DModel( char *triangleMesh );
extern void	delete3DModel();
extern void renderWithTangentSpace();

#endif