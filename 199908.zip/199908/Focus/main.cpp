////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground - Focus Demo              //
//                                                        //
//  (w)(c)�99 Carsten Dachsbacher                         //
//                                                        //
////////////////////////////////////////////////////////////

#include "demo.h"

bitmaptype logobmp;

unsigned short *screen;		
unsigned long  *focus;		

#define NUMPICTURES		6
#define PICSIZE			SCREEN_X * SCREEN_Y

int LoadFocus( char *name, int n )
{
	// Ein Bild laden
	if ( bmp_load( name, logobmp ) != BMP_NOERROR ) return 0;

	// Jeden Pixel in folgendes Format konvertieren:
	// 00000000rrrrrrrrggggggggbbbbbbbb
	for ( int i = 0; i < PICSIZE; i++ )
	{
		unsigned long c;
		c = logobmp.cBitmap[ i * 3 + 2 ] << 16;
		c |= logobmp.cBitmap[ i * 3 + 1 ] << 8;
		c |= logobmp.cBitmap[ i * 3 + 0 ];

		focus[ i + n * PICSIZE ] = c;
	}

	bmp_free( logobmp );

	return 1;
}

BOOL demoinit (void)
{
	Fenster_Modus = FENSTER;

	// Speicher allokieren
	screen = (unsigned short *)malloc( SCREEN_X * SCREEN_Y * sizeof( short ) );
	assert( screen );
	focus   = (unsigned long *)malloc( SCREEN_X * SCREEN_Y * sizeof( long ) * NUMPICTURES );
	assert( focus );

	// Bilder laden und konvertieren
	if ( !LoadFocus( "focus1.bmp", 0 ) ) return 0;
	if ( !LoadFocus( "focus2.bmp", 1 ) ) return 0;
	if ( !LoadFocus( "focus3.bmp", 2 ) ) return 0;
	if ( !LoadFocus( "focus4.bmp", 3 ) ) return 0;
	if ( !LoadFocus( "focus5.bmp", 4 ) ) return 0;
	if ( !LoadFocus( "focus6.bmp", 5 ) ) return 0;

	return TRUE;
}

void Interpolate( unsigned long *source1, unsigned long *source2, float mix )
{
	// Die 2 Faktoren in den Bereich von 0 bis 255 skalieren
	int	factor1 = (int)( (1.0f - mix ) * 255.0f );
	int factor2 = (int)( mix * 255.0f );

	for ( int i = 0; i < PICSIZE; i++ )
	{
		unsigned long c1, c2;
		int r, g, b;

		c1 = source1[ i ];
		c2 = source2[ i ];

		// Rot-, Gr�n- und Blauwerte mischen
		r = ( (c1 >> 16) * factor1 + (c2 >> 16) * factor2 ) >> 8;
		g = ( ((c1 >> 8)&255) * factor1 + ((c2 >> 8)&255) * factor2 ) >> 8;
		b = ( (c1&255) * factor1 + (c2&255) * factor2 ) >> 8;

		// Und auf den Bildschirm bringen
		screen[ i ] = Rtab[ r ] | Gtab[ g ] | Btab[ b ];
	}
}

extern HWND DemoHWND;

void demomain (void)
{
	int frame = 0;

	// wanted ist die Nummer des gew�nschten Bildes mit Mischverh�ltnis zum
	// darrauffoldenden
	float wanted = 0.0f;
	float delta = 0.01f;

	// Zur Zeitmessung
	float oldtime = (float)GetDemoTime();

	while ( ( DemoRunning ) && (!KeyStatus[ VK_ESCAPE ] ) )
	{
		float time = (float)GetDemoTime();

		// Zeit seit dem letztem berechneten Bild bestimmen,
		// um die Tiefenschaerfe gleichm��ig zu variieren
		float timestep = ( time - oldtime ) / 10.0f;
		oldtime = time;

		// die kleiner und die gr��ere ganze Zahl finden
		int untere_grenze = (int)wanted;
		int obere_grenze = (int)ceil( wanted );

		// Der Nachkommaanteil, d.h. das Mischverh�ltnis berechnen
		float mischverhaeltnis = wanted - untere_grenze;

		// Zeiger auf die 2 zu mischenden Bilder
		unsigned long *source1 = focus + untere_grenze * PICSIZE;
		unsigned long *source2 = focus + obere_grenze * PICSIZE;

		Interpolate( source1, source2, mischverhaeltnis );

		// Gew�nschtes Bild w�hlen
		wanted += delta * timestep;

		if ( wanted > (NUMPICTURES-1) )
		{
			delta = -delta;
			wanted = NUMPICTURES-1;
		}
		if ( wanted < 0 )
		{
			delta = -delta;
			wanted = 0;
		}

		BlitGraphic( screen );
	}
}	


void demoquit (void)
{
	free( screen );
	free( focus );
}

