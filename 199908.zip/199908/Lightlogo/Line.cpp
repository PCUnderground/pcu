#include "line.h"

#define TRUE  1
#define FALSE 0

static int XLeft   = 10;
static int XRight  = 629;
static int YTop    = 10;
static int YBottom = 469;


#define ClipPBottom                                    \
{                                                      \
  px = (qx - px)*(YBottom - py) / (qy - py) + px;      \
  py = YBottom;                                        \
}

#define ClipPTop                                       \
{                                                      \
  px = (qx - px)*(YTop - py) / (qy - py) + px;         \
  py = YTop;                                           \
}

#define ClipPRight                                     \
{                                                      \
  py = (qy - py)*(XRight - px) / (qx - px) + py;       \
  px = XRight;                                         \
}

#define ClipPLeft                                      \
{                                                      \
  py = (qy - py)*(XLeft - px) / (qx - px) + py;        \
  px = XLeft;                                          \
}

#define ClipQBottom                                    \
{                                                      \
  qx = (px - qx)*(YBottom - qy) / (py - qy) + qx;      \
  qy = YBottom;                                        \
}

#define ClipQTop                                       \
{                                                      \
  qx = (px - qx)*(YTop - qy) / (py - qy) + qx;         \
  qy = YTop;                                           \
}

#define ClipQRight                                     \
{                                                      \
  qy = (py - qy)*(XRight - qx) / (px - qx) + qy;       \
  qx = XRight;                                         \
}

#define ClipQLeft                                      \
{                                                      \
  qy = (py - qy)*(XLeft - qx) / (px - qx) + qy;        \
  qx = XLeft;                                          \
}


int clip2d(int &px, int &py, int &qx, int &qy)
{
  int code = 0;

  if ( qy > YBottom ) {
    code |=8;
  } else if ( qy < YTop ) {
    code |=4;
  }

  if ( qx > XRight ) {
    code |=2;
  } else if ( qx < XLeft ) {
    code |=1;
  }

  if ( py > YBottom ) {
    code |=128;
  } else if ( py < YTop ) {
    code |=64;
  }

  if ( px > XRight ) {
    code |=32;
  } else if ( px < XLeft ) {
    code |=16;
  }

  switch ( code ) {
    case 0x00 : return TRUE;
    case 0x01 : ClipQLeft;
                return TRUE;
    case 0x02 : ClipQRight;
                return TRUE;
    case 0x04 : ClipQTop;
                return TRUE;
    case 0x05 : ClipQLeft;
               if ( qy < YTop ) {
                 ClipQTop;
               }
               return TRUE;
    case 0x06 : ClipQRight;
                if ( qy < YTop ) {
                  ClipQTop;
                }
                return TRUE;
    case 0x08 : ClipQBottom;
                return TRUE;
    case 0x09 : ClipQLeft;
                if ( qy > YBottom ) {
                  ClipQBottom;
                }
                return TRUE;
    case 0x0A : ClipQRight;
                if ( qy > YBottom ) {
                  ClipQBottom;
                }
                return TRUE;
    case 0x10 : ClipPLeft;
                return TRUE;
    case 0x11 : return FALSE;
    case 0x12 : ClipPLeft;
                ClipQRight;
                return TRUE;
    case 0x14 : ClipPLeft;
                if ( py < YTop ) {
                  return FALSE;
                } else {
                  ClipQTop;
                 return TRUE;
                }
    case 0x15 : return FALSE;
    case 0x16 : ClipPLeft;
                if ( py < YTop ) {
                  return FALSE;
                } else {
                  ClipQTop;
                  if ( qx > XRight ) {
                    ClipQRight;
                  }
                  return TRUE;
                }
    case 0x18 : ClipPLeft;
                if ( py > YBottom ) {
                  return FALSE;
                } else {
                  ClipQBottom;
                  return TRUE;
                }
    case 0x19 : return FALSE;
    case 0x1A : ClipPLeft;
                if ( py > YBottom ) {
                  return FALSE;
                } else {
                  ClipQBottom;
                  if ( qx > XRight ) {
                    ClipQRight;
                  }
                  return TRUE;
                }
    case 0x20 : ClipPRight;
            return TRUE;
    case 0x21 : ClipPRight;
            ClipQLeft;
            return TRUE;
    case 0x22 : return FALSE;
    case 0x24 : ClipPRight;
            if ( py < YTop ) {
              return FALSE;
            } else {
              ClipQTop;
              return TRUE;
            }
    case 0x25 : ClipPRight;
            if ( py < YTop ) {
              return FALSE;
            } else {
              ClipQTop;
              if ( qx < XLeft ) {
                ClipQLeft;
              }
              return TRUE;
            }
    case 0x26 : return FALSE;
    case 0x28 : ClipPRight;
            if ( py > YBottom ) {
              return FALSE;
            } else {
              ClipQBottom;
              return TRUE;
            }
    case 0x29 : ClipPRight;
            if ( py > YBottom ) {
              return FALSE;
            } else {
              ClipQBottom;
              if ( qx < XLeft ) {
                ClipQLeft;
              }
              return TRUE;
            }
    case 0x2A : return FALSE;
    case 0x40 : ClipPTop;
            return TRUE;
    case 0x41 : ClipPTop;
            if ( px < XLeft ) {
              return FALSE;
            } else {
              ClipQLeft;
              if ( qy < YTop ) {
                ClipQTop;
              }
              return TRUE;
            }
    case 0x42 : ClipPTop;
            if ( px > XRight ) {
              return FALSE;
            } else {
              ClipQRight;
              return TRUE;
            }
    case 0x44 : return FALSE;
    case 0x45 : return FALSE;
    case 0x46 : return FALSE;
    case 0x48 : ClipPTop;
            ClipQBottom;
            return TRUE;
    case 0x49 : ClipPTop;
            if ( px < XLeft ) {
              return FALSE;
            } else {
              ClipQLeft;
              if ( qy > YBottom ) {
                ClipQBottom;
              }
              return TRUE;
            }
    case 0x4A : ClipPTop;
            if ( px > XRight ) {
              return FALSE;
            } else {
              ClipQRight;
              if ( qy > YBottom ) {
                ClipQBottom;
              }
              return TRUE;
            }
    case 0x50 : ClipPLeft;
            if ( py < YTop ) {
              ClipPTop;
            }
            return TRUE;
    case 0x51 : return FALSE;
    case 0x52 : ClipQRight;
            if ( qy < YTop ) {
              return FALSE;
            } else {
              ClipPTop;
              if ( px < XLeft ) {
                ClipPLeft;
              }
              return TRUE;
            }
    case 0x54 : return FALSE;
    case 0x55 : return FALSE;
    case 0x56 : return FALSE;
    case 0x58 : ClipQBottom;
            if ( qx < XLeft ) {
              return FALSE;
            } else {
              ClipPTop;
              if ( px < XLeft ) {
                ClipPLeft;
              }
              return TRUE;
            }
    case 0x59 : return FALSE;
    case 0x5A : ClipPLeft;
            if ( py > YBottom ) {
              return FALSE;
            } else {
              ClipQRight;
              if ( qy < YTop ) {
                return FALSE;
              } else {
                if ( py < YTop ) {
                  ClipPTop;
                }
                if ( qy > YBottom ) {
                  ClipQBottom;
                }
                return TRUE;
              }
            }
    case 0x60 : ClipPRight;
            if ( py < YTop ) {
              ClipPTop;
            }
            return TRUE;
    case 0x61 : ClipQLeft;
            if ( qy < YTop ) {
              return FALSE;
            } else {
              ClipPTop;
              if ( px > XRight ) {
                ClipPRight;
              }
              return TRUE;
            }
    case 0x62 : return FALSE;
    case 0x64 : return FALSE;
    case 0x65 : return FALSE;
    case 0x66 : return FALSE;
    case 0x68 : ClipQBottom;
            if ( qx > XRight ) {
              return FALSE;
            } else {
              ClipPRight;
              if ( py < YTop ) {
                ClipPTop;
              }
              return TRUE;
            }
    case 0x69 : ClipQLeft;
            if ( qy < YTop ) {
              return FALSE;
            } else {
              ClipPRight;
              if ( py > YBottom ) {
                return FALSE;
              } else {
                if ( qy > YBottom ) {
                  ClipQBottom;
                }
                if ( py < YTop ) {
                  ClipPTop;
                }
                return TRUE;
              }
            }
    case 0x6A : return FALSE;
    case 0x80 : ClipPBottom;
            return TRUE;
    case 0x81 : ClipPBottom;
            if ( px < XLeft ) {
              return FALSE;
            } else {
              ClipQLeft;
              return TRUE;
            }
    case 0x82 : ClipPBottom;
            if ( px > XRight ) {
              return FALSE;
            } else {
              ClipQRight;
              return TRUE;
            }
    case 0x84 : ClipPBottom;
            ClipQTop;
            return TRUE;
    case 0x85 : ClipPBottom;
            if ( px < XLeft ) {
              return FALSE;
            } else {
              ClipQLeft;
              if ( qy < YTop ) {
                ClipQTop;
              }
              return TRUE;
            }
    case 0x86 : ClipPBottom;
            if ( px > XRight ) {
              return FALSE;
            } else {
              ClipQRight;
              if ( qy < YTop ) {
                ClipQTop;
              }
              return TRUE;
            }
    case 0x88 : return FALSE;
    case 0x89 : return FALSE;
    case 0x8A : return FALSE;
    case 0x90 : ClipPLeft;
            if ( py > YBottom ) {
              ClipPBottom;
            }
            return TRUE;
    case 0x91 : return FALSE;
    case 0x92 : ClipQRight;
            if ( qy > YBottom ) {
              return FALSE;
            } else {
              ClipPBottom;
              if ( px < XLeft ) {
                ClipPLeft;
              }
              return TRUE;
            }
    case 0x94 : ClipQTop;
            if ( qx < XLeft ) {
              return FALSE;
            } else {
              ClipPLeft;
              if ( py > YBottom ) {
                ClipPBottom;
              }
              return TRUE;
            }
    case 0x95 : return FALSE;
    case 0x96 : ClipPLeft;
            if ( py < YTop ) {
              return FALSE;
            } else {
              ClipQRight;
              if ( qy > YBottom ) {
                return FALSE;
              } else {
                if ( py > YBottom ) {
                  ClipPBottom;
                }
                if ( qy < YTop ) {
                  ClipQTop;
                }
                return TRUE;
              }
            }
    case 0x98 : return FALSE;
    case 0x99 : return FALSE;
    case 0x9A : return FALSE;
    case 0x0A0 : ClipPRight;
             if ( py > YBottom ) {
               ClipPBottom;
             }
             return TRUE;
    case 0x0A1 : ClipQLeft;
             if ( qy > YBottom ) {
               return FALSE;
             } else {
               ClipPBottom;
               if ( px > XRight ) {
                 ClipPRight;
               }
               return TRUE;
             }
    case 0x0A2 : return FALSE;
    case 0x0A4 : ClipQTop;
             if ( qx > XRight ) {
               return FALSE;
             } else {
               ClipPRight;
               if ( py > YBottom ) {
                 ClipPBottom;
               }
               return TRUE;
             }
    case 0x0A5 : ClipQLeft;
             if ( qy > YBottom ) {
               return FALSE;
             } else {
               ClipPRight;
               if ( py < YTop ) {
                 return FALSE;
               } else {
                 if ( qy < YTop ) {
                   ClipQTop;
                 }
                 if ( py > YBottom ) {
                   ClipPBottom;
                 }
                 return TRUE;
               }
             }
    case 0x0A6 : return FALSE;
    case 0x0A8 : return FALSE;
    case 0x0A9 : return FALSE;
    case 0x0AA : return FALSE;
    default    : return FALSE;
  }
}


void SetClipRect (int x0, int y0, int x1, int y1)
{
  XLeft   = x0;
  XRight  = x1;
  YTop    = y0;
  YBottom = y1;
}

extern void SimpleLine( int x00, int y00, int x10, int y10, int v );


void LineDrawClipped (int x0, int y0, int x1, int y1, long c)
{
  if ( clip2d(x0, y0, x1, y1) ) SimpleLine (x0, y0, x1, y1, c);
}
