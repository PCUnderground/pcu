////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground - Light Logo              //
//                                                        //
//  (w)(c)�99 Carsten Dachsbacher                         //
//                                                        //
////////////////////////////////////////////////////////////

#include "demo.h"

#define RAYS 1500

//#define FLASH

#define LOGOOBEN	96
#define LOGOUNTEN	141

typedef struct
{
	float x, y, z;
}VERTEX3D;

// Die Richtungsvektoren
VERTEX3D ray[ RAYS ];
int		 raycolor[ RAYS ];

// Position der Lichtquelle in 2D und 3D
VERTEX3D light;
VERTEX3D light2d;

// Listen, in denen die Linien gespeichert sind
float	 BackLines[ RAYS ][ 2 ];
int		 nBackLines, nFrontLines;
float	 FrontLines[ 2*RAYS ][ 2 ];
int		 BackColor[ RAYS ];
int		 FrontColor[ RAYS ];

#ifdef FLASH
int		 flash;
#endif

bitmaptype logobmp;

unsigned short *screen;		// 16 Bit Bildschirm
unsigned int   *screen32;	// 32 Bit Bildschirm
unsigned char  *logo;		// Zeiger auf das Logo

// Strahlengenerierung
void InitRays()
{
	for ( int i = 0; i < RAYS; i++ )
	{
		float x, y, z;

		// Zuf�llige Richtung
		x = (float)( rand() - 16384 );
		y = (float)( rand() - 16384 );
		z = (float)( rand() - 16384 );

		float l = x * x + y * y + z * z;
		
		l = (float)sqrt( l * 16 );
		l -= rand();
		l -= rand();
		if ( l < 10000 ) l = 10000;

		ray[ i ].x = x / l;
		ray[ i ].y = y / l;
		ray[ i ].z = z / l;

		// Farbe
		int rr, rg, rb;
		rr = rand() % 16 - 8;
		rg = rand() % 16 - 8;
		rb = rand() % 16 - 8;

		int red   = (int)( rr + 24 + ray[ i ].x * 16.0f );
		int green = (int)( rg + 24 + ray[ i ].y * 16.0f );
		int blue  = (int)( rb + 24 + ray[ i ].z * 16.0f );

		if ( red   < 0 ) red   = 0;
		if ( green < 0 ) green = 0;
		if ( blue  < 0 ) blue  = 0;

		raycolor[ i ] = ( red << 16 ) | ( green << 8 ) | blue;

		// Skalierung der L�nge der Strahlen
		ray[ i ].x *= 340.0f;
		ray[ i ].y *= 340.0f;
		ray[ i ].z *= 340.0f;
	}

}


// 64Bit Farbwerte f�r die Shadebobs
__int64 left;
__int64 right;
__int64 highv;

// Zeichnen einen Shadebob an der Stelle (x/y)
// x und y in Fixpointkoordinaten
inline void DrawAdd( int x, int y )
{
	__asm
	{
		mov		eax, [ y ]
		mov		edx, [ x ]
		mov		edi, [ screen32 ]
		shr		eax, 16
		shr		edx, 16
		// spezieller Code f�r y * 320
		mov		ecx, eax
		shl		eax, 8
		shl		ecx, 6
		add		eax, ecx
		//		Allgemein SCREEN_X * y
		//		mov		ecx, [ SCREEN_X ]
		//		imul	ecx
		add		eax, edx
		shl		eax, 2
		add		edi, eax

		movq	mm1, [ left ]
		movq	mm0, [ right ]
		movq	mm2, [ highv ]

		movq	mm3, [ edi ]
		paddusb	mm3, mm0
		movq	mm4, [ edi+8 ]
		paddusb	mm4, mm1
		movq	[ edi ], mm3
		movq	[ edi+8 ], mm4

		add		edi, SCREEN_X * 4

		movq	mm3, [ edi ]
		paddusb	mm3, mm0
		movq	mm4, [ edi+8 ]
		paddusb	mm4, mm1
		movq	[ edi ], mm3
		movq	[ edi+8 ], mm4
	}
}


void SimpleLine( int x0, int y0, int x1, int y1, int v )
{
	// Farbwerte f�r MMX DrawAdd
	int low = (v & 0xfefefe)>>1; // leicht abgedunkelter Farbwert
	// Werte f�r Shadebob mit dunkleren R�ndern
	left = ((__int64)low << 32) | (__int64)v;
	right = ((__int64)v << 32) | (__int64)low;
	highv = ( (__int64)v << 32 ) | (__int64)v;
	
	// Linienkoordinaten
	int x = x0 << 16;
	int y = y0 << 16;
	int xx = x1 << 16;

	int ddx = ( x1 - x0 ) << 16;
	int ddy = ( y1 - y0 ) << 16;

	int l = max( abs( x1 - x0 ), abs( y1 - y0 ) );

	if ( l == 0 ) return;

	ddx /= l;
	ddy /= l;

	// C - Code
/*	while ( l > 0 )
	{
		l --;

		DrawAdd( x, y );

		x += ddx;
		y += ddy;
	}*/
	// Schnellere Assemblervariante
	__asm
	{
		mov		ecx, [ l ]			; L�nge

		mov		edx, [ x ]			; X - Startkoordinate
		mov		eax, [ y ]			; Y - Startkoordinate

		mov		ebx, [ ddx ]		; X - Inkrement
		mov		esi, [ ddy ]		; Y - Inkrement

		movq	mm1, [ left ]		; Farbwerte
		movq	mm0, [ right ]
		movq	mm2, [ highv ]

	more_pixels:


			push	eax
			push	ecx
			push	edx

			; Shadebob zeichnen, wie in DrawAdd(...)
			mov		edi, [ screen32 ]
			shr		eax, 16
			shr		edx, 16
			// y * 320
			mov		ecx, eax
			shl		eax, 8
			shl		ecx, 6
			add		eax, ecx
			//		Allgemein SCREEN_X * y
			//		mov		ecx, [ SCREEN_X ]
			//		imul	ecx
			add		eax, edx
			shl		eax, 2
			add		edi, eax

			movq	mm3, [ edi ]
			paddusb	mm3, mm0
			movq	mm4, [ edi+8 ]
			paddusb	mm4, mm1
			movq	[ edi ], mm3
			movq	[ edi+8 ], mm4

			add		edi, SCREEN_X * 4

			movq	mm3, [ edi ]
			paddusb	mm3, mm0
			movq	mm4, [ edi+8 ]
			paddusb	mm4, mm1
			movq	[ edi ], mm3
			movq	[ edi+8 ], mm4

			pop		edx
			pop		ecx
			pop		eax

			; Koordinaten aktualisieren
			add		edx, [ ddx ]
			add		eax, [ ddy ]

		dec		ecx
		jnz		more_pixels
	}

	__asm
	{
		// MMX Register freigeben/aufr�umen
		emms
	}

}

extern void SetClipRect (int x0, int y0, int x1, int y1);

BOOL demoinit (void)
{
	Fenster_Modus = FENSTER;

	screen = (unsigned short *)malloc( SCREEN_X * SCREEN_Y * sizeof( short ) );
	screen32 = (unsigned int *)malloc( SCREEN_X * SCREEN_Y * sizeof( int ) );
	logo   = (unsigned char *)malloc( SCREEN_X * SCREEN_Y * sizeof( char ) );

	if ( bmp_load( "pcu320.bmp", logobmp ) != BMP_NOERROR ) return 0;

	logo = logobmp.cBitmap;

	InitRays();
	SetClipRect ( 0, 0, SCREEN_X - 4, SCREEN_Y - 4 );

	return TRUE;
}

inline void ProjectVertex( const VERTEX3D &v3, VERTEX3D &v2 )
{
	v2.z = 1000.0f / ( v3.z + 1000.0f );
	v2.x = v3.x * v2.z + SCREEN_X/2;
	v2.y = v3.y * v2.z + SCREEN_Y/2; 
}

extern void LineDrawClipped (int x0, int y0, int x1, int y1, long c);

void DrawLight( const VERTEX3D &rotate )
{
	// Listen "leeren"
	nBackLines = nFrontLines = 0;

	ProjectVertex( light, light2d );
	int	light2dx = (int)light2d.x;
	int	light2dy = (int)light2d.y;

	// Rotationsmatrix f�r Strahlendrehung berechnen
	float matrix[ 9 ];

	float sy = (float)sin( rotate.y );
	float sx = (float)sin( rotate.x );
	float sz = (float)sin( rotate.z );
	float cy = (float)cos( rotate.y );
	float cx = (float)cos( rotate.x );
	float cz = (float)cos( rotate.z );

	matrix[ 0 + 3 * 0 ] = cx * cy + -sx * -sz * -sy;
	matrix[ 1 + 3 * 0 ] = -sx * cz;
	matrix[ 2 + 3 * 0 ] = cx * sy + -sx * -sz * cy;
	matrix[ 0 + 3 * 1 ] = sx * cy + cx * -sz * -sy;
	matrix[ 1 + 3 * 1 ] = cx * cz;
	matrix[ 2 + 3 * 1 ] = sx * sy + cx * -sz * cy;
	matrix[ 0 + 3 * 2 ] = cz * -sy;
	matrix[ 1 + 3 * 2 ] = sz;
	matrix[ 2 + 3 * 2 ] = cz * cy;

	for ( int i = 0; i < RAYS; i++ )
	{
		VERTEX3D t;

		// gedrehten Strahl berechnen und verwenden
		t.x = ray[ i ].x * matrix[ 0 + 3 * 0 ] +
			  ray[ i ].y * matrix[ 1 + 3 * 0 ] +
			  ray[ i ].z * matrix[ 2 + 3 * 0 ];
		t.y = ray[ i ].x * matrix[ 0 + 3 * 1 ] +
			  ray[ i ].y * matrix[ 1 + 3 * 1 ] +
			  ray[ i ].z * matrix[ 2 + 3 * 1 ];
		t.z = ray[ i ].x * matrix[ 0 + 3 * 2 ] +
			  ray[ i ].y * matrix[ 1 + 3 * 2 ] +
			  ray[ i ].z * matrix[ 2 + 3 * 2 ];

		float l = t.x * t.x + t.y*t.y +t.z*t.z;

		// Schnittpunkt mit Logoebene ( z = 0 ):

		VERTEX3D	logovertex;

		float f = - light.z / t.z;
		float l2 = f * f * l;
		if ( l2 < l && f > 0 )
		{
			logovertex.x = light.x + f * t.x;
			logovertex.z = 0;
			logovertex.y = light.y + f * t.y;
		} else
		{
			logovertex.x = light.x + t.x;
			logovertex.y = light.y + t.y;
			logovertex.z = light.z + t.z;
		}

		// Logokoordinaten
		int ix = SCREEN_X/2+1+(int)logovertex.x;
		int iy = SCREEN_Y/2+1+(int)logovertex.y;

		// Linie hinter dem Logo
		VERTEX3D	t3;
		ProjectVertex( logovertex, t3 );
		BackLines[ nBackLines ][ 0 ] = t3.x;
		BackLines[ nBackLines ][ 1 ] = t3.y;
		BackColor[ nBackLines ] = raycolor[ i ];
		nBackLines ++;

		// Linie vor dem Logo ?
		if ( ( (ix >= 0) && (ix <= SCREEN_X) && (iy >= LOGOOBEN) && (iy <= LOGOUNTEN) ) &&
			 ( logo[ ix + iy * SCREEN_X ] == 0 ) )
		{
			VERTEX3D t2;

			t.x += light.x;
			t.y += light.y;
			t.z += light.z;
			ProjectVertex( t, t2 );

			FrontLines[ nFrontLines ][ 0 ] = t2.x;
			FrontLines[ nFrontLines ][ 1 ] = t2.y;
			FrontLines[ nFrontLines+1 ][ 0 ] = t3.x;
			FrontLines[ nFrontLines+1 ][ 1 ] = t3.y;
			FrontColor[ nFrontLines>>1 ] = raycolor[ i ];
			nFrontLines += 2;
		}
	}

#ifdef FLASH
	// Lichtblend-Effekt ?
	flash = 0;
	if ( ( (light2dx >= 4) && (light2dx <= (SCREEN_X-4)) && (light2dy >= LOGOOBEN) && (light2dy <= LOGOUNTEN) ) )
	{
		int o = light2dx + light2dy * SCREEN_X;

		o -= SCREEN_X * 4 - 4;

		for ( int j = 0; j < 8; j++ )
		{
			for ( int i = 0; i < 8; i++ )
			{
				if ( logo[ o ] == 0 ) flash ++;
				o ++;
			}
			o += SCREEN_X - i;
		}
	}
#endif

	// Zeichnen des Bildes

	// Hintere Linien
	for ( i = 0; i < nBackLines; i++ )
	{
		LineDrawClipped( light2dx, light2dy, (int)BackLines[ i ][ 0 ], (int)BackLines[ i ][ 1 ], BackColor[ i ] );
	}

	// Logo
	int o = LOGOOBEN * SCREEN_X;
	for ( int j = LOGOOBEN; j < LOGOUNTEN; j++ )
		for ( i = 0; i < SCREEN_X; i++ )
		{
			int x = logo[ o ];
			if ( x )
			{
				screen32[ o ] = x | ( x << 8 ) | ( x << 16 );
			}
			o++;
		}

	// vordere Linien
	for ( i = 0; i < nFrontLines; i+=2 )
	{
		LineDrawClipped( (int)FrontLines[ i+1 ][ 0 ], (int)FrontLines[ i+1 ][ 1 ], 
			             (int)FrontLines[ i ][ 0 ], (int)FrontLines[ i ][ 1 ], 
						 FrontColor[ i >> 1 ] );
	}
}

extern HWND DemoHWND;

void demomain (void)
{
	int frame = 0;

	while ( ( DemoRunning ) && (!KeyStatus[ VK_ESCAPE ] ) )
	{
		float time = GetDemoTime() / 3000.0f;

		// Lichtquellenposition und -drehung
		VERTEX3D rotate;
		rotate.x = time / 1.7f;
		rotate.y = time / 2.0f;
		rotate.z = time / 3.0f;
		light.x = (float)( (int)GetDemoTime() % 46000 );
		light.x /= 100.0f;
		light.x -= 230.0f;
		light.y = -10;
		light.z = 3;

		// Bild zeichnen
		DrawLight( rotate );

#ifdef FLASH
		// Blenden
		__int64	flashlight;

		int temp = (int)((float)flash * 255.0f / 64.0f );

		flashlight = (temp << 16) | ( temp << 8 ) | temp;
		flashlight |= flashlight << 32;
#endif

		// 32 nach 16 Bit Konvertierung
		const __int64 MASK   = (__int64)0x00fefefe00fefefe;
		const __int64 BLUES  = (__int64)0x000000f8000000f8;
		const __int64 GREENS = (__int64)0x0000fc000000fc00;
		const __int64 REDS   = (__int64)0x00f8000000f80000;
		const __int64 ZERO   = 0;

		__asm
		{
			movq	mm7, ZERO
			mov		esi, [ screen32 ]
			mov		edi, [ screen ]
			mov		ecx, SCREEN_X * SCREEN_Y / 2
		pixloop:
			movq    mm0, [esi]              ;zwei 32 Bit Farbwerte lesen
#ifdef FLASH
			paddusb	mm0, [ flashlight ]
#endif
			movq    mm1, mm0                ;Werte nochmal aufheben
			pand    mm0, BLUES              ;alles bis auf Blauwerte ausmaskieren
			psrld   mm0, 4                  ;Blauwerte shiften
			movq    mm2, mm1                ;Werte nochmal aufheben
			pand    mm1, GREENS             ;alles bis auf Gr�nwerte ausmaslieren
			psrld   mm1, 5+1                ;Gr�nbits shiften
			por     mm0, mm1                ;Gr�n- und Blauwert mit Oder Verkn�pfen
			pand    mm2, REDS               ;alles bis auf Rotwerte ausmaskieren
			psrld   mm2, 8+1                ;auch diese shiften
			por     mm0, mm2                ;und mit Oder zu den anderen hinzuf�gen
											;mm0 enth�lt jetzt 2 16-bit Farbwerte in den
											;Lowwords der beiden DWORDs
			packssdw mm0, mm7               ;diese zwei 16-bit Werte in das untere DWORD bringen
			paddd	mm0, mm0
		
			movd [ edi ], mm0				; 16 Bit Wert schreiben
			movq [ esi ], mm7				; und gleich 32Bit-Bild-Pixel l�schen

			add esi, 8
			add edi, 4

			dec ecx
			jnz pixloop

			emms

		}

		BlitGraphic( screen );
	}
}	


void demoquit (void)
{
	free( screen );
	free( screen32 );
	bmp_free( logobmp );
}

