#include "demo.h"
#include "soundsys.h"

static SoundSystem * SoundSys = 0;
static int           Sound1;

BOOL demoinit (void)
{
  // Fenstermode setzen. Das war's auch schon mit der Initialisierung...
  Fenster_Modus = DDVOLLBILD;
  return TRUE;
}


void demomain (void)
{
  // -------------------------------------------------------------
  // ein - zugegeben - sehr einfacher Grafik-Effekt. Nicht 
  // h�bsch aber zum Testen der Keyboard-Input Funktion reicht es.
  // -------------------------------------------------------------

  // Sound-System initialisieren. Dies k�nnen Sie erst hier machen,
  // da in demoinit noch kein g�ltiger Windowhandle vorhanden ist.
  SoundSys  = new SoundSystem;

  if (SoundSys->initialize (DemoHWND))
  {
    // einen Sample laden
    Sound1 = SoundSys->LoadSound ("pop.wav", 10);
  } else return;



  short * screen  = new short[SCREEN_X * SCREEN_Y];
  short * palette = new short[256];

  while ((DemoRunning) && (!KeyStatus[VK_ESCAPE]))
  {

    long ticks = GetDemoTime();

    // die Tasten R, G und B beeinflussen die
    // F�rbung der Palette:
    int r = KeyStatus['R']? 0:1;
    int g = KeyStatus['G']? 0:1;
    int b = KeyStatus['B']? 0:1;

    // eine bunte Palette generieren
    for (int i=0; i<256; i++)
      palette[i] = ColorCode (i*r,(i*2-128)*g,(255-i)*b);


    // Und space spielt einen Plop-Sound
    if (KeyStatus[' ']) SoundSys->PlaySound (Sound1);

    // Grafik-Effekt zeichnen:
    short * s = screen;
    for (int y=0; y<SCREEN_Y; y++)
    {

      // Vertikale Sinus-Balken berechnen:
      float sin1 = (float)( sin((ticks/5.0+y)/400.0) );
      float sin2 = (float)( sin((ticks/4.0-y)/32.0)+sin((ticks/3.0+y)/32.0) );
      long sinusx = (long)( (SCREEN_X/2) + (SCREEN_X/5)*(sin1*sin2) );

      // Linken Teil der Zeile zeichen
      long delta = (255<<16)/sinusx;
      long start = 0;
      for (int x=0; x<sinusx; x++)
      {
        *s++ = palette[start>>16];
        start += delta;
      }

      // rechten Teil der Zeile zeichnen:
      delta = (255<<16)/(SCREEN_X-sinusx);
      start = 255<<16;
      for (x=sinusx; x<SCREEN_X; x++)
      {
        *s++ = palette[start>>16];
        start -= delta;
      }
    }
    // grafik darstellen:
    BlitGraphic (screen);
  }
  delete screen;
  delete palette;
}


void demoquit (void)
{
  if (SoundSys) delete SoundSys;   
}

