#define  WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "soundsys.h"


static SoundSystem * ss;
static int SoundHandle1;
static int SoundHandle2;


static BOOL CALLBACK DialogProc (HWND hwndDlg,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
    wParam = wParam;
    lParam = lParam;

    switch (uMsg)
    {
        case WM_INITDIALOG:
        {
            // --------------------------
            // SoundSystem Initialisieren
            // --------------------------
            if (!ss->initialize (hwndDlg))
            {
                MessageBox (0, "Error initializing DirectSound", "Error", 0);
                EndDialog (hwndDlg, -1);
                return TRUE;
            } else {
                // ----------------------------------------------
                // Samples laden, max 5 davon gleichzeitig h�rbar
                // ----------------------------------------------
                SoundHandle1 = ss->LoadSound ("pop.wav", 5);
                SoundHandle2 = ss->LoadSound ("thunder.wav",  5);
           }
        } break;

        case WM_COMMAND:
        {
            switch (LOWORD(wParam))
            {
                case IDCANCEL:
                case IDOK:
                {
                    // OK und Cancel Button schliessen den Dialog
                    EndDialog (hwndDlg, LOWORD(wParam));
                    return TRUE;
                }


                // Button 1 fuer Sample 1
                case 100: ss->PlaySound (SoundHandle1);
                break;

                // Button 2 fuer Sample 2
                case 101: ss->PlaySound (SoundHandle2);
                break;

            }
        } break;
    }
    return FALSE;
}



int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInst, LPSTR lpCmdLine, int nCmdShow)
///////////////////////////////////////////////////////////////////////////////////////////
{
    // Unwichtige zuweisungen. Sie sollen nur Fehlermeldungen des
    // Compilers verhindern
    hPrevInst = hPrevInst;
    lpCmdLine = lpCmdLine;
    nCmdShow  = nCmdShow;

    // Soundsystem Initialisieren
    ss = new SoundSystem;

    // Dialog Fenster zeigen.
    DialogBox (hInstance, "DSTESTDLG", 0, (DLGPROC) DialogProc);

    // Soundsystem De-Initialisieren
    delete ss;
    return 0;
}




