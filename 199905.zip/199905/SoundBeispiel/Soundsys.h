#ifndef __SOUNDSYSTEM_H
#define __SOUNDSYSTEM_H

#define  WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <mmsystem.h>
#include <dsound.h>


class SoundSystem;

class SoundEffect
{
    protected:
      SoundSystem        * MeinSystem;
      IDirectSoundBuffer * Buffer;
      SoundEffect        * next;
      SoundEffect        ();

    public:
      friend class SoundSystem;
      ~SoundEffect      ();
      void Play         (int freq=0, int vol=0, int pan=0, BOOL loop=FALSE);
      void Stop         (void);
      void SetFrequency (int freq);
      void SetVolume    (int volume);
      void SetPan       (int pan);
};


class SoundSystem
{
    protected:

        struct Sound
        {
            int                   MaxBuffers;
            int                   SoundId;
            IDirectSoundBuffer ** BufferListe;
            int                 * BufferFree;
            Sound               * next;
        };

        Sound          *SoundListe;
        int             SoundCount;
        IDirectSound   *DSound;

        BOOL FindFreeBuffer (int id, Sound * &s, int &i);

    public:
  
        SoundSystem     ();
        ~SoundSystem    ();
        BOOL initialize (HWND ParentWindow);

        // Die einfache Sound-Api
        int  LoadSound  (char *filename, int maxUsage); 
        BOOL PlaySound  (int id, int freq=0, int vol=0, int pan=0);

        // Die Sound-Api f�r Fortgeschrittene
        SoundEffect *   GetEffect     (int id);
        void            ReleaseEffect (SoundEffect *fx);
};



#endif
