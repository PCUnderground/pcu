///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - Demo Projekt                            //
//                                                       //
//  Beispielprogramm zur Berechnung der Sounds           //
//                                                       //
//  Carsten Dachsbacher �99                              //
//                                                       //
///////////////////////////////////////////////////////////

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "synth.h"

extern int			solo;
extern int			enabled[];
extern int			sample_length;
extern short int	*wave16bit;

void FILE_load( char *name )
{
	// Hier wird ein FSS File geladen
	FILE *f = fopen( name, "rb" );
	if ( f != NULL )
	{
		// Dateikennung �berpr�fen
		char head[ 3 ];
		fread( head, 3, 1, f );
		if ( ( head[ 0 ] != 'F' ) || ( head[ 1 ] != 'S' ) || ( head[ 2 ] != 'S' ) )
		{
			exit( 1 );
		}

		// Daten lesen
		signed char t;
		fread( &t, 1, 1, f );
		solo = t;

		for ( int i = 0; i < MAXOP; i ++ )
		{
			fread( &t, 1, 1, f );
			enabled[ i ] = t;
		}

		fread( &op, sizeof( op ), 1, f );
		fclose( f );
	}
}


void FILE_writewave( char *name )
{
	// Sample berechnen
	calculate_sample();

	unsigned long header[ 11 ];

	// Der Einfachheithalber ein vorgefertigten Waveheader laden
	char name2[ 256 ];
	strcpy( name2, "stub2.wav" );

	FILE *stub = fopen( name2, "rb" );
	fread( header, 4, 11, stub );
	fclose( stub );

	// Samplel�nge eintragen
	header[ 10 ] = sample_length * 2;
	
	// und mit Raw-Daten speichern
	FILE *raw = fopen( name, "wb" );

	fwrite( header, 4, 11, raw );

	for ( int i = 0; i < sample_length; i++ )
	{
		signed short c = ( wave16bit[ i ] );
		fwrite( &c, 2, 1, raw );
	}		

	fclose( raw );
}

void main()
{
	printf( "Lade FSS Soundfile ...\n" );
	FILE_load( "test.fss" );
	printf( "Berechne Wavefile ...\n" );
	FILE_writewave( "test.wav" );
	printf( "Beendet.\n" );
}