///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - Demo Projekt                            //
//                                                       //
//  Programm zur Klangsynthese mit Hilfe der in          //
//  PC Underground beschriebenen Algorithmen             //
//                                                       //
//  Carsten Dachsbacher �99                              //
//                                                       //
///////////////////////////////////////////////////////////

#include "synth.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

// Die Operator Daten
OPERATOR	op[ MAXOP ];
int			solo = -1;
int			enabled[ MAXOP ];
int			numop = 1;
int			aktop = 0;

float sample_frequenz = 44100;

// Daten zur Sampleberechnung
signed short *wave16bit = NULL;
float *wavedata = NULL;
int sample_length = 0;
extern char datapath[ 2068 ];

// Filter - Methoden
void filter_write( FILTER &f, double s )
{
	f.sample = s;
	f.low += f.cutoff * f.band;
	f.high = s - ( 1.0 - f.resonanz ) * f.band - f.low;
	f.band += f.cutoff * f.high;
}

double filter_read( FILTER &f )
{
	switch ( f.mode )
	{
	case 0: return f.sample;	break;
	case 1: return f.low;		break;
	case 2: return f.band;		break;
	case 3: return f.high;		break;
	default: return 0;			break;
	}
}

float	maxtime = 0;
float	time = 0;

int calculate_sample()
{
	for ( int oo = 0; oo < MAXOP; oo++ )
	{
		op[ oo ].time = 0;
		op[ oo ].pos = 0;
		op[ oo ].rcount = 0;
	}

	srand( 5 );
	maxtime = 0;
	time	= 0;

	int start = 0, ende = MAXOP;
	if ( solo != -1 )
	{
		start = ende = solo;
		ende ++;
	}

	// maximale Operatorzeit und entsprechende Sample-L�nge
	for ( int o = start; o < ende; o++ )
		if ( enabled[ o ] )
			maxtime = __max( maxtime, op[ o ].ende_zeit);

	sample_length = (int)( sample_frequenz * maxtime / 1000.0f );

	wavedata = (float*)malloc( sizeof( float ) * sample_length );
	if ( wave16bit != NULL ) free( wave16bit );
	wave16bit = (signed short*)malloc( sizeof( signed short ) * sample_length );
	float *random = (float *)malloc( 512 * sizeof( float ) );

	float out, rtime = 0;
	float mtime = 0, tempout;

	// Zufallswerte f�r Rauschen
	for ( int j = 0; j < 512; j++ )
		random[ j ] = rand() / 16384.0f - 1.0f;


	int i = 0;
	while ( (i < sample_length) )
	{
		// Zeit in ms
		mtime = (float)i * 1000.0f / sample_frequenz;
		
		out = 0;

		// Alle angeschalteten Oszillatoren/Filter
		for ( int o = start; o < ende; o++ )
		if ( enabled[ o ] )
		{
			// Ist der Operator zur aktuellen Zeit angeschalten ?
			if ( ( mtime < op[ o ].start_zeit ) ||
				 ( mtime > op[ o ].ende_zeit ) )
				 goto skip;

			// Relative Zeit innerhalb des Operators
			rtime = op[ o ].time;
			if ( rtime > 1.0 ) rtime = 1;

			if ( op[ o ].type == 0 )
			{
				// Oszillator

				// aktuelle Frequenz und Amplitude
				float freq = (float)( op[ o ].start_frequenz + ( op[ o ].ende_frequenz - op[ o ].start_frequenz ) * pow( rtime, op[ o ].curve_frequenz ) );
				float amp  = (float)( op[ o ].start_amplitude + ( op[ o ].ende_amplitude - op[ o ].start_amplitude ) * pow( rtime, op[ o ].curve_amplitude ) );
				if ( amp > 1.0 ) amp = 1.0;
				if ( amp < 0 ) amp = 0;

				// Phase �ndern
 				op[ o ].pos += (float)( 2.0f * freq / ( sample_frequenz * 2.0 ) * 2.0 * 3.1415 * 1.0 );

				// Rauschen ? Wenn ja, dann Phase weiter �ndern
				float distort = random[ (int)op[ o ].rcount ] * op[ o ].noise * 3;
				op[ o ].pos += (float)( distort * freq / ( sample_frequenz * 2.0 ) * 2.0 * 3.1415 * 1.0 );
				op[ o ].rcount += 0.15f;
				if ( op[ o ].rcount > 512 ) op[ o ].rcount = 0;

				// Ausgangsspannung des Oszillators je nach Typ bestimmen
				float t;
				switch ( op[ o ].wave )
				{
					case SINUS:
						t = (float)sin( op[ o ].pos );
						tempout = (float)( pow( fabs( t ), op[ o ].curve_tone ) * amp );
						break;
					case SAW:
						while ( op[ o ].pos > 2.0f * 3.14f ) op[ o ].pos -= 2.0f * 3.14f;
						t = op[ o ].pos / ( 3.14f ) - 1.0f;
						tempout = (float)( pow( fabs( t ), op[ o ].curve_tone ) * amp );
						break;
					case SQUARE:
						while ( op[ o ].pos > 2.0f * 3.14f ) op[ o ].pos -= 2.0f * 3.14f;
						if ( op[ o ].pos <= 3.14f ) t = -1; else t = 1;
						tempout = (float)( pow( fabs( t ), op[ o ].curve_tone ) * amp );
						break;
				}
				if ( t < 0 ) tempout *= -1;

				// und auf das Gesamtausgangssignal addieren
				out += tempout;
			} else
			if ( op[ o ].type == 1 )
			{
				// Filter

				// Aktuelle Resonanz und Cutoff Frequenz bestimmen
				float ffreq = (float)( op[ o ].start_frequenz + ( op[ o ].ende_frequenz - op[ o ].start_frequenz ) * pow( rtime, op[ o ].curve_frequenz ) );
				float freso = (float)( op[ o ].fstart_resonanz + ( op[ o ].fende_resonanz - op[ o ].fstart_resonanz ) * pow( rtime, op[ o ].fcurve_resonanz ) );
				if ( ffreq < 0 ) ffreq = 0;

				// Filterparameter setzen
				op[ o ].filter.cutoff = 8.0f * ffreq / ( sample_frequenz * 2.0 ) * 1.0;
				op[ o ].filter.resonanz = freso;
				op[ o ].filter.mode = 2;


				// Wert filtern
				filter_write( op[ o ].filter, out / 1.0);
				out = (float)filter_read( op[ o ].filter );
			}

			// Operatorzeit aktualisieren
			op[ o ].time += (float)( 10.0f / ( sample_frequenz * 2.0 ) / (op[ o ].ende_zeit - op[ o ].start_zeit) * 200.0f );
			skip:;
		}
		wavedata[ i++ ] = out;
	}

	// Werte nach short int skalieren
	float wmax = -1e19f, wmin = 1e19f;
	for ( i = 0; i < sample_length; i++ )
	{
		if ( wavedata[ i ] > wmax ) wmax = wavedata[ i ];
		if ( wavedata[ i ] < wmin ) wmin = wavedata[ i ];
	}
	float faktor = (float)( 32767.0f / ( __max( wmax, fabs( wmin ) ) ) );
	for ( i = 0; i < sample_length; i++ )
		wave16bit[ i ] = (short)( ( wavedata[ i ] ) * faktor );  

	free( wavedata );
	free( random );

	return (int)sample_length;
}
