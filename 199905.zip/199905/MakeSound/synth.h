///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - Demo Projekt                            //
//                                                       //
//  Programm zur Klangsynthese mit Hilfe der in          //
//  PC Underground beschriebenen Algorithmen             //
//                                                       //
//  Carsten Dachsbacher �99                              //
//                                                       //
///////////////////////////////////////////////////////////

#ifndef __SYNTH_H
#define __SYNTH_H

#define		MAXOP	32

#define		TOSCILLATOR	0
#define		TFILTER		1

#define		SINUS	0
#define		SAW		1
#define		SQUARE	2


// +/- 6db Bandpass Filter
typedef struct 
{
	double	cutoff,			// CutOff Frequenz
			resonanz,		// Resonanzfrequenz
			low,
			band,
			high,
			sample;
	int		mode;  // 0 durchgang, 1 low, 2 band, 3 high
}FILTER;

typedef struct
{
	int		type;

	float	rcount;
	float	pos;
	float	start_frequenz,
			ende_frequenz;
	float	curve_frequenz;
	float	start_amplitude,
			ende_amplitude;
	float	curve_amplitude;
	float	start_zeit;
	float	ende_zeit;
	float	curve_tone;
	int		wave;
	float	time;

	float	slide_frequenz,
			slide_amplitude; 

	float	fstart_resonanz,
			fende_resonanz;
	float	fcurve_resonanz;

	float	noise;

	FILTER	filter, filter2;
}OPERATOR;

extern	OPERATOR op[ MAXOP ];
extern	int			numop;
extern	int			aktop;

extern	int calculate_sample();
extern	void play_sample();

#endif