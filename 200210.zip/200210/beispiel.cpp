////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  CSG mit Stencil Buffers und Radial Blur               //
//  (w)(c)2002 Carsten Dachsbacher                        //
//  Original CSG/Stencil Code von Tom McReynolds, SGI     //
//                                                        //
////////////////////////////////////////////////////////////

#include	<windows.h>			
#include	<math.h>
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	"texture.h"

PCUTexture *texMetal;

GLUquadric	*sphere, *cube;
GLuint listCube, listSphere;

#define BLURSIZE 256
GLuint radialBlurTexture;

void (*renderFunc)( void (*A)(), void (*B)() );
void (*object1)();
void (*object2)();

int  toggleAnimation = 0;
int  blurMode = 0;

static GLfloat material1a[] = { 0.0f, 0.5f, 0.0f, 1.0f };
static GLfloat material2a[] = { 0.4f, 0.5f, 1.0f, 1.0f };
static GLfloat material1c[] = { 0.6f, 0.3f, 0.0f, 1.0f };
static GLfloat material2c[] = { 0.6f, 0.3f, 0.6f, 1.0f };

GLfloat *material1 = material1a, *material2 = material2a;

#include "keys.h"

void	init3DEngine()
{
	// Allgemeine Renderstates
    glShadeModel( GL_SMOOTH );

	glHint( GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST );

	glDisable( GL_POLYGON_SMOOTH );

	glEnable( GL_DEPTH_TEST );
	glFrontFace( GL_CCW );
	glEnable( GL_CULL_FACE );

	// Lichtquelle zur Beleuchtung der 3D Modelle
	glEnable( GL_LIGHT0 );

	GLfloat light_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat light_diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat light_ambient[] = { 0.0f, 0.0f, 0.0f, 1.0f };

	glLightfv( GL_LIGHT0, GL_AMBIENT, light_ambient );
	glLightfv( GL_LIGHT0, GL_DIFFUSE, light_diffuse );
	glLightfv( GL_LIGHT0, GL_SPECULAR, light_specular );

	glLightf( GL_LIGHT0, GL_SPOT_EXPONENT, 18 );

	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);

	GLfloat specular[]={1.0f,1.0f,1.0f,1.0f};					// Sets Up Specular Lighting

	glEnable( GL_TEXTURE_2D );

	//
	// Radial Blur Texture
	//
	glGenTextures( 1, &radialBlurTexture );
	glBindTexture( GL_TEXTURE_2D, radialBlurTexture );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );


	//
	// Display Lists erstellen
	//
	listCube = glGenLists( 1 );
	glNewList( listCube, GL_COMPILE );
	cube = gluNewQuadric();
	gluQuadricTexture( cube, GL_TRUE );

	glPushMatrix();

	glTranslatef( 0, 0, -12 );

	gluCylinder( cube, 17.0f, 17.0f, 24.0f, 4, 3 );
	
	glPushMatrix();
	glTranslatef( 0.0f, 0.0f, 24.0f );
	gluDisk( cube, 0.0f, 17.0f , 4, 1);
	glPopMatrix();

	glPushMatrix();
	glScalef( -1.0f, 1.0f, -1.0f );
	gluDisk( cube, 0.0f, 17.0f, 4, 1);
	glPopMatrix();

	glPopMatrix();

	gluDeleteQuadric( cube );
	glEndList();


	listSphere = glGenLists( 1 );
	glNewList( listSphere, GL_COMPILE );
	sphere = gluNewQuadric();
	gluQuadricTexture( sphere, GL_TRUE );
 	gluSphere( sphere, 15.0f, 64, 64 );
	gluDeleteQuadric( sphere );
	glEndList();

	texMetal = new PCUTexture();
	texMetal->loadBMP( "./data/texture.bmp" );

	loadKeyTexture();
}

static GLfloat lightPosition[] = { -55.0f, 55.0f, -55.0f, 1.0f };

void drawSphere()
{
  glPushMatrix();

  float time = GetTickCount() * 0.001f;
  if ( toggleAnimation )
	  glTranslatef(
		  (float)sin( time * 1.01212 ) * 5.0f, 
		  (float)cos( time * 1.23412 ) * 7.0f, 
		  (float)sin( time * 1.34612 ) * 9.0f
		  );

  glMaterialfv( GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, material2 );
  glCallList( listSphere );
  glPopMatrix();
}

void drawCube()
{
  glMaterialfv( GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, material1 );

  glCallList( listCube );
}

void	renderSingle( void (*A)() )
{
	glEnable( GL_DEPTH_TEST );
	A();
}

void	renderUnion( void (*A)(), void (*B)() )
{
	glEnable( GL_DEPTH_TEST );
	A();
	B();
}

void	AinsideB( void (*A)(), void (*B)(), GLenum cullFace, GLenum test )
{
	// eine Seite von A in den Z-Buffer schreiben
	glEnable( GL_DEPTH_TEST );
	glColorMask( GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE );
	glCullFace( cullFace );
	A();

	// im Folgenden Z-Buffer Test an, Z-Write aus

	// von A nicht verdeckte Teile der 
	// Vorderseite von B in den Stencil Buffer
	glDepthMask( GL_FALSE );
	glEnable( GL_STENCIL_TEST );
	glStencilFunc( GL_ALWAYS, 0, 0 );
	glStencilOp( GL_KEEP, GL_KEEP, GL_INCR );
	glCullFace( GL_BACK );
	B();

	// sichtbare Teile der R�ckseite wieder aus 
	// Stencil Buffer l�schen
	glStencilOp( GL_KEEP, GL_KEEP, GL_DECR );
	glCullFace( GL_FRONT );
	B();


	glDepthMask( GL_TRUE );
	glColorMask( GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE );

	glDisable( GL_DEPTH_TEST );
	glStencilFunc( test, 0, 1 );

	glCullFace( cullFace );
	A();
}

void	fixZBuffer( void (*A)() )
{
	glColorMask( GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE );
	glEnable( GL_DEPTH_TEST );
	glDisable( GL_STENCIL_TEST );
	glDepthFunc( GL_ALWAYS );
	A();
	glDepthFunc( GL_LESS );
}

void	renderIntersection( void (*A)(), void (*B)() )
{
	AinsideB( A, B, GL_BACK, GL_NOTEQUAL );

	fixZBuffer( B );

	AinsideB( B, A, GL_BACK, GL_NOTEQUAL );

	glDisable( GL_STENCIL_TEST );
}

void	renderSubstraction( void (*A)(), void (*B)() )
{
	AinsideB( A, B, GL_FRONT, GL_NOTEQUAL );

	fixZBuffer( B );

	AinsideB( B, A, GL_BACK, GL_EQUAL );

	glDisable( GL_STENCIL_TEST );
}


void	renderCSG()
{
	texMetal->select();
	glEnable( GL_TEXTURE_2D );

	renderFunc( object1, object2 );
}

void	render2Texture( GLenum format )
{
	// Viewport auf Texturegr��e und l�schen
	glViewport( 0, 0, BLURSIZE, BLURSIZE );

	glClearColor( 0.0f, 0.0f, 0.0f, 0.5f );
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

	renderCSG();

	// Texture kopieren
	glBindTexture( GL_TEXTURE_2D, radialBlurTexture );
	glCopyTexImage2D( GL_TEXTURE_2D, 0, format, 0, 0, BLURSIZE, BLURSIZE, 0 );

	// Viewport wieder restaurieren
	glClearColor( 0.0f, 0.0f, 0.5f, 0.5f );
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

	extern int windowX, windowY;
	glViewport( 0, 0, windowX, windowY );
}

void renderBlur( int n, float delta )
{
	float texZoom = 0.0f;
	float alpha   = 0.15f;

	glDisable( GL_DEPTH_TEST );

	glEnable( GL_BLEND );
	glBlendFunc( GL_SRC_ALPHA, GL_ONE );
	
	glBindTexture( GL_TEXTURE_2D, radialBlurTexture );

	glMatrixMode( GL_PROJECTION );
	glPushMatrix();
	glLoadIdentity();
	
	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();
	glLoadIdentity();

	glDisable( GL_LIGHTING );
	glDisable( GL_CULL_FACE );


	glBegin( GL_QUADS );
	for ( int i = 0; i < n; i++ )
	{
		glColor4f( 1.0f, 1.0f, 1.0f, alpha );

		glTexCoord2f( 0 + texZoom, 1 - texZoom );
		glVertex2f( -1, 1 );

		glTexCoord2f( 0 + texZoom, 0 + texZoom );
		glVertex2f( -1, -1 );

		glTexCoord2f( 1 - texZoom, 0 + texZoom );
		glVertex2f( 1, -1 );

		glTexCoord2f( 1 - texZoom, 1 - texZoom );
		glVertex2f( 1, 1 );

		texZoom += delta;
		alpha -= 0.15f / (float)n;
	}
	glEnd();

	glEnable( GL_LIGHTING );
	glEnable( GL_CULL_FACE );

	glPopMatrix();
	glMatrixMode( GL_PROJECTION );
	glPopMatrix();
	glMatrixMode( GL_MODELVIEW );

	glDisable( GL_BLEND );
	glEnable( GL_DEPTH_TEST );
}


static int first = 1;

void	draw3DEngine()
{

	extern bool keys[ 256 ];

	if ( keys[ '1' ] || first )
	{
		first = 0;
		renderFunc = renderUnion;
		object1 = drawSphere;
		object2 = drawCube;
		keys[ '1' ] = 0;
	} else
	if ( keys[ '2' ] )
	{
		renderFunc = renderSubstraction;
		object1 = drawSphere;
		object2 = drawCube;
		keys[ '2' ] = 0;
	}  else
	if ( keys[ '3' ] )
	{
		renderFunc = renderSubstraction;
		object2 = drawSphere;
		object1 = drawCube;
		keys[ '3' ] = 0;
	}  else
	if ( keys[ '4' ] )
	{
		renderFunc = renderIntersection;
		object1 = drawSphere;
		object2 = drawCube;
		keys[ '4' ] = 0;
	}  else
	if ( keys[ 'A' ] )
	{
		toggleAnimation = 1 - toggleAnimation;
		keys[ 'A' ] = 0;
	}  else
	if ( keys[ 'L' ] )
	{
		if ( blurMode == 1 )
			blurMode = 0; else
			blurMode = 1;
		keys[ 'L' ] = 0;
	}  else
	if ( keys[ 'C' ] )
	{
		if ( blurMode == 2 )
			blurMode = 0; else
			blurMode = 2;
		keys[ 'C' ] = 0;
	}

	switch ( blurMode )
	{
		case 0:
		case 1:
			material1 = material1a;
			material2 = material2a;
			break;
		case 2:
			material1 = material1c;
			material2 = material2c;
			break;
	}

	glClear(GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();

	extern int windowX, windowY;

	gluPerspective( 45.0f, (float)windowX / (float)max( 1, windowY ), 0.1f, 500.0f );

	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();
	glTranslatef( 0, 0, -100 );


	
	glEnable( GL_NORMALIZE );
	glEnable( GL_LIGHTING );
	glDisable( GL_BLEND );

	// "Animation"
	glRotatef( 20, 1, 0, 0 );
	glRotatef( GetTickCount() * 0.02f, 0, 1, 0 );


	if ( blurMode == 2 )
		render2Texture( GL_RGBA ); else
	if ( blurMode == 1 )
		render2Texture( GL_LUMINANCE );


	glMatrixMode( GL_PROJECTION );
	glPushMatrix();
	glLoadIdentity();
	
	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();
	glLoadIdentity();

	glDisable( GL_LIGHTING );
	glDisable( GL_CULL_FACE );
	glDisable( GL_TEXTURE_2D );

	glDepthMask( GL_FALSE );

	glBegin( GL_QUADS );
		glColor3ub( 0, 128, 128 );
		glVertex2f( -1, 1 );

		glColor3ub( 0, 64, 128 );
		glVertex2f( -1, -1 );

		glColor3ub( 0, 64, 64 );
		glVertex2f( 1, -1 );

		glColor3ub( 0, 128, 128 );
		glVertex2f( 1, 1 );
	glEnd();

	glDepthMask( GL_TRUE );

	glEnable( GL_LIGHTING );
	glEnable( GL_CULL_FACE );

	glPopMatrix();
	glMatrixMode( GL_PROJECTION );
	glPopMatrix();
	glMatrixMode( GL_MODELVIEW );

	renderCSG();

	if ( blurMode )
		renderBlur( 50, 0.01f );

	drawKeys();

	glFlush();
}

void	quit3DEngine()
{
}


