// (c)(w)05/20000 Carsten Dachsbacher und Oliver Kaefersttein 

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#pragma warning(disable:4786)
#define  D3D_OVERLOADS
#include <d3dx.h> 
#include <d3d.h>
#include <ddraw.h>

#include "logsystem.h"


#ifdef NDEBUG
 #define RUN_FULLSCREEN 1
#endif

// links
#pragma comment(lib, "d3dx.lib")
#pragma comment(lib, "ddraw.lib")

// Globale Variablen, inkl. D3DX und Matrizen
HWND              _hwnd(0);
LPD3DXCONTEXT     _D3DXContext(0);
LPDIRECT3DDEVICE7 _D3DDevice(0);
LPDIRECT3D7       _D3D7(0);
LPDIRECTDRAW7     _DDraw(0);

// window dimensions
int unsigned      _wndWIDTH(800);
int unsigned      _wndHEIGHT(600);

// window activiation semaphore :)
bool              _appPAUSED( false );  // if our application has lost focus

// textur
LPDIRECTDRAWSURFACE7 _tex;


// input system
#include "./input/inputWRAPPER.h"
#include <dinput.h>
#include "./input/inputWRAPPER_DX7.h"
inputWRAPPER_DX7  directINPUT;
inputWRAPPER* _input = &directINPUT;



// forward declarations
long  _stdcall mainproc(HWND hwnd, UINT message, WPARAM wParm, LPARAM lParm);
BOOL  draw( void );             // zeichenroutine
BOOL  initD3DX( HWND hwnd );    // d3d initialisierung
BOOL  initAPP();                // applikations initialisierung
void  appSHUTDOWN( void );      // application shutdown... alle variablen l�schen

// macros
#define     RELEASENULL(object) if (object) { object->Release(); }


// die zeichen routine
BOOL draw( void ) {

  // exit
  if( _input->_keys[DIK_ESCAPE] )
    return false;

  if( _input->_keys[DIK_W] )
    _input->playEFFECT( "./data/plasmagun.ffe" );
  
  if ( SUCCEEDED(_D3DDevice->BeginScene()) )   {

    _D3DXContext->Clear( D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER );
    

    int x = _input->_x;
    int y = _input->_y;
    D3DXVECTOR4 pos[4] = { D3DXVECTOR4( x, y, 0, 0 ),
                           D3DXVECTOR4( x+32, y, 0, 0 ),
                           D3DXVECTOR4( x+32, y+32, 0, 0 ),
                           D3DXVECTOR4( x, y+32, 0, 0 )
                         };
    D3DXDrawSprite3D( _tex, _D3DDevice, pos, 1.0f, NULL );

    _D3DDevice->EndScene();
  }
  else
    _D3DXContext->RestoreSurfaces();

  HRESULT hr = _D3DXContext->UpdateFrame( D3DX_UPDATE_NOVSYNC );
  return ( hr != DDERR_SURFACELOST || hr != DDERR_SURFACEBUSY );
}


int _stdcall WinMain( HINSTANCE hInst, HINSTANCE hPInst, char* pCmd, int nCmd ) {

  // Fensterklasse
  WNDCLASSEX wc ={0};
  wc.cbSize = sizeof(wc);
  wc.lpfnWndProc = mainproc;
  wc.lpszClassName = "mainwindow";
  wc.hbrBackground = reinterpret_cast<HBRUSH>( GetStockObject(BLACK_BRUSH) );
  wc.hIcon = wc.hIconSm = LoadIcon( 0, IDI_WINLOGO );
  wc.hCursor = reinterpret_cast<HCURSOR>( NULL );
  wc.hInstance = hInst;
  if( !RegisterClassEx(&wc) ) {
    _log( "failed to register window class" );
    return -1;
  }
  
  // fenster erzeugen
#ifdef RUN_FULLSCREEN
  if( !(_hwnd=CreateWindow( wc.lpszClassName, "PC Magazin", WS_POPUP, CW_USEDEFAULT, CW_USEDEFAULT, 1, 1, 0, 0, hInst, 0)) ) {
    _log( "failed to create mainwindow" );
    return -1;
  }
#else
  if( !(_hwnd=CreateWindow( wc.lpszClassName, "PC Magazin", WS_POPUP, CW_USEDEFAULT, CW_USEDEFAULT, _wndWIDTH, _wndHEIGHT, 0, 0, hInst, 0)) ) {
    _log( "failed to create mainwindow" );
    return -1;
  }
#endif
  
  // und anzeigen
  ShowWindow(_hwnd, nCmd);
  UpdateWindow(_hwnd);
  
  if( initD3DX( _hwnd ) == FALSE ) {
    _log( std::endl << "unable to initialize DirectX 7.0 subsystem!" << std::endl << "  exiting!" );
    return -1;
  }

  initAPP();

  // alles initialisert, imputsystem alle 10 millisekunden pollen
  SetTimer( _hwnd, 0, 10, NULL );
  
  // und im Message-Loop auf das Programmende warten
  MSG msg;
  PeekMessage( &msg, NULL, 0U, 0U, PM_NOREMOVE );
  while( WM_QUIT != msg.message  ) {

    if(PeekMessage(&msg, 0, 0, 0, PM_REMOVE)) {

      TranslateMessage(&msg);
      DispatchMessage(&msg);
    }
    else if( !_appPAUSED ) {
      if( !draw() )
        PostQuitMessage(0);
    }
  }
  
  // speicher wieder freigeben
  appSHUTDOWN();
  
  UNREFERENCED_PARAMETER(hPInst);
  UNREFERENCED_PARAMETER(pCmd);
  return msg.wParam;
}


// Der Messagehandler des Hauptfensters
long _stdcall mainproc(HWND hwnd, UINT message, WPARAM wParm, LPARAM lParm) {
  
  switch( message ) {

  case WM_TIMER:
    if( !_appPAUSED )
      _input->update();
    break;

  case WM_ACTIVATE:
    _appPAUSED = (wParm == WA_INACTIVE) ? true : false;
    break;

  case WM_DESTROY:
    PostQuitMessage(0);
    return 0;

  case WM_SETCURSOR:
    SetCursor(NULL);  // dinput exclusive schaltet cursor aus, im "debug" state ist es besser so
    break;
  }
  
  return DefWindowProc(hwnd, message, wParm, lParm);
}


BOOL  initD3DX( HWND hwnd ) {
  
  // D3DX Initialisieren
  if( FAILED(D3DXInitialize()) ) {
    _log( "failed to initialize Direct3D 7.0a" );
    return FALSE;
  }
  
  // Und Context erzeugen
#ifdef RUN_FULLSCREEN
  if( FAILED( D3DXCreateContextEx( D3DX_HWLEVEL_RASTER , D3DX_CONTEXT_FULLSCREEN, hwnd, NULL,  16, 0, D3DX_DEFAULT, 0, 2, _wndWIDTH, _wndHEIGHT, D3DX_DEFAULT, &_D3DXContext)) ) {
    _log( "failed to create a Direct3D 7.0 render window" );
    return FALSE;
  }
#else
  if ( FAILED( D3DXCreateContextEx(D3DX_HWLEVEL_RASTER, 0, hwnd, NULL, D3DX_DEFAULT, 0, D3DX_DEFAULT, 0, 1, D3DX_DEFAULT, _wndWIDTH, _wndHEIGHT, &_D3DXContext) ) )  {
    _log( "failed to create a Direct3D 7.0 render window" );
    return FALSE;
  }
#endif

  // Die Daten aus dem Context holen
  _D3DDevice = _D3DXContext->GetD3DDevice();
  _D3D7      = _D3DXContext->GetD3D();
  _DDraw     = _D3DXContext->GetDD();

  // Renderstates setzen
  _D3DDevice->SetRenderState(D3DRENDERSTATE_SRCBLEND, D3DBLEND_ONE);
  _D3DDevice->SetRenderState(D3DRENDERSTATE_DESTBLEND, D3DBLEND_ONE);
  _D3DDevice->SetRenderState(D3DRENDERSTATE_SHADEMODE, D3DSHADE_GOURAUD );
  _D3DDevice->SetRenderState( D3DRENDERSTATE_CULLMODE, D3DCULL_CCW );
  
  _D3DDevice->SetRenderState(D3DRENDERSTATE_ZENABLE,D3DZB_TRUE);
  _D3DDevice->SetRenderState(D3DRENDERSTATE_ZFUNC,D3DCMP_GREATEREQUAL);

  _D3DDevice->SetRenderState(D3DRENDERSTATE_CLIPPING,FALSE ); 
  _D3DDevice->SetRenderState(D3DRENDERSTATE_LIGHTING,FALSE); 
  
  _D3DDevice->SetRenderState(D3DRENDERSTATE_WRAPU, TRUE ); 
  _D3DDevice->SetRenderState(D3DRENDERSTATE_WRAPV, TRUE ); 

  _D3DDevice->SetRenderState( D3DRENDERSTATE_DITHERENABLE, TRUE );

  _D3DDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
  _D3DDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
  _D3DDevice->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTFN_LINEAR);
  _D3DDevice->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTFG_LINEAR);
  _D3DDevice->SetTextureStageState(0, D3DTSS_MIPFILTER, D3DTFP_LINEAR);

  
  // Hintergrundfarbe setzen
  _D3DXContext->SetClearColor(D3DRGBA(0.0f,0.0f,0.0f,0));
  _D3DXContext->SetClearDepth( 0.0f );
  _D3DXContext->Clear( D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER );

  return true;
}


BOOL  initAPP() {

  // textur laden
	D3DX_SURFACEFORMAT		sf = D3DX_SF_UNKNOWN;
  HRESULT hr = D3DXCreateTextureFromFile( _D3DDevice, 0, 0, 0, &sf, NULL, &_tex, NULL, "cursor.bmp", D3DX_FT_LINEAR );
  if( hr != S_OK ) 
    return FALSE;


  // input system initialisieren
  _input->setMOUSESTATE( ENABLED );
  _input->setKEYBSTATE( ENABLED );
  _input->setJOYSTATE( ENABLED );

  _input->init( reinterpret_cast<DWORD>(_hwnd) );
  _input->setCLIPRECT( 0, 0, _wndWIDTH, _wndHEIGHT );

  _input->addEFFECT( "./data/plasmagun.ffe" );

  return TRUE;
}


// application shutdown... alle variablen l�schen
void  appSHUTDOWN( void ) {
  
  // DirectX Daten freigeben
  RELEASENULL( _D3D7 );
  RELEASENULL( _D3DDevice );
  RELEASENULL( _D3DXContext );

  // D3DX beenden
  D3DXUninitialize();
}