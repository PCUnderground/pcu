///////////////////////////////////////////////////////////////////////////
//
//  Inputsystem Master Class
//
///////////////////////////////////////////////////////////////////////////
//
//  Original code by: Oliver 'r0k@tap.de' Kaeferstein
//
//  Date of Creation: 26.03.2000
//
//  Modification History:
//  Date             Name             Modifications
//
//  Usage:
//     masterwrapper for derived classes
//     setCLIPRECT forces coordinates to be "stucked" to that area
//
//
///////////////////////////////////////////////////////////////////////////
//
// inputWRAPPER.h : class definition file
//

#ifndef _INPUT_WRAPPER_H
#define _INPUT_WRAPPER_H

#include <windows.h>

enum deviceSTATE { DISABLED, ENABLED };

#define INP_NUMBER_OF_KEYS 256
#define INP_NUMBER_OF_BUTTONS 32
 
class inputWRAPPER {
  
  // all devices cuurently know.. other ones are usually mapped to one of those  
  DWORD  _useMOUSE;
  DWORD  _useKEYBOARD;
  DWORD  _useJOYSTICK;

protected:
  // clip rect to clip coordinates/positions to
  int  _xCLIP, _yCLIP, _xeCLIP, _yeCLIP;
  
//protected:
public:
  int  _x, _y, _z;          // positions of input system
  
  DWORD  _rotX, _rotY, _rotZ; // joystick rotation info ( z mostly the "rudder", on pc's also the mousewheel )
  DWORD  _sliders[2];         // joystick sliders 
  DWORD  _direction[4];       // up to four direction controllers ( 0 to -1 degrees )
  
  char   _keys[INP_NUMBER_OF_KEYS] ;         // up to 256 keys
  char   _buttons[INP_NUMBER_OF_BUTTONS];    // up to 32 buttons for a controller
  
public:
  inputWRAPPER();
  virtual ~inputWRAPPER() {};
  
  // should be changed by the derived init routine
  void setMOUSESTATE(DWORD state = ENABLED) { _useMOUSE = state; }
  void setKEYBSTATE(DWORD state = ENABLED) { _useKEYBOARD = state; }
  void setJOYSTATE(DWORD state = ENABLED) { _useJOYSTICK = state; }
  
  bool getMOUSESTATE() { return( _useMOUSE != DISABLED ); }
  bool getKEYBSTATE() { return( _useKEYBOARD != DISABLED ); }
  bool getJOYSTATE() { return( _useJOYSTICK != DISABLED ); }

  void setCLIPRECT( DWORD x, DWORD y, DWORD xe, DWORD ye );
  void clip_toRECT();
  
  virtual bool init( DWORD data = 0 ) = 0;
  virtual bool update() = 0;

  // tempor�r.. die fliegen hier wieder raus
  virtual bool addEFFECT( const char* file ) = 0;
  virtual void playEFFECT( const char* file ) = 0;
};

#endif  // #ifndef _INPUT_WRAPPER_H