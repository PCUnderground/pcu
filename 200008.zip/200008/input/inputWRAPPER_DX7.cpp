///////////////////////////////////////////////////////////////////////////
//
//  Inputsystem Implementation for DirectX 7.x
//
///////////////////////////////////////////////////////////////////////////
//
//  Original code by: Oliver 'r0k@tap.de' Kaeferstein
//
//  Date of Creation: 26.03.2000
//
//  Modification History:
//  Date             Name             Modifications
//  10.05.2000       TW               added Joystick / Joystick Enum
//  22.05.2000       OK               changed Joystick enum to global enum
//  22.05.2000       OK               changed devices to device entry
//  22.05.2000       OK               added forcefeedback 
//
//
//  Usage:
//     with inputwrapper class
//
//
///////////////////////////////////////////////////////////////////////////
//
// inputWRAPPER_DX7.cpp : class implementation file
//

#include <dinput.h>
#include "inputWRAPPER.h"
#include "inputWRAPPER_DX7.h"

#include "../logsystem.h"

#pragma comment(lib, "dxguid.lib")
#pragma comment(lib, "dinput.lib")


inputWRAPPER_DX7::inputWRAPPER_DX7() : _di(0) {
}

inputWRAPPER_DX7::~inputWRAPPER_DX7() {
  
  if( _keyboard.device ) {
    _keyboard.device->Unacquire();
    _keyboard.device->Release();
    _keyboard.device = 0;
  }
  if( _mouse.device ) {
    _mouse.device->Unacquire();
    _mouse.device->Release();
    _mouse.device = 0;
  }
  if( _joy.device ) {
    _joy.device->Unacquire();
    _joy.device->Release();
    _joy.device = 0;
  }
  if( _di ) {
    _di->Release();
    _di = 0;
  }
}


bool inputWRAPPER_DX7::init( DWORD hwnd ) {

  _hwnd = reinterpret_cast<HWND>(hwnd);
  _hinst = reinterpret_cast<HINSTANCE>( ::GetWindowLong( _hwnd, GWL_HINSTANCE ) );

  bool  hasINPUTDEVICE = false;

  // mouseinput wanted ?
  if( getMOUSESTATE() ) {
    if( initMOUSE() ) {
      setMOUSESTATE( ENABLED );
      hasINPUTDEVICE = true;
    }
    else
      setMOUSESTATE( DISABLED );
  }

  // keyboardinput wanted ?
  if( getKEYBSTATE() ) {
    if( initKEYB() ) {
      setKEYBSTATE( ENABLED );
      hasINPUTDEVICE = true;
    }
    else
      setKEYBSTATE( DISABLED );
  }

  // joystickinput wanted ?
  if( getJOYSTATE() ) {
    if( initJOY() ) {
      setJOYSTATE( ENABLED );
      hasINPUTDEVICE = true;
    }
    else
      setJOYSTATE( DISABLED );
  }

  return hasINPUTDEVICE;
}


bool inputWRAPPER_DX7::update() {

  bool result = updateMOUSE();
  result |= updateJOY();
  result |= updateKEYB();
  
  return result;
}

// maus initialisieren
bool inputWRAPPER_DX7::initMOUSE(){

  HRESULT hr;

  if( !_di  ) {
    hr = DirectInputCreateEx( _hinst, DIRECTINPUT_VERSION, IID_IDirectInput7, (void**)&_di, NULL ); 
    if( FAILED(hr) )  {
      _log( "inputWRAPPER_DX7: cannot DirectInputCreateEx version " << DIRECTINPUT_VERSION );
      return false;
    }
  }

  hr = _di->CreateDeviceEx(GUID_SysMouse, IID_IDirectInputDevice7, (void**)&_mouse.device, NULL); 
  if( FAILED(hr) )  {
    _log( "inputWRAPPER_DX7: initMOUSE : cannot CreateDeviceEx" );
    return false;
  }

  hr = _mouse.device->SetDataFormat( &c_dfDIMouse2 );  // c_dfDIMouse2 ist ein dx predefiniertes format 
  if( FAILED(hr) ) { 
    _log( "inputWRAPPER_DX7: initMOUSE : cannot SetDataFormat" );
    return false;
  } 

#ifdef _DEBUG
  hr = _mouse.device->SetCooperativeLevel( _hwnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE ); 
#else
  hr = _mouse.device->SetCooperativeLevel( _hwnd, DISCL_FOREGROUND | DISCL_EXCLUSIVE ); 
#endif

  if( FAILED(hr) ) { 
    _log( "inputWRAPPER_DX7: initMOUSE : cannot SetCooperativeLevel" );
    return false;
  } 

  return aquireMOUSE();
}


bool inputWRAPPER_DX7::initKEYB(){

  HRESULT hr;

  if( !_di  ) {
    hr = DirectInputCreateEx( _hinst, DIRECTINPUT_VERSION, IID_IDirectInput7, (void**)&_di, NULL ); 
    if( FAILED(hr) )  {
      _log( "inputWRAPPER_DX7: cannot DirectInputCreateEx version " << DIRECTINPUT_VERSION );
      return false;
    }
  }

  hr = _di->CreateDeviceEx(GUID_SysKeyboard, IID_IDirectInputDevice7, (void**)&_keyboard.device, NULL); 
  if( FAILED(hr) )  {
    _log( "inputWRAPPER_DX7: initKEYB : cannot CreateDeviceEx" );
    return false;
  }

  hr = _keyboard.device->SetDataFormat( &c_dfDIKeyboard ); // c_dfDIKeyboard ist ein dx predefiniertes format
  if( FAILED(hr) ) { 
    _log( "inputWRAPPER_DX7: initKEYB : cannot SetDataFormat" );
    return false;
  } 


#ifdef _DEBUG
  hr = _keyboard.device->SetCooperativeLevel( _hwnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE ); 
#else
  hr = _keyboard.device->SetCooperativeLevel( _hwnd, DISCL_FOREGROUND | DISCL_EXCLUSIVE ); 
#endif

  if( FAILED(hr) ) { 
    _log( "inputWRAPPER_DX7: initKEYB : cannot SetCooperativeLevel" );
    return false;
  } 
   return aquireKEYB();
}


extern unsigned int _wndWIDTH;
extern unsigned int _wndHEIGHT;

bool inputWRAPPER_DX7::initJOY(){

  HRESULT hr;

  if( !_di  ) {
    hr = DirectInputCreateEx( _hinst, DIRECTINPUT_VERSION, IID_IDirectInput7, (void**)&_di, NULL ); 
    if( FAILED(hr) )  {
      _log( "inputWRAPPER_DX7: cannot DirectInputCreateEx version " << DIRECTINPUT_VERSION );
      return false;
    }
  }

  // einen angeschlossenen forcefeedback joystick suchen
  enumENTRY wanted;
  wanted.di = _di;
  hr = _di->EnumDevices( DIDEVTYPE_JOYSTICK, &EnumCallback, (void*)&wanted, DIEDFL_ATTACHEDONLY | DIEDFL_FORCEFEEDBACK );
  if( !wanted.device ) {
    hr = _di->EnumDevices( DIDEVTYPE_JOYSTICK, &EnumCallback, (void*)&wanted, DIEDFL_ATTACHEDONLY );
  }
  else
    _joy.canREACT = true;

  _joy.device = wanted.device;

  if( FAILED(hr) )  {
    _log( "inputWRAPPER_DX7: initJOY : cannot EnumDevices" );
    return false;
  }

  if( !(_joy.device = wanted.device) )
    return false;

  if ( FAILED( hr = _joy.device->SetDataFormat( &c_dfDIJoystick2 ) ) ) {
    _log( "inputWRAPPER_DX7: initJOY : cannot SetDataFormat" );
    return false;
  }


#ifdef _DEBUG
  hr = _joy.device->SetCooperativeLevel( _hwnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE ); 
  #else
  hr = _joy.device->SetCooperativeLevel( _hwnd, DISCL_FOREGROUND | DISCL_EXCLUSIVE ); 
#endif

  if( FAILED( hr ) ) { 
    _log( "inputWRAPPER_DX7: initJOY : cannot SetCooperativeLevel" );
    return false;
  }

  DIPROPRANGE diprg; 
  diprg.diph.dwSize       = sizeof( diprg );
  diprg.diph.dwHeaderSize = sizeof( diprg.diph );
  diprg.diph.dwHow        = DIPH_BYOFFSET;

  // absolute positionen, wir wollen den joystick wie einen mausersatz benutzen 
  diprg.diph.dwObj        = DIJOFS_X;
  diprg.lMin              = 0;
  diprg.lMax              = _wndWIDTH;

  if FAILED( hr = _joy.device->SetProperty( DIPROP_RANGE, &diprg.diph ) ) {
    _log( "inputWRAPPER_DX7: initJOY : cannot SetProperty( DIPROP_RANGE )" );
    return false;
  }

  // und nun f�r y-achse
  diprg.diph.dwObj        = DIJOFS_Y;
  diprg.lMin              = 0;
  diprg.lMax              = _wndHEIGHT;

  if FAILED( hr = _joy.device->SetProperty( DIPROP_RANGE, &diprg.diph ) ) {
    _log( "inputWRAPPER_DX7: initJOY : cannot SetProperty( DIPROP_RANGE )" );
    return false;
  }

  // nun noch die "dead zones" des joysticks einstellen da die meisten
  // joysticks nicht wirklich auf center = 0 justiert sind
  // der wert sagt dem joystick das er sich 10% von der mitte bewegen
  // muss damit er "off center" reported
  DIPROPDWORD dipdw;
  dipdw.diph.dwSize       = sizeof( dipdw );
  dipdw.diph.dwHeaderSize = sizeof( dipdw.diph );
  dipdw.diph.dwHow        = DIPH_BYOFFSET;
  
  dipdw.dwData            = _wndWIDTH/10;  // 10% fehlertoleranz auf der x achse
  dipdw.diph.dwObj        = DIJOFS_X;

  if FAILED( hr = _joy.device->SetProperty( DIPROP_DEADZONE, &dipdw.diph ) ) {
    _log( "inputWRAPPER_DX7: initJOY : cannot SetProperty( DIPROP_DEADZONE X )" );
    return false;
  }

  dipdw.dwData            = _wndHEIGHT/10;  // 10% fehlertoleranz auf der y achse
  dipdw.diph.dwObj        = DIJOFS_Y;

  if FAILED( hr = _joy.device->SetProperty( DIPROP_DEADZONE, &dipdw.diph ) ) {
    _log( "inputWRAPPER_DX7: initJOY : cannot SetProperty( DIPROP_DEADZONE Y )" );
    return false;
  }

  // den auto-centering spring abschalten wenn wir ein forcefeedback device haben
  dipdw.diph.dwObj        = 0;
  dipdw.diph.dwHow        = DIPH_DEVICE;
  dipdw.dwData            = FALSE;

  if( _joy.canREACT )
    _joy.device->SetProperty( DIPROP_AUTOCENTER, &dipdw.diph );

  return aquireJOY();
}


// acquire the input device 
bool inputWRAPPER_DX7::aquireMOUSE() {

  HRESULT hr;

  if( !_mouse.device )
    return false;

  if( getKEYBSTATE() )
    hr = _mouse.device->Acquire();
  else 
    hr = _mouse.device->Unacquire();

  return( hr==DI_OK );
}


// acquire the input device 
bool inputWRAPPER_DX7::aquireKEYB() {

  HRESULT hr;

  if( !_keyboard.device )
    return false;

  if( getKEYBSTATE() )
    hr = _keyboard.device->Acquire();
  else 
    hr = _keyboard.device->Unacquire();

  return( hr==DI_OK );
}


// acquire the input device 
bool inputWRAPPER_DX7::aquireJOY() {

  HRESULT hr;

  if( !_joy.device )
    return false;

  if( getJOYSTATE() )
    hr = _joy.device->Acquire();
  else 
    hr = _joy.device->Unacquire();

  return( hr==DI_OK );
}


// update the input device 
bool inputWRAPPER_DX7::updateMOUSE() {

  HRESULT hr;
  DIMOUSESTATE2 dims2;

  if( !_mouse.device )
    return false;

  if( getMOUSESTATE() == DISABLED )
    return true;

  // get mouseinfo
  hr = DIERR_INPUTLOST;
  while( DIERR_INPUTLOST == hr ) {

    hr = _mouse.device->GetDeviceState( sizeof(DIMOUSESTATE2), &dims2 );
    if( hr == DIERR_INPUTLOST )
      if( FAILED( _mouse.device->Acquire() ) ) {
        _log( "inputWRAPPER_DX7: updateMOUSE : cannot GetDeviceState" );
        return false;
      }
  }

  // mouse hat relative koordinaten
  _x += dims2.lX; 
  _y += dims2.lY;
  _z += dims2.lZ;

  // nun die mausbuttons in den buffer kopieren
  hr = 8; // DIMOUSESTATE2 hat 8 button entrys
  while( hr-- ) {
    _buttons[hr] |= (dims2.rgbButtons[hr] && 0x80);
  }

  // mauskoordianten in ein "cliprect" fixieren 
  clip_toRECT();

  return true;
}


// update the input device 
bool inputWRAPPER_DX7::updateKEYB() {

  HRESULT hr;

  if( !_keyboard.device )
    return false;

  if( getKEYBSTATE() == DISABLED )
    return true;

  // get keyinfo
  hr = DIERR_INPUTLOST;
  while( DIERR_INPUTLOST == hr ) {

    hr = _keyboard.device->GetDeviceState( sizeof(_keys), &_keys ); // copy system keystates to buffer 
    if( hr == DIERR_INPUTLOST )
      if( FAILED( _keyboard.device->Acquire() ) ) {
        memset( _keys, 0x0, INP_NUMBER_OF_KEYS );
        return false;
      }
  }

  hr = INP_NUMBER_OF_KEYS;
  while( hr-- ) {
    _keys[hr] = (_keys[hr] && 0x80);
  }
  return true;
}


// update the input device 
bool inputWRAPPER_DX7::updateJOY() {

  HRESULT hr;
  DIJOYSTATE2 js2;

  if( !_joy.device )
    return false;

  if( getJOYSTATE() == DISABLED )
    return true;

  // get joystickinfo
  hr = DIERR_INPUTLOST;
  while( DIERR_INPUTLOST == hr ) {

    // poll the joystick to read the current state
    hr = _joy.device->Poll();

    hr = _joy.device->GetDeviceState( sizeof(DIJOYSTATE2), &js2 );
    if( hr == DIERR_INPUTLOST )
      if( FAILED( _joy.device->Acquire() ) ) {
        _log( "inputWRAPPER_DX7: updateJOY : cannot GetDeviceState" );
        return false;
      }
    }

  static int last_x = 0, last_y = 0, last_z = 0;

  // check for joystick usage -- keep data retrieved from mouse input if no change.
  if ( js2.lX != last_x || js2.lY != last_y || js2.lZ != last_z ) {

    // joystick movement range mapped to clip region
    _x = last_x = js2.lX;
    _y = last_y = js2.lY;
    _z = last_z = js2.lZ;

    // rotations
    _rotX = js2.lRx;
    _rotY = js2.lRy;
    _rotZ = js2.lRz;

    _sliders[0] = js2.rglSlider[0];
    _sliders[1] = js2.rglSlider[1];

    _direction[0] = js2.rgdwPOV[0];
    _direction[1] = js2.rgdwPOV[1];
    _direction[2] = js2.rgdwPOV[2];
    _direction[3] = js2.rgdwPOV[3];

  }

  // copy states to buffer
  hr = INP_NUMBER_OF_BUTTONS; // copy button states
  while ( hr--  ) {
    _buttons[hr] |= js2.rgbButtons[hr] && 0x80;
  }

  // joykoordianten in ein "cliprect" fixieren 
  clip_toRECT();

  return true;
}

#pragma warning(disable:4786)
#include <map>
#include <vector>
#include <string>
#define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p)=NULL; } }

struct EFFECT_NODE {

  LPDIRECTINPUTEFFECT effect;
  DWORD               repeats;
  EFFECT_NODE() : effect(0), repeats(0) {}
//  ~EFFECT_NODE() { SAFE_RELEASE( effect ); }
  ~EFFECT_NODE() {}
};

struct FILE_EFFECT {
  std::vector<EFFECT_NODE> effects;
  LPDIRECTINPUTDEVICE7 device;
  FILE_EFFECT() { effects.clear(); }
  ~FILE_EFFECT() {}
/*
  ~FILE_EFFECT() { 
    std::vector<EFFECT_NODE>::iterator it;
    for( it = effects.begin(); it < effects.end(); it++ )
      SAFE_RELEASE( (*it).effect );
    effects.clear();
  }
*/
};

std::map<std::string, FILE_EFFECT> _list;
std::map<std::string, FILE_EFFECT>::iterator _pos;


bool inputWRAPPER_DX7::addEFFECT( const char* file ) {

  // haben wir den effekt schon geladen ?
  if ( (_pos = _list.find( file )) != _list.end() )
    return true;

  FILE_EFFECT effects;
  effects.device = _joy.device;
  
  // enumerieren der effekte in dem file und sie in dem callback kreiren
  if( _joy.canREACT ) {
    if( FAILED( _joy.device->EnumEffectsInFile( file, EnumAndCreateEffectsCallback, &effects, 0 ) ) )
      return false;
  }

  // und in einer lookup liste abspeichern
  _list.insert( std::pair<std::string, FILE_EFFECT>( file, effects ) );  

  return true;
}


void inputWRAPPER_DX7::playEFFECT( const char* file ) {

  // kennen wir den file effekt ?
  if ( (_pos = _list.find( file )) == _list.end() )
    return;

  // ja, dann werden wir ihn an das device senden
  FILE_EFFECT* feff = &((*_pos).second);

  // alle vorherigen effekte stoppen
  if( FAILED( feff->device->SendForceFeedbackCommand( DISFFC_STOPALL ) ) )
    return;

  // und die liste von effekten durchlaufen
  std::vector<EFFECT_NODE>::iterator it;
  for( it = feff->effects.begin(); it < feff->effects.end(); it++ )
    (*it).effect->Start( (*it).repeats, 0 );

  return;
}


// direct input device enumeration callback routine
BOOL CALLBACK inputWRAPPER_DX7::EnumCallback( LPCDIDEVICEINSTANCE pdidInstance, LPVOID pvRef ) {

  HRESULT hr;

  enumENTRY* wanted = reinterpret_cast<enumENTRY*>(pvRef);

  // versuchen ob man das gew�nschte device einrichten kann
  hr = wanted->di->CreateDeviceEx( pdidInstance->guidInstance, IID_IDirectInputDevice7, (void**)&wanted->device, NULL );
  if( FAILED(hr) )
    return DIENUM_CONTINUE;

  // wenn wir bis hierhin gekommen sind, haben wir das gew�nschte device gefunden
  return DIENUM_STOP;
}


// die effekte kreiern wenn sie durch den enumerator laufen und sie in die verkette liste einh�ngen
BOOL CALLBACK inputWRAPPER_DX7::EnumAndCreateEffectsCallback( LPCDIFILEEFFECT fileEFFECT, LPVOID pvRef ) {   

  HRESULT hr;
  LPDIRECTINPUTEFFECT effect = NULL;

  FILE_EFFECT* entry = reinterpret_cast<FILE_EFFECT*>( pvRef );

  // den fileeffekt anlegen
  if( FAILED( hr = entry->device->CreateEffect( fileEFFECT->GuidEffect, fileEFFECT->lpDiEffect, &effect, NULL ) ) )
    return DIENUM_CONTINUE; // der effekt kann auf diesem ger�t nicht wiedergegeben werden. n�chster bitte

  // eine neue effekt node anlegen
  EFFECT_NODE enode;
  enode.effect = effect;
  enode.repeats = 1;

  // und in die verkettet liste einh�ngen wenn alles klar ist
  if( effect )
    entry->effects.push_back( enode );

  return DIENUM_CONTINUE;
}

