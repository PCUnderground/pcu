///////////////////////////////////////////////////////////////////////////
//
//  Inputsystem Implementation for DirectX 7.x
//
///////////////////////////////////////////////////////////////////////////
//
//  Original code by: Oliver 'r0k@tap.de' Kaeferstein
//
//  Date of Creation: 26.03.2000
//
//  Modification History:
//  Date             Name             Modifications
//  10.05.2000       TW               added Joystick / Joystick Enum
//  22.05.2000       OK               changed Joystick enum to global enum
//  22.05.2000       OK               changed devices to device entry
//  22.05.2000       OK               added forcefeedback 
//
//
//  Usage:
//     with inputwrapper class
//
//
///////////////////////////////////////////////////////////////////////////
//
// inputWRAPPER_DX7.h : class definition file
//

#ifndef _INPUT_WRAPPER_DX7_H
#define _INPUT_WRAPPER_DX7_H

#include <windows.h>
#include "inputWRAPPER.h"


class inputWRAPPER_DX7 : public inputWRAPPER {

  HINSTANCE _hinst;
  HWND      _hwnd;

  // direct input device
  struct deviceENTRY {
    bool  canREACT;
    LPDIRECTINPUTDEVICE7 device;
    deviceENTRY() : canREACT(false), device(0) {}
  };

  // struct f�r den enum callback
  struct enumENTRY {
    LPDIRECTINPUT7       di;
    LPDIRECTINPUTDEVICE7 device;
    enumENTRY() : di(0), device(0) {}
  };

  // die eingabesysteme
  LPDIRECTINPUT7 _di;
  deviceENTRY    _keyboard;
  deviceENTRY    _mouse;
  deviceENTRY    _joy;

  // und der sucher f�r input devices
  static BOOL CALLBACK EnumCallback( LPCDIDEVICEINSTANCE pdidInstance, LPVOID pvRef );

  // sowie der generierer f�r direct input devices
  static BOOL CALLBACK EnumAndCreateEffectsCallback( LPCDIFILEEFFECT fileEFFECT, LPVOID pvRef );

protected:
  bool  initMOUSE();
  bool  initKEYB();
  bool  initJOY();

  bool  aquireMOUSE();
  bool  aquireKEYB();
  bool  aquireJOY();

  bool  updateMOUSE();
  bool  updateKEYB();
  bool  updateJOY();
  
public:
  inputWRAPPER_DX7();
  ~inputWRAPPER_DX7();
  
  bool init( DWORD hwnd = 0 );
  bool update();

  // tempor�r.. die fliegen hier wieder raus
  bool addEFFECT( const char* file );
  void playEFFECT( const char* file );
};

#endif // #ifndef _INPUT_WRAPPER_DX7_H