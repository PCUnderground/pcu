///////////////////////////////////////////////////////////////////////////
//
//  Inputsystem Master Class
//
///////////////////////////////////////////////////////////////////////////
//
//  Original code by: Oliver 'r0k@tap.de' Kaeferstein
//
//  Date of Creation: 26.03.2000
//
//  Modification History:
//  Date             Name             Modifications
//
//  Usage:
//     masterwrapper for derived classes
//     setCLIPRECT forces coordinates to be "stucked" to that area
//
//
///////////////////////////////////////////////////////////////////////////
//
// inputWRAPPER.cpp : class implementation file
//

#include "inputWRAPPER.h"

inputWRAPPER::inputWRAPPER() : _x(0),_y(0),_z(0),_rotX(0),_rotY(0),_rotZ(0),_useMOUSE(0),_useKEYBOARD(0),_useJOYSTICK(0) {
  
  memset( _sliders, 0x0, sizeof( _sliders ) );
  memset( _direction, 0x0, sizeof( _sliders ) );
  memset( _keys, 0x0, sizeof( _sliders ) );
  memset( _buttons, 0x0, sizeof( _sliders ) );
}

void inputWRAPPER::setCLIPRECT( DWORD x, DWORD y, DWORD xe, DWORD ye ) {

  if( (xe < x) || (ye < y ) )
    return;

  _xCLIP = x;
  _yCLIP = y;
  _xeCLIP = xe;
  _yeCLIP = ye;
}

void inputWRAPPER::clip_toRECT() {

  _x = ( _x < _xCLIP ) ? _xCLIP+1 : ( _x > _xeCLIP ) ? _xeCLIP-1 : _x;
  _y = ( _y < _yCLIP ) ? _yCLIP+1 : ( _y > _yeCLIP ) ? _yeCLIP-1 : _y;
}
