#include <strstream>
#define _log( a ) { std::ostrstream t; t.clear(); t << a; MessageBox( NULL, t.str(), "error!", MB_OK ); }
