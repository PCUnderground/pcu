////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  P-Buffer Klasse Header File                           //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#ifndef _P_BUFFER__H
#define _P_BUFFER__H

#include "wglext.h"

class CPBuffer
{
	private:	
		HPBUFFERARB hPBuffer;
		HDC         hDC;
		HGLRC       hRC;

		// Gr��e
		int         sizeX, sizeY;

		// Texture
		GLuint		textureID;

		// Status
		int			exists;

	public:
		CPBuffer( int _x, int _y, HDC hDC );
		~CPBuffer();

		int		bind();
		int		release();
		int		makeCurrent();

		GLuint	getTexID() { return textureID; };

		int	exist() { return exists; };
};

#endif







