////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Post-Processing Effekte Hardware-Beschleunigt         //
//  (w)(c)2003 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////

#include	<windows.h>			
#include	<math.h>
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	"glext.h"
#include	"texture.h"
#include	"p_buffer.h"
#include	"oglExtension.h"
#include	"hprender.h"

#define FXGLOW		1
#define FXDITHER	2
#define FXEDGE		3

#define EFFECT		FXEDGE

// HDC und HGLRC des OpenGL Fensters
extern HDC		hDC;
extern HGLRC	hRC;

PCUTexture *texFloor;
PCUTexture *texDither;

#include "keys.h"

#if (EFFECT == FXGLOW)
	const int BLURSIZE = 64;
#else
	const int BLURSIZE = 512;
#endif

// Pointer auf die P-Buffer Klasse
CPBuffer *pBufferGlow;
CPBuffer *pBufferBlur;

// Prototypes
void	renderPlane();
void	renderModel();


// setzt Lightquellen Parameter
void	applyLighting()
{
	glEnable( GL_LIGHT0 );

	GLfloat light_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat light_diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat light_ambient[] = { 0.0f, 0.0f, 0.0f, 1.0f };

	glLightfv( GL_LIGHT0, GL_AMBIENT, light_ambient );
	glLightfv( GL_LIGHT0, GL_DIFFUSE, light_diffuse );
	glLightfv( GL_LIGHT0, GL_SPECULAR, light_specular );

	glLightf( GL_LIGHT0, GL_SPOT_EXPONENT, 18 );

	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);

	setMaterial();
}


//
// Initialisierung
//
void	init3DEngine()
{
    glShadeModel( GL_SMOOTH );

	glHint( GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST );

	glDisable( GL_POLYGON_SMOOTH );

	glEnable( GL_DEPTH_TEST );
	glFrontFace( GL_CCW );
	glEnable( GL_CULL_FACE );

	// Lichtquelle zur Beleuchtung der 3D Modelle
	applyLighting();

	glEnable( GL_TEXTURE_2D );
	glDisable( GL_BLEND );

	loadKeyTexture();

	// ben�tigte Extensions initialisieren
	getOpenGLExtensions();

	//
	// Zufallstexture f�r das Dithering
	//
//####################
#if (EFFECT == FXDITHER)
//####################
	unsigned int *lookup = new unsigned int[512 * 512];
	for (int i = 0; i < 512 * 512; i++)
	{
		lookup[i] = min( 255, (rand() & 255) + 16 );
		
		// 8-Bit -> RGBA Graustufen
		lookup[i] *= 0x01010101;
	}

	// und OpenGL Texture daraus erzeugen
	texDither = new PCUTexture();
	texDither->createTexture();
	gluBuild2DMipmaps(GL_TEXTURE_2D, 4, 512, 512, GL_RGBA, GL_UNSIGNED_BYTE, lookup );

	delete lookup;
//####################
#endif
//####################

	//
	// P-Buffers anlegen
	//
	extern HDC hDC;
	pBufferGlow = new CPBuffer( BLURSIZE, BLURSIZE, hDC );
	pBufferBlur = new CPBuffer( BLURSIZE, BLURSIZE, hDC );

	if ( !pBufferGlow->exist() || !pBufferBlur->exist() )
		exit( 1 );

	// P-Buffer Kontext setzen und initialisieren
	if ( !pBufferBlur->makeCurrent() ) exit(1);

	glClearColor( 0.0f, 0.0f, 0.0f, 0.0f );
	
	glDisable  ( GL_DEPTH_TEST );
	
	glEnable   ( GL_BLEND );
	glBlendFunc( GL_ONE, GL_ONE );
	
	glEnable   ( GL_TEXTURE_2D );

	// P-Buffer Kontext setzen und initialisieren
	if ( !pBufferGlow->makeCurrent() )
	{
		MessageBox( NULL, "P-Buffer Kontext konnte nicht aktiviert werden !", "PCU", MB_OK );
		exit( 1 );
	}

	applyLighting();

	glClearColor( 1.0f, 1.0f, 1.0f, 1.0f );

	glDisable( GL_POLYGON_SMOOTH );
	glEnable( GL_DEPTH_TEST );
	glFrontFace( GL_CCW );
	glEnable( GL_CULL_FACE );
	glDisable( GL_LIGHTING );
	glDisable( GL_BLEND );
	glDisable( GL_TEXTURE_2D );
	glColor3ub( 0, 0, 0 );

	texFloor = new PCUTexture();
	texFloor->loadBMP( "./data/floor2.bmp" );

	init3DModel( "./data/bunny" );
}

static GLfloat lightPosition[] = { 2.0f, 3.0f, 2.0f, 1.0f };
static GLfloat lightDirection[] = { 2.0f, -4.0f, 2.0f, 1.0f };

#define SPOT_ANGLE	80.0f


//
// Zeichnet ein texturiertes Quad �ber den ganzen Viewport, sichert Matrizen
//
void screenRect( int du = 0, int dv = 0 )
{
	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();
	glLoadIdentity();

	glMatrixMode( GL_PROJECTION );
	glPushMatrix();
	glLoadIdentity();

	glBegin( GL_TRIANGLE_STRIP );
		glTexCoord2f( 0 + (float)du/(float)BLURSIZE, 1 + (float)dv/(float)BLURSIZE );
		glMultiTexCoord2fARB( GL_TEXTURE1_ARB, 0 + (float)du/(float)BLURSIZE, 1 + (float)dv/(float)BLURSIZE );
		glVertex2i( -1,  1 );
		glTexCoord2f( 0 + (float)du/(float)BLURSIZE, 0 + (float)dv/(float)BLURSIZE );
		glMultiTexCoord2fARB( GL_TEXTURE1_ARB, 0 + (float)du/(float)BLURSIZE, 0 + (float)dv/(float)BLURSIZE );
		glVertex2i( -1, -1 );
		glTexCoord2f( 1 + (float)du/(float)BLURSIZE, 1 + (float)dv/(float)BLURSIZE );
		glMultiTexCoord2fARB( GL_TEXTURE1_ARB, 1 + (float)du/(float)BLURSIZE, 1 + (float)dv/(float)BLURSIZE );
		glVertex2i(  1,  1 );
		glTexCoord2f( 1 + (float)du/(float)BLURSIZE, 0 + (float)dv/(float)BLURSIZE );
		glMultiTexCoord2fARB( GL_TEXTURE1_ARB, 1 + (float)du/(float)BLURSIZE, 0 + (float)dv/(float)BLURSIZE );
		glVertex2i(  1, -1 );
	glEnd();

	glPopMatrix();
	glMatrixMode( GL_MODELVIEW );
	glPopMatrix();
}

void screenRectDisplace( int texSize )
{
	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();
	glLoadIdentity();

	glMatrixMode( GL_PROJECTION );
	glPushMatrix();
	glLoadIdentity();

	glBegin( GL_TRIANGLE_STRIP );

		glMultiTexCoord2fARB( GL_TEXTURE0_ARB, 0 + (float)-1/(float)texSize, 1 + (float)+0/(float)texSize );
		glMultiTexCoord2fARB( GL_TEXTURE1_ARB, 0 + (float)+1/(float)texSize, 1 + (float)+0/(float)texSize );
		glMultiTexCoord2fARB( GL_TEXTURE2_ARB, 0 + (float)+0/(float)texSize, 1 + (float)-1/(float)texSize );
		glMultiTexCoord2fARB( GL_TEXTURE3_ARB, 0 + (float)+0/(float)texSize, 1 + (float)+1/(float)texSize );
		glVertex2i( -1,  1 );

		glMultiTexCoord2fARB( GL_TEXTURE0_ARB, 0 + (float)-1/(float)texSize, 0 + (float)+0/(float)texSize );
		glMultiTexCoord2fARB( GL_TEXTURE1_ARB, 0 + (float)+1/(float)texSize, 0 + (float)+0/(float)texSize );
		glMultiTexCoord2fARB( GL_TEXTURE2_ARB, 0 + (float)+0/(float)texSize, 0 + (float)-1/(float)texSize );
		glMultiTexCoord2fARB( GL_TEXTURE3_ARB, 0 + (float)+0/(float)texSize, 0 + (float)+1/(float)texSize );
		glVertex2i( -1, -1 );

		glMultiTexCoord2fARB( GL_TEXTURE0_ARB, 1 + (float)-1/(float)texSize, 1 + (float)+0/(float)texSize );
		glMultiTexCoord2fARB( GL_TEXTURE1_ARB, 1 + (float)+1/(float)texSize, 1 + (float)+0/(float)texSize );
		glMultiTexCoord2fARB( GL_TEXTURE2_ARB, 1 + (float)+0/(float)texSize, 1 + (float)-1/(float)texSize );
		glMultiTexCoord2fARB( GL_TEXTURE3_ARB, 1 + (float)+0/(float)texSize, 1 + (float)+1/(float)texSize );
		glVertex2i(  1,  1 );

		glMultiTexCoord2fARB( GL_TEXTURE0_ARB, 1 + (float)-1/(float)texSize, 0 + (float)+0/(float)texSize );
		glMultiTexCoord2fARB( GL_TEXTURE1_ARB, 1 + (float)+1/(float)texSize, 0 + (float)+0/(float)texSize );
		glMultiTexCoord2fARB( GL_TEXTURE2_ARB, 1 + (float)+0/(float)texSize, 0 + (float)-1/(float)texSize );
		glMultiTexCoord2fARB( GL_TEXTURE3_ARB, 1 + (float)+0/(float)texSize, 0 + (float)+1/(float)texSize );
		glVertex2i(  1, -1 );
	glEnd();

	glPopMatrix();
	glMatrixMode( GL_MODELVIEW );
	glPopMatrix();
}


//
// Setup der Register Combiner f�r den Dithering Effekt !
//
void	setupDithering()
{
	glCombinerParameteriNV( GL_NUM_GENERAL_COMBINERS_NV, 2 );

	GLfloat grau[] = {0.30f, 0.59f, 0.11f, 0.0f};
	glCombinerParameterfvNV( GL_CONSTANT_COLOR0_NV, grau );

	// spare0.rgb = tex0 . const0
	glCombinerInputNV(  GL_COMBINER0_NV,  GL_RGB, GL_VARIABLE_A_NV, GL_TEXTURE0_ARB,       GL_UNSIGNED_IDENTITY_NV, GL_RGB );
	glCombinerInputNV(  GL_COMBINER0_NV,  GL_RGB, GL_VARIABLE_B_NV, GL_CONSTANT_COLOR0_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB );
	
	glCombinerOutputNV( GL_COMBINER0_NV, GL_RGB, GL_SPARE0_NV, GL_DISCARD_NV, GL_DISCARD_NV, GL_NONE, GL_NONE, GL_TRUE, GL_FALSE, GL_FALSE );

	// spare0.rgb = (1, 1, 1)
	glCombinerInputNV(  GL_COMBINER1_NV,  GL_RGB, GL_VARIABLE_A_NV, GL_ZERO,       GL_UNSIGNED_INVERT_NV, GL_RGB );
	glCombinerInputNV(  GL_COMBINER1_NV,  GL_RGB, GL_VARIABLE_B_NV, GL_ZERO,       GL_UNSIGNED_INVERT_NV, GL_RGB );
	glCombinerInputNV(  GL_COMBINER1_NV,  GL_RGB, GL_VARIABLE_D_NV, GL_ZERO,       GL_UNSIGNED_INVERT_NV, GL_RGB );
	glCombinerInputNV(  GL_COMBINER1_NV,  GL_RGB, GL_VARIABLE_C_NV, GL_ZERO,       GL_UNSIGNED_INVERT_NV, GL_RGB );
	
	glCombinerOutputNV( GL_COMBINER1_NV, GL_RGB, GL_DISCARD_NV, GL_DISCARD_NV, GL_SPARE0_NV, GL_NONE, GL_NONE, GL_FALSE, GL_FALSE, GL_FALSE );

	// spare0.a = signed_identity(tex0.b) + half_bias(tex1.b)
	glCombinerInputNV(  GL_COMBINER1_NV,  GL_ALPHA, GL_VARIABLE_A_NV, GL_SPARE0_NV,	   GL_SIGNED_IDENTITY_NV,  GL_BLUE );
	glCombinerInputNV(  GL_COMBINER1_NV,  GL_ALPHA, GL_VARIABLE_B_NV, GL_ZERO,         GL_UNSIGNED_INVERT_NV,  GL_BLUE );
	glCombinerInputNV(  GL_COMBINER1_NV,  GL_ALPHA, GL_VARIABLE_C_NV, GL_TEXTURE1_ARB, GL_HALF_BIAS_NORMAL_NV, GL_BLUE );
	glCombinerInputNV(  GL_COMBINER1_NV,  GL_ALPHA, GL_VARIABLE_D_NV, GL_ZERO,         GL_UNSIGNED_INVERT_NV,  GL_BLUE );

	glCombinerOutputNV( GL_COMBINER1_NV, GL_ALPHA, GL_DISCARD_NV, GL_DISCARD_NV, GL_SPARE0_NV, GL_NONE, GL_NONE, GL_FALSE, GL_FALSE, GL_FALSE );

	// result = spare0;
	glFinalCombinerInputNV( GL_VARIABLE_A_NV, GL_ZERO,      GL_UNSIGNED_IDENTITY_NV, GL_RGB );
	glFinalCombinerInputNV( GL_VARIABLE_B_NV, GL_ZERO,      GL_UNSIGNED_IDENTITY_NV, GL_RGB );
	glFinalCombinerInputNV( GL_VARIABLE_C_NV, GL_ZERO,      GL_UNSIGNED_IDENTITY_NV, GL_RGB );
	glFinalCombinerInputNV( GL_VARIABLE_D_NV, GL_SPARE0_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB );
}

//
// Setup der Register Combiner f�r den Kantenfilter Effekt !
//
void	setupEdgeFilter()
{
	/* 
	// NV Parse �quivalent
	{
	  rgb {
		discard = unsigned(tex0);
		discard = -tex1;
		spare0 = sum();
		scale_by_one_two();
	  }
	}
	{
	  rgb {
		discard = unsigned(tex2);
		discard = -tex3;
		spare1 = sum();
		scale_by_one_two();
	  }
	}
	{
	  rgb {
		discard = spare0 . spare0;
		spare1 = spare1 . spare1;
		spare0 = sum();
		scale_by_one_four();
	  }
	}
	out.rgb = spare0;
	*/
	glCombinerParameteriNV( GL_NUM_GENERAL_COMBINERS_NV, 3 );

	glCombinerInputNV(  GL_COMBINER0_NV,  GL_RGB, GL_VARIABLE_A_NV, GL_TEXTURE0_ARB,    GL_UNSIGNED_IDENTITY_NV, GL_RGB );
	glCombinerInputNV(  GL_COMBINER0_NV,  GL_RGB, GL_VARIABLE_B_NV, GL_ZERO,			GL_UNSIGNED_INVERT_NV, GL_RGB );
	glCombinerInputNV(  GL_COMBINER0_NV,  GL_RGB, GL_VARIABLE_D_NV, GL_TEXTURE1_ARB,    GL_SIGNED_NEGATE_NV, GL_RGB );
	glCombinerInputNV(  GL_COMBINER0_NV,  GL_RGB, GL_VARIABLE_C_NV, GL_ZERO,			GL_UNSIGNED_INVERT_NV, GL_RGB );
	
	glCombinerOutputNV( GL_COMBINER0_NV, GL_RGB, GL_DISCARD_NV, GL_DISCARD_NV, GL_SPARE0_NV, GL_SCALE_BY_TWO_NV, GL_NONE, GL_TRUE, GL_TRUE, GL_FALSE );

	glCombinerInputNV(  GL_COMBINER1_NV,  GL_RGB, GL_VARIABLE_A_NV, GL_TEXTURE2_ARB,    GL_UNSIGNED_IDENTITY_NV, GL_RGB );
	glCombinerInputNV(  GL_COMBINER1_NV,  GL_RGB, GL_VARIABLE_B_NV, GL_ZERO,			GL_UNSIGNED_INVERT_NV, GL_RGB );
	glCombinerInputNV(  GL_COMBINER1_NV,  GL_RGB, GL_VARIABLE_D_NV, GL_TEXTURE3_ARB,    GL_SIGNED_NEGATE_NV, GL_RGB );
	glCombinerInputNV(  GL_COMBINER1_NV,  GL_RGB, GL_VARIABLE_C_NV, GL_ZERO,			GL_UNSIGNED_INVERT_NV, GL_RGB );
	
	glCombinerOutputNV( GL_COMBINER1_NV, GL_RGB, GL_DISCARD_NV, GL_DISCARD_NV, GL_SPARE1_NV, GL_SCALE_BY_TWO_NV, GL_NONE, GL_TRUE, GL_TRUE, GL_FALSE);

	glCombinerInputNV(  GL_COMBINER2_NV,  GL_RGB, GL_VARIABLE_A_NV, GL_SPARE0_NV,    GL_SIGNED_IDENTITY_NV, GL_RGB );
	glCombinerInputNV(  GL_COMBINER2_NV,  GL_RGB, GL_VARIABLE_B_NV, GL_SPARE0_NV,	 GL_SIGNED_IDENTITY_NV, GL_RGB );
	glCombinerInputNV(  GL_COMBINER2_NV,  GL_RGB, GL_VARIABLE_D_NV, GL_SPARE1_NV,	 GL_SIGNED_IDENTITY_NV, GL_RGB );
	glCombinerInputNV(  GL_COMBINER2_NV,  GL_RGB, GL_VARIABLE_C_NV, GL_SPARE1_NV,	 GL_SIGNED_IDENTITY_NV, GL_RGB );

	glCombinerOutputNV( GL_COMBINER2_NV, GL_RGB, GL_DISCARD_NV, GL_SPARE1_NV, GL_SPARE0_NV, GL_SCALE_BY_FOUR_NV, GL_NONE, GL_TRUE, GL_TRUE, GL_FALSE );

	glFinalCombinerInputNV( GL_VARIABLE_A_NV, GL_ZERO,      GL_UNSIGNED_IDENTITY_NV, GL_RGB );
	glFinalCombinerInputNV( GL_VARIABLE_B_NV, GL_ZERO,      GL_UNSIGNED_IDENTITY_NV, GL_RGB );
	glFinalCombinerInputNV( GL_VARIABLE_C_NV, GL_ZERO,      GL_UNSIGNED_IDENTITY_NV, GL_RGB );
	glFinalCombinerInputNV( GL_VARIABLE_D_NV, GL_SPARE0_NV, GL_UNSIGNED_IDENTITY_NV, GL_RGB );
}



void	applyTransformation()
{
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();
	extern int windowX, windowY;
	gluPerspective( 45.0f, (float)windowX / (float)max( 1, windowY ), 0.1f, 500.0f );

	glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();
	glTranslatef( 0, 0, -4 );
	glRotatef( 30, 1, 0, 0 );
	glRotatef( GetTickCount() * 0.02f, 0, 1, 0 );
}

//
// Render Callback
//
void	draw3DEngine()
{
	float time = GetTickCount() * 0.001f;
	lightPosition[ 0 ] = (float)cos( time ) * 2.0f;
	lightPosition[ 1 ] = (float)sin( time * 0.123f ) * 1.0f + 3.0f;
	lightPosition[ 2 ] = (float)sin( time ) * 2.0f;

	lightDirection[ 0 ] = -lightPosition[ 0 ];
	lightDirection[ 1 ] = -lightPosition[ 1 ];
	lightDirection[ 2 ] = -lightPosition[ 2 ];

	extern bool keys[ 256 ];

	  //
	 // P-Buffer Glow-Parts rendern
	//
	if ( !pBufferGlow->makeCurrent() )
	{
		MessageBox( NULL, "P-Buffer Kontext konnte nicht aktiviert werden !", "PCU", MB_OK );
		exit( 1 );
	}

	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	glEnable( GL_DEPTH_TEST );

	glColor4ub( 255, 255, 255, 255 );

	applyTransformation();

	glLightfv( GL_LIGHT0, GL_POSITION, lightPosition );
	glLightfv( GL_LIGHT0, GL_SPOT_DIRECTION, lightDirection );

#if (EFFECT == FXGLOW)
	glDisable( GL_LIGHTING );
	glColorMask( 0, 0, 0, 0 );
	renderModel();

	glColorMask( 1, 1, 1, 1 );
	glColor4ub( 55, 55, 55, 55 );
	renderPlane();
#else
	glEnable( GL_LIGHTING );
	renderModel();
#endif

//####################
#if (EFFECT == FXGLOW)
//####################
	//
	 // P-Buffer Blur Horizontal
	//
	if ( !pBufferBlur->makeCurrent() ) exit( 1 );

	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	glDisable( GL_LIGHTING );

	// Quelle ist der erste P-Buffer
	glBindTexture( GL_TEXTURE_2D, pBufferGlow->getTexID() );
	glTexEnvi( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

	if ( !pBufferGlow->bind() ) exit( 1 );

	// 7 Pixel horizontal gewichten und additiv mischen
	for ( int i = 0; i < 4; i++ )
	{
		float w = (float)exp( -0.5f * (float)i );

		glColor4f( w, w, w, w );
		
		screenRect( i, 0 );
		
		if ( i != 0 )
			screenRect( -i, 0 );
	}

	if ( !pBufferGlow->release() ) exit( 1 );


	  //
	 // P-Buffer Blur Vertikal
	//
	if ( !pBufferGlow->makeCurrent() ) exit( 1 );

	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glClearColor( 0, 0, 0, 0 );
	glDisable( GL_DEPTH_TEST );
	glEnable( GL_BLEND );
	glBlendFunc( GL_ONE, GL_ONE );
	glEnable( GL_TEXTURE_2D );

	glDisable( GL_LIGHTING );

	// Quelle ist der bereits horizontal gefilterte P-Buffer
	glBindTexture( GL_TEXTURE_2D, pBufferBlur->getTexID() );
	glTexEnvi( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

	if ( !pBufferBlur->bind() ) exit( 1 );

	for ( i = 0; i < 4; i++ )
	{
		float w = (float)exp( -0.5f * (float)i );

		glColor4f( w, w, w, w );
		
		screenRect( 0, i );
		
		if ( i != 0 )
			screenRect( 0, -i );
	}

	if ( !pBufferBlur->release() ) exit( 1 );

//####################
#endif
//####################

	  //
	 // Frame Buffer
	//
	wglMakeCurrent( hDC, hRC );

    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	applyTransformation();


	//
	// und damit rendern
	//
	
	glDisable( GL_BLEND );
	glEnable( GL_DEPTH_TEST );

//####################
#if (EFFECT == FXGLOW)
//####################

	// Objekt normal zeichnen
	glLightfv( GL_LIGHT0, GL_POSITION, lightPosition );
	glLightfv( GL_LIGHT0, GL_SPOT_DIRECTION, lightDirection );

	glDisable( GL_TEXTURE_2D );
	glEnable( GL_LIGHTING );
	renderModel();

	// und anschliessend den Glow-Effekt hinzuf�gen
	glActiveTextureARB( GL_TEXTURE0_ARB );
	glEnable( GL_TEXTURE_2D );

	glBindTexture( GL_TEXTURE_2D, pBufferGlow->getTexID() );
	glTexEnvi( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
	if ( !pBufferGlow->bind() ) exit( 1 );

	glDisable( GL_LIGHTING );
	glEnable( GL_BLEND );
	glBlendFunc( GL_ONE, GL_ONE );

	screenRect();

	if ( !pBufferGlow->release() ) exit( 1 );
//####################
#endif
//####################


//####################
#if (EFFECT == FXDITHER)
//####################
	// Dithering
	glDisable( GL_BLEND );
	glEnable( GL_ALPHA_TEST );
	glAlphaFunc( GL_GREATER, 0.5f );
	setupDithering();
	

	glActiveTextureARB( GL_TEXTURE1_ARB );
	glEnable( GL_TEXTURE_2D );
	texDither->select();

	glActiveTextureARB( GL_TEXTURE0_ARB );
	glEnable( GL_TEXTURE_2D );
	glBindTexture( GL_TEXTURE_2D, pBufferGlow->getTexID() );
	glTexEnvi( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
	if ( !pBufferGlow->bind() ) exit( 1 );

	glEnable( GL_REGISTER_COMBINERS_NV );

	screenRect( 0, 0 );

	glDisable( GL_REGISTER_COMBINERS_NV );

	if ( !pBufferGlow->release() ) exit( 1 );
	
	glDisable( GL_BLEND );
	glDisable( GL_ALPHA_TEST );
//####################
#endif
//####################


//####################
#if (EFFECT == FXEDGE)
//####################
	setupEdgeFilter();
	glActiveTextureARB( GL_TEXTURE0_ARB );
	glEnable( GL_TEXTURE_2D );
	glBindTexture( GL_TEXTURE_2D, pBufferGlow->getTexID() );
	glActiveTextureARB( GL_TEXTURE1_ARB );
	glEnable( GL_TEXTURE_2D );
	glBindTexture( GL_TEXTURE_2D, pBufferGlow->getTexID() );
	glActiveTextureARB( GL_TEXTURE2_ARB );
	glEnable( GL_TEXTURE_2D );
	glBindTexture( GL_TEXTURE_2D, pBufferGlow->getTexID() );
	glActiveTextureARB( GL_TEXTURE3_ARB );
	glEnable( GL_TEXTURE_2D );
	glBindTexture( GL_TEXTURE_2D, pBufferGlow->getTexID() );

	if ( !pBufferGlow->bind() ) exit( 1 );

	glEnable( GL_REGISTER_COMBINERS_NV );
	screenRectDisplace( BLURSIZE );
	glDisable( GL_REGISTER_COMBINERS_NV );

	glDisable( GL_BLEND );

	if ( !pBufferGlow->release() ) exit( 1 );
//####################
#endif
//####################

	glActiveTextureARB( GL_TEXTURE1_ARB );
	glDisable( GL_TEXTURE_2D );
	glActiveTextureARB( GL_TEXTURE0_ARB );
	glEnable( GL_TEXTURE_2D );

	//
	// P-Buffer Texture zeichnen
	// 
	glDisable( GL_BLEND );
	glBindTexture( GL_TEXTURE_2D, pBufferGlow->getTexID() );
	glTexEnvi( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

	if ( !pBufferGlow->bind() ) exit( 1 );

	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();

	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();

	glBegin( GL_TRIANGLE_STRIP );
		glTexCoord2f(  0.0f,  1.0f );
		glVertex2f  ( -1.0f,  1.0f );
		glTexCoord2f(  0.0f,  0.0f );
		glVertex2f  ( -1.0f,  0.5f );
		glTexCoord2f(  1.0f,  1.0f );
		glVertex2f  ( -0.5f,  1.0f );
		glTexCoord2f(  1.0f,  0.0f );
		glVertex2f  ( -0.5f,  0.5f );
	glEnd();


	if ( !pBufferGlow->release() ) exit( 1 );

	//
	// Logo zeichnen
	// 
	drawKeys();

	glFlush();
}

void	quit3DEngine()
{
	wglMakeCurrent( hDC, hRC );

	delete pBufferGlow;
	delete pBufferBlur;
}


void renderModel()
{
	glPushMatrix();

	glEnable( GL_NORMALIZE );
	glDisable( GL_TEXTURE_2D );

	glRotatef( -(float)GetTickCount() * 0.01f, 0, 1, 0 );
	glScalef( 4.0f, 4.0f, 4.0f );

	render3DModel();

	glPopMatrix();
}

void renderPlane()
{
	glEnable( GL_TEXTURE_2D );
	texFloor->select();

	glBegin( GL_QUADS );
	const float height = -1.0f;
	glNormal3f( 0.0f, 1.0f, 0.0f );
	glTexCoord2f( 0.0f, 0.0f );
	glVertex3f( -10.0f, height, -10.0f );
	glTexCoord2f( 0.0f, 1.0f );
	glVertex3f( -10.0f, height, 10.0f );
	glTexCoord2f( 1.0f, 1.0f );
	glVertex3f( 10.0f, height, 10.0f );
	glTexCoord2f( 1.0f, 0.0f );
	glVertex3f( 10.0f, height, -10.0f );
	glEnd();
}