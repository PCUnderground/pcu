// simple NMF to OBJ converter and tangent space calculation
// based on ATI normalmapper code, requires normal mapper source code package
// Carsten Dachsbacher, 2003

#include <windows.h>
#include <stdio.h>
#include <float.h>
#include <math.h>
#include "NmFileIO.h"


// Geomtery data
int nTriangles = 0;
int nVertices  = 0;

NmRawTriangle    *pTriangles = NULL;
NmTangentPointD  *pVertices  = NULL;
NmIndex          *pIndices   = NULL;

void main( int argc, char *argv[] )
{
	int v;

	if ( argc != 3 )
	{
		printf( "syntax: nmf2obj input.nmf output.obj\n\n" );
		exit( 1 );
	}

	FILE *fp = fopen ( argv[ 1 ], "rb" );
	
	if ( fp == NULL )
	{
		printf( "[ERROR]: unable to open file !\n" );
		exit( 1 );
	}
	
	if ( !NmReadTriangles( fp, &nTriangles, &pTriangles ) )
	{
		printf( "[ERROR]: unable to open file !\n" );
		exit(1);
	}

	fclose( fp );
	
	// create vertex buffers, used for creating the tangent space etc.
	if ( !NmCreateVertexBuffers( nTriangles, pTriangles, &nVertices, &pVertices, &pIndices ) )
		exit(1);

	// ATI code for scaling/normalizing the object
	float bbox[ 6 ];
	bbox[ 0 ] =  FLT_MAX; // X min
	bbox[ 1 ] =  FLT_MAX; // Y min
	bbox[ 2 ] =  FLT_MAX; // Z min
	bbox[ 3 ] = -FLT_MAX; // X max
	bbox[ 4 ] = -FLT_MAX; // Y max
	bbox[ 5 ] = -FLT_MAX; // Z max
	
	for ( v = 0; v < nVertices; v++)
	{
		if (pVertices[v].vertex[0] < bbox[0])
		{
			bbox[0] = (float)pVertices[v].vertex[0];
		}
		if (pVertices[v].vertex[0] > bbox[3])
		{
			bbox[3] = (float)pVertices[v].vertex[0];
		}
		if (pVertices[v].vertex[1] < bbox[1])
		{
			bbox[1] = (float)pVertices[v].vertex[1];
		}
		if (pVertices[v].vertex[1] > bbox[4])
		{
			bbox[4] = (float)pVertices[v].vertex[1];
		}
		if (pVertices[v].vertex[2] < bbox[2])
		{
			bbox[2] = (float)pVertices[v].vertex[2];
		}
		if (pVertices[v].vertex[2] > bbox[5])
		{
			bbox[5] = (float)pVertices[v].vertex[2];
		}
	}
	float dx = bbox[3] - bbox[0];
	float dy = bbox[4] - bbox[1];
	float dz = bbox[5] - bbox[2];
	float center[3];
	center[0] = (dx)/2.0f + bbox[0];
	center[1] = (dy)/2.0f + bbox[1];
	center[2] = (dz)/2.0f + bbox[2];
	
	// Center on the origin and rescale to be 50 units maximum
	float scale = 1.0f;
	if ( dx > dy )
	{
		if ( dx > dz )
			scale = 50.0f / dx;	else
			scale = 50.0f / dz;
	} else
	{
		if ( dy > dz )
			scale = 50.0f / dy;	else
			scale = 50.0f / dz;
	}

	for ( v = 0; v < nVertices; v++)
	{
		pVertices[ v ].vertex[ 0 ] -= center[ 0 ];
		pVertices[ v ].vertex[ 1 ] -= center[ 1 ];
		pVertices[ v ].vertex[ 2 ] -= center[ 2 ];
		pVertices[ v ].vertex[ 0 ] *= scale;
		pVertices[ v ].vertex[ 1 ] *= scale;
		pVertices[ v ].vertex[ 2 ] *= scale;
	}
	
	//
	// Export Data here !!!!
	//
	
	FILE *f = fopen( argv[ 2 ], "wt" );
	
	int i;
	
	for ( i = 0; i < nVertices; i++ )
		fprintf( f, "v %f %f %f\n", pVertices[ i ].vertex[ 0 ], pVertices[ i ].vertex[ 1 ], pVertices[ i ].vertex[ 2 ] );
	
	// attention: not standard conform OBJ token:
	// "vx": tangent space = three vectors
	for ( i = 0; i < nVertices; i++ )
		fprintf( f, "vx %f %f %f %f %f %f %f %f %f\n", 
		pVertices[ i ].normal[ 0 ],   pVertices[ i ].normal[ 1 ],   pVertices[ i ].normal[ 2 ],
		pVertices[ i ].tangent[ 0 ],  pVertices[ i ].tangent[ 1 ],  pVertices[ i ].tangent[ 2 ],
		pVertices[ i ].binormal[ 0 ], pVertices[ i ].binormal[ 1 ], pVertices[ i ].binormal[ 2 ] );
	
	for ( i = 0; i < nVertices; i++ )
		fprintf( f, "vt %f %f\n", pVertices[ i ].uv[ 0 ], pVertices[ i ].uv[ 1 ] );
	
	for ( i = 0; i < nTriangles; i++ )
		fprintf( f, "f %d/%d/%d %d/%d/%d %d/%d/%d\n", 
		pIndices[ i ].idx[ 0 ]+1, pIndices[ i ].idx[ 0 ]+1, pIndices[ i ].idx[ 0 ]+1, 
		pIndices[ i ].idx[ 1 ]+1, pIndices[ i ].idx[ 1 ]+1, pIndices[ i ].idx[ 1 ]+1, 
		pIndices[ i ].idx[ 2 ]+1, pIndices[ i ].idx[ 2 ]+1, pIndices[ i ].idx[ 2 ]+1 );
	
	fclose( f );
}