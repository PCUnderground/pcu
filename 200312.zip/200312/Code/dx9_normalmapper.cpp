   //  
  // PC Underground: HLSL + ATI Normalmapper
 // (w)(c)2003 Carsten Dachsbacher
//

#include <windows.h>
#include <d3dx9.h>
#include "resource.h"

// F�r Pixel Shader 2.0 Karten: diese Option w�hlen
//#define USE_PS20

const bool  DX9Fullscreen = FALSE;
const DWORD	DX9ScreenX    = 800;
const DWORD	DX9ScreenY    = 800;
const DWORD DX9Refresh    = 75;

const char windowTitle[] = "PCUvsD3D9";

HWND					gHWND      = NULL;
LPDIRECT3D9				pD3D       = NULL;
LPDIRECT3DDEVICE9		pD3DDevice = NULL;

LPDIRECT3DVERTEXBUFFER9	pMeshVB	   = NULL;

LPDIRECT3DTEXTURE9      pNormalTexture = NULL;

LPD3DXEFFECT            pEffect        = NULL;
LPD3DXFONT				pD3DXFont      = NULL;

DWORD					renderMode = 0;

#include <stdio.h>
#include "obj.h"

  //
 // prototypes
//
int WINAPI WinMain( HINSTANCE hInst, HINSTANCE hPrevInst,
                    LPSTR lpCmdLine, int nCmdShow );

void	initialize3D();
void	shutdown3D();
void	render3D();
void	loadModel( char *model );

  //
 // WindowProc: Window Class Message Handler
//
LRESULT CALLBACK WindowProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
    switch( msg )
	{
        case WM_KEYDOWN:
			if ( wParam == VK_ESCAPE )
				PostQuitMessage(0);

			if ( wParam == '1' ) renderMode = 0;
			if ( wParam == '2' ) renderMode = 1;
			if ( wParam == '3' ) renderMode = 2;

			if ( wParam == 'A' ) loadModel( "dragon" );
			if ( wParam == 'B' ) loadModel( "bunny" );
	        break;

		case WM_CLOSE:
        case WM_DESTROY:
            PostQuitMessage(0);
	        break;

		default:
			return DefWindowProc( hWnd, msg, wParam, lParam );
	}

	return 0;
}

  //
 // WinMain: Register Window Class, Create Window and wait until program end
//
int WINAPI WinMain( HINSTANCE hInst,
                    HINSTANCE hPrevInst,
                    LPSTR     lpCmdLine,
                    int       nCmdShow )
{
	WNDCLASSEX wndClass;

	wndClass.lpszClassName = "PCUvsD3D9";
	wndClass.cbSize        = sizeof( WNDCLASSEX );
	wndClass.style         = CS_HREDRAW | CS_VREDRAW;
	wndClass.lpfnWndProc   = WindowProc;
	wndClass.cbClsExtra    = 0;
	wndClass.cbWndExtra    = 0;
	wndClass.hInstance     = hInst;
	wndClass.hIcon	       = LoadIcon( hInst, (LPCTSTR)IDI_PCUICON );
	wndClass.hCursor       = LoadCursor( NULL, IDC_ARROW );
	wndClass.hbrBackground = (HBRUSH)GetStockObject( BLACK_BRUSH );
    wndClass.hIconSm	   = NULL;
	wndClass.lpszMenuName  = NULL;

	if( RegisterClassEx( &wndClass) == 0 ) return E_FAIL;

	DWORD windowParam;

	if ( DX9Fullscreen )
		windowParam = WS_POPUP | WS_SYSMENU | WS_VISIBLE; else
		windowParam = WS_OVERLAPPEDWINDOW | WS_VISIBLE;

	gHWND = CreateWindowEx( NULL, "PCUvsD3D9", windowTitle,
							 windowParam, 0, 0, 
							 DX9ScreenX, DX9ScreenY, 
							 NULL, NULL, hInst, NULL );

	if( gHWND == NULL ) return E_FAIL;

    ShowWindow( gHWND, nCmdShow );
    UpdateWindow( gHWND );

	initialize3D();
  
	MSG msg;
	ZeroMemory( &msg, sizeof( msg ) );

	while( msg.message != WM_QUIT )
	{
		if( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) )
		{ 
			TranslateMessage( &msg );
			DispatchMessage ( &msg );
		} else
		    render3D();
	}

	shutdown3D();

    UnregisterClass( "PCUvsD3D9", wndClass.hInstance );

	return msg.wParam;
}


  //
 // error: Display error message and quit program
//
void error( char *msg = NULL )
{
	if ( msg )
		MessageBox( NULL, msg, "PCUvsDX9", MB_OK | MB_ICONEXCLAMATION ); else
		MessageBox( NULL, "Error occured !", "PCUvsDX9", MB_OK | MB_ICONEXCLAMATION );

	shutdown3D();

	exit( 1 );
}

OBJmodel *obj3D = NULL;


  //
 // initializeEffect: initializes the HLSL effect in the fx file
//
void initializeEffect( void )
{
	HRESULT hr;
	LPD3DXBUFFER pBufferErrors = NULL;

	hr = D3DXCreateEffectFromFile( pD3DDevice, 
		                           "pcu.fx",
		                           NULL, 
		                           NULL, 
		                           0, 
		                           NULL, 
		                           &pEffect, 
		                           &pBufferErrors );

	if( FAILED(hr) )
	{
		LPVOID pCompilErrors = pBufferErrors->GetBufferPointer();
		MessageBox(NULL, (const char*)pCompilErrors, "Fx Compile Error",
			MB_OK|MB_ICONEXCLAMATION);
	}
	
}

void createFont( void )
{
    HDC   hDC;
    HFONT hFont;
    int   fontHeight;
    int   fontPointSize = 11;

    hDC = GetDC( NULL );

    fontHeight = -( MulDiv( fontPointSize, GetDeviceCaps( hDC, LOGPIXELSY ), 72 ) );

    ReleaseDC( NULL, hDC );

    hFont = CreateFont( fontHeight, 
        0, 0, 0,
        FW_DONTCARE,
        false, false, false,
        DEFAULT_CHARSET,
        OUT_DEFAULT_PRECIS,
        CLIP_DEFAULT_PRECIS,
        DEFAULT_QUALITY,
        DEFAULT_PITCH | FF_DONTCARE,
        "Tahoma" );

    if( hFont != NULL )
    {
        if( FAILED( D3DXCreateFont( pD3DDevice, hFont, &pD3DXFont ) ) )
        {
            MessageBox( NULL, "error creating font", "PCUvsD3D9", MB_OK );
        }

		DeleteObject( hFont );
    } else
		MessageBox( NULL, "error creating font", "PCUvsD3D9", MB_OK );
}

void	loadModel( char *model )
{
	if ( obj3D != NULL )
	{
		delete obj3D;
		obj3D = NULL;
	}

	if ( pNormalTexture != NULL )
	{
		pNormalTexture->Release();
		pNormalTexture = NULL;
	}

	char buf[ 512 ];
	sprintf( buf, "./data/%s.obj", model );
	obj3D = new OBJmodel();
	obj3D->readOBJ( buf );

	sprintf( buf, "./data/%s.bmp", model );
	D3DXCreateTextureFromFile( pD3DDevice, buf, &pNormalTexture );

	obj3D->scaleIsotropic();
	obj3D->buildVertexBuffer( pD3DDevice, RENDER_TANGENT_SPACE_UV );

}

  //
 // initialize3D: initialize Direct3D stuff
//
void initialize3D( void )
{
	HRESULT			hr;
	D3DDISPLAYMODE	dm;

    pD3D = Direct3DCreate9( D3D_SDK_VERSION );

	if( pD3D == NULL ) error( "Error creating Direct3D Object" );

	if ( DX9Fullscreen )
	{
		// fullscreen
		//
		int nMaxModes = pD3D->GetAdapterModeCount( D3DADAPTER_DEFAULT, D3DFMT_X8R8G8B8 );

		bool foundMode = false;

		for( int m = 0; m < nMaxModes; m ++ )
		{
		  if ( FAILED( pD3D->EnumAdapterModes( D3DADAPTER_DEFAULT, 
											   D3DFMT_X8R8G8B8, m, &dm ) ) )
			 error( "Error enumerating adapter mode" );

		  if ( dm.Width  != DX9ScreenX || 
			   dm.Height != DX9ScreenY ||
			   dm.RefreshRate != DX9Refresh ||
			   dm.Format != D3DFMT_X8R8G8B8 )
			   continue;

		  foundMode = true;
		  break;
		}

		if ( foundMode == false )
		  error( "Not suitable graphic mode found !" );

		if ( FAILED( pD3D->CheckDeviceType( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL,
											D3DFMT_X8R8G8B8, D3DFMT_X8R8G8B8, FALSE ) ) )
		   error( "No hardware acceleration for this graphic mode !" );
	} else
	{
		// windowed
		//
		if( FAILED( pD3D->GetAdapterDisplayMode( D3DADAPTER_DEFAULT, &dm ) ) )
			error( "Error getting Adapter Display Mode" );
	}

	hr = pD3D->CheckDeviceFormat( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, 
								  dm.Format, D3DUSAGE_DEPTHSTENCIL,
								  D3DRTYPE_SURFACE, D3DFMT_D16 );

	if ( hr == D3DERR_NOTAVAILABLE ) error( "Desired Z-Buffer Format (16Bit) not available" );

	D3DCAPS9 caps;

	if( FAILED( pD3D->GetDeviceCaps( D3DADAPTER_DEFAULT, 
									 D3DDEVTYPE_HAL, &caps ) ) )
		error( "Error reading Device Caps" );
	
	DWORD flags = 0;

	if( caps.VertexProcessingCaps != 0 )
		flags |= D3DCREATE_HARDWARE_VERTEXPROCESSING;
	else
		flags |= D3DCREATE_SOFTWARE_VERTEXPROCESSING;

	D3DPRESENT_PARAMETERS pp;
	ZeroMemory( &pp, sizeof( pp ) );

	pp.BackBufferFormat       = dm.Format;
	pp.SwapEffect             = D3DSWAPEFFECT_DISCARD;
	pp.Windowed               = !DX9Fullscreen;
	pp.EnableAutoDepthStencil = TRUE;
	pp.AutoDepthStencilFormat = D3DFMT_D16;
	pp.BackBufferWidth        = DX9ScreenX;
    pp.BackBufferHeight       = DX9ScreenY;
    pp.BackBufferFormat       = D3DFMT_X8R8G8B8;

	if( FAILED( pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, gHWND,
									  flags, &pp, &pD3DDevice ) ) )
		error( "Error creating Direct3D device" );


	//
	// Init Demo Stuff
	//
	pD3DDevice->SetRenderState( D3DRS_LIGHTING, FALSE );
	pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

	pD3DDevice->SetRenderState( D3DRS_ZENABLE, TRUE );
	pD3DDevice->SetRenderState( D3DRS_ZFUNC, D3DCMP_LESSEQUAL );

	pD3DDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID );

	obj3D = new OBJmodel();
	obj3D->readOBJ( "./data/dragon.obj" );

	D3DXCreateTextureFromFile( pD3DDevice, "./data/dragon.bmp", &pNormalTexture );

	obj3D->scaleIsotropic();
	
	obj3D->buildVertexBuffer( pD3DDevice, RENDER_TANGENT_SPACE_UV );

	//
	// Vertex/Pixel Shader
	//

#ifdef USE_PS20
	if ( caps.PixelShaderVersion < D3DVS_VERSION(2,0) )
		exit( 1 );
#else
	if ( caps.PixelShaderVersion < D3DVS_VERSION(1,1) )
		exit( 1 );
#endif

	if ( caps.VertexShaderVersion < D3DVS_VERSION(1,1) )
		exit( 1 );



	initializeEffect();
	createFont();
}

void	renderScene()
{
	// set up matrices
	D3DXMATRIX mProjection;

	float zNear = 3.0f, zFar = 30.0f;

	D3DXMatrixPerspectiveFovLH( &mProjection, 45.0f, (float)DX9ScreenX/(float)DX9ScreenY, zNear, zFar );
	pD3DDevice->SetTransform( D3DTS_PROJECTION, &mProjection );

	float time = GetTickCount() * 0.03f;
    float rotateZ = 0.0f;
	float rotateY = -90.0f*0;
	float rotateX = time * 0.7f;
	
    D3DXMATRIX matWorld;
    D3DXMATRIX matTrans;
    D3DXMATRIX matScale;
	D3DXMATRIX matRot;
	D3DXMATRIX matView;
	D3DXMATRIX matWorldInverse;

    D3DXMatrixIdentity( &matView );


	D3DXVECTOR4	cameraPos = D3DXVECTOR4( 10.0f, 5.0f, 10.0f, 1.0f );
//	D3DXVECTOR4	lightPos = D3DXVECTOR4( 0.0f, -2.0f, -10.0f, 1.0f );
	D3DXVECTOR4	lightPos = D3DXVECTOR4( 0.0f, 0.0f, 12.0f, 1.0f );

	D3DXMatrixLookAtLH( &matView,
						(D3DXVECTOR3*)&cameraPos,
						&D3DXVECTOR3( 0.0, 0.0, 0.0 ),
						&D3DXVECTOR3( 0.0, 1.0, 0.0 ) );


	// rotation matrix
	D3DXMatrixRotationYawPitchRoll( &matRot, D3DXToRadian( rotateX ),  D3DXToRadian( rotateY ), D3DXToRadian( rotateZ ) );

	D3DXMatrixScaling( &matScale, 0.6f, 0.6f, 0.6f );

    matWorld = matRot;
    pD3DDevice->SetTransform( D3DTS_WORLD, &matWorld );

	D3DXMatrixInverse( &matWorldInverse, NULL, &matWorld );

	D3DXVECTOR4 lightPosObjectSpace;
	D3DXVECTOR4 cameraPosObjectSpace;

	// transform viewer and light into object space
	D3DXVec4Transform( &lightPosObjectSpace, &lightPos, &matWorldInverse );
	D3DXVec4Transform( &cameraPosObjectSpace, &cameraPos, &matWorldInverse );

	pEffect->SetVector( "lightPosition", &lightPosObjectSpace );
	pEffect->SetVector( "cameraPosition", &cameraPosObjectSpace );

	// set technique
	switch ( renderMode )
	{
	case 0:
#ifdef USE_PS20
		pEffect->SetTechnique( "NormalMapper20" );
#else
		pEffect->SetTechnique( "NormalMapper11" );
#endif
		break;
	case 1:
		pEffect->SetTechnique( "Gouraud" );
		break;
	case 2:
		pEffect->SetTechnique( "Normals" );
		break;
	case 3:
		break;
	}

	// set parameters
    D3DXMATRIX worldViewProjection = matWorld * matView * mProjection;
	D3DXMatrixTranspose( &worldViewProjection, &worldViewProjection );
	
	pEffect->SetMatrix( "matWVP", &worldViewProjection );

	pEffect->SetTexture( "normalTexture", pNormalTexture );

    D3DXMATRIX worldView = matRot * matView;
	D3DXMatrixTranspose( &worldView, &worldView );

	pEffect->SetMatrix( "matWV", &worldView );

	UINT nPasses;
    pEffect->Begin( &nPasses, 0 );
    
    for( UINT p = 0; p < nPasses; p++ )
    {
        pEffect->Pass( p );

		obj3D->drawModel( pD3DDevice );
    }
 
    pEffect->End();

}


  //
 // render3D: render loop
//
void render3D()
{
	//
	// -= Render Camera View =-
	//
    pD3DDevice->Clear( 0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
                       0x00707070, 1.0f, 0 );

    pD3DDevice->BeginScene();

	renderScene();

	if ( pD3DXFont )
	{
		RECT destRect1;

		char buf[80], buf2[80], buf3[80], buf4[80];

		sprintf( buf4, "Object Space Bump Mapping - (w)(c)2003 Carsten Dachsbacher" );
		sprintf( buf2, "hit 1, 2, or 3 for render modes, A or B for models" );

		switch ( renderMode )
		{
		case 0: sprintf( buf, "render mode: normal mapper" ); break;
		case 1: sprintf( buf, "render mode: gouraud shading" ); break;
		case 2: sprintf( buf, "render mode: show normals" ); break;
		}

		sprintf( buf3, "vertices: %d, triangles: %d", obj3D->getNVertices(), obj3D->getNTriangles() );

		pD3DXFont->Begin();
		{
			SetRect( &destRect1, 5, 5, 0, 0 );
			pD3DXFont->DrawText( buf4, -1, &destRect1, DT_SINGLELINE, 
				D3DCOLOR_COLORVALUE(1.0f, 1.0f, 1.0f, 1.0f) );
	
			SetRect( &destRect1, 5, 25, 0, 0 );
			pD3DXFont->DrawText( buf2, -1, &destRect1, DT_SINGLELINE, 
				D3DCOLOR_COLORVALUE(1.0f, 1.0f, 1.0f, 1.0f) );
	
			SetRect( &destRect1, 5, 45, 0, 0 );
			pD3DXFont->DrawText( buf, -1, &destRect1, DT_SINGLELINE, 
				D3DCOLOR_COLORVALUE(1.0f, 1.0f, 1.0f, 1.0f) );

			SetRect( &destRect1, 5, 65, 0, 0 );
			pD3DXFont->DrawText( buf3, -1, &destRect1, DT_SINGLELINE, 
				D3DCOLOR_COLORVALUE(1.0f, 1.0f, 1.0f, 1.0f) );
		}
		pD3DXFont->End();
	}

    pD3DDevice->EndScene();

    pD3DDevice->Present( NULL, NULL, NULL, NULL );
}

  //
 // shutdown3D: free Direct3D ressources
//
void shutdown3D()
{
	if ( pNormalTexture != NULL )
		pNormalTexture->Release();

	if ( pD3DXFont != NULL )
		pD3DXFont->Release();

	if ( pEffect != NULL )
		pEffect->Release();

	delete obj3D;

    if( pD3DDevice != NULL )
        pD3DDevice->Release();

    if( pD3D != NULL )
        pD3D->Release();
}

