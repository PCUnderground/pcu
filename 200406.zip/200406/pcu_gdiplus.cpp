   //  
  // PC Underground: GDI+ Einfaches Demo
 // (w)(c)2004 Carsten Dachsbacher
//
#pragma comment(lib, "gdiplus.lib")
#pragma comment(lib, "ole32.lib")

#include <windows.h>
#include <math.h>
#include <stdio.h>
#include <gdiplus.h>
#include <gdiplusimaging.h>

using namespace Gdiplus;

#include "resource.h"


LRESULT CALLBACK DialogWindowProc   ( HWND, UINT, WPARAM, LPARAM );

static HINSTANCE	hInstance;
static ULONG_PTR	gdiplusToken;

//
// Win Main
//
int APIENTRY WinMain( HINSTANCE _hInstance, HINSTANCE hPrevInstance, 
					  LPSTR lpszCmdParam, int cmdShow )
{
	hInstance = _hInstance;

	// Initialize GDI+
	GdiplusStartupInput gdiplusStartupInput;
	GdiplusStartup( &gdiplusToken, &gdiplusStartupInput, NULL );

	DialogBox( hInstance, (LPCTSTR)IDD_ABOUTBOX, NULL, (DLGPROC)DialogWindowProc );

	GdiplusShutdown( gdiplusToken );	

	return 0;
}

//
// Diese Methode sucht die Class-ID eines Encoders (aus der MSDN Library)
//
int GetEncoderClsid(const WCHAR* format, CLSID* pClsid)
{
   UINT  num = 0;          // number of image encoders
   UINT  size = 0;         // size of the image encoder array in bytes

   ImageCodecInfo *pImageCodecInfo = NULL;

   GetImageEncodersSize(&num, &size);
   if(size == 0)
      return -1;  // Failure

   pImageCodecInfo = (ImageCodecInfo*)(malloc(size));
   if(pImageCodecInfo == NULL)
      return -1;  // Failure

   GetImageEncoders(num, size, pImageCodecInfo);

   for(UINT j = 0; j < num; ++j)
   {
      if( wcscmp(pImageCodecInfo[j].MimeType, format) == 0 )
      {
         *pClsid = pImageCodecInfo[j].Clsid;
         free(pImageCodecInfo);
         return j;  // Success
      }    
   }

   free(pImageCodecInfo);
   return -1;  // Failure
}


void saveBitmap( char *filename, Bitmap *bmp )
{
	// Create stream with 0 size
	IStream *stream = NULL;

	if ( CreateStreamOnHGlobal( NULL, TRUE, (LPSTREAM*)&stream ) != S_OK )
	{
		// Stream im Global Memory konnte nicht angelegt werden !
		return;
	}

	// Die Encoder der Standard Installation sind:
	//    image/bmp
	//    image/jpeg
	//    image/gif
	//    image/tiff
	//    image/png
	CLSID jpegClsid;
	GetEncoderClsid( L"image/jpeg", &jpegClsid );

	// Encoder Parameter festlegen
	EncoderParameters encoderParameters;
	encoderParameters.Count = 1;
	encoderParameters.Parameter[ 0 ].Guid = EncoderQuality;
	encoderParameters.Parameter[ 0 ].Type = EncoderParameterValueTypeLong;
	encoderParameters.Parameter[ 0 ].NumberOfValues = 1;

	// Compression Level
	ULONG quality = 80;
	encoderParameters.Parameter[ 0 ].Value = &quality;

	ULARGE_INTEGER	compressedSize;
	LARGE_INTEGER	libMove;
	
	libMove.QuadPart = 0;

	// Jetzt schreiben wir das Bitmap in den Output Stream mithilfe des gew�hlten Encoders
	if ( bmp->Save( stream, &jpegClsid, &encoderParameters ) == Ok &&
		 stream->Seek( libMove, STREAM_SEEK_END, &compressedSize ) == S_OK &&
		 stream->Seek( libMove, STREAM_SEEK_SET, NULL ) == S_OK )
	{
		// Das Encoding hat geklappt, die Gr��e der Daten ist bekannt
		// also ab damit in ein File !
		FILE *f = fopen( filename, "wb" );
		if ( f )
		{
			// erstmal Speicher daf�r allokieren
			char *buf = new char[ (int)compressedSize.QuadPart ];

			// Und die Daten aus dem Stream dorthin kopieren
			ULONG bytesRead;
			if ( stream->Read( buf, (int)compressedSize.QuadPart, &bytesRead ) == S_OK )
			{
				fwrite( buf, bytesRead, 1, f );
				fclose( f );
			}
			delete buf;
		}
	}
	
	// Speicher wieder freigeben
	stream->Release();
}





//
// Das ist der Message Handler f�r die "About Box"
// Er verwendet GDI+ f�r die WM_PAINT Message
//
LRESULT CALLBACK DialogWindowProc( HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam )
{

	switch (message)
	{
		case WM_INITDIALOG:
			SetTimer( hDlg, 1000, 20, NULL);
			return true;

		case WM_TIMER:
		{
			RECT rect;
			GetClientRect( hDlg, &rect );
			InvalidateRect( hDlg, &rect, false );
		}

		case WM_PAINT:
		{

			HDC	hdc = GetDC( hDlg );
			
			// Graphics Objekt f�r den DC des Dialogs anlegen
			Graphics graphics( hdc );

			RECT rect;
			GetClientRect( hDlg, &rect );

			// Ein Bitmap mit derselben Gr��e anlegen
			Bitmap bmp( rect.right, rect.bottom );

			// und ein Graphics Objekt anlegen, das mit dem Bild assoziiert ist
			Graphics* graph = Graphics::FromImage( &bmp );
   
			Image image(L"./data/image.jpg");
			TextureBrush brush( &image, WrapModeTile );


			// Ein bisschen zeitabh�ngige Transformation des Bitmaps
			float time = (float)GetTickCount();
			brush.TranslateTransform( sinf( time * 0.00002f ) * 64.0f, cosf( time * 0.00032f ) * 64.0f, MatrixOrderPrepend );
			brush.RotateTransform( time * 0.01f, MatrixOrderPrepend );
			brush.ScaleTransform( 
				sinf( time * 0.0000824f ) + 1.5f, 
				sinf( time * 0.0000824f ) + 1.5f, MatrixOrderPrepend );


			// und Zeichnen !
			graph->FillRectangle( &brush, *(Rect*)&rect );


			static int ctime = 0;
			ctime += 50;
			for ( int i = 0; i < 32; i++ )
			{
				Pen pen( Color( i * 8, 0, 255, 0 ), 2 );

				int xs = (int)( cosf( (ctime+i*128) * 0.000721f ) * 127.0f + 127.0f );
				int ys = (int)( sinf( (ctime+i*128) * 0.000231f ) * 127.0f + 127.0f );
				int xe = (int)( cosf( (ctime+i*128) * 0.000352f ) * 127.0f + 127.0f );
				int ye = (int)( sinf( (ctime+i*128) * 0.000563f ) * 127.0f + 127.0f );

				graph->DrawLine( &pen, xs, ys, xe, ye );
			}

			FontFamily  fontFamily( L"Arial" );
	
			Font		font( &fontFamily, 35, FontStyleItalic | FontStyleBold, UnitPixel );

			PointF      position(5.0f, 55.0f);
		
			LinearGradientBrush 
				brushGradient( *(Rect*)&rect,				// Gradient soll �ber das ganze Fenster verlaufen
					Color( 128, 255, 255,   0 ),			// halb-transparentes gelb
					Color( 255,   0,   0, 255 ),			// opakes blau
					(float)GetTickCount() * -0.01f, TRUE );	// Gradient Winkel

		
			SolidBrush brushSolid( Color( 255, 255, 255, 255 ) );
		
			graph->DrawString( L"PC\nUnderground", -1, &font, position, &brushGradient);


			// Und das Bild in den Dialog zeichnen
			graphics.DrawImage( &bmp, *(Rect*)&rect );

			//saveBitmap( "screenshot.jpg", &bmp );

			ValidateRect( hDlg, &rect );
		}
		return true;

		case WM_COMMAND:
			switch ( LOWORD( wParam ) )
			{
				case IDOK:
				case IDCANCEL:
					EndDialog( hDlg, 0 );
					return true;
			}
			return true;

	}
    return false;
}







