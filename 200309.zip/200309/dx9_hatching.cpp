   //  
  // PC Underground: DX9 Part III
 // (w)(c)2003 Carsten Dachsbacher
//

#include <windows.h>
#include <d3dx9.h>
#include "resource.h"

const bool  DX9Fullscreen = FALSE;
const DWORD	DX9ScreenX    = 800;
const DWORD	DX9ScreenY    = 600;
const DWORD DX9Refresh    = 75;

const char windowTitle[] = "PCUvsD3D9 OBJ Hatching";


HWND					gHWND      = NULL;
LPDIRECT3D9				pD3D       = NULL;
LPDIRECT3DDEVICE9		pD3DDevice = NULL;

LPDIRECT3DVERTEXBUFFER9	pMeshVB	   = NULL;

LPDIRECT3DVERTEXSHADER9 pVertexShader = NULL;
LPDIRECT3DPIXELSHADER9  pPixelShader  = NULL;

LPDIRECT3DTEXTURE9      pTextureH0    = NULL;
LPDIRECT3DTEXTURE9      pTextureH1    = NULL;
LPDIRECT3DTEXTURE9      pTextureH2    = NULL;
LPDIRECT3DTEXTURE9      pTextureH3    = NULL;

#include <stdio.h>
#include "vertex3dop.h"
#include "obj.h"

  //
 // prototypes
//
int WINAPI WinMain( HINSTANCE hInst, HINSTANCE hPrevInst,
                    LPSTR lpCmdLine, int nCmdShow );

void	initialize3D();
void	shutdown3D();
void	render3D();

  //
 // WindowProc: Window Class Message Handler
//
LRESULT CALLBACK WindowProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
    switch( msg )
	{
        case WM_KEYDOWN:
			if ( wParam == VK_ESCAPE )
				PostQuitMessage(0);

/*			if ( wParam == VK_F1 ) activeLight = 0;
			if ( wParam == VK_F2 ) activeLight = 1;
			if ( wParam == VK_F3 ) activeLight = 2;*/
	        break;

		case WM_CLOSE:
        case WM_DESTROY:
            PostQuitMessage(0);
	        break;

		default:
			return DefWindowProc( hWnd, msg, wParam, lParam );
	}

	return 0;
}

  //
 // WinMain: Register Window Class, Create Window and wait until program end
//
int WINAPI WinMain( HINSTANCE hInst,
                    HINSTANCE hPrevInst,
                    LPSTR     lpCmdLine,
                    int       nCmdShow )
{
	WNDCLASSEX wndClass;

	wndClass.lpszClassName = "PCUvsD3D9";
	wndClass.cbSize        = sizeof( WNDCLASSEX );
	wndClass.style         = CS_HREDRAW | CS_VREDRAW;
	wndClass.lpfnWndProc   = WindowProc;
	wndClass.cbClsExtra    = 0;
	wndClass.cbWndExtra    = 0;
	wndClass.hInstance     = hInst;
	wndClass.hIcon	       = LoadIcon( hInst, (LPCTSTR)IDI_PCUICON );
	wndClass.hCursor       = LoadCursor( NULL, IDC_ARROW );
	wndClass.hbrBackground = (HBRUSH)GetStockObject( BLACK_BRUSH );
    wndClass.hIconSm	   = NULL;
	wndClass.lpszMenuName  = NULL;

	if( RegisterClassEx( &wndClass) == 0 ) return E_FAIL;

	DWORD windowParam;

	if ( DX9Fullscreen )
		windowParam = WS_POPUP | WS_SYSMENU | WS_VISIBLE; else
		windowParam = WS_OVERLAPPEDWINDOW | WS_VISIBLE;

	gHWND = CreateWindowEx( NULL, "PCUvsD3D9", windowTitle,
							 windowParam, 0, 0, 
							 DX9ScreenX, DX9ScreenY, 
							 NULL, NULL, hInst, NULL );

	if( gHWND == NULL ) return E_FAIL;

    ShowWindow( gHWND, nCmdShow );
    UpdateWindow( gHWND );

	initialize3D();
  
	MSG msg;
	ZeroMemory( &msg, sizeof( msg ) );

	while( msg.message != WM_QUIT )
	{
		if( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) )
		{ 
			TranslateMessage( &msg );
			DispatchMessage ( &msg );
		} else
		    render3D();
	}

	shutdown3D();

    UnregisterClass( "PCUvsD3D9", wndClass.hInstance );

	return msg.wParam;
}


  //
 // error: Display error message and quit program
//
void error( char *msg = NULL )
{
	if ( msg )
		MessageBox( NULL, msg, "PCUvsDX9", MB_OK | MB_ICONEXCLAMATION ); else
		MessageBox( NULL, "Error occured !", "PCUvsDX9", MB_OK | MB_ICONEXCLAMATION );

	shutdown3D();

	exit( 1 );
}

OBJmodel *al;

  //
 // initialize3D: initialize Direct3D stuff
//
void initialize3D( void )
{
	HRESULT			hr;
	D3DDISPLAYMODE	dm;

    pD3D = Direct3DCreate9( D3D_SDK_VERSION );

	if( pD3D == NULL ) error( "Error creating Direct3D Object" );

	if ( DX9Fullscreen )
	{
		// fullscreen
		//
		int nMaxModes = pD3D->GetAdapterModeCount( D3DADAPTER_DEFAULT, D3DFMT_X8R8G8B8 );

		bool foundMode = false;

		for( int m = 0; m < nMaxModes; m ++ )
		{
		  if ( FAILED( pD3D->EnumAdapterModes( D3DADAPTER_DEFAULT, 
											   D3DFMT_X8R8G8B8, m, &dm ) ) )
			 error( "Error enumerating adapter mode" );

		  if ( dm.Width  != DX9ScreenX || 
			   dm.Height != DX9ScreenY ||
			   dm.RefreshRate != DX9Refresh ||
			   dm.Format != D3DFMT_X8R8G8B8 )
			   continue;

		  foundMode = true;
		  break;
		}

		if ( foundMode == false )
		  error( "Not suitable graphic mode found !" );

		if ( FAILED( pD3D->CheckDeviceType( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL,
											D3DFMT_X8R8G8B8, D3DFMT_X8R8G8B8, FALSE ) ) )
		   error( "No hardware acceleration for this graphic mode !" );
	} else
	{
		// windowed
		//
		if( FAILED( pD3D->GetAdapterDisplayMode( D3DADAPTER_DEFAULT, &dm ) ) )
			error( "Error getting Adapter Display Mode" );
	}

	hr = pD3D->CheckDeviceFormat( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, 
								  dm.Format, D3DUSAGE_DEPTHSTENCIL,
								  D3DRTYPE_SURFACE, D3DFMT_D16 );

	if ( hr == D3DERR_NOTAVAILABLE ) error( "Desired Z-Buffer Format (16Bit) not available" );

	D3DCAPS9 caps;

	if( FAILED( pD3D->GetDeviceCaps( D3DADAPTER_DEFAULT, 
									 D3DDEVTYPE_HAL, &caps ) ) )
		error( "Error reading Device Caps" );
	
	DWORD flags = 0;

	if( caps.VertexProcessingCaps != 0 )
		flags |= D3DCREATE_HARDWARE_VERTEXPROCESSING;
	else
		flags |= D3DCREATE_SOFTWARE_VERTEXPROCESSING;

	D3DPRESENT_PARAMETERS pp;
	ZeroMemory( &pp, sizeof( pp ) );

	pp.BackBufferFormat       = dm.Format;
	pp.SwapEffect             = D3DSWAPEFFECT_DISCARD;
	pp.Windowed               = !DX9Fullscreen;
	pp.EnableAutoDepthStencil = TRUE;
	pp.AutoDepthStencilFormat = D3DFMT_D16;
	pp.BackBufferWidth        = DX9ScreenX;
    pp.BackBufferHeight       = DX9ScreenY;
    pp.BackBufferFormat       = D3DFMT_X8R8G8B8;

	if( FAILED( pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, gHWND,
									  flags, &pp, &pD3DDevice ) ) )
		error( "Error creating Direct3D device" );


	//
	// Init Demo Stuff
	//

	//
	// Material Parameters
	//
	D3DMATERIAL9 mat;

	ZeroMemory( &mat, sizeof( D3DMATERIAL9 ) );

	mat.Ambient.r  =
	mat.Ambient.g  =
	mat.Ambient.b  =
	mat.Ambient.a  = 0.0f;
	mat.Diffuse.r  = 0.5f;
	mat.Diffuse.g  = 0.5f;
	mat.Diffuse.b  = 0.5f;
	mat.Diffuse.a  = 1.0f;
	mat.Specular.r =
	mat.Specular.g =
	mat.Specular.b =
	mat.Specular.a = 0.5f;
	mat.Power      = 20.0f;

	pD3DDevice->SetMaterial( &mat );

	//
	// Light Sources
	//
	D3DLIGHT9 light;
	
	ZeroMemory( &light, sizeof( D3DLIGHT9 ) );

	// common light parameter
	light.Diffuse.r  = 1.5f;
	light.Diffuse.g  = 1.5f;
	light.Diffuse.b  = 1.5f;
	light.Specular.r = 0.0f;
	light.Specular.g = 0.0f;
	light.Specular.b = 0.0f;
	light.Range      = 100.0f;
	light.Attenuation0 = 1.0f;
	light.Attenuation2 = 0.0f;

	// directional light
	light.Type = D3DLIGHT_DIRECTIONAL;

	light.Direction = D3DXVECTOR3( -1.0f, 1.0f, 4.0f );

	pD3DDevice->SetLight( 0, &light );

	// static render states
	pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );
	pD3DDevice->SetRenderState( D3DRS_LIGHTING, TRUE );
    pD3DDevice->SetRenderState( D3DRS_SPECULARENABLE, TRUE );

	pD3DDevice->SetRenderState( D3DRS_ZENABLE, TRUE );
	pD3DDevice->SetRenderState( D3DRS_ZFUNC, D3DCMP_LESSEQUAL );
	pD3DDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID );

	al = new OBJmodel();
	al->readOBJ( "./data/palace.obj" );

	al->scaleIsotropic();
	//al->buildVertexBuffer( pD3DDevice, RENDER_SMOOTH_SHADED | RENDER_MATERIAL );
	//al->buildVertexBuffer( pD3DDevice, RENDER_FLAT_SHADED   | RENDER_MATERIAL );
	//al->buildVertexBuffer( pD3DDevice, RENDER_SMOOTH_SHADED | RENDER_DIFFUSE_COLOR );
	al->buildVertexBuffer( pD3DDevice, RENDER_SMOOTH_SHADED );


	D3DXCreateTextureFromFile( pD3DDevice, "./data/hatch0.bmp", &pTextureH0 );
	D3DXCreateTextureFromFile( pD3DDevice, "./data/hatch1.bmp", &pTextureH1 );
	D3DXCreateTextureFromFile( pD3DDevice, "./data/hatch2.bmp", &pTextureH2 );
	D3DXCreateTextureFromFile( pD3DDevice, "./data/hatch3.bmp", &pTextureH3 );

	pD3DDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	pD3DDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
	pD3DDevice->SetSamplerState( 0, D3DSAMP_MIPFILTER, D3DTEXF_POINT  );
	pD3DDevice->SetSamplerState( 1, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	pD3DDevice->SetSamplerState( 1, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
	pD3DDevice->SetSamplerState( 1, D3DSAMP_MIPFILTER, D3DTEXF_POINT  );
	pD3DDevice->SetSamplerState( 2, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	pD3DDevice->SetSamplerState( 2, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
	pD3DDevice->SetSamplerState( 2, D3DSAMP_MIPFILTER, D3DTEXF_POINT  );
	pD3DDevice->SetSamplerState( 3, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	pD3DDevice->SetSamplerState( 3, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
	pD3DDevice->SetSamplerState( 3, D3DSAMP_MIPFILTER, D3DTEXF_POINT  );

	//
	// Vertex Shader
	//

	if ( caps.VertexShaderVersion < D3DVS_VERSION(1,0) )
		exit( 1 );

    DWORD dwFlags = 0;
    LPD3DXBUFFER pCode;

    D3DXAssembleShaderFromFile( "hatching.vp", NULL, NULL, dwFlags, &pCode, NULL );
	pD3DDevice->CreateVertexShader( (DWORD*)pCode->GetBufferPointer(), &pVertexShader );
	pCode->Release();

	//
	// Pixel Shader
	//
    hr = D3DXAssembleShaderFromFile( "hatching.ps", NULL, NULL, dwFlags, &pCode, NULL );
	pD3DDevice->CreatePixelShader( (DWORD*)pCode->GetBufferPointer(), &pPixelShader );
	pCode->Release();
}

  //
 // render3D: render loop
//
void render3D()
{
	pD3DDevice->LightEnable( 0, TRUE );


    pD3DDevice->Clear( 0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
                       0x00303030, 1.0f, 0 );

    pD3DDevice->BeginScene();

	// set up matrices
	D3DXMATRIX mProjection;
	D3DXMatrixPerspectiveFovLH( &mProjection, 45.0f, (float)DX9ScreenX/(float)DX9ScreenY, 0.1f, 1000.0f );
	pD3DDevice->SetTransform( D3DTS_PROJECTION, &mProjection );

	float time = GetTickCount() * 0.03f;
    float rotateX = 0.0f;
	float rotateY = - 120.0f;
	float rotateZ = time * 0.7f;
	
    D3DXMATRIX matWorld;
    D3DXMATRIX matTrans;
	D3DXMATRIX matRot;
	D3DXMATRIX matView;

    D3DXMatrixIdentity( &matView );
	
	// camera distance
    D3DXMatrixTranslation( &matTrans, 0.0f, 1.0f, 12.0f );

	// rotation matrix
	D3DXMatrixRotationYawPitchRoll( &matRot, D3DXToRadian( rotateX ),  D3DXToRadian( rotateY ), D3DXToRadian( rotateZ ) );

    matWorld = matRot * matTrans;
    pD3DDevice->SetTransform( D3DTS_WORLD, &matWorld );

	//
	// set textures
	//
	pD3DDevice->SetTexture( 0, pTextureH3 );
	pD3DDevice->SetTexture( 1, pTextureH2 );
	pD3DDevice->SetTexture( 2, pTextureH1 );
    pD3DDevice->SetTexture( 3, pTextureH0 );

	//
	// set shaders + constants
	//
    pD3DDevice->SetVertexShader( pVertexShader );

    D3DXMATRIX modelViewProjection = matWorld * matView * mProjection;
	D3DXMatrixTranspose( &modelViewProjection, &modelViewProjection );

    // Load the combined model-view-projection matrix in registers c[0]-c[3]
    pD3DDevice->SetVertexShaderConstantF( 0, (float*)modelViewProjection, 4 );

	// Load a constant color into register c[4]
	float lightDirection[ 4 ] = { 0.0f, 0.0f, 1.0f, 0.0f };
	pD3DDevice->SetVertexShaderConstantF( 4, (float*)&lightDirection, 1 );

	pD3DDevice->SetPixelShader( pPixelShader );

	// render mesh
	al->drawModel( pD3DDevice );

    pD3DDevice->EndScene();

    pD3DDevice->Present( NULL, NULL, NULL, NULL );
}

  //
 // shutdown3D: free Direct3D ressources
//
void shutdown3D()
{
	if ( pTextureH0 != NULL )
		pTextureH0->Release();
	if ( pTextureH1 != NULL )
		pTextureH1->Release();
	if ( pTextureH2 != NULL )
		pTextureH2->Release();
	if ( pTextureH3 != NULL )
		pTextureH3->Release();


	delete al;

    if( pD3DDevice != NULL )
        pD3DDevice->Release();

    if( pD3D != NULL )
        pD3D->Release();
}



