////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  High Performance Rendering                            //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#ifndef _HPRENDER__H
#define _HPRENDER__H

#include "syndefines.h"

// NVidia Memory Locations
#define NV_VIDEOMEMORY  0
#define NV_AGPMEMORY    1
#define NV_SYSTEMMEMORY 2

// ATI Memory Optione
#define ATI_NO_VAO		0
#define ATI_VAO			1
#define ATI_VAO_PLUS_AE 2

// Rendermodi
#define RM_SHAREDVERTEX  0
#define RM_TRIANGLESTRIP 1

// allgemein: renderMode == RM_SHAREDVERTEX oder RM_TRIANGLESTRIP
extern U32 renderMode;

// f�r NVIDIA: NV_VIDEOMEMORY, NV_AGPMEMORY oder NV_SYSTEMMEMORY
extern U32 nvMemoryType;

// f�r ATI: ATI_NO_VAO (keine Extension nutzen), ATI_VAO (Array Objects) oder 
//          ATI_VAO_PLUS_AE (Array Objects und Array Elements)
extern U32	atiMemoryType;


extern void	init3DModel( char *triangleMesh );
extern void	render3DModel();
extern void	delete3DModel();

#endif