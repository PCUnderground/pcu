   //  
  // PC Underground: DX9 Part I (Initialization+Simple VertexBuffers)
 // (w)(c)2003 Carsten Dachsbacher
//

#include <windows.h>
#include <d3dx9.h>
#include "resource.h"

const bool  DX9Fullscreen = FALSE;
const DWORD	DX9ScreenX    = 640;
const DWORD	DX9ScreenY    = 480;
const DWORD DX9Refresh    = 75;


HWND              gHWND      = NULL;
LPDIRECT3D9       pD3D       = NULL;
LPDIRECT3DDEVICE9 pD3DDevice = NULL;

LPDIRECT3DVERTEXBUFFER9	pMeshVB = NULL;

#include <stdio.h>
#include "vertex3dop.h"
#include "example.h"

  //
 // prototypes
//
int WINAPI WinMain( HINSTANCE hInst, HINSTANCE hPrevInst,
                    LPSTR lpCmdLine, int nCmdShow );

void	initialize3D();
void	shutdown3D();
void	render3D();

  //
 // WindowProc: Window Class Message Handler
//
LRESULT CALLBACK WindowProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
    switch( msg )
	{
        case WM_KEYDOWN:
			if ( wParam == VK_ESCAPE )
				PostQuitMessage(0);
	        break;

		case WM_CLOSE:
        case WM_DESTROY:
            PostQuitMessage(0);
	        break;

		default:
			return DefWindowProc( hWnd, msg, wParam, lParam );
	}

	return 0;
}

  //
 // WinMain: Register Window Class, Create Window and wait until program end
//
int WINAPI WinMain( HINSTANCE hInst,
                    HINSTANCE hPrevInst,
                    LPSTR     lpCmdLine,
                    int       nCmdShow )
{
	WNDCLASSEX wndClass;

	wndClass.lpszClassName = "PCUvsD3D9";
	wndClass.cbSize        = sizeof( WNDCLASSEX );
	wndClass.style         = CS_HREDRAW | CS_VREDRAW;
	wndClass.lpfnWndProc   = WindowProc;
	wndClass.cbClsExtra    = 0;
	wndClass.cbWndExtra    = 0;
	wndClass.hInstance     = hInst;
	wndClass.hIcon	       = LoadIcon( hInst, (LPCTSTR)IDI_PCUICON );
	wndClass.hCursor       = LoadCursor( NULL, IDC_ARROW );
	wndClass.hbrBackground = (HBRUSH)GetStockObject( BLACK_BRUSH );
    wndClass.hIconSm	   = NULL;
	wndClass.lpszMenuName  = NULL;

	if( RegisterClassEx( &wndClass) == 0 ) return E_FAIL;

	DWORD windowParam;

	if ( DX9Fullscreen )
		windowParam = WS_POPUP | WS_SYSMENU | WS_VISIBLE; else
		windowParam = WS_OVERLAPPEDWINDOW | WS_VISIBLE;

	gHWND = CreateWindowEx( NULL, "PCUvsD3D9", "Direct3D9",
							 windowParam, 0, 0, 
							 DX9ScreenX, DX9ScreenY, 
							 NULL, NULL, hInst, NULL );

	if( gHWND == NULL ) return E_FAIL;

    ShowWindow( gHWND, nCmdShow );
    UpdateWindow( gHWND );

	initialize3D();
  
	MSG msg;
	ZeroMemory( &msg, sizeof( msg ) );

	while( msg.message != WM_QUIT )
	{
		if( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) )
		{ 
			TranslateMessage( &msg );
			DispatchMessage ( &msg );
		} else
		    render3D();
	}

	shutdown3D();

    UnregisterClass( "PCUvsD3D9", wndClass.hInstance );

	return msg.wParam;
}


  //
 // error: Display error message and quit program
//
void error( char *msg = NULL )
{
	if ( msg )
		MessageBox( NULL, msg, "PCUvsDX9", MB_OK | MB_ICONEXCLAMATION ); else
		MessageBox( NULL, "Error occured !", "PCUvsDX9", MB_OK | MB_ICONEXCLAMATION );

	shutdown3D();

	exit( 1 );
}

  //
 // initialize3D: initialize Direct3D stuff
//
void initialize3D( void )
{
	HRESULT			hr;
	D3DDISPLAYMODE	dm;

    pD3D = Direct3DCreate9( D3D_SDK_VERSION );

	if( pD3D == NULL ) error( "Error creating Direct3D Object" );

	if ( DX9Fullscreen )
	{
		// fullscreen
		//
		int nMaxModes = pD3D->GetAdapterModeCount( D3DADAPTER_DEFAULT, D3DFMT_X8R8G8B8 );

		bool foundMode = false;

		for( int m = 0; m < nMaxModes; m ++ )
		{
		  if ( FAILED( pD3D->EnumAdapterModes( D3DADAPTER_DEFAULT, 
											   D3DFMT_X8R8G8B8, m, &dm ) ) )
			 error( "Error enumerating adapter mode" );

		  if ( dm.Width  != DX9ScreenX || 
			   dm.Height != DX9ScreenY ||
			   dm.RefreshRate != DX9Refresh ||
			   dm.Format != D3DFMT_X8R8G8B8 )
			   continue;

		  foundMode = true;
		  break;
		}

		if ( foundMode == false )
		  error( "Not suitable graphic mode found !" );

		if ( FAILED( pD3D->CheckDeviceType( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL,
											D3DFMT_X8R8G8B8, D3DFMT_X8R8G8B8, FALSE ) ) )
		   error( "No hardware acceleration for this graphic mode !" );
	} else
	{
		// windowed
		//
		if( FAILED( pD3D->GetAdapterDisplayMode( D3DADAPTER_DEFAULT, &dm ) ) )
			error( "Error getting Adapter Display Mode" );
	}

	hr = pD3D->CheckDeviceFormat( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, 
								  dm.Format, D3DUSAGE_DEPTHSTENCIL,
								  D3DRTYPE_SURFACE, D3DFMT_D16 );

	if ( hr == D3DERR_NOTAVAILABLE ) error( "Desired Z-Buffer Format (16Bit) not available" );

	D3DCAPS9 caps;

	if( FAILED( pD3D->GetDeviceCaps( D3DADAPTER_DEFAULT, 
									 D3DDEVTYPE_HAL, &caps ) ) )
		error( "Error reading Device Caps" );
	
	DWORD flags = 0;

	if( caps.VertexProcessingCaps != 0 )
		flags |= D3DCREATE_HARDWARE_VERTEXPROCESSING;
	else
		flags |= D3DCREATE_SOFTWARE_VERTEXPROCESSING;

	D3DPRESENT_PARAMETERS pp;
	ZeroMemory( &pp, sizeof( pp ) );

	pp.BackBufferFormat       = dm.Format;
	pp.SwapEffect             = D3DSWAPEFFECT_DISCARD;
	pp.Windowed               = !DX9Fullscreen;
	pp.EnableAutoDepthStencil = TRUE;
	pp.AutoDepthStencilFormat = D3DFMT_D16;
	pp.BackBufferWidth        = DX9ScreenX;
    pp.BackBufferHeight       = DX9ScreenY;
    pp.BackBufferFormat       = D3DFMT_X8R8G8B8;

	if( FAILED( pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, gHWND,
									  flags, &pp, &pD3DDevice ) ) )
		error( "Error creating Direct3D device" );


	//
	// Init Demo Stuff
	//
	readTriangleMesh( "./data/roundcube.cnd" );
	scaleIsotropic( pVertexList, nVertices );

	//
	// Create Vertex Buffer
	//
	hr = pD3DDevice->CreateVertexBuffer( nFaces * 3 * sizeof( MESHVERTEX ), 
										 D3DUSAGE_DONOTCLIP|D3DUSAGE_WRITEONLY, 
										 FVF_MESHVERTEX, D3DPOOL_MANAGED, &pMeshVB, NULL );

	D3DVERTEXBUFFER_DESC desc;
	pMeshVB->GetDesc( &desc );

	MESHVERTEX *pData = NULL;

	hr = pMeshVB->Lock( 0, 0, (void**)&pData, D3DLOCK_DISCARD );

	for ( DWORD i = 0; i < nFaces; i++ )
	for ( DWORD j = 0; j < 3; j++ )
	{
		int idx;

		switch ( j )
		{ case 0: idx = pFaceList[ i ].a; break;
		  case 1: idx = pFaceList[ i ].b; break;
		  case 2: idx = pFaceList[ i ].c; break;
		};

		pData->x = pVertexList[ idx ].x;
		pData->y = pVertexList[ idx ].y;
		pData->z = pVertexList[ idx ].z;
		
		pData->color = 0xffffffff+0*normal2color( pNormalList[ idx ] );

		pData ++;
	}

	pMeshVB->Unlock();

	// static render states
//    pD3DDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID );
    pD3DDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME );

    pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );
    pD3DDevice->SetRenderState( D3DRS_LIGHTING, FALSE );
    pD3DDevice->SetRenderState( D3DRS_ZENABLE, TRUE );
	pD3DDevice->SetRenderState( D3DRS_ZFUNC, D3DCMP_LESSEQUAL );

/*	    pD3DDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );
		pD3DDevice->SetRenderState( D3DRS_ZENABLE, FALSE );
		pD3DDevice->SetRenderState( D3DRS_ALPHABLENDENABLE , TRUE );
		pD3DDevice->SetRenderState( D3DRS_SRCBLEND, D3DBLEND_ONE );
		pD3DDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_ONE );
*/
}

  //
 // render3D: render loop
//
void render3D()
{
    pD3DDevice->Clear( 0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
                       0x00303030, 1.0f, 0 );

    pD3DDevice->BeginScene();

	// set up matrices
	D3DXMATRIX mProjection;
	D3DXMatrixPerspectiveFovLH( &mProjection, 45.0f, (float)DX9ScreenX/(float)DX9ScreenY, 0.1f, 100.0f );
	pD3DDevice->SetTransform( D3DTS_PROJECTION, &mProjection );

    static float fXrot = 0.0f;
	static float fYrot = 0.0f;
	static float fZrot = 0.0f;

	fXrot += 0.521f;
	fYrot += 0.632f;
	fZrot += 0.743f*0;
	
    D3DXMATRIX matWorld;
    D3DXMATRIX matTrans;
	D3DXMATRIX matRot;

    D3DXMatrixTranslation( &matTrans, 0.0f, 0.0f, 20.0f );

	D3DXMatrixRotationYawPitchRoll( &matRot,
		                            D3DXToRadian(fXrot), 
		                            D3DXToRadian(fYrot), 
		                            D3DXToRadian(fZrot) );

    matWorld = matRot * matTrans;
    pD3DDevice->SetTransform( D3DTS_WORLD, &matWorld );

	// render mesh
	pD3DDevice->SetStreamSource( 0, pMeshVB, 0, sizeof( MESHVERTEX ) );
	pD3DDevice->SetFVF( FVF_MESHVERTEX );
	pD3DDevice->DrawPrimitive( D3DPT_TRIANGLELIST, 0, nFaces );

/*	MESHVERTEX pStrip[ 4 ];

	for ( int i = 0; i < 100; i++ )
	{
		DWORD color = hsvColor( (float)i * 0.01f );

		float time = GetTickCount() * 0.001f;
		time += (float)i * 0.2f * sin( time * 0.5f );

		float mx = cos( (time+i*0.01f) * 3.1231f ) * 2.0f,
			  my = sin( (time+i*0.07f) * 2.4131f ) * 2.0f;

		float dx = cos( time ) * 2.0f;
		float dy = sin( time ) * 2.0f;
		float dx2 = -dy * 5.0f;
		float dy2 = dx * 5.0f;

		pStrip[ 0 ].x = mx + dx + dx2;
		pStrip[ 1 ].x = mx + dx - dx2;
		pStrip[ 2 ].x = mx - dx + dx2;
		pStrip[ 3 ].x = mx - dx - dx2;
		pStrip[ 0 ].y = my + dy + dy2;
		pStrip[ 1 ].y = my + dy - dy2;
		pStrip[ 2 ].y = my - dy + dy2;
		pStrip[ 3 ].y = my - dy - dy2;
		pStrip[ 0 ].z =
		pStrip[ 1 ].z = dy;
		pStrip[ 2 ].z =
		pStrip[ 3 ].z = dx;
		pStrip[ 0 ].color =
		pStrip[ 1 ].color =
		pStrip[ 2 ].color =
		pStrip[ 3 ].color = color;

		pD3DDevice->SetFVF( FVF_MESHVERTEX );

		HRESULT hr = pD3DDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, &pStrip[ 0 ], sizeof( MESHVERTEX ) );
	}
*/
    pD3DDevice->EndScene();

    pD3DDevice->Present( NULL, NULL, NULL, NULL );
}

  //
 // shutdown3D: free Direct3D ressources
//
void shutdown3D()
{
	if ( pMeshVB != NULL )
		pMeshVB->Release();

    if( pD3DDevice != NULL )
        pD3DDevice->Release();

    if( pD3D != NULL )
        pD3D->Release();
}

