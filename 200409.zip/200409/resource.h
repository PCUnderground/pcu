//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dx9_init.rc
//
#define IDI_PCUICON                     129
