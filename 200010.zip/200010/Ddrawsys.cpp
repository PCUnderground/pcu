///////////////////////////////////////////////////////////
//                                                       //
// PC MAGAZIN - Demo Projekt                             //
//                                                       //
// Dieses Modul stellt die Schnittstelle zu DirectDraw   //
// her. Es setzt mindestens DirectX Version 3.0 vorraus. //
//                                                       //
// Dieses Modul braucht zum Linken folgende Libraries:   //
//                                                       //
//  * ddraw.lib                                          //
//  * guids.lib                                          //
//                                                       //
// Nils Pipenbrinck                                      //
//                                                       //
///////////////////////////////////////////////////////////
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <ddraw.h>
#include <string.h>
#include <stdlib.h>
#include "ddrawsys.h"


#ifdef __WATCOM_CPLUSPLUS__
#pragma library ("ddraw.lib");
#pragma library ("guids.lib");
#else
#pragma message ("Nicht vergessen ddraw.lib und guids.lib zu linken!");
#endif

// Konstanten f�r den Auswahl-Dialog
#define LISTBOX_ID 102
#define DIALOG_ID  103


// Defines f�r die Konfiguration des Moduls:
#define ASSEMBLER_INNERLOOP



// Struktur zum Erfassen der installierten DirectDraw Ger�te
struct DirectDrawDevice
{
    GUID FAR          *lpGUID;
    char              *DriverDescription;
    char              *DriverName;
    DirectDrawDevice  *nextDevice;
};


// Und einige statische Variablen:
static DirectDrawDevice   *DeviceList    = 0;
static unsigned int       DeviceCount    = 0;
static GUID FAR           *ddguid        = 0;
static IDirectDraw        *dd            = 0;
static IDirectDraw2       *dd2           = 0;
static IDirectDrawSurface *ddSurface     = 0;
static signed int        width;
static signed int        height;


static BOOL WINAPI DeviceEnumerateCallback ( GUID FAR * lpGUID,
                                             LPSTR lpDriverDescription,
                                             LPSTR lpDriverName,
                                             LPVOID lpContext)
{
    // -------------------------------------------------------------------
    // Diese Routine wird von DirectDraw f�r jedes Ger�t einmal aufgerufen
    // Sie f�gt die m�glichen DirectDraw Ger�te in eine Liste ein.
    // -------------------------------------------------------------------
    lpContext              = lpContext;
    DirectDrawDevice * neu = new DirectDrawDevice;
    neu->lpGUID            = lpGUID;
    neu->DriverDescription = strdup (lpDriverDescription);
    neu->DriverName        = strdup (lpDriverName);
    neu->nextDevice        = DeviceList;
    DeviceList             = neu;
    DeviceCount ++;
    return DDENUMRET_OK;
}


BOOL CALLBACK SelectDeviceDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    // -------------------------------------------------------------------
    // Dialog-Prozedur f�r den DirectDraw Auswahldialog.
    // -------------------------------------------------------------------
    switch (uMsg)
    {
        case WM_INITDIALOG:
        {
            // Dialog Initialisieren:
            for (DirectDrawDevice * lauf = DeviceList; lauf; lauf = lauf->nextDevice)
            {
                // Alle verf�gbaren DirectDraw Display Treiber in die Listbox einf�gen
                SendDlgItemMessage   (hwndDlg, LISTBOX_ID, LB_SETITEMDATA,
                  SendDlgItemMessage (hwndDlg, LISTBOX_ID, LB_ADDSTRING, 0, (long) lauf->DriverDescription), (long) lauf);
            }
            // ersten Eintrag w�hlen
            SendDlgItemMessage (hwndDlg, LISTBOX_ID, LB_SETCURSEL, 0, 0);
            return TRUE;
        }

        case WM_COMMAND:
        {
            switch (LOWORD(wParam))
            {
                case IDCANCEL:
                    // Dialog mit Cancel beenden
                    EndDialog (hwndDlg, LOWORD(wParam));
                return TRUE;

                case IDOK:
                     // Gew�hlten Eintrag holen:
                    ddguid = ((DirectDrawDevice *) SendDlgItemMessage (hwndDlg, LISTBOX_ID, LB_GETITEMDATA,
                                                   SendDlgItemMessage (hwndDlg, LISTBOX_ID, LB_GETCURSEL, 0, 0), 0))->lpGUID;
                    // Und mit OK beenden
                    EndDialog (hwndDlg, LOWORD(wParam));
                return TRUE;
            }
        }
    }
    lParam  = lParam;
    wParam  = wParam;
    hwndDlg = hwndDlg;
    uMsg    = uMsg;
    return FALSE;
}



BOOL DirectDrawConfig (HINSTANCE InstanceHandle)
{
    // -----------------------------------------------------------
    // Suchen aller m�glichen DirectDraw Ger�te und Auswahl, falls
    // mehrere im System vorhanden sind.
    // -----------------------------------------------------------

    // DirectDraw Ger�te aufz�hlen:
    if (DirectDrawEnumerate (DeviceEnumerateCallback, 0)!=DD_OK) return FALSE;

    // Nichts gefunden? Dann zur�ck
    if (!DeviceCount) return FALSE;

    // Standard Ger�t ID in ddguid merken.
    ddguid = DeviceList->lpGUID;

    // Mehr als eine Ger�t vorhanden?  -> Auswahl Dialog anzeigen
    if (DeviceCount > 1)
    {
        // Der Dialog �berschreibt, wenn OK gedr�ckt wird die Variable ddguid.
        if ( DialogBox(InstanceHandle, MAKEINTRESOURCE(DIALOG_ID), 0, (DLGPROC) SelectDeviceDialogProc) != 1) return FALSE;
    }

    // Speicher aufr�umen
    DirectDrawDevice * next = 0;
    for (DirectDrawDevice * lauf = DeviceList; lauf; lauf = next)
    {
        free (lauf->DriverDescription);
        free (lauf->DriverName);
        next = lauf->nextDevice;
        delete lauf;
    }

    return TRUE;
}


BOOL InitDirectDraw (HWND ParentWindow, int aWidth, int aHeight)
{
    dd      = 0;
    dd2     = 0;
    width   = aWidth;
    height  = aHeight;
    // ---------------------------------------------------------
    // Initlialisieren der DirectDraw Library
    // -----------------------------------------------------------

    // DirectDraw Ger�t erstellen:
    if (DirectDrawCreate (ddguid, &dd, 0)!= DD_OK) return FALSE;

    // Jetzt gehen wir in den 'Exclusiven Mode, da wir Vollbild haben wollen
    if (dd->SetCooperativeLevel  (ParentWindow, DDSCL_EXCLUSIVE  | DDSCL_FULLSCREEN | DDSCL_ALLOWREBOOT)!=DD_OK) return FALSE;

    // Interface 2 erzeugen
    if (dd->QueryInterface (IID_IDirectDraw2, (void **) &dd2)!=DD_OK) return FALSE;

    // Video Modus setzen:
    if (dd2->SetDisplayMode (width, height, 32, 0, 0)!=DD_OK) return FALSE;

    // --------------------------------------------------------------------
    // Surface erstellen:
    // --------------------------------------------------------------------
    // Wir ben�tigen eine prim�re Surface (d.h. echtes Video-RAM) mit einem
    // Backbuffer f�r Page-Flipping.
    // --------------------------------------------------------------------
    DDSURFACEDESC Surface;
    memset (&Surface, 0, sizeof (Surface));
    Surface.dwSize            = sizeof( Surface );
    Surface.dwFlags           = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
    Surface.dwBackBufferCount = 1;
    Surface.ddsCaps.dwCaps    = DDSCAPS_PRIMARYSURFACE | DDSCAPS_FLIP | DDSCAPS_COMPLEX;

    if (dd2->CreateSurface(&Surface, &ddSurface, 0)!=DD_OK) return FALSE;

    return TRUE;
}



BOOL DirectDrawBlit (void *buf )
{
    // Kontrolle, ob die Surface noch aktiv ist,
    // ansonsten probieren wir die Surface zu erneuern.
    if (ddSurface->IsLost()!=DD_OK)
    {
      if (ddSurface->Restore()!=DD_OK) return FALSE;
    }


    // Hintergrund Surface suchen

    DDSCAPS caps;
    IDirectDrawSurface * dds;
    caps.dwCaps = DDSCAPS_BACKBUFFER;
    if (ddSurface-> GetAttachedSurface(&caps, & dds) != DD_OK) return FALSE;

    // Erneut Kontrolle, ob die Surface noch aktiv ist,
    // ansonsten probieren wir die Surface zu erneuern.
    if (dds->IsLost()!=DD_OK)
    {
      if (dds->Restore()!=DD_OK) return FALSE;
    }


    // Zugriff auf die Surface:
    DDSURFACEDESC SurfaceDescription;
    memset (&SurfaceDescription, 0, sizeof (DDSURFACEDESC));
    SurfaceDescription.dwSize = sizeof (SurfaceDescription);
    if (dds->Lock (0, &SurfaceDescription, DDLOCK_SURFACEMEMORYPTR  | DDLOCK_WAIT ,0)!=DD_OK) return FALSE;


    // Jetzt m�ssen wir erfahren, ob das Ger�t 15 oder 16 Bit Highcolor macht:
    unsigned long BitMaske = SurfaceDescription.ddpfPixelFormat.dwRBitMask |
                             SurfaceDescription.ddpfPixelFormat.dwGBitMask |
                             SurfaceDescription.ddpfPixelFormat.dwBBitMask;

    int *source = (int *) buf;
    char  *dest   = (char  *) SurfaceDescription.lpSurface;

//            memcpy (dest, source, width*height*2);
            for (register int y=0; y<height; y++)
            {
                memcpy (dest, source, width*4);
                dest   += SurfaceDescription.lPitch;
                source += width;
            }
/*    if (BitMaske == 0x0000ffff)
    {
        // -----------------------------
        // Die Surface hat echte 16 Bit:
        // -----------------------------
        if (SurfaceDescription.lPitch == width*2)
        {
            // Wir k�nnen einfach linear kopieren:
            memcpy (dest, source, width*height*2);
        } else {
            // Wir m�ssen zeilenweise kopieren
            for (register int y=0; y<height; y++)
            {
                memcpy (dest, source, width*2);
                dest   += SurfaceDescription.lPitch;
                source += width;
            }
        }
    } else {
        // -----------------------------------------------
        // Die Surface hat 15 Bit. Wir m�ssen konvertieren
        // -----------------------------------------------
        register unsigned long * lsource   = (unsigned long *) source;
        register unsigned long * ldest     = (unsigned long *) dest;
        register unsigned long  nQuadWords = width>>2;

        for (register int y=0; y<height; y++)
        {
#ifdef ASSEMBLER_INNERLOOP
            // ----------------------------------------------------------
            // Assembler Innerloop konvertiert mit ca. 2 Cycles pro Pixel
            // 4 Pixels werden parallel konvertiert
            // ----------------------------------------------------------
            _asm {
                pushad
                mov   esi, lsource
                mov   edi, ldest
                mov   ecx, nQuadWords
                lea   esi, [esi + ecx*8]
                lea   edi, [edi + ecx*8]
                not   ecx
             Next4Pixels:
                mov   eax, [ecx*8+esi]
                mov   edx, [ecx*8+esi+4]
                mov   ebx, eax
                mov   ebp, edx
                shr   ebx, 1
                and   eax, 0x0001f001f
                shr   ebp, 1
                and   edx, 0x0001f001f
                and   ebx, 0x0ffe0ffe0
                and   ebp, 0x0ffe0ffe0
                or    ebx, eax
                or    edx, ebp
                mov   [ecx*8+edi],   ebx
                mov   [ecx*8+edi+4], edx
                inc   ecx
                jnz   Next4Pixels
                popad
            }

            lsource += (width>>1);
            ldest   += (SurfaceDescription.lPitch>>2);
#else
            for (register int x=0; x<width/2; x++)
                *ldest++ = (*lsource & 0x001f001f) | (((*lsource++)>>1) & 0x0ffe0ffe0);
#endif
        }
    }*/


    // Zugriff wieder Freigeben
    if (dds->Unlock (SurfaceDescription.lpSurface)!=DD_OK) return FALSE;

    // Und Page-Flipping starten
    if (ddSurface->Flip (0, DDFLIP_WAIT)!=DD_OK) return FALSE;
    return TRUE;
}





void CloseDirectDraw (void)
{
  // -----------------------------------------
  // Hier werden alle von DirectDraw benutzen
  // Resourcen freigegeben
  // -----------------------------------------
  if (ddSurface)
  {
    ddSurface->Release();
    ddSurface = 0;
  }

  if (dd2)
  {
    dd2->RestoreDisplayMode();
    dd2->Release();
    dd2=0;
  }

  if (dd)
  {
    dd->SetCooperativeLevel  (0, DDSCL_NORMAL);
    dd->Release();
    dd=0;
  }
}




