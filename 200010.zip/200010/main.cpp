///////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Texture Generator                                     //
//  (w)(c)2000 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////

#include "demo.h"
#include <math.h>

// Visual C++ Warnings ausschalten
#pragma warning(disable : 4244)		// truncation from const double to float
#pragma warning(disable : 4305)		// truncation from const double to float
#pragma warning(disable : 4018)		// signed/unsigned mismatch
#pragma warning(disable : 4101)		// unreferenced local variable

unsigned int *screen;		

#define MAXLAYER 8
#define TEMPLAYER MAXLAYER
#define SIZE	 256
#define SIZE2	 (SIZE*SIZE)

typedef struct
{
	unsigned char r, g, b;
}COLOR;

typedef struct
{
	unsigned char v[ 3 ];
}COLORI;

COLOR layer[ MAXLAYER+1 ][ SIZE * SIZE ];

#define pix(x,y) ((((x)&(SIZE-1)) + ((y)&(SIZE-1)) * SIZE))
#define nachkomma(x) ((x)-(int)(x))

  //
 // ein einfacher Zufallszahlengenerator
//
int	seedvalue;
int	random()
{
	seedvalue *= 0x015a4e35;
	return seedvalue >> 16;
}

  //
 // 2D Interpolation mit Kosinus
//
void	interpolate( COLORI *o, COLORI *c, float x, float y )
{
	// Gewichte ausrechnen
	float f1 = ( 1.0f - (float)cos( x * 3.141592 ) ) * 0.5f;
	float f2 = ( 1.0f - (float)cos( y * 3.141592 ) ) * 0.5f;
	f1 = 1.0f-f1;
	f2 = 1.0f-f2;

	float g[ 4 ] = { f1*f2, (1-f1)*f2, f1*(1-f2), (1-f1)*(1-f2) };

	float v[ 3 ] = {0,0,0};

	for ( int i = 0; i < 3; i++ )
	{
		for ( int j = 0; j < 4; j++ )
			v[ i ] += (float)o[ j ].v[ i ] * g[ j ];
	}
	for ( i = 0; i < 3; i++ )
		c->v[ i ] = (unsigned char)v[ i ];
}

  //
 // getPixel Funktion mit bilinearer Interpolation
//
COLOR	getPixel( int l, float x, float y )
{
	COLOR corner[ 4 ];
	corner[ 0 ] = layer[ l ][ pix((int)x,(int)y) ];
	corner[ 1 ] = layer[ l ][ pix((int)x+1,(int)y) ];
	corner[ 2 ] = layer[ l ][ pix((int)x,(int)y+1) ];
	corner[ 3 ] = layer[ l ][ pix((int)x+1,(int)y+1) ];
	COLOR res;

	interpolate( (COLORI*)corner, (COLORI*)&res, nachkomma( x ), nachkomma( y ) );

	return res;
}
  //
 // Sub Plasma
//
void	subPlasma( int l, int dist, int seed, int amplitude )
{
	int x, y, a, b;

	if ( seed )
		seedvalue = seed;

	// schritt 1: zufallswerte
	for ( y = 0; y < SIZE; y+=dist )
		for ( x = 0; x < SIZE; x+=dist )
		{
			layer[ l ][ pix(x,y) ].r =
			layer[ l ][ pix(x,y) ].g =
			layer[ l ][ pix(x,y) ].b = ( random() ) & (amplitude-1);
		}

	if ( dist <= 1 )
		return;

	// schritt 2: interpolation
	for ( y = 0; y < SIZE; y+=dist )
		for ( x = 0; x < SIZE; x+=dist )
		{
			COLOR corner[ 4 ];
			corner[ 0 ] = layer[ l ][ pix(x,y) ];
			corner[ 1 ] = layer[ l ][ pix(x+dist,y) ];
			corner[ 2 ] = layer[ l ][ pix(x,y+dist) ];
			corner[ 3 ] = layer[ l ][ pix(x+dist,y+dist) ];
			COLOR res;
			for ( b = 0; b < dist; b++ )
				for ( a = 0; a < dist; a++ )
				{
					float f1 = (float)a/(float)dist;
					float f2 = (float)b/(float)dist;
					interpolate( (COLORI*)corner, (COLORI*)&res, f1, f2 );
					layer[ l ][ pix(x+a,y+b) ] = res;
				}
		}

}

  //
 // SinusLayer
//
void	sinusLayer( int l, float dx, float dy, int amplitude )
{
	int x, y;

	for ( y = 0; y < SIZE; y++ )
		for ( x = 0; x < SIZE; x++ )
		{
			float f = 127.0f + 63.5f * (float)sin( (float)x * dx ) + 
							   63.5f * (float)sin( (float)y * dy );
			layer[ l ][ pix(x,y) ].r =
			layer[ l ][ pix(x,y) ].g =
			layer[ l ][ pix(x,y) ].b = (int)( f * (float)amplitude / 256.0f );
		}
}

  //
 // addiert die Farben zweier Layer
//
void addLayer( int src1, int src2, int dst )
{
	for ( int i = 0; i < SIZE2; i++ )
	{
		int r = layer[ src1 ][ i ].r + layer[ src2 ][ i ].r;
		int g = layer[ src1 ][ i ].g + layer[ src2 ][ i ].g;
		int b = layer[ src1 ][ i ].b + layer[ src2 ][ i ].b;
		layer[ dst ][ i ].r = min( r, 255 );
		layer[ dst ][ i ].g = min( g, 255 );
		layer[ dst ][ i ].b = min( b, 255 );
	}
}

  //
 // multipliziert die Farben zweier Layer
//
void multiplyLayer( int src1, int src2, int dst )
{
	for ( int i = 0; i < SIZE2; i++ )
	{
		float r = layer[ src1 ][ i ].r * layer[ src2 ][ i ].r;
		float g = layer[ src1 ][ i ].g * layer[ src2 ][ i ].g;
		float b = layer[ src1 ][ i ].b * layer[ src2 ][ i ].b;
		layer[ dst ][ i ].r = r / 256.0f;
		layer[ dst ][ i ].g = g / 256.0f;
		layer[ dst ][ i ].b = b / 256.0f;
	}
}

  //
 // Perlin Noise
//
void perlinNoise( int l, int dist, int seed, int amplitude, int persistence, int octaves )
{
	subPlasma( l, dist, seed, amplitude*0+1 );

	for ( int i = 0; i < octaves-1; i++ )
	{
		amplitude *= persistence;
		amplitude >>= 8;
		if ( amplitude <= 0 )
			return;
		dist >>= 1;
		if ( dist <= 0 )
			return;
		subPlasma( TEMPLAYER, dist, 0, amplitude );
		addLayer( l, TEMPLAYER, l );
	}
}

  //
 // Twirl Effekt, Parameter: Quelllayer, Ziellayer, max Drehwinkel, Skalierung f�r die Entfernung
//
void twirlLayer( int s, int dst, float rot, float scale )
{
	for ( int y = 0; y < SIZE; y++ )
		for ( int x = 0; x < SIZE; x++ )
		{
			float a = x - SIZE/2;
			float b = y - SIZE/2;
			float d = SIZE/2 - sqrt( a * a + b * b );
			if ( d < 0 ) d = 0;

			// st�rkere abnahme der drehung nach aussen:
			d *= d; d /= sqrt(SIZE*SIZE*2);
			//d *= d; d /= sqrt(SIZE*SIZE*2);

			// Winkel f�r diesen Pixel
			float winkel = rot * d / scale;
			float cw = cos( winkel );
			float sw = sin( winkel );

			float na, nb;

			// Drehung
			na = a * cw - b * sw + SIZE/2;
			nb = a * sw + b * cw + SIZE/2;
			int ina = (int)na;
			int inb = (int)nb;

			COLOR corner[ 4 ], res;
			corner[ 0 ] = layer[ s ][ pix(ina,inb) ];
			corner[ 1 ] = layer[ s ][ pix(ina+1,inb) ];
			corner[ 2 ] = layer[ s ][ pix(ina,inb+1) ];
			corner[ 3 ] = layer[ s ][ pix(ina+1,inb+1) ];
			interpolate( (COLORI*)corner, (COLORI*)&res, nachkomma(na), nachkomma(nb) );

			layer[ dst ][ pix(x,y) ] = res;
		}
}

  //
 // Sinusverzerrung f�r Sinusverzerrung
//
void sinusDistort( int s, int d, float dx, float depthx, float dy, float depthy )
{
	for ( int y = 0; y < SIZE; y++ )
		for ( int x = 0; x < SIZE; x++ )
		{
			float nx = x + sin( y * dx ) * depthx;
			float ny = y + sin( x * dy ) * depthy;

			// ohne Interpolation
			//layer[ d ][ pix(x,y) ] = layer[ s ][pix((int)nx,(int)ny)];
			// mit...
			layer[ d ][ pix(x,y) ] = getPixel( s, nx, ny );
		}
}

void colorLayer( int l, float r, float g, float b )
{
	for ( int i = 0; i < SIZE2; i++ )
	{
		float rn, gn, bn;
		rn = layer[ l ][ i ].r * r; if ( rn < -254 ) rn = -254; if ( rn < 0 ) rn = 255 + rn;
		gn = layer[ l ][ i ].g * g; if ( gn < -254 ) gn = -254; if ( gn < 0 ) gn = 255 + gn;
		bn = layer[ l ][ i ].b * b; if ( bn < -254 ) bn = -254; if ( bn < 0 ) bn = 255 + bn;
		layer[ l ][ i ].r = min( 255, fabs( rn ) );
		layer[ l ][ i ].g = min( 255, fabs( gn ) );
		layer[ l ][ i ].b = min( 255, fabs( bn ) );
	}
}

void woodLayer( int l, int b )
{
	for ( int i = 0; i < SIZE2; i++ )
	{
		layer[ l ][ i ].r = ( layer[ l ][ i ].r << b ) | ( layer[ l ][ i ].r >> (8-b) );
		layer[ l ][ i ].g = ( layer[ l ][ i ].g << b ) | ( layer[ l ][ i ].g >> (8-b) );
		layer[ l ][ i ].b = ( layer[ l ][ i ].b << b ) | ( layer[ l ][ i ].b >> (8-b) );
	}
}

void copyLayer( int s, int d )
{
	for ( int i = 0; i < SIZE2; i++ )
		layer[ d ][ i ] = layer[ s ][ i ];
}

void embossLayer( int s, int d )
{
	for ( int y = 0; y < SIZE; y++ )
		for ( int x = 0; x < SIZE; x++ )
		{
			float r, g, b;
			r = -layer[ s ][ pix(x-1,y-1) ].r;
			r -= layer[ s ][ pix(x-1,y-0) ].r;
			r -= layer[ s ][ pix(x-1,y+1) ].r;
			r += layer[ s ][ pix(x+1,y-1) ].r;
			r += layer[ s ][ pix(x+1,y-0) ].r;
			r += layer[ s ][ pix(x+1,y+1) ].r;
			r += 128;
			g = -layer[ s ][ pix(x-1,y-1) ].g;
			g -= layer[ s ][ pix(x-1,y-0) ].g;
			g -= layer[ s ][ pix(x-1,y+1) ].g;
			g += layer[ s ][ pix(x+1,y-1) ].g;
			g += layer[ s ][ pix(x+1,y-0) ].g;
			g += layer[ s ][ pix(x+1,y+1) ].g;
			g += 128;
			b = -layer[ s ][ pix(x-1,y-1) ].b;
			b -= layer[ s ][ pix(x-1,y-0) ].b;
			b -= layer[ s ][ pix(x-1,y+1) ].b;
			b += layer[ s ][ pix(x+1,y-1) ].b;
			b += layer[ s ][ pix(x+1,y-0) ].b;
			b += layer[ s ][ pix(x+1,y+1) ].b;
			b += 128;
			layer[ d ][ pix(x,y) ].r = min( 255, max( 0, r ) );
			layer[ d ][ pix(x,y) ].g = min( 255, max( 0, g ) );
			layer[ d ][ pix(x,y) ].b = min( 255, max( 0, b ) );
		}
}

void invertLayer( int l )
{
	colorLayer( l, -1.0f, -1.0f, -1.0f );
}

void display( int l )
{
	for ( int y = 0; y < min(256,SCREEN_Y); y++ )
		for ( int x = 0; x < min(256,SCREEN_X); x++ )
			screen[ x + y * SCREEN_X ] = 
			 ( layer[ l ][ pix(x,y) ].r << 16 ) |
			 ( layer[ l ][ pix(x,y) ].g << 8 ) |
			 ( layer[ l ][ pix(x,y) ].b << 0 );
}

void demomain (void)
{
	// Beispiel 1
	//sinusLayer( 0, 0.08, 0.05, 256 );
	// Beispiel 2
	//subPlasma( 0, 64, 341251, 256 );
	// Beispiel 3
	/*
	perlinNoise( 0, 128, 2341251, 256, 138, 8 );
	colorLayer( 0, 0.8, 0.8, 1);
	twirlLayer( 0, 1, 64.0f, 182.0f );
	display( 1 );
	*/
	perlinNoise( 0, 128, 2341251, 256, 138, 8 );
	perlinNoise( 1, 128, 256262, 256, 138, 8 );
	twirlLayer( 0, 1, 14.0f, 182.0f );
	colorLayer( 1, 0.8, 0.8, 1);
	int l = 1;
	for ( int y = 0; y < min(256,SCREEN_Y); y++ )
		for ( int x = 0; x < min(256,SCREEN_X); x++ )
		{
			int a = x >> 5;
			int b = y >> 5;
			if ( (a+b)&1 )
			{
				layer[ l ][ pix(x,y) ].r >>= 1;
				layer[ l ][ pix(x,y) ].g >>= 1;
				layer[ l ][ pix(x,y) ].b >>= 1; 
			}
		}
	display( 1 );

	// Beispiel 4
/*	
	perlinNoise( 0, 128, 2341251, 256, 138, 8 );
	copyLayer( 0, 1 );
	invertLayer( 1 );

	colorLayer( 0, 0.7f, 0.5f, 0.2f );
	colorLayer( 1, -0.7f, -0.99f, -0.7f );
	colorLayer( 0, 0.75f, 0.75f, 0.75f );
	colorLayer( 1, 0.75f, 0.75f, 0.75f );
	addLayer( 0, 1, 0 );

	twirlLayer( 0, 1, 48.0f, 182.0f );
	sinusDistort( 1, 0, 0.0245437f, 20.0f, 0.0245437f*2.0f, 30.0f );


	embossLayer( 0, 1 );

	multiplyLayer( 0, 1, 2 );
	multiplyLayer( 2, 1, 0 );

	colorLayer( 0, 2.0f, 2.0f, 2.0f );

	display( 0 );
	

	// Beispiel 5
/*	perlinNoise( 0, 256, 1325251, 256, 108, 8 );
	woodLayer( 0, 4 );
	colorLayer( 0, 0.7f, 0.5f, 0.2f );
	display( 0 );
*/
	while ( ( DemoRunning ) && (!KeyStatus[ VK_ESCAPE ] ) )
	{
		BlitGraphic( screen );
	}
}	

BOOL demoinit (void)
{
	Fenster_Modus = FENSTER;

	// Speicher allokieren
	screen = (unsigned int *)malloc( SCREEN_X * SCREEN_Y * sizeof( int ) );
	assert( screen );

	return TRUE;
}

void demoquit (void)
{
	free( screen );
}


