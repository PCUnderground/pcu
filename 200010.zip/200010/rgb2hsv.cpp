////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  HSV <-> RGB Konvertierung                             //
//                                                        //
////////////////////////////////////////////////////////////

void hsv2rgb( float h, float s, float v, float *r, float *g, float *b )
{
   while ( h < 0.0f ) h += 360.0f;
   while ( h >= 360.0f ) h -= 360.0f;

   if ( s == 0.0f )
   {
      *r = v;
      *g = v;
      *b = v;
   } else
   {
      float f, p, q, t;
      float i;

      h /= 60.0f;
      i = floor( h );
      f = h - i;
      p = v * ( 1.0f - s );
      q = v * ( 1.0f - ( s * f ) );
      t = v * ( 1.0f - ( s * ( 1.0f - f ) ) );

      int o = i;
      switch( o ) 
	  {
         case 0: r = v; g = t; b = p; break;
         case 1: r = q; g = v; b = p; break;
         case 2: r = p; g = v; b = t; break;
         case 3: r = p; g = q; b = v; break;
         case 4: r = t; g = p; b = v; break;
         case 5: r = v; g = p; b = q; break;
      }
   }
}

void rgb2hsv( float r, float g, float b, float *h, float *s, float *v )
{
	float max, min;
	float temp;
	
	if (r > g) max = r;
	else max = g;
	
	if (b > max ) max = b;
	
	if (r < g ) min = r;
	else min = g;
	
	if ( b < min ) min = b;
	
	*v = max;
	
	*s = 0.0f;
	if ( max != 0.0f )
		*s = ( ( max - min ) / max );
	 
	if ( *s == 0.0f )
		 *h = -1.0f;
	else 
	{
		float delta = max - min;
		float maxr = max - r;
		float maxg = max - g;
		float maxb = max - b;
		
		if ( r == max )
			*h = ( maxb - maxg ) / delta;
		else if ( g == max )
			*h = 2.0f + ( ( maxr - maxb ) / delta);
		else if ( b == max)
			*h = 4.0f + ( ( maxg - maxr ) / delta);
		
		*h *= 60.0f;
		while ( *h < 0.0f )	*h += 360.0f;
		while ( *h >= 360.0f ) *h -= 360.0f;
	} 
}
