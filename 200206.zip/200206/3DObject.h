////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Stencil Buffer Shadows Mini 3D Engine                 //
//  (w)(c)2001 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#ifndef _3DOBJECT__H
#define _3DOBJECT__H

#include	<windows.h>			
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	<math.h>
#include	"texture.h"

typedef struct
{
	GLfloat		x, y, z;
}VERTEX3D;

typedef struct FACE
{
	GLint		a, b, c;
	GLint		p[3];
	VERTEX3D	normal;
	float		w;
	GLint		adjacent[ 3 ];
	FACE		*adjacentFace[ 3 ];
	GLint		facesLight;
}FACE;

typedef struct
{
	GLint		a, b;
	int			boundary;
	int			poly[ 2 ];
}EDGE;

class C3DObject
{
	private:

		VERTEX3D	*pVertexList;
		VERTEX3D	*pNormalList;
		float		*pTexCoordList;
		EDGE		*pEdgeList;
		FACE		*pFaceList;

		int			nVertices,
					nFaces,
					nEdges;

		int			shadeMode;

		float		texOffset;

		// Farbe
		GLfloat		r, g, b;

	public:
		C3DObject( char *file = NULL, float _texOffset = 0.0f );
		~C3DObject();

		void		drawObject();
		void		drawShadow( VERTEX3D lightPosition );
		void		finishShadow();

		void		setShadeMode( int s ) { shadeMode = s; };
		void		setColor( GLfloat rr, GLfloat gg, GLfloat bb )
		{
			r = rr; g = gg; b = bb;
		}
};


#endif