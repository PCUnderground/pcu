////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Stencil Buffer Schatten Rendering Beispiel            //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include	"3DObject.h"

C3DObject		*model;
GLUquadricObj	*q;

static GLfloat lightPosition[] = { 0.0f, 100.0f, 0.0f, 1.0f };

void	init3DEngine()
{
	glEnable( GL_CULL_FACE );
	glDepthFunc( GL_LEQUAL );

	model = new C3DObject( "data/cube.3d", 0.1f );
	model->setColor( 0.6f, 0.6f, 0.6f );

	// Quadric f�r Kugel zeichnen (die Lichtquelle)
	q = gluNewQuadric();
	gluQuadricNormals( q, GL_SMOOTH );
	gluQuadricTexture( q, GL_FALSE );

	// Licht an
	glEnable( GL_LIGHTING );
	glEnable( GL_LIGHT0 );
	GLfloat light_specular[] = { 0.0f, 0.0f, 0.0f, 0.0f };
	GLfloat light_diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat light_ambient[] = { 0.0f, 0.0f, 0.0f, 0.0f };
	glLightfv( GL_LIGHT0, GL_AMBIENT, light_ambient );
	glLightfv( GL_LIGHT0, GL_DIFFUSE, light_diffuse );
	glLightfv( GL_LIGHT0, GL_SPECULAR, light_specular );
	glLightf( GL_LIGHT0, GL_SPOT_EXPONENT, 18 );
	glLightfv(GL_LIGHT0, GL_POSITION, lightPosition);

	GLfloat mat[] = { 1.0f, 1.0f, 1.0f, 1.0f };

	glMaterialfv( GL_FRONT_AND_BACK, GL_DIFFUSE, (float*)mat );
}

void	draw3DEngine()
{
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT );

	float time = (float)GetTickCount() * 0.1f;

	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();
	gluPerspective( 45.0f, 1.33f, 1.01f, 1000.0f );
	glTranslatef( 0.0f, 0.0f, -50.0f );

	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();

	glLoadIdentity();
	
	// Lichtquelle zeichnen
	glTranslatef( lightPosition[ 0 ], lightPosition[ 1 ], lightPosition[ 2 ] );
	glColor3ub( 255, 255, 0 );
	glDisable( GL_LIGHTING );
	gluSphere( q, 1.1f, 32, 16 );

	float rotate_x = time * 0.2f;
	float rotate_y = -time * 0.2f;

	glLoadIdentity();

	// Boden zeichnen
	glDisable( GL_CULL_FACE );
	glColor3ub( 128, 128, 128 );
	glBegin( GL_TRIANGLE_STRIP );
		glVertex3i( -30, -15,  30 );
		glVertex3i( -30, -15, -30 );
		glVertex3i(  30, -15,  30 );
		glVertex3i(  30, -15, -30 );
	glEnd();
	glEnable( GL_CULL_FACE );


	glScalef( 4.0, 4.0, 4.0 );

	// Alle Objekte zeichnen:
	glPushMatrix();
	for ( int i = 0; i < 3; i++ )
	{
		glScalef( 0.6f, 0.6f, 0.6f );
		glRotatef( rotate_x, 1.0f, 0.0f, 0.0f );
		glRotatef( rotate_y, 0.0f, 1.0f, 0.0f );
		model->drawObject( );
	}
	glPopMatrix();

	// alle Schatten in den Stencil Buffer
	for ( i = 0; i < 3; i++ )
	{
		glScalef( 0.6f, 0.6f, 0.6f );
		glRotatef( rotate_x, 1.0f, 0.0f, 0.0f );
		glRotatef( rotate_y, 0.0f, 1.0f, 0.0f );
		model->drawShadow( *(VERTEX3D*)&lightPosition );
	}

	model->finishShadow();

	glPopMatrix();
	
}

void	quit3DEngine()
{
	delete model;
}
