////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Stencil Buffer Shadows                                //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include	<windows.h>			
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	<stdio.h>
#include	<assert.h>
#include	<math.h>
#include	"3DObject.h"

#include	"vertex3dOP.h"

#define		SHADOW_LENGTH	256.0f

C3DObject::C3DObject( char *file, float _texOffset )
{
	if ( file == NULL )
	{
		nVertices = nFaces = 0;
	}

	texOffset = _texOffset;

	FILE *f = fopen( file, "rt" );
	assert( f );

	fscanf( f, "%d %d", &nVertices, &nFaces );

	pVertexList	= new VERTEX3D[ nVertices ];
	assert( pVertexList );
	pNormalList	= new VERTEX3D[ nVertices ];
	assert( pNormalList );
	pTexCoordList = new float[ 2*nVertices ];
	assert( pTexCoordList );
	pFaceList	= new FACE[ nFaces ];
	assert( pFaceList );

	for ( int i = 0; i < nVertices; i++ )
		fscanf( f, "%f %f %f", &pVertexList[ i ].x, &pVertexList[ i ].y, &pVertexList[ i ].z );

	for ( i = 0; i < nFaces; i++ )
		fscanf( f, "%d %d %d", &pFaceList[ i ].a, &pFaceList[ i ].b, &pFaceList[ i ].c );

	for ( i = 0; i < nFaces; i++ )
	{
		//pFaceList[ i ].a--;
		//pFaceList[ i ].b--;
		//pFaceList[ i ].c--;
		pFaceList[ i ].p[ 0 ] = pFaceList[ i ].a;
		pFaceList[ i ].p[ 1 ] = pFaceList[ i ].b;
		pFaceList[ i ].p[ 2 ] = pFaceList[ i ].c;
	}

	fclose( f );

	// Standardfarbe
	r = g = b = 1.0f;

	// Normalen berechnen
	for ( i = 0; i < nFaces; i++ )
	{
		VERTEX3D	*a1, *a2, *a3;
		VERTEX3D	a, b;

		a1 = &pVertexList[ pFaceList[ i ].a ];
		a2 = &pVertexList[ pFaceList[ i ].b ];
		a3 = &pVertexList[ pFaceList[ i ].c ];

		a = *a2 - *a1;
		b = *a3 - *a1;

		pFaceList[ i ].normal = a ^ b;

		~pFaceList[ i ].normal;
	}

	// Vertexnormalen
	for ( i = 0; i < nVertices; i++ )
		pNormalList[ i ].x =
		pNormalList[ i ].y =
		pNormalList[ i ].z = 0.0f;

	for ( i = 0; i < nFaces; i++ )
	{
		pNormalList[ pFaceList[ i ].a ] += pFaceList[ i ].normal;
		pNormalList[ pFaceList[ i ].b ] += pFaceList[ i ].normal;
		pNormalList[ pFaceList[ i ].c ] += pFaceList[ i ].normal;
	}

	for ( i = 0; i < nVertices; i++ )
	{
		~pNormalList[ i ];
	}

	pEdgeList   = new EDGE[ nFaces * 3 ];
	nEdges = 0;

#define ADDEDGE2LIST( pp, aa, bb ) \
low  = min( aa, bb );					\
high = max( aa, bb );					\
found = -1;															\
for ( j = 0; j < nEdges; j++ )										\
	if ( pEdgeList[ j ].a == low && pEdgeList[ j ].b == high )		\
	{																\
		found = j; break;											\
	}																\
if ( found == -1 )													\
{																	\
	found = nEdges;													\
	pEdgeList[ nEdges ].a = low;									\
	pEdgeList[ nEdges ].b = high;									\
	pEdgeList[ nEdges ].poly[ 0 ] = pp;								\
	pEdgeList[ nEdges++ ].boundary = 1;								\
} else																\
{																	\
	pEdgeList[ j ].poly[ 1 ] = pp;									\
	pEdgeList[ j ].boundary ++;										\
}

	// Kantenliste aufbauen
	for ( i = 0; i < nFaces; i++ )
	{
		int low, high, found, j;

		// Jede Kante hinzuf�gen (keine doppelt, daf�r da Makro
		ADDEDGE2LIST( i, pFaceList[ i ].a, pFaceList[ i ].b );
		// und Index der Kante in der Liste speichern
		pFaceList[ i ].adjacent[ 0 ] = found;
		ADDEDGE2LIST( i, pFaceList[ i ].b, pFaceList[ i ].c );
		pFaceList[ i ].adjacent[ 1 ] = found;
		ADDEDGE2LIST( i, pFaceList[ i ].a, pFaceList[ i ].c );
		pFaceList[ i ].adjacent[ 2 ] = found;
	}

	// Nachbarschaftsinformation f�r die Dreiecke
	for ( i = 0; i < nFaces; i++ )
	{
		for ( int j = 0; j < 3; j++ )
		{
			// Jede Kante
			int edge = pFaceList[ i ].adjacent[ j ];
			int *adj = &pEdgeList[ edge ].poly[ 0 ];

			// und schauen, welches das andere Dreieck ist, das die Kante
			// teilt (sofern es eines gibt)
			if ( pEdgeList[ edge ].boundary == 1 )
				pFaceList[ i ].adjacentFace[ j ] = NULL; else
			{
				if ( adj[ 0 ] == i )
					pFaceList[ i ].adjacentFace[ j ] = &pFaceList[ adj[ 1 ] ]; else
					pFaceList[ i ].adjacentFace[ j ] = &pFaceList[ adj[ 0 ] ];
			}

		}

	}

	// Dieser Wert wird noch zum Backface Culling (ausser der Polygonnormale) ben�tigt:
	// Abstand der Ebene in der ein Dreieck liegt zum Ursprung
	for ( i = 0; i < nFaces; i++ )
	{
		pFaceList[ i ].w = pFaceList[ i ].normal * pVertexList[ pFaceList[ i ].a ];
	}
}

C3DObject::~C3DObject()
{
	delete pVertexList;
	delete pNormalList;
	delete pFaceList;
}

void	C3DObject::drawShadow( VERTEX3D lightPosition )
{
	MATRIX44 modelView, invModelView;

	// Modelview Matrix holen...
	glGetFloatv( GL_MODELVIEW_MATRIX, modelView );

	// ... invertieren
	InverseMatrixAnglePreserving( modelView, invModelView );

	// ... und Lichtquelle in Object Space
	VERTEX3D lightPos;
	lightPos = invModelView * lightPosition;

	// Backface Culling von der Lichtquelle aus
	for ( int i = 0; i < nFaces; i++ )
	{
		if ( pFaceList[ i ].normal * lightPos + 
		     pFaceList[ i ].w > 0 )
			pFaceList[ i ].facesLight = 1; else
			pFaceList[ i ].facesLight = 0;
	}

	// Vorbereiten von Stencil Buffer zeichnen
 	glDisable( GL_LIGHTING );
	glDepthFunc( GL_LEQUAL );
	glDepthMask( GL_FALSE );

	glEnable( GL_STENCIL_TEST );
	glColorMask( 0, 0, 0, 0 );
	glStencilFunc( GL_ALWAYS, 1, 0xffffffff );

	// 1. Pass: Zeichnen der Frontfacing Polygone des Shadow Volumes, Stencil Buffer inkrementieren
	glFrontFace( GL_CCW );
	glStencilOp( GL_KEEP, GL_KEEP, GL_INCR );

	// alle Polygone die zum Licht hinzeigen
	for ( i = 0; i < nFaces; i ++ )
	if ( pFaceList[ i ].facesLight )
	{
		FACE *k;
		// alle Nachbardreiecke anschauen
		for ( int j = 0; j < 3; j++ )
		if ( ( k = pFaceList[ i ].adjacentFace[ j ] ) != NULL && !k->facesLight )
		{
			// Ja, es gibt eins und es ist vom Licht abgewandt
			// => Polygon bilden und in den Stencil Buffer zeichnen

			VERTEX3D	*e1 = &pVertexList[ pFaceList[ i ].p[ j ] ];
			VERTEX3D	*e2 = &pVertexList[ pFaceList[ i ].p[ (j+1)%3 ] ];
			VERTEX3D	e3, e4;
			e3 = *e1 + ( *e1 - lightPos ) * SHADOW_LENGTH;
			e4 = *e2 + ( *e2 - lightPos ) * SHADOW_LENGTH;

			glBegin( GL_TRIANGLE_STRIP );
				glVertex3fv( (GLfloat*)e1 );
				glVertex3fv( (GLfloat*)&e3 );
				glVertex3fv( (GLfloat*)e2 );
				glVertex3fv( (GLfloat*)&e4 );
			glEnd();
		}
	}

	// 2. Pass: Zeichnen der Backfacing Polygone des Shadow Volumes, Stencil Buffer dekrementieren
	glFrontFace( GL_CW );
	glStencilOp( GL_KEEP, GL_KEEP, GL_DECR );

	for ( i = 0; i < nFaces; i ++ )
	if ( pFaceList[ i ].facesLight )
	{
		FACE *k;
		for ( int j = 0; j < 3; j++ )
		if ( ( k = pFaceList[ i ].adjacentFace[ j ] ) != NULL && !k->facesLight )
		{
			VERTEX3D	*e1 = &pVertexList[ pFaceList[ i ].p[ j ] ];
			VERTEX3D	*e2 = &pVertexList[ pFaceList[ i ].p[ (j+1)%3 ] ];
			VERTEX3D	e3, e4;

			e3 = *e1 + ( *e1 - lightPos ) * SHADOW_LENGTH;
			e4 = *e2 + ( *e2 - lightPos ) * SHADOW_LENGTH;

			glBegin( GL_TRIANGLE_STRIP );
				glVertex3fv( (GLfloat*)e1 );
				glVertex3fv( (GLfloat*)&e3 );
				glVertex3fv( (GLfloat*)e2 );
				glVertex3fv( (GLfloat*)&e4 );
			glEnd();
		}
	}

	glFrontFace( GL_CCW );
	glColorMask( 1, 1, 1, 1 );

	glDepthFunc( GL_LEQUAL );
	glDepthMask( GL_TRUE );
	glEnable( GL_LIGHTING );
	glDisable( GL_STENCIL_TEST );
}

// mit dieser Funktion wird der Schatten im Bild, definiert
// durch den Stencil Buffer abgedunkelt
void	C3DObject::finishShadow()
{
 	glDisable( GL_LIGHTING );
	glDepthFunc( GL_LEQUAL );
	glDepthMask( GL_FALSE );
	glEnable( GL_STENCIL_TEST );

	glColor4ub( 0, 0, 0, 128 );

	glEnable( GL_BLEND );
	glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

	glStencilFunc( GL_NOTEQUAL, 0, 0xffffffff );
	glStencilOp( GL_KEEP, GL_KEEP, GL_KEEP );

	glMatrixMode( GL_MODELVIEW );
	glPushMatrix();
	glLoadIdentity();

	glMatrixMode( GL_PROJECTION );
	glPushMatrix();
	glLoadIdentity();

	glDisable( GL_DEPTH_TEST );
	glBegin( GL_TRIANGLE_STRIP );
		glVertex2i( -1,  1 );
		glVertex2i( -1, -1 );
		glVertex2i(  1,  1 );
		glVertex2i(  1, -1 );
	glEnd();
	glEnable( GL_DEPTH_TEST );

	glPopMatrix();
	glMatrixMode( GL_MODELVIEW );
	glPopMatrix();

	glDisable( GL_BLEND );

	glDepthFunc( GL_LEQUAL );
	glDepthMask( GL_TRUE );
	glEnable( GL_LIGHTING );
	glDisable( GL_STENCIL_TEST );
}

// einfach nur ein Objekt flatshaded zeichnen
void	C3DObject::drawObject()
{
	int i;

	glEnable( GL_LIGHTING );

	glDisable( GL_TEXTURE_2D );

	glBegin( GL_TRIANGLES );
	for ( i = 0; i < nFaces; i++ )
	{
		glNormal3fv( (GLfloat*)&pFaceList[ i ].normal );
		glVertex3fv( (GLfloat*)&pVertexList[ pFaceList[ i ].a ] );
		glVertex3fv( (GLfloat*)&pVertexList[ pFaceList[ i ].b ] );
		glVertex3fv( (GLfloat*)&pVertexList[ pFaceList[ i ].c ] );
	}
	glEnd();

}









