////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//                                                        //
//  Beispielimplementation des A*-Algorithmus             //
//                                                        //
//  (w)(c)2001 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include    <windows.h>         
#include    <stdio.h>
#include    <assert.h>
#include    <math.h>
#include    <gl\gl.h>           
#include    <gl\glu.h>          
#include    "glext.h"

#include    "texture.h"

#define     MAPSIZE 32

unsigned char   map[ MAPSIZE ][ MAPSIZE ];
unsigned char   marked[ MAPSIZE ][ MAPSIZE ];

static const int xofs[ 8 ] = { -1, 0, 1, -1, 1, -1, 0, 1 };
static const int yofs[ 8 ] = { -1, -1, -1, 0, 0, 1, 1, 1 };

#define COSTDIAGONAL 554    // sqrt(2)*100000/255
#define COSTSTRAIGHT 392    // 100000/255

static const int travCost[ 8 ] = 
    { COSTDIAGONAL, COSTSTRAIGHT, COSTDIAGONAL, 
      COSTSTRAIGHT, COSTSTRAIGHT, COSTDIAGONAL, 
      COSTSTRAIGHT, COSTDIAGONAL };

class Position
{
    private:

        int _x, _y;

    public:

        Position( int x, int y ) : _x( x ), _y( y ) {};
        Position() : _x( 0 ), _y( 0 ) {};

        const int x() const { return _x; };
        const int y() const { return _y; };

        void x( int x ) { _x = x; };
        void y( int y ) { _y = y; };

        const bool operator == ( const Position &p ) const { return ( p._x == _x && p._y == _y ); }
        const bool operator != ( const Position &p ) const { return !( p._x == _x && p._y == _y ); }

        Position & operator = ( const Position &p ) { _x = p._x; _y = p._y; return *this; }

        const Position neighbour( const int d ) const { return Position( _x + xofs[ d ], _y + yofs[ d ] ); }
};

class Node
{
    friend class AStar;
    private:
        int         g,      // kosten vom start bis zu dieser node
                    h,      // gesch�tzte restkosten
                    f;      // f = g + h
        Node        *pred;  // zeiger auf vorg�ngerknoten
        int         nPred;
        Position    p;      // eigene position

    public:
        Node() : pred( NULL ), g( 0 ), h( 0 ), f( 0 ), nPred( 0 ) { p.x(0); p.y(0); };

		Node( int _g, int _h, Node *_pred, int _nPred, Position _p )
		{
			g = _g;
			h = _h;
			f = g + h;
			pred = _pred;
			nPred = _nPred;
			p = _p;
		}
};

class AStar
{
    private:
        Position    start,
                    goal;

        // node "stack", als liste implementiert, definitiv nicht optimal !
        int         nOpen, nClosed;
        int         lowestOpen;             // index auf node in open, mit den geringsten gesamtkosten !
        int         lowestCost;
        int         nodesExpanded;
        Node        **open;
        Node        **closed;

        Node        *goalNode;

        int     pathCostEstimate( Position &s, Position &g )
        {
            int c = ( map[ s.x() ][ s.y() ] + 
				      map[ g.x() ][ g.y() ] ) >> 1;

            // variante 1
            int straight = max( abs( s.x() - g.x() ), abs( s.y() - g.y() ) );
            int diagonal = min( abs( s.x() - g.x() ), abs( s.y() - g.y() ) );
            return ( diagonal * COSTDIAGONAL + ( straight - diagonal ) * COSTSTRAIGHT ) * c;
            // variante 2
            //return max( abs( s.x() - g.x() ), abs( s.y() - g.y() ) ) * COSTSTRAIGHT * c;
            // variante 3
            //return sqrt( abs( s.x() - g.x() ) * abs( s.x() - g.x() ) + abs( s.y() - g.y() ) * abs( s.y() - g.y() ) ) * COSTSTRAIGHT * c;
            // triviale variante
            return 0;
        }

        int     traversalCost( Position &a, Position &b, int d )
        {
            int c = ( map[ a.x() ][ a.y() ] +
                      map[ b.x() ][ b.y() ] ) >> 1;

            return c * travCost[ d ];
        }

        void    pushNode( Node **list, int *count, Node *node )
        {
			list[ (*count)++ ] = node;
        }

        int     containsNode( Node **list, int count, Node *me )
        {
            for ( int i = 0; i < count; i++ )
                if ( list[ i ]->p == me->p )
                    return i;
            return -1;
        }

        void    removeNode( Node **list, int *count, int me )
        {
            list[ me ] = list[ --(*count) ];
        }

		int		isValid( Position &p )
		{
 			if ( p.x() < 0 || p.x() >= MAPSIZE || p.y() < 0 || p.y() >= MAPSIZE || map[ p.x() ][ p.y() ] == 255 )
				return 0;
			return 1;
		}

    public:
        AStar( Position &_start, Position &_goal ) : start( _start ), goal( _goal ), nOpen(0), nClosed(0), nodesExpanded(0) 
        {
            open  = new Node*[ MAPSIZE * MAPSIZE ];
            closed = new Node*[ MAPSIZE * MAPSIZE ];
        };
        AStar() : start( 0, 0 ), goal( 0, 0 ), nOpen(0), nClosed(0), nodesExpanded(0)
        {
            open  = new Node*[ MAPSIZE * MAPSIZE ];
            closed = new Node*[ MAPSIZE * MAPSIZE ];
        };

        ~AStar()
        {
            for ( int i = 0; i < nClosed; i++ )
                delete closed[ i ];
            for ( i = 0; i < nOpen; i++ )
                delete open[ i ];

            delete open;
            delete closed;
        }

        void    init( Position &s, Position &g )
        {
            nOpen = nClosed = 0;

            Node *startNode = new Node();

            startNode->p     = s;
            startNode->h     = pathCostEstimate( s, g );
            startNode->f     = startNode->h;
            startNode->pred  = NULL;
            startNode->nPred = 0;

            pushNode( open, &nOpen, startNode );

            lowestOpen = nOpen - 1;
            lowestCost = startNode->f;

            goal = g;
        };

		void	findLowestCost()
		{
            lowestCost = 0x7fffffff;
            for ( int i = 0; i < nOpen; i++ )
            {
                if ( open[ i ]->f < lowestCost )
                {
                    lowestCost = open[ i ]->f;
                    lowestOpen = i;
                }
            }
		}

		void	expandNode( Node *node )
		{
            for ( int d = 0; d < 8; d++ )
            {
                Position p = node->p.neighbour( d );

                if ( isValid( p ) )
                {
                    int newCost = node->g + traversalCost( node->p, p, d );

					Node *newNode = new Node(
					    newCost, pathCostEstimate( p, goal ),
						node, node->nPred+1, p );

                    int io, ic, contained = 0, oldCost = -1;

                    io = containsNode( open, nOpen, newNode );
                    ic = containsNode( closed, nClosed, newNode );

                    if ( io != -1 || ic != -1 )
                    {
                        if ( io != -1 )
                            oldCost = open[ io ]->g; else
                            oldCost = closed[ ic ]->g;
                    }

                    if ( oldCost != -1 &&
                         oldCost <= newCost )
                    {
                        delete newNode;
                        continue;
                    } else
                    {
                        if ( ic != -1 )
                            removeNode( closed, &nClosed, ic );

						// ein bisschen schneller  
						if ( io != - 1 )
                        {
                            delete open[ io ];
                            open[ io ] = newNode;

                            if ( newNode->f < lowestCost )
                            {
                                lowestCost = newNode->f;
                                lowestOpen = io;
                            }
                        } else
                        {
                            pushNode( open, &nOpen, newNode );
                            if ( newNode->f < lowestCost )
                            {
                                lowestCost = newNode->f;
                                lowestOpen = nOpen - 1;
                            }
                        }

						// ein bisschen besser zu lesen ;)
						/*if ( io != -1 )
							removeNode( open, &nOpen, io );

						pushNode( open, &nOpen, newNode );
						findLowestCost();*/

                    }
                }
            } // fertig mit der node expansion
		}

        int     searchPath()
        {
            while ( nOpen > 0 )
            {
                Node *node = open[ lowestOpen ];
                removeNode( (Node**)open, &nOpen, lowestOpen );

				findLowestCost();

                if ( node->p == goal )
                {
                    // ziel gefunden ! => pfad aufbauen
                    goalNode = node;
                    return node->nPred + 1;
                } else
                {
                    // node in jede richtung expandieren !
                    nodesExpanded ++;

					expandNode( node );

					marked[ node->p.x() ][ node->p.y() ] ++;
                }

                pushNode( closed, &nClosed, node );
            }
            return -1;
        }

        int getPath( Position *p )
        {
            Position *dst = &p[ goalNode->nPred ];

            int length = goalNode->nPred + 1;

            Node *node = goalNode;

            while ( 1 ) 
            {
                *dst = node->p;
                *dst --;
                if ( node->pred != NULL )
                    node = node->pred; else
                    break;
            };

            return length;
        }
};










void    drawMap()
{
    glLineWidth( 1.0f );

    for ( int j = 0; j < MAPSIZE; j++ )
        for ( int i = 0; i < MAPSIZE; i++ )
        {
            int c = 255 - map[ i ][ j ];

            glColor3ub( c, c, c );
            glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );

            glBegin( GL_QUADS );
            glVertex2i( i, j );
            glVertex2i( i+1, j );
            glVertex2i( i+1, j+1 );
            glVertex2i( i, j+1 );
            glEnd();

            glColor3ub( 0, 0, 0 );
            glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );

            glBegin( GL_QUADS );
            glVertex2i( i, j );
            glVertex2i( i+1, j );
            glVertex2i( i+1, j+1 );
            glVertex2i( i, j+1 );
            glEnd();
        }

    for ( j = 0; j < MAPSIZE; j++ )
        for ( int i = 0; i < MAPSIZE; i++ )
		if ( marked[ i ][ j ] )
        {
            glColor3ub( 0, 0, 255 );

            glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );
            glBegin( GL_QUADS );
            glVertex2f( i+0.4f, j+0.4f );
            glVertex2f( i+0.6f, j+0.4f );
            glVertex2f( i+0.6f, j+0.6f );
            glVertex2f( i+0.4f, j+0.6f );
            glEnd();
        }

}

void    drawPath( Position *path, int length )
{
    if ( path == NULL )
        return;

    for ( int i = 1; i < length; i++ )
    {
        Position *last = &path[ i - 1 ];
        Position *curr = &path[ i ];

        // draw line
        glColor3ub( 255, 0, 0 );

        glLineWidth( 2.0f );

        glBegin( GL_LINES );

        glVertex2f( last->x() + 0.5f, last->y() + 0.5f );
        glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );

        // Pfeilspitzen nicht sch�n, aber einfach !
        int dx = last->x() - curr->x();
        int dy = last->y() - curr->y();

        if ( dx == 0 && dy > 0 )
        {
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.35f, curr->y() + 0.85f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.65f, curr->y() + 0.85f );
        } else
        if ( dx == 0 && dy < 0 )
        {
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.35f, curr->y() + 0.15f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.65f, curr->y() + 0.15f );
        } else
        if ( dy == 0 && dx > 0 )
        {
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.85f, curr->y() + 0.35f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.85f, curr->y() + 0.65f );
        } else
        if ( dy == 0 && dx < 0 )
        {
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.15f, curr->y() + 0.35f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.15f, curr->y() + 0.65f );
        } else
        if ( dx < 0 && dy < 0 )
        {
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.15f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.15f );
        } else
        if ( dx < 0 && dy > 0 )
        {
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.15f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.85f );
        } else
        if ( dx > 0 && dy < 0 )
        {
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.85f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.15f );
        } else
        if ( dx > 0 && dy > 0 )
        {
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.85f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.5f );
            glVertex2f( curr->x() + 0.5f, curr->y() + 0.85f );
        } 

        glEnd();
    }
}

AStar       pathFinder;
Position    *path = NULL;
int         length = 0;

void    initGLoutput()
{
    Position start( 30, 30 );
    Position end( 1, 1 );

    pathFinder.init( start, end );

    memset( (unsigned char *)map, 1, MAPSIZE * MAPSIZE );
    memset( (unsigned char *)marked, 0, MAPSIZE * MAPSIZE );

	FILE *f = fopen( "cost1.raw", "rb" );
//	FILE *f = fopen( "labyrinth.raw", "rb" );
	fread( map, 32*32, 1, f );
	fclose( f );

	for ( int i = 0; i < MAPSIZE*MAPSIZE; i++ )
		((unsigned char*)&map)[ i ] = (255-((unsigned char*)&map)[ i ]);

	// Barriere hinzuf�gen !
    //for ( int j = 0; j < 31; j++ )
    //  map[ j ][ 16 ] = 255;

    if ( ( length = pathFinder.searchPath() ) != -1 )
    {
        // pfad gefunden
        path = new Position[ length ];

        pathFinder.getPath( path );
    }
}



void    drawGLOutput()
{
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

    glMatrixMode( GL_PROJECTION );
    glLoadIdentity();
    glTranslatef( -1.0f, -1.0f, -1.0f );
    glScalef( 2.0f / (float)MAPSIZE, 2.0f / (float)MAPSIZE, 2.0f / (float)MAPSIZE );

    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();

    drawMap();

    drawPath( path, length );
}

void    quitGLOutput()
{
    delete path;
}