////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//                                                        //
//  Spiegelungen mit Stencil Buffers                      //
//                                                        //
//  (w)(c)2002 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include	<windows.h>			
#include	<math.h>
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	"glext.h"
#include	"texture.h"
#include	"skybox.h"
#include	"3DObject.h"

typedef struct
{
	GLfloat x, y, z;
}VERTEX3D;

// Texturen die geladen werden
PCUTexture *marble;
PCUTexture *box;
PCUTexture *spiegel;
PCUTexture *spheremap;
PCUTexture *wood;

// 3D Objekte die geladen werden
C3DObject *chess[ 4 ]; 

void	init3DEngine()
{
	// Allgemeine Renderstates

    glShadeModel( GL_SMOOTH );

	glHint( GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST );

	glDisable( GL_POLYGON_SMOOTH );

	glEnable( GL_DEPTH_TEST );
	glFrontFace( GL_CCW );
	glEnable( GL_CULL_FACE );
	glCullFace( GL_BACK );
	glDepthFunc( GL_LEQUAL );
	glDisable( GL_LINE_SMOOTH );

	// texturen laden
	marble = new PCUTexture();
	marble->loadBMP( "./data/marble.bmp" );

	wood = new PCUTexture();
	wood->loadBMP( "./data/wood.bmp" );

	spheremap = new PCUTexture();
	spheremap->loadBMP( "./data/spheremap.bmp" );

	box = new PCUTexture();
	box->loadBMP( "./data/box.bmp" );

	spiegel = new PCUTexture();
	spiegel->loadBMP( "./data/mirror.bmp" );

	// skybox initialisieren
	skyboxInit();

	glClearDepth( 1.0f );
	glClearStencil( 0 );

	// Lichtquelle zur Beleuchtung der 3D Modelle
	glEnable( GL_LIGHT0 );

	GLfloat light_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat light_diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	GLfloat light_ambient[] = { 0.0f, 0.0f, 0.0f, 1.0f };

	glLightfv( GL_LIGHT0, GL_AMBIENT, light_ambient );
	glLightfv( GL_LIGHT0, GL_DIFFUSE, light_diffuse );
	glLightfv( GL_LIGHT0, GL_SPECULAR, light_specular );

	glLightf( GL_LIGHT0, GL_SPOT_EXPONENT, 18 );

	// 3D Modelle laden
	chess[ 0 ] = new C3DObject( "./data/king.3d" );
	chess[ 1 ] = new C3DObject( "./data/queen.3d" );
	chess[ 2 ] = new C3DObject( "./data/bishop.3d" );
	chess[ 3 ] = new C3DObject( "./data/rook.3d" );

}

static GLfloat lightPosition[] = { 5.0f, 5.0f, 5.0f, 1.0f };

  //
 // 3D Szene zeichnen
//
void drawScene()
{
	glPushMatrix();

	// Schachbrett
	glDisable( GL_BLEND );
	glDisable( GL_LIGHTING );
	marble->select();

	glBegin( GL_QUADS );
		glTexCoord2f( 0.0f, 1.0f );
		glVertex3f(  -2.0f, 0.0f, 2.0f );
			
		glTexCoord2f( 1.0f, 1.0f );
		glVertex3f(   2.0f, 0.0f, 2.0f );
			
		glTexCoord2f( 1.0f, 0.0f );
		glVertex3f(   2.0f, 0.0f, -2.0f );
			
		glTexCoord2f( 0.0f, 0.0f );
		glVertex3f(  -2.0f, 0.0f, -2.0f );
	glEnd();

	// Schachfiguren: 1. Pass = Basistexture !
	wood->select();

	glEnable( GL_LIGHTING );
	glEnable( GL_TEXTURE_2D );

	// Texturekoordinaten generieren lassen
	glTexGeni( GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR );
	glTexGeni( GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR );
	
	glEnable( GL_TEXTURE_GEN_S );
	glEnable( GL_TEXTURE_GEN_T );

	glMatrixMode( GL_TEXTURE );
	glScalef( 0.033f, 0.033f, 0.033f );
	glMatrixMode( GL_MODELVIEW );

	glColor4ub( 255, 255, 255, 255 );

	// und Figuren skaliert und positioniert zeichnen
	glPushMatrix();
	glTranslatef( -0.25f, 0, 0.25f+0.5f );
	glScalef( 0.032f, 0.032f, 0.032f );
	glTranslatef( 0.0f, 18.0f, 0.0f );
	chess[ 0 ]->drawObject();
	glPopMatrix();

	glPushMatrix();
	glTranslatef( -0.25f-0.5f, 0, 0.25f-1.0f );
	glScalef( 0.032f, 0.032f, 0.032f );
	glTranslatef( 0.0f, 17.5f, 0.0f );
	chess[ 1 ]->drawObject();
	glPopMatrix();

	glPushMatrix();
	glTranslatef( -0.25f+1.0f, 0, 0.25f+0.5f );
	glScalef( 0.025f, 0.025f, 0.025f );
	glTranslatef( 0.0f, 21.0f, 0.0f );
	chess[ 2 ]->drawObject();
	glPopMatrix();

	glPushMatrix();
	glTranslatef( -0.25f+0.5f, 0, 0.25f-0.5f );
	glScalef( 0.018f, 0.018f, 0.018f );
	glTranslatef( 0.0f, 19.5f, 0.0f );
	chess[ 3 ]->drawObject();
	glPopMatrix();

	glMatrixMode( GL_TEXTURE );
	glLoadIdentity();
	glMatrixMode( GL_MODELVIEW );

	// Schachfiguren: 2. Pass = Reflectionmap (nur damits sch�ner aussieht)
	glEnable( GL_TEXTURE_2D );

	spheremap->select();

	glColor4ub( 255, 255, 255, 128 );

	// additiv �berblenden
	glEnable( GL_BLEND );
	glBlendFunc( GL_SRC_ALPHA, GL_ONE );
	
	// Texturemapping Koordinaten f�r Spheremaps generieren lassen
	glTexGeni( GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP );
	glTexGeni( GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP );
	
	glEnable( GL_TEXTURE_GEN_S );
	glEnable( GL_TEXTURE_GEN_T );

	glPushMatrix();
	glTranslatef( -0.25f, 0, 0.25f+0.5f );
	glScalef( 0.032f, 0.032f, 0.032f );
	glTranslatef( 0.0f, 18.0f, 0.0f );
	chess[ 0 ]->drawObject();
	glPopMatrix();

	glPushMatrix();
	glTranslatef( -0.25f-0.5f, 0, 0.25f-1.0f );
	glScalef( 0.032f, 0.032f, 0.032f );
	glTranslatef( 0.0f, 17.5f, 0.0f );
	chess[ 1 ]->drawObject();
	glPopMatrix();

	glPushMatrix();
	glTranslatef( -0.25f+1.0f, 0, 0.25f+0.5f );
	glScalef( 0.025f, 0.025f, 0.025f );
	glTranslatef( 0.0f, 21.0f, 0.0f );
	chess[ 2 ]->drawObject();
	glPopMatrix();

	glPushMatrix();
	glTranslatef( -0.25f+0.5f, 0, 0.25f-0.5f );
	glScalef( 0.018f, 0.018f, 0.018f );
	glTranslatef( 0.0f, 19.5f, 0.0f );
	chess[ 3 ]->drawObject();
	glPopMatrix();

	glDisable( GL_TEXTURE_GEN_S );
	glDisable( GL_TEXTURE_GEN_T );
	glDisable( GL_BLEND );

	glPopMatrix();
}

  //
 // Spiegelfl�che zeichnen !
//
void drawMirror()
{
	// Texture leicht einblenden
	glColor4ub( 255, 255, 255, 96 );
	spiegel->select();

	glDisable( GL_LIGHTING );
	glBegin( GL_QUADS );

		glNormal3f(   0.0f, 1.0f, 0.0f );

		glTexCoord2f( 0.0f, 1.0f );
		glVertex3f(  -1.0f, 0.0f, 1.0f );
			
		glTexCoord2f( 1.0f, 1.0f );
		glVertex3f(   1.0f, 0.0f, 1.0f );
			
		glTexCoord2f( 1.0f, 0.0f );
		glVertex3f(   1.0f, 0.0f, -1.0f );
			
		glTexCoord2f( 0.0f, 0.0f );
		glVertex3f(  -1.0f, 0.0f, -1.0f );

	glEnd();
}

  //
 // Kiste hinter dem Spiegel zeichnen
//
void drawMirrorBox()
{
	box->select();
	glEnable( GL_LIGHTING );
	glColor4ub( 255, 255, 255, 255 );

	VERTEX3D pBoxList[ 8 ] = 
	{
		{ -1,  1, -1 },
		{  1,  1, -1 },
		{  1, -1, -1 },
		{ -1, -1, -1 },
		{ -1,  1, 1 },
		{  1,  1, 1 },
		{  1, -1, 1 },
		{ -1, -1, 1 },
	};

	VERTEX3D pBoxNormal[ 6 ] = 
	{
		{ 0, 1, 0 },
		{ -1, 0, 0 },
		{ 0, -1, 0 },
		{ 1, 0, 0 },
		{ 0, 0, -1 },
		{ 0, 0, 1 },
	};

	#define nIndices (4 * 6)
	WORD	pIndices[ nIndices ] = 
	{
		0, 1, 5, 4,
		1, 2, 6, 5,
		2, 3, 7, 6,
		3, 0, 4, 7,
		6, 7, 4, 5,
		1, 0, 3, 2
	};


	for ( int i = 0; i < 6; i++ ) 
	{
		glBegin( GL_QUADS );

		glNormal3fv( (GLfloat*)&pBoxNormal[ i*3 ] );

		glTexCoord2f( 0.0f + (1.0f / 256.0f), 0.0f + (1.0f / 256.0f) );
		glVertex3fv( (GLfloat*)&pBoxList[ pIndices[ i * 4 + 0 ] ] );

		glTexCoord2f( 0.0f + (1.0f / 256.0f), 1.0f - (1.0f / 256.0f) );
		glVertex3fv( (GLfloat*)&pBoxList[ pIndices[ i * 4 + 3 ] ] );

		glTexCoord2f( 1.0f - (1.0f / 256.0f), 1.0f - (1.0f / 256.0f) );
		glVertex3fv( (GLfloat*)&pBoxList[ pIndices[ i * 4 + 2 ] ] );

		glTexCoord2f( 1.0f - (1.0f / 256.0f), 0.0f + (1.0f / 256.0f) );
		glVertex3fv( (GLfloat*)&pBoxList[ pIndices[ i * 4 + 1 ] ] );

		glEnd();
	}
}

static float winkel = 90.0f;
static float winkel2 = 90.0f;

static VERTEX3D mirror = { -2, 1.1f, 0 };

// Transformation des Spiegels
void transformMirror()
{
	glTranslatef( mirror.x, mirror.y, mirror.z );
	glRotatef( winkel2, 0, 1, 0 );
	glRotatef( winkel, 0, 0, 1 );
	glScalef( 1.0, 1.0, 1.0 );
}

// inverse Transformation des Spiegels
void transformInverseMirror()
{
	glScalef( 1.0f/1.0, 1.0f/1.0, 1.0f/1.0 );
	glRotatef( -winkel, 0, 0, 1 );
	glRotatef( -winkel2, 0, 1, 0 );
	glTranslatef( -mirror.x, -mirror.y, -mirror.z );
}


void	draw3DEngine()
{
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT );

	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();

	extern int windowX, windowY;

	gluPerspective( 45.0f, (float)windowX / (float)max( 1, windowY ), 0.1f, 100.0f );

	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();
	
	glEnable( GL_NORMALIZE );
	glDisable( GL_BLEND );

	// "Animation"
	gluLookAt( 
		0.0f + cos( GetTickCount() * 0.0003f   ) * 4.0f, 
		2.0f + sin( GetTickCount() * 0.000123f ) * 1.0f, 
		0.0f + sin( GetTickCount() * 0.0003f   ) * 4.0f, 
		0, 0, 0, 0, 1, 0 );

	winkel2 = (float)sin( GetTickCount() * 0.001f ) * 25.0f + 180.0f;

	// 1. Schritt: Spiegel nur in den Stencil Buffer
	
	glColorMask( 0, 0, 0, 0 );					
	glEnable( GL_STENCIL_TEST );
	glStencilFunc( GL_ALWAYS, 1, 1 );
	glStencilOp( GL_KEEP, GL_KEEP, GL_REPLACE );
							
	glDisable( GL_DEPTH_TEST );
	
	glPushMatrix();
		transformMirror();
		drawMirror();										
	glPopMatrix();
	
	// 2. Schritt: gespiegelte Szene, dort, wo der Spiegel im Stencil Buffer ist
	
	glEnable( GL_DEPTH_TEST );
	glColorMask( 1, 1, 1, 1 );
	glStencilFunc( GL_EQUAL, 1, 1 );
														
	glStencilOp( GL_KEEP, GL_KEEP, GL_KEEP );
	glEnable( GL_CLIP_PLANE0 );

	glPushMatrix();
		
		transformMirror();
	
		double clipPlaneEq[] = { 0.0f,-1.0f, 0.0f, 0.0f };
		glClipPlane( GL_CLIP_PLANE0, clipPlaneEq );
	
		// Spiegelung
		glScalef( 1.0f, -1.0f, 1.0f );
		transformInverseMirror();

		glLightfv(GL_LIGHT0, GL_POSITION, lightPosition);

		// gespiegelte Szene zeichnen (Achtung: Culling andersrum)
		glCullFace( GL_FRONT );
		drawScene();

		glDisable( GL_LIGHTING );
		drawSkybox();

	glPopMatrix();

	glDisable( GL_CLIP_PLANE0 );
	glDisable( GL_STENCIL_TEST );

	// 3. Schritt: richtige Szene zeichnen
	glCullFace( GL_BACK );
	glClear( GL_DEPTH_BUFFER_BIT );
	
	// Spiegel zeichnen
	glLightfv( GL_LIGHT0, GL_POSITION, lightPosition );
	glDisable( GL_LIGHTING );
	glEnable( GL_BLEND );
	glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

	glPushMatrix();
		transformMirror();
		drawMirror();

		// Kiste
		glDisable( GL_BLEND );
		glScalef( 1.1f, 0.2f, 1.1f );
		glTranslatef( 0.0f, -1.05f, 0.0f );
		drawMirrorBox();
	
	glPopMatrix();

	// Rest der Szene
	drawScene();

	glDisable( GL_LIGHTING );
	drawSkybox();

	glFlush();
}

void	quit3DEngine()
{
	delete	marble;
	delete	box;
	delete	spiegel;
	delete	spheremap;
	delete	wood;
	delete	chess[ 0 ];
	delete	chess[ 1 ];
	delete	chess[ 2 ];
	delete	chess[ 3 ];
}

