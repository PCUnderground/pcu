////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Cartoon Rendering Mini 3D Engine Beispiel             //
//  (w)(c)2001 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include	"3DObject.h"

C3DObject	*model;

void	init3DEngine()
{
	glDisable( GL_CULL_FACE );
	glDepthFunc( GL_LEQUAL );

	model = new C3DObject( "data/ludwig.3d", "data/colors.bmp", 0.1f );
	model->setShadeMode( SHADE_INK_AND_PAINT );
	model->setColor( 0.6f, 0.6f, 0.6f );
}

void	draw3DEngine()
{
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	float time = (float)GetTickCount();

/*	glPushMatrix();
	model->setShadeMode( SHADE_INK );
	model->setColor( 1.0f, 1.0f, 1.0f );
	glTranslatef( -15.0f, 15.0f, 0.0f );
	glRotatef( time * 0.05f, 0.0f, 1.0f, 0.0f );
	glScalef( 2.0f, 2.0f, 2.0f );
	model->drawObject();
	glPopMatrix();

	glPushMatrix();
	model->setShadeMode( SHADE_INK );
	model->setColor( 0.6f, 0.6f, 0.6f );
	glTranslatef( 15.0f, 15.0f, 0.0f );
	glRotatef( time * 0.05f, 0.0f, 1.0f, 0.0f );
	glScalef( 2.0f, 2.0f, 2.0f );
	model->drawObject();
	glPopMatrix();
*/
	glPushMatrix();
	model->setShadeMode( SHADE_INK_AND_PAINT );
//	glTranslatef( 0.0f, -15.0f, 0.0f );
	glRotatef( time * 0.05f, 0.0f, 1.0f, 0.0f );
	glScalef( 2.0f, 2.0f, 2.0f );
	model->drawObject();
	glPopMatrix();
	
}

void	quit3DEngine()
{
	delete model;
}