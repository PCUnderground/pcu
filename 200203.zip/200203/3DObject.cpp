////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Cartoon Rendering Mini 3D Engine                      //
//  (w)(c)2001 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include	<windows.h>			
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	<stdio.h>
#include	<assert.h>
#include	<math.h>
#include	"3DObject.h"

#include	"vertex3dOP.h"

C3DObject::C3DObject( char *file, char *colorfile, float _texOffset ) : shadeMode(SHADE_INK), colors(NULL)
{
	if ( file == NULL )
	{
		nVertices = nFaces = 0;
	}

	texOffset = _texOffset;

	FILE *f = fopen( file, "rt" );
	assert( f );

	fscanf( f, "%d %d", &nVertices, &nFaces );

	pVertexList	= new VERTEX3D[ nVertices ];
	assert( pVertexList );
	pNormalList	= new VERTEX3D[ nVertices ];
	assert( pNormalList );
	pTexCoordList = new float[ 2*nVertices ];
	assert( pTexCoordList );
	pFaceList	= new FACE[ nFaces ];
	assert( pFaceList );

	for ( int i = 0; i < nVertices; i++ )
		fscanf( f, "%f %f %f", &pVertexList[ i ].x, &pVertexList[ i ].y, &pVertexList[ i ].z );

	for ( i = 0; i < nFaces; i++ )
		fscanf( f, "%d %d %d", &pFaceList[ i ].a, &pFaceList[ i ].b, &pFaceList[ i ].c );

	fclose( f );

	// Standardfarbe
	r = g = b = 1.0f;

	// Normalen berechnen
	for ( i = 0; i < nFaces; i++ )
	{
		VERTEX3D	*a1, *a2, *a3;
		VERTEX3D	a, b;

		a1 = &pVertexList[ pFaceList[ i ].a ];
		a2 = &pVertexList[ pFaceList[ i ].b ];
		a3 = &pVertexList[ pFaceList[ i ].c ];

		a = *a2 - *a1;
		b = *a3 - *a1;

		pFaceList[ i ].normal = a ^ b;

		~pFaceList[ i ].normal;
	}

	// Vertexnormalen
	for ( i = 0; i < nVertices; i++ )
		pNormalList[ i ].x =
		pNormalList[ i ].y =
		pNormalList[ i ].z = 0.0f;

	for ( i = 0; i < nFaces; i++ )
	{
		pNormalList[ pFaceList[ i ].a ] += pFaceList[ i ].normal;
		pNormalList[ pFaceList[ i ].b ] += pFaceList[ i ].normal;
		pNormalList[ pFaceList[ i ].c ] += pFaceList[ i ].normal;
	}

	for ( i = 0; i < nVertices; i++ )
	{
		~pNormalList[ i ];
	}

	pEdgeList   = new EDGE[ nFaces * 3 ];
	pRenderEdge = new EDGE[ nFaces * 3 ];
	nEdges = 0;

#define ADDEDGE2LIST( pp, aa, bb ) \
low  = min( aa, bb );					\
high = max( aa, bb );					\
found = 0;															\
for ( j = 0; j < nEdges; j++ )										\
	if ( pEdgeList[ j ].a == low && pEdgeList[ j ].b == high )		\
	{																\
		found = 1; break;											\
	}																\
if ( !found )														\
{																	\
	pEdgeList[ nEdges ].a = low;									\
	pEdgeList[ nEdges ].b = high;									\
	pEdgeList[ nEdges ].poly[ 0 ] = pp;								\
	pEdgeList[ nEdges++ ].boundary = 1;								\
} else																\
{																	\
	pEdgeList[ j ].poly[ 1 ] = pp;									\
	pEdgeList[ j ].boundary ++;										\
}

	for ( i = 0; i < nFaces; i++ )
	{
		int low, high, found, j;

		ADDEDGE2LIST( i, pFaceList[ i ].a, pFaceList[ i ].b );
		ADDEDGE2LIST( i, pFaceList[ i ].a, pFaceList[ i ].c );
		ADDEDGE2LIST( i, pFaceList[ i ].b, pFaceList[ i ].c );
	}

	colors = new PCUTexture();
	colors->loadBMP( colorfile );
}

C3DObject::~C3DObject()
{
	delete pVertexList;
	delete pNormalList;
	delete pFaceList;
}



void	C3DObject::drawObject()
{
	if ( shadeMode == SHADE_INK )
	{
		int i;

		glDisable( GL_BLEND );
		glDisable( GL_LIGHTING );

		glColor3f( r, g, b );

		glDisable( GL_TEXTURE_2D );

		glEnable( GL_POLYGON_OFFSET_FILL );
		glPolygonOffset( 1.0f, 5.0f );


		glBegin( GL_TRIANGLES );
		for ( i = 0; i < nFaces; i++ )
		{
			glVertex3fv( (GLfloat*)&pVertexList[ pFaceList[ i ].a ] );
			glVertex3fv( (GLfloat*)&pVertexList[ pFaceList[ i ].b ] );
			glVertex3fv( (GLfloat*)&pVertexList[ pFaceList[ i ].c ] );
		}
		glEnd();

		glDisable( GL_TEXTURE_2D );
		glDisable( GL_POLYGON_OFFSET_FILL );

		nRenderEdges = 0;
		for ( i = 0; i < nEdges; i++ )
		{
			int add2List = 0;

			// rand kante ?
			if ( pEdgeList[ i ].boundary == 1 )
				add2List = 1;

			if ( pEdgeList[ i ].boundary == 2 )
			{
				VERTEX3D *n1 = &pFaceList[ pEdgeList[ i ].poly[ 0 ] ].normal,
						 *n2 = &pFaceList[ pEdgeList[ i ].poly[ 1 ] ].normal;

				// knick in der oberfl�che ?
				float	 dot = *n1 * *n2;

				if ( dot < 0.4f )
					add2List = 1;
				
				// kante der silhoutte ?
				VERTEX3D *vertex = &pVertexList[ pEdgeList[ i ].a ];

				float matrix[ 16 ];
				glGetFloatv( GL_MODELVIEW_MATRIX, matrix );

				VERTEX3D viewVector;
				viewVector.x = matrix[ 0+2 ];
				viewVector.y = matrix[ 4+2 ];
				viewVector.z = matrix[ 8+2 ];
				~viewVector;

				float dot1 = viewVector * *n1;
				float dot2 = viewVector * *n2;

				if( ( dot1 * dot2 ) <= 0.00000001f )
					add2List = 1;

			}

			if ( add2List )
				pRenderEdge[ nRenderEdges ++ ] = pEdgeList[ i ];
		}

		glDisable( GL_LIGHTING );
		glDepthFunc( GL_LEQUAL );
		glColor3ub( 0, 0, 0 );
		glLineWidth( 2 );
		glPointSize( 2 );

		glEnable( GL_BLEND );
		glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );
		glEnable( GL_LINE_SMOOTH ); 
		glEnable( GL_POINT_SMOOTH );

		glBegin( GL_LINES );
		for ( i = 0; i < nRenderEdges; i++ )
		{
			glVertex3fv( (float*)&pVertexList[ pRenderEdge[ i ].a ] );
			glVertex3fv( (float*)&pVertexList[ pRenderEdge[ i ].b ] );
		}
		glEnd();

		glDepthFunc( GL_LESS );
		glBegin( GL_POINTS );
		for ( i = 0; i < nRenderEdges; i++ )
		{
			glVertex3fv( (float*)&pVertexList[ pRenderEdge[ i ].a ] );
			glVertex3fv( (float*)&pVertexList[ pRenderEdge[ i ].b ] );
		}
		glEnd();

		return;
	} else
	if ( shadeMode == SHADE_INK_AND_PAINT )
	{
		int i;

		glDisable( GL_BLEND );
		glDisable( GL_LIGHTING );
		glColor3ub( 255, 255, 255 );

		glEnable( GL_TEXTURE_2D );
		colors->select();

		glEnable( GL_POLYGON_OFFSET_FILL );
		glPolygonOffset( 1.0f, 5.0f );

		MATRIX44 modelview, invmodel;

		glGetFloatv( GL_MODELVIEW_MATRIX, modelview );
		InverseMatrixAnglePreserving( modelview, invmodel );

		// beleuchtungsberechnung
		for ( i = 0; i < nVertices; i++ )
		{
			// normale in worldspace transformieren
			VERTEX3D *n = &pNormalList[ i ];
			VERTEX3D tn;
			tn.x = *n * *(VERTEX3D*)&invmodel[ 0 ];
			tn.y = *n * *(VERTEX3D*)&invmodel[ 4 ];
			tn.z = *n * *(VERTEX3D*)&invmodel[ 8 ];
			~tn;

			// lichtrichtung
			VERTEX3D lightDir = { 0.0f, 1.0f, 1.0f };
			~lightDir;

			float light = lightDir * tn;

			if ( light < 0.1 ) 
				light = 0.1f;
			if ( light > 0.9f ) 
				light = 0.9f;
			
			pTexCoordList[ i * 2 + 0 ] = light;
			pTexCoordList[ i * 2 + 1 ] = 1.0f-texOffset;
		}

		glBegin( GL_TRIANGLES );
		for ( i = 0; i < nFaces; i++ )
		{
			glTexCoord2fv( (GLfloat*)&pTexCoordList[ pFaceList[ i ].a * 2 ] );
			glVertex3fv( (GLfloat*)&pVertexList[ pFaceList[ i ].a ] );
			glTexCoord2fv( (GLfloat*)&pTexCoordList[ pFaceList[ i ].b * 2 ] );
			glVertex3fv( (GLfloat*)&pVertexList[ pFaceList[ i ].b ] );
			glTexCoord2fv( (GLfloat*)&pTexCoordList[ pFaceList[ i ].c * 2 ] );
			glVertex3fv( (GLfloat*)&pVertexList[ pFaceList[ i ].c ] );
		}
		glEnd();

		glDisable( GL_TEXTURE_2D );
		glDisable(GL_POLYGON_OFFSET_FILL);

		nRenderEdges = 0;
		for ( i = 0; i < nEdges; i++ )
		{
			int add2List = 0;

			// rand kante ?
			if ( pEdgeList[ i ].boundary == 1 )
				add2List = 1;

			if ( pEdgeList[ i ].boundary == 2 )
			{
				VERTEX3D *n1 = &pFaceList[ pEdgeList[ i ].poly[ 0 ] ].normal,
						 *n2 = &pFaceList[ pEdgeList[ i ].poly[ 1 ] ].normal;

				// knick in der oberfl�che ?
				float	 dot = *n1 * *n2;

				if ( dot < 0.4f )
					add2List = 1;
				
				// kante der silhoutte ?
				VERTEX3D *vertex = &pVertexList[ pEdgeList[ i ].a ];

				float matrix[ 16 ];
				glGetFloatv( GL_MODELVIEW_MATRIX, matrix );

				VERTEX3D viewVector;
				viewVector.x = matrix[ 0+2 ];
				viewVector.y = matrix[ 4+2 ];
				viewVector.z = matrix[ 8+2 ];
				~viewVector;

				float dot1 = viewVector * *n1;
				float dot2 = viewVector * *n2;

				if( ( dot1 * dot2 ) <= 0.00000001f )
					add2List = 1;

			}

			if ( add2List )
				pRenderEdge[ nRenderEdges ++ ] = pEdgeList[ i ];
		}

		glDisable( GL_LIGHTING );
		glDepthFunc( GL_LEQUAL );
		glColor3ub( 0, 0, 0 );
		glLineWidth( 2 );
		glPointSize( 2 );

		glEnable( GL_BLEND );
		glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );
		glEnable( GL_LINE_SMOOTH ); 
		glEnable( GL_POINT_SMOOTH );

		glBegin( GL_LINES );
		for ( i = 0; i < nRenderEdges; i++ )
		{
			glVertex3fv( (float*)&pVertexList[ pRenderEdge[ i ].a ] );
			glVertex3fv( (float*)&pVertexList[ pRenderEdge[ i ].b ] );
		}
		glEnd();

		glDepthFunc( GL_LESS );
		glBegin( GL_POINTS );
		for ( i = 0; i < nRenderEdges; i++ )
		{
			glVertex3fv( (float*)&pVertexList[ pRenderEdge[ i ].a ] );
			glVertex3fv( (float*)&pVertexList[ pRenderEdge[ i ].b ] );
		}
		glEnd();


		return;
	} 
}









