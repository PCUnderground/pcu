////////////////////////////////////////////////////////////
//                                                        //
//  PC MAGAZIN - PC Underground                           //
//  Cartoon Rendering Mini 3D Engine                      //
//  (w)(c)2001 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#ifndef _3DOBJECT__H
#define _3DOBJECT__H

#include	<windows.h>			
#include	<gl\gl.h>			
#include	<gl\glu.h>			
#include	<math.h>
#include	"texture.h"

#define	SHADE_INK    		0x00000001
#define SHADE_INK_AND_PAINT	0x00000002

typedef struct
{
	GLfloat		x, y, z;
}VERTEX3D;

typedef struct
{
	GLint		a, b, c;
	VERTEX3D	normal;
}FACE;

typedef struct
{
	GLint		a, b;
	int			boundary;
	int			poly[ 2 ];
}EDGE;

class C3DObject
{
	private:

		VERTEX3D	*pVertexList;
		VERTEX3D	*pNormalList;
		float		*pTexCoordList;
		EDGE		*pEdgeList;
		EDGE		*pRenderEdge;
		FACE		*pFaceList;

		int			nVertices,
					nFaces,
					nEdges,
					nRenderEdges;

		int			shadeMode;

		PCUTexture	*colors;
		float		texOffset;

		// Farbe
		GLfloat		r, g, b;

	public:
		C3DObject( char *file = NULL, char *colorfile = NULL, float _texOffset = 0.0f );
		~C3DObject();

		void		drawObject();
		void		setShadeMode( int s ) { shadeMode = s; };
		void		setColor( GLfloat rr, GLfloat gg, GLfloat bb )
		{
			r = rr; g = gg; b = bb;
		}
};


#endif