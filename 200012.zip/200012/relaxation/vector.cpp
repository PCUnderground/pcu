////////////////////////////////////////////////////////////
//                                                        //
//  PC Underground - Dreiecknetze                         //
//  (w)(c)2000 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include "vector.h"

void	operator += ( VERTEX3DI &a, const VERTEX3DI &b )
{
	a.x += b.x;
	a.y += b.y;
	a.z += b.z;
}

void	operator *= ( VERTEX3DI &a, const float b )
{
	a.x = (long)((float)a.x * b);
	a.y = (long)((float)a.y * b);
	a.z = (long)((float)a.z * b);
}

VERTEX3DI	operator - ( const VERTEX3DI &a, const VERTEX3DI &b )
{
	VERTEX3DI result;

	result.x = a.x - b.x;
	result.y = a.y - b.y;
	result.z = a.z - b.z;

	return result;
}

void	operator += ( VERTEX3D &a, const VERTEX3D &b )
{
	a.x += b.x;
	a.y += b.y;
	a.z += b.z;
}

void	operator -= ( VERTEX3D &a, const VERTEX3D &b )
{
	a.x -= b.x;
	a.y -= b.y;
	a.z -= b.z;
}

void	operator *= ( VERTEX3D &a, const float b )
{
	a.x *= b;
	a.y *= b;
	a.z *= b;
}

VERTEX3D	operator - ( const VERTEX3D &a, const VERTEX3D &b )
{
	VERTEX3D result;

	result.x = a.x - b.x;
	result.y = a.y - b.y;
	result.z = a.z - b.z;

	return result;
}

VERTEX3D	operator + ( const VERTEX3D &a, const VERTEX3D &b )
{
	VERTEX3D result;

	result.x = a.x + b.x;
	result.y = a.y + b.y;
	result.z = a.z + b.z;

	return result;
}

float	operator * ( const VERTEX3D &a, const VERTEX3D &b )
{
	return ( a.x * b.x + a.y * b.y + a.z * b.z );
}

void	operator ~ ( VERTEX3D &a )
{
	float faktor = a * a;

	if ( faktor > 0 ) faktor = (float)1.0 / (float)sqrt( faktor );

	a *= faktor;
}

float	VLength( const VERTEX3D &a )
{
	return (float)sqrt( a * a );
}

VERTEX3D	operator * ( const VERTEX3D &a, const float b )
{
	VERTEX3D result;

	result.x = a.x * b;
	result.y = a.y * b;
	result.z = a.z * b;

	return result;
}

VERTEX3D	operator ^ ( const VERTEX3D &a, const VERTEX3D &b )
{
	VERTEX3D result;

	result.x = a.y * b.z - b.y * a.z;
	result.y = a.z * b.x - b.z * a.x;
	result.z = a.x * b.y - b.x * a.y;

	return result;
}
