////////////////////////////////////////////////////////////
//                                                        //
//  PC Underground - Dreiecknetze                         //
//  (w)(c)2000 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include <stdlib.h>
#include <stdio.h>
#include <iostream.h>
#include <limits.h>
#include <string.h>
#include <math.h>
#include "vector.h"
#include "mesh.h"


// reads off and scales coordinates
void	CMesh::importOFF( char *name )
{
	int i;

	FILE *f = fopen( name, "rt" );

	if ( f == NULL )
	{
		return;
	}

	// OFF
	char dummy[ 256 ];
	fscanf( f, "%s", dummy );

	// # Vertices, Faces
	int zero;
	fscanf( f, "%d %d %d", &nVertices, &nPolys, &zero );

	// Vertices
	pVertexList = new VERTEX[ nVertices ];

	for ( i = 0; i < nVertices; i++ )
	{
		float	a, b, c;
		fscanf( f, "%f %f %f", &a, &b, &c );

		pVertexList[ i ].fPosition.x = a;
		pVertexList[ i ].fPosition.y = b;
		pVertexList[ i ].fPosition.z = c;
	}

	// Polygons
	pPolyList = new TRIANGLE[ nPolys ];

	for ( i = 0; i < nPolys; i++ )
	{
		int	a, b, c, d;
		char bla[1234];
		fgets( bla, 1000, f );
		fscanf( f, "%d %d %d %d", &d, &a, &b, &c );

		pPolyList[ i ].a = a;
		pPolyList[ i ].b = b;
		pPolyList[ i ].c = c;
	}

	fclose( f );
}

// writes the mesh as a new off file (coordinates are rescaled)
void CMesh::exportOFF( char *name )
{
	FILE *f = fopen( name, "wt" );
	if ( f == NULL )
		return;

	fprintf( f, "OFF\n%d %d 0\n", nVertices, nPolys );

	for ( int i = 0; i < nVertices; i++ )
	{
		VERTEX3D v;

		v.x = (float)pVertexList[ i ].fPosition.x;
		v.y = (float)pVertexList[ i ].fPosition.y;
		v.z = (float)pVertexList[ i ].fPosition.z;

		fprintf( f, "%f %f %f\n", v.x, v.y, v.z );
	}

	for ( i = 0; i < nPolys; i++ )
	{
		fprintf( f, "3 %d %d %d\n", pPolyList[ i ].a, pPolyList[ i ].b, pPolyList[ i ].c );
	}

	fclose( f );
}

int		CMesh::insertVertex( VERTEX3D *v )
{
	for ( int i = 0; i < nVertices2; i++ )
	{
		if ( pVertexList2[ i ].fPosition.x == v->x &&
			 pVertexList2[ i ].fPosition.y == v->y &&
			 pVertexList2[ i ].fPosition.z == v->z )
		{
			return i;
		}
	}
	pVertexList2[ nVertices2++ ].fPosition = *v;

	return nVertices2-1;
}

void	CMesh::split1to4()
{

	// backup vertices and polys
	pPolyList2 = new TRIANGLE[ nPolys * 4 ];
	pVertexList2 = new VERTEX[ nVertices * 4 ];

	//memcpy( pPolyList2, pPolyList, sizeof( TRIANGLE ) * nPolys );
	memcpy( pVertexList2, pVertexList, sizeof( VERTEX ) * nVertices );

	nPolys2 = 0;
	nVertices2 = nVertices;

	for ( int i = 0; i < nPolys; i++ )
	{
		VERTEX3D	m1, m2, m3;
		m1 = ( pVertexList[ pPolyList[ i ].a ].fPosition + pVertexList[ pPolyList[ i ].b ].fPosition ) * 0.5f;
		m2 = ( pVertexList[ pPolyList[ i ].b ].fPosition + pVertexList[ pPolyList[ i ].c ].fPosition ) * 0.5f;
		m3 = ( pVertexList[ pPolyList[ i ].c ].fPosition + pVertexList[ pPolyList[ i ].a ].fPosition ) * 0.5f;

		int i1, i2, i3;
		i1 = insertVertex( &m1 );
		i2 = insertVertex( &m2 );
		i3 = insertVertex( &m3 );


		pPolyList2[ nPolys2 ].a = pPolyList[ i ].a;
		pPolyList2[ nPolys2 ].b = i1;
		pPolyList2[ nPolys2++ ].c = i3;
		
		pPolyList2[ nPolys2 ].a = i1;
		pPolyList2[ nPolys2 ].b = pPolyList[ i ].b;
		pPolyList2[ nPolys2++ ].c = i2;
		
		pPolyList2[ nPolys2 ].a = i1;
		pPolyList2[ nPolys2 ].b = i2;
		pPolyList2[ nPolys2++ ].c = i3;

		pPolyList2[ nPolys2 ].a = i3;
		pPolyList2[ nPolys2 ].b = i2;
		pPolyList2[ nPolys2++ ].c = pPolyList[ i ].c;
	}

	delete pPolyList;
	delete pVertexList;

	nPolys = nPolys2; nVertices = nVertices2;
	pPolyList = new TRIANGLE[ nPolys ];
	pVertexList = new VERTEX[ nVertices ];

	memcpy( pPolyList, pPolyList2, sizeof( TRIANGLE ) * nPolys2 );
	memcpy( pVertexList, pVertexList2, sizeof( VERTEX ) * nVertices2 );

	delete pPolyList2;
	delete pVertexList2;
}


void	CMesh::relax()
{
	// backup vertices and polys
	pVertexList2 = new VERTEX[ nVertices ];

	memcpy( pVertexList2, pVertexList, sizeof( VERTEX ) * nVertices );

	for ( int i = 0; i < nVertices; i++ )
	{
		VERTEX3D	summe = { 0, 0, 0 };
		int			count = 0;
		VERTEX3D	pi = pVertexList2[ i ].fPosition;

		// Alle Dreiecke, in denen Vertex i vorkommt
		// leicht optimierte Variante der Berechnung, dafuer langsame Suche nach Nachbarvertices
		for ( int j = 0; j < nPolys; j++ )
		{
			if ( i == pPolyList[ j ].a || i == pPolyList[ j ].b || i == pPolyList[ j ].c )
			{
				summe = summe + pVertexList2[ pPolyList[ j ].a ].fPosition;
				summe = summe + pVertexList2[ pPolyList[ j ].b ].fPosition;
				summe = summe + pVertexList2[ pPolyList[ j ].c ].fPosition;
				summe = summe - pi * 3;
				count += 2;
			}
		}

		summe = summe * ( 1.0f / count );
		pi = pi + summe;
		pVertexList[ i ].fPosition = pi;
	}

	delete pVertexList2;
}

