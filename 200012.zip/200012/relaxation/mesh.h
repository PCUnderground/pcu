////////////////////////////////////////////////////////////
//                                                        //
//  PC Underground - Dreiecknetze                         //
//  (w)(c)2000 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#ifndef __MESH__H
#define __MESH__H

#include <windows.h>
#include "vector.h"

// polygon structure
typedef struct
{
	int			a, b, c;		// vertex indices
}TRIANGLE;

// vertex structure
typedef struct
{
	VERTEX3D	fPosition;		// floating point coordinates
	// ... other data here
}VERTEX;

// mesh class
class	CMesh
{
	public:
		// variables for the fine mesh
		int			nPolys, nVertices;
		TRIANGLE	*pPolyList;
		VERTEX		*pVertexList;

		// variables for the coarser mesh
		int			nPolys2, nVertices2;
		TRIANGLE	*pPolyList2;
		VERTEX		*pVertexList2;

		CMesh() 
		{ 
			nPolys = nVertices = 0;
			pPolyList = NULL;
			pVertexList = NULL;

			nPolys2 = nVertices2 = 0;
			pPolyList2 = NULL;
			pVertexList2 = NULL;
		};

		~CMesh()
		{
			if ( pPolyList )
				delete pPolyList;
			if ( pVertexList )
				delete pVertexList;
			if ( pPolyList2 )
				delete pPolyList2;
			if ( pVertexList2 )
				delete pVertexList2;
		}

		// loading/saving
		void	importOFF( char *name );
		void	exportOFF( char *name );

		// geometry/topology operators
		void	split1to4();
		void	relax();
		int		insertVertex( VERTEX3D *v );

	private:
};

#ifndef max
#define max __max
#endif

#ifndef min
#define min __min
#endif

#endif