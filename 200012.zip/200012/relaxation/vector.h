////////////////////////////////////////////////////////////
//                                                        //
//  PC Underground - Dreiecknetze                         //
//  (w)(c)2000 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#ifndef __VECTOR__H
#define __VECTOR__H

#include <math.h>

typedef struct
{
	float	x, y, z;
}VERTEX3D;

typedef struct
{
	signed long	x, y, z;
}VERTEX3DI;

void	operator += ( VERTEX3DI &a, const VERTEX3DI &b );
void	operator *= ( VERTEX3DI &a, const float b );
VERTEX3DI	operator - ( const VERTEX3DI &a, const VERTEX3DI &b );

void	operator += ( VERTEX3D &a, const VERTEX3D &b );
void	operator -= ( VERTEX3D &a, const VERTEX3D &b );
void	operator *= ( VERTEX3D &a, const float b );
VERTEX3D	operator - ( const VERTEX3D &a, const VERTEX3D &b );
VERTEX3D	operator + ( const VERTEX3D &a, const VERTEX3D &b );
float	operator * ( const VERTEX3D &a, const VERTEX3D &b );
void	operator ~ ( VERTEX3D &a );
float	VLength( const VERTEX3D &a );
VERTEX3D	operator * ( const VERTEX3D &a, const float b );
VERTEX3D	operator ^ ( const VERTEX3D &a, const VERTEX3D &b );


#endif