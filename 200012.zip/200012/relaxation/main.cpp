////////////////////////////////////////////////////////////
//                                                        //
//  PC Underground - Dreiecknetze                         //
//  (w)(c)2000 Carsten Dachsbacher                        //
//                                                        //
////////////////////////////////////////////////////////////
#include "mesh.h"

void main()
{
	CMesh *mesh = new CMesh();

	mesh->importOFF( "cube.off" );

	for ( int i = 0; i < 4; i++ )
		mesh->split1to4();

	for ( i = 0; i < 10; i++ )
		mesh->relax();

	mesh->exportOFF( "cube5.off" );
}