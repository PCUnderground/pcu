///////////////////////////////////////////////////////////
//                                                       //
// PC MAGAZIN - PC Underground                           //
//                                                       //
// Marching Cubes und Alphablend Demo                    //
// (w)(c)2000 by Carsten Dachsbacher                     //
//                                                       //
///////////////////////////////////////////////////////////
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#define  D3D_OVERLOADS
#include <d3dx.h> 
#include <d3d.h>
#include <ddraw.h>

#include <stdio.h>
#include <math.h>

#include "marching_cubes.h"

// Links
#pragma comment(lib, "d3dx.lib")
#pragma comment(lib, "ddraw.lib")

// unn�tige Compilerwarnings abschalten
#pragma warning(disable : 4244)		// truncation from const double to float
#pragma warning(disable : 4305)		// truncation from const double to float
#pragma warning(disable : 4018)		// signed/unsigned mismatch
#pragma warning(disable : 4101)		// unreferenced local variable

// Globale Variablen, inkl. D3DX und Matrizen
const int width  = 800;
const int height = 600;

HWND				_hwnd(0);
LPD3DXCONTEXT		D3DXContext(0);
LPDIRECT3DDEVICE7	D3DDevice(0);
LPDIRECT3D7			D3D7(0);
LPDIRECTDRAW7		DDraw(0);

D3DXMATRIX			matView;
D3DXMATRIX			matPosition;
D3DXMATRIX			matProjection;

D3DLVERTEX			vTriangle[4];

// Texturen
LPDIRECTDRAWSURFACE7 background;
LPDIRECTDRAWSURFACE7 texture;

// Rotationswinkel f�r Animation
float				RX=0, RY=0, RZ=0;

D3DXMATRIX g_DDraw
(1.0f, 0.0f, 0.0f, 0.0f,
 0.0f, 1.0f, 0.0f, 0.0f,
 0.0f, 0.0f, 1.0f, 0.0f,
 0.0f, 0.0f, 0.0f, 1.0f);

#define     RELEASENULL(object) if (object) {object->Release();}

// Variable f�r Hintergrundeffekt
float		BackgroundScale = 0.0f;

long _stdcall mainproc(HWND hwnd, UINT message, WPARAM wParm, LPARAM lParm);

LPDIRECTDRAWSURFACE7 LoadTexture( char *file ) 
{
	D3DX_SURFACEFORMAT		sf = D3DX_SF_A8R8G8B8;
	DWORD					flags = D3DX_TEXTURE_NOMIPMAP;
	LPDIRECTDRAWSURFACE7	pTex;
	
	if( !file )
		return NULL;
	
	if( FAILED( D3DXCreateTextureFromFile( D3DDevice, &flags, 0, 0, &sf, NULL, &pTex, NULL, file, D3DX_FT_POINT ) ) ) 
	{
		pTex = NULL;
	}

	return pTex;  
}


// Funktion zum �ndern des Alphakanals einer ARGB Textur
bool updateALPHA( DWORD surf, unsigned char* pdata ) 
{
	LPDIRECTDRAWSURFACE7 surface = (LPDIRECTDRAWSURFACE7) surf;
	
	if( !pdata ) return false;
	
	// zul�ssige Surface ?
	if( surface->Restore() != DD_OK )
		return false;
	
	// Lock
	DDSURFACEDESC2 ddsd;
	ddsd.dwSize = sizeof(ddsd);
	while( surface->Lock( NULL, &ddsd, 0, NULL ) == DDERR_WASSTILLDRAWING );
	
	DWORD lPitch = ddsd.lPitch;
	BYTE* pBytes = (BYTE*)ddsd.lpSurface;
	
	DWORD dwAShiftR = 24;
	DWORD dwAMask = 0xff000000;
	
	for( DWORD y=0; y<ddsd.dwHeight; y++ ) 
	{
		DWORD* pDstData32 = (DWORD*)pBytes;
		
		for( DWORD x=0; x<ddsd.dwWidth; x++ ) 
		{
			DWORD da = ( pdata[ y * ddsd.dwWidth + x ] << dwAShiftR ) & dwAMask;
			
			pDstData32[ x ] &= (DWORD)(-1 ^ dwAMask);
			pDstData32[ x ] |= (DWORD)(da);
		}
		pBytes += ddsd.lPitch;
	}
	
	return (surface->Unlock(NULL) == DD_OK );
}

// Zeichenroutine
BOOL draw( void ) 
{
	nFrames++;
	DoMarchingCubes();
	
	if ( SUCCEEDED(D3DDevice->BeginScene()) ) 
	{
		// nur Z-Buffer l�schen
		D3DXContext->Clear(D3DCLEAR_ZBUFFER);
		
		D3DDevice->SetTexture( 0, background );
		

		// Hintergrund zeichnen
		D3DTLVERTEX	vQuad[ 4 ];
		
		vQuad[ 0 ].dvTU = 0;
		vQuad[ 0 ].dvTV = 0;
		vQuad[ 1 ].dvTU = 0;
		vQuad[ 1 ].dvTV = 1;
		vQuad[ 2 ].dvTU = 1;
		vQuad[ 2 ].dvTV = 1;
		vQuad[ 3 ].dvTU = 1;
		vQuad[ 3 ].dvTV = 0;
		
		vQuad[ 0 ].dcColor = D3DRGBA( 1.0f, 1.0f, 1.0f, 1.0f );
		vQuad[ 1 ].dcColor = D3DRGBA( 1.0f, 1.0f, 1.0f, 1.0f );
		vQuad[ 2 ].dcColor = D3DRGBA( 1.0f, 1.0f, 1.0f, 1.0f );
		vQuad[ 3 ].dcColor = D3DRGBA( 1.0f, 1.0f, 1.0f, 1.0f );
		
		D3DDevice->SetRenderState(D3DRENDERSTATE_SRCBLEND, D3DBLEND_SRCALPHA);
		
		// nur einmal, ohne Zoomeffekt ?
		if ( BackgroundScale < 0.1f )
		{
			D3DDevice->SetRenderState( D3DRENDERSTATE_ALPHABLENDENABLE, FALSE );
			vQuad[ 0 ].dvSX = 0;
			vQuad[ 0 ].dvSY = 0;
			vQuad[ 0 ].dvSZ = vQuad[ 0 ].dvRHW = 1.0f;
			
			vQuad[ 1 ].dvSX = 0;
			vQuad[ 1 ].dvSY = height;
			vQuad[ 1 ].dvSZ = vQuad[ 1 ].dvRHW = 1.0f;
			
			vQuad[ 2 ].dvSX = width;
			vQuad[ 2 ].dvSY = height;
			vQuad[ 2 ].dvSZ = vQuad[ 2 ].dvRHW = 1.0f;
			
			vQuad[ 3 ].dvSX = width;
			vQuad[ 3 ].dvSY = 0;
			vQuad[ 3 ].dvSZ = vQuad[ 3 ].dvRHW = 1.0f;
			
			D3DDevice->DrawPrimitive( D3DPT_TRIANGLEFAN, D3DFVF_TLVERTEX, vQuad, 4, 0 );
			D3DDevice->SetRenderState( D3DRENDERSTATE_ALPHABLENDENABLE, TRUE );
		} else
		{
			// mehrmals, mit zoomen !
			for ( int j = 0; j < 9; j++ )
			{
				float move = BackgroundScale * (float)j;
				vQuad[ 0 ].dvSX = -move;
				vQuad[ 0 ].dvSY = -move;
				vQuad[ 0 ].dvSZ = vQuad[ 0 ].dvRHW = 1.0f;
				
				vQuad[ 1 ].dvSX = -move;
				vQuad[ 1 ].dvSY = height+move;
				vQuad[ 1 ].dvSZ = vQuad[ 1 ].dvRHW = 1.0f;
				
				vQuad[ 2 ].dvSX = width+move;
				vQuad[ 2 ].dvSY = height+move;
				vQuad[ 2 ].dvSZ = vQuad[ 2 ].dvRHW = 1.0f;
				
				vQuad[ 3 ].dvSX = width+move;
				vQuad[ 3 ].dvSY = -move;
				vQuad[ 3 ].dvSZ = vQuad[ 3 ].dvRHW = 1.0f;
				
				D3DDevice->DrawPrimitive( D3DPT_TRIANGLEFAN, D3DFVF_TLVERTEX, vQuad, 4, 0 );
			}
		}
		
		D3DDevice->SetTexture( 0, texture );
		
		// Objekt/Kameradrehung
		D3DXQUATERNION qR;
		D3DXMATRIX matPosition2;
		D3DXVECTOR3 vecPosition(0.0f, 0.0f, 0.0f);
		
		D3DXMatrixTranslation(&matView, 0.0f, 0.0f, 10.0f);
		
		D3DXQuaternionRotationYawPitchRoll(&qR, 0, D3DXToRadian( 0.0f ), 0 );
		D3DXMatrixAffineTransformation(&matPosition, 1.0f, NULL, &qR, &vecPosition);
		
		D3DXQuaternionRotationYawPitchRoll(&qR, RY, RX, RZ );
		D3DXMatrixAffineTransformation(&matPosition2, 1.0f, NULL, &qR, &vecPosition);
		
		D3DXMatrixMultiply(&matPosition, &matPosition2, &matPosition );
		
		D3DXMatrixMultiply(&matPosition, &matView, &matPosition );
		D3DXMatrixInverse(&matView, NULL, &matPosition);
		
		D3DDevice->SetTransform(D3DTRANSFORMSTATE_WORLD, g_DDraw);
		
		D3DDevice->SetTransform(D3DTRANSFORMSTATE_PROJECTION, matProjection );
		
		// Jetzt die Spiegelung r�ckg�ngig machen
		D3DDevice->SetTransform(D3DTRANSFORMSTATE_VIEW, matView);
		
		int i;

		// Environmentmapping Koordinaten one Betrachtung der Kameraposition
		for( i = 0; i < nVertices; i++ )
		{
			float nx = VertexList[i].nx;
			float ny = VertexList[i].ny;
			float nz = VertexList[i].nz;
			
			VertexList[i].nx = 0.5f * ( 1.0f + VertexList[i].nx );
			VertexList[i].ny = 0.5f * ( 1.0f + VertexList[i].ny );
		}

		D3DDevice->SetRenderState(D3DRENDERSTATE_SRCBLEND, D3DBLEND_ONE);
		// Dreiecke nacheinander zeichnen (Vertexbuffer w�re wahrscheinlich etwas besser)
		for ( i = 0; i < nFaces; i++ )
		{
			
			vTriangle[ 0 ].dvX = VertexList[FaceList[i].v1].x;
			vTriangle[ 0 ].dvY = VertexList[FaceList[i].v1].y;
			vTriangle[ 0 ].dvZ = VertexList[FaceList[i].v1].z;
			vTriangle[ 0 ].dvTU = VertexList[FaceList[i].v1].nx;
			vTriangle[ 0 ].dvTV = VertexList[FaceList[i].v1].ny;
			vTriangle[ 0 ].dcColor = 0xffffffff;
			
			vTriangle[ 1 ].dvX = VertexList[FaceList[i].v2].x;
			vTriangle[ 1 ].dvY = VertexList[FaceList[i].v2].y;
			vTriangle[ 1 ].dvZ = VertexList[FaceList[i].v2].z;
			vTriangle[ 1 ].dvTU = VertexList[FaceList[i].v2].nx;
			vTriangle[ 1 ].dvTV = VertexList[FaceList[i].v2].ny;
			vTriangle[ 1 ].dcColor = 0xffffffff;
			
			vTriangle[ 2 ].dvX = VertexList[FaceList[i].v3].x;
			vTriangle[ 2 ].dvY = VertexList[FaceList[i].v3].y;
			vTriangle[ 2 ].dvZ = VertexList[FaceList[i].v3].z;
			vTriangle[ 2 ].dvTU = VertexList[FaceList[i].v3].nx;
			vTriangle[ 2 ].dvTV = VertexList[FaceList[i].v3].ny;
			vTriangle[ 2 ].dcColor = 0xffffffff;
			
			D3DDevice->DrawPrimitive(D3DPT_TRIANGLELIST, D3DFVF_LVERTEX, vTriangle, 3, 0 );
		}
		
		D3DDevice->EndScene();
	}
	
	HRESULT hr = D3DXContext->UpdateFrame( D3DX_UPDATE_NOVSYNC );
	return ( hr != DDERR_SURFACELOST || hr != DDERR_SURFACEBUSY );
}

int _stdcall WinMain( HINSTANCE hInst, HINSTANCE hPInst, char* pCmd, int nCmd ) 
{
	// Fensterklasse
	WNDCLASSEX wc ={0};
	wc.cbSize = sizeof(wc);
	wc.lpfnWndProc = mainproc;
	wc.lpszClassName = "mainwindow";
	wc.hbrBackground = reinterpret_cast<HBRUSH>( GetStockObject(BLACK_BRUSH) );
	wc.hIcon = wc.hIconSm = LoadIcon( 0, IDI_WINLOGO );
	wc.hCursor = reinterpret_cast<HCURSOR>( NULL );
	wc.hInstance = hInst;
	if( !RegisterClassEx(&wc) )
		return -1;
	
	// Fenster erzeugen
	if( !(_hwnd=CreateWindow( wc.lpszClassName, "mainwindow", WS_POPUP, CW_USEDEFAULT, CW_USEDEFAULT, 640, 480, 0, 0, hInst, 0)) )
		return -1;
	
	// und anzeigen
	ShowWindow(_hwnd, nCmd);
	UpdateWindow(_hwnd);
	
	
	// D3DX Initialisieren
	if( FAILED(D3DXInitialize()) )
		return -1;
	
	// Und Context erzeugen
	// Fullscreen
	if( FAILED( D3DXCreateContextEx( D3DX_HWLEVEL_RASTER , D3DX_CONTEXT_FULLSCREEN, _hwnd, NULL,  D3DX_DEFAULT, 0, D3DX_DEFAULT, 0, 2, width, height, D3DX_DEFAULT, &D3DXContext)) )
		return -1;
	// Fenster
//	if ( FAILED( D3DXCreateContextEx(D3DX_HWLEVEL_RASTER, 0, _hwnd, NULL, D3DX_DEFAULT, 0, D3DX_DEFAULT, 0, 1, width, height, D3DX_DEFAULT, &D3DXContext) ) )
//			return -1;

	// Die Daten aus dem Context holen
	D3DDevice	= D3DXContext->GetD3DDevice();
	D3D7		= D3DXContext->GetD3D();
	DDraw		= D3DXContext->GetDD();

	D3DVIEWPORT7	FLViewport;

	D3DDevice->GetViewport( &FLViewport );
	// Renderstates setzen
	D3DDevice->SetRenderState(D3DRENDERSTATE_LIGHTING, FALSE);
	D3DDevice->SetRenderState(D3DRENDERSTATE_SHADEMODE, D3DSHADE_FLAT );
	
	D3DDevice->SetRenderState( D3DRENDERSTATE_CULLMODE, D3DCULL_CW );
	
	D3DDevice->SetRenderState(D3DRENDERSTATE_ZENABLE,D3DZB_TRUE);
	D3DDevice->SetRenderState(D3DRENDERSTATE_CLIPPING,FALSE ); 
	
    D3DDevice->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTFN_LINEAR);
    D3DDevice->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTFG_LINEAR);
    D3DDevice->SetTextureStageState(0, D3DTSS_MIPFILTER, D3DTFP_POINT);
    D3DDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
    D3DDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
    D3DDevice->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_DISABLE);
    D3DDevice->SetTextureStageState(1, D3DTSS_ALPHAOP, D3DTOP_DISABLE);

	// Texturen laden
	texture = LoadTexture( "texture2.bmp" );
	background = LoadTexture( "background.bmp" );

	// Alphawerte �ndern
	unsigned char alpha[256*256];
	memset( alpha, 128, 256*256 );
	updateALPHA( (DWORD)texture, alpha );
	updateALPHA( (DWORD)background, alpha );

    D3DXMatrixPerspectiveFov(&matProjection, D3DXToRadian( 45.0f ), 3.0f / 4.0f, 0.1f, 100.0f);

	D3DDevice->SetRenderState(D3DRENDERSTATE_SRCBLEND, D3DBLEND_ONE);
	D3DDevice->SetRenderState(D3DRENDERSTATE_DESTBLEND, D3DBLEND_INVSRCALPHA);
	D3DDevice->SetRenderState(D3DRENDERSTATE_ALPHABLENDENABLE, TRUE);

	// Hintergrundfarbe setzen
	D3DXContext->SetClearColor(D3DRGBA(0.0f,0.0f,0.0f,0));
	D3DXContext->Clear( D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER );

	InitMarchingCubes( -4.0, 4.0, -4.0, 4.0, -4.0, 4.0, 1.0 );

	// und im Windowmessage-Loop auf das Programmende warten
	MSG msg;
	PeekMessage( &msg, NULL, 0U, 0U, PM_NOREMOVE );
	while( WM_QUIT != msg.message  ) 
	{
		char buf[256];
		sprintf(buf, "%d", nFaces );
		SetWindowText(_hwnd, buf );
		if(PeekMessage(&msg, 0, 0, 0, PM_REMOVE)) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else if( !draw() )
			PostQuitMessage(0);
	}
	
	// DirectX Daten freigeben
	RELEASENULL( D3D7 );
	RELEASENULL( D3DDevice );
	RELEASENULL(D3DXContext );

	// D3DX beenden
	D3DXUninitialize();
	
	UNREFERENCED_PARAMETER(hPInst);
	UNREFERENCED_PARAMETER(pCmd);
	return msg.wParam;
}

// Der Messagehandler des Hauptfensters
long _stdcall mainproc(HWND hwnd, UINT message, WPARAM wParm, LPARAM lParm) 
{
	float t;
	switch( message ) {
		
    case WM_CREATE:
		SetTimer(hwnd, 1, 1, NULL );
		break;
	case WM_TIMER:
		// Animationsdaten aktualisieren
		RY -= 0.01f;
		RX -= 0.0111f;
		RZ -= 0.0131f;
		FrameTime += 0.01f;
		t = sin( FrameTime );
		t = pow( t, 10.0f );
		if ( t > 0.1f )
			BackgroundScale = (t-0.1f) * 20.0f;
		break;
	case WM_SETCURSOR:
		SetCursor(NULL);
		break;
    case WM_DESTROY:
		KillTimer(hwnd, 1);
		PostQuitMessage(0);
		return 0;
	case WM_KEYDOWN:
        if( wParm == 0x1b )
			PostQuitMessage(0);
        return 0;
	}
	return DefWindowProc(hwnd, message, wParm, lParm);
}
