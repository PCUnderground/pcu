#ifndef _MARCHINGCUBES_H
#define _MARCHINGCUBES_H

#define  D3D_OVERLOADS
#include <d3dx.h> 
#include <d3d.h>
#include <ddraw.h>

#define MB_DETAIL		30

typedef struct 
{
	int		v1, v2, v3;
} TRIANGLEIDX;

extern D3DVERTEX		*VertexList;		// Liste der erzeugten Vertices
extern int				nVertices;			
extern TRIANGLEIDX		*FaceList;			// Liste der erzeugten Dreiecke
extern int				nFaces;				
extern float			FrameTime;			
extern int				nFrames;

extern void InitMarchingCubes( float x1, float x2, float y1, float y2, float z1, float z2, float pot );
extern void DoMarchingCubes();

#endif