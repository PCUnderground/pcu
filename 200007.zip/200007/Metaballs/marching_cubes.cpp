///////////////////////////////////////////////////////////
//                                                       //
// PC MAGAZIN - PC Underground                           //
//                                                       //
// Marching Cubes Algorithmus							 //
// (w)(c)2000 by Carsten Dachsbacher                     //
//                                                       //
///////////////////////////////////////////////////////////
#include "marching_cubes.h"

D3DVERTEX		*VertexList;
int				nVertices;
TRIANGLEIDX		*FaceList;
int				nFaces;
int				*GridVertex;		// die f�r die Cubes erzeugten Vertices
float			*GridPotential;		// Eingabedaten
unsigned char	*GridToggle;		// Eingabedaten verglichen mit Referenzwert => 0 oder 255 !

float			MB_x1,MB_x2,MB_y1,MB_y2,MB_z1,MB_z2;	// Eckkoordinaten des Eingabefeldes
float			Potential;								// Referenzwert
float			FrameTime;
int				nFrames;

// Konstanten des Eingabefeldes
#define			StepsX	MB_DETAIL
#define			StepsY	MB_DETAIL
#define			StepsZ	MB_DETAIL
#define			StepsX_StepsY (StepsX * StepsY)
#define			StepsX_StepsY_StepsZ (StepsX * StepsY * StepsZ)

#include		"isotable.h"

// Innen/Au�en Test f�r einen Gitterpunkt
#define f(i,j,k) GridToggle[(i)+(j)*(StepsX+1)+(k)*(StepsX_StepsY+StepsX+StepsY+1)]
//----------------------------------------------

void FillInputData()
{
	int i,j,k;
	float x,y,z;
	float stepx,stepy,stepz;
	float Kugel_X_1, Kugel_Y_1, Kugel_Z_1;
	float Kugel_X_2, Kugel_Y_2, Kugel_Z_2;
	float Kugel_X_3, Kugel_Y_3, Kugel_Z_3;
	float Kugel_X_4, Kugel_Y_4, Kugel_Z_4;
	int index;

	// Positionen der Kugeln
	Kugel_X_1 = (float)sin(FrameTime*1.2f) * 2.5f;
	Kugel_Y_1 = (float)sin(FrameTime*1.3f) * 2.5f;
	Kugel_Z_1 = (float)sin(FrameTime*2.4f) * 2.5f;
	Kugel_X_2 = (float)sin(FrameTime*3.8f) * 2.0f;
	Kugel_Y_2 = (float)sin(FrameTime*2.2f) * 2.0f;
	Kugel_Z_2 = (float)sin(FrameTime*1.4f) * 2.0f;
	Kugel_X_3 = (float)sin(FrameTime*2.8f) * 1.0f;
	Kugel_Y_3 = (float)sin(FrameTime*3.6f) * 1.0f;
	Kugel_Z_3 = (float)sin(FrameTime*1.3f) * 1.0f;
	Kugel_X_4 = (float)cos(FrameTime*2.5f) * 1.0f;
	Kugel_Y_4 = (float)cos(FrameTime*3.4f) * 1.5f;
	Kugel_Z_4 = (float)cos(FrameTime*1.7f) * 1.5f;

	stepx = (MB_x2-MB_x1) / StepsX;
	stepy = (MB_y2-MB_y1) / StepsY;
	stepz = (MB_z2-MB_z1) / StepsZ;

	index = 0;
	z = MB_z1;
	for ( k = 0; k <= StepsZ; k ++ ) 
	{
		y = MB_y1;
		for ( j = 0; j <= StepsY; j ++ ) 
		{
			x = MB_x1;
			for ( i = 0; i <= StepsX; i ++ ) 
			{
				//index = i+j*(StepsX+1)+k*(StepsX+1)*(StepsY+1);
				GridPotential[ index ] = 0.0;
	
				/* Implizite Darstellung eines Torus
				float  r2 = 1.0;
				float  r1 = 2.5;
				double x2 = x*x, y2 = y*y, z2 = z*z;
				double a = (x2+y2+z2+(r1*r1)-(r2*r2));
				GridPotential[ index ] -= (a*a-4.0*(r1*r1)*(y2+z2))*0.05f;
				*/

				/* Implizite Darstellung eines Kegels
				GridPotential[ index ] += (x*x+y*y)-(z*z);
				*/

				GridPotential[ index ] += 
					1.0f/((x-Kugel_X_1)*(x-Kugel_X_1) + (y+Kugel_Y_1)*(y+Kugel_Y_1) + (z-Kugel_Z_1)*(z-Kugel_Z_1)) +
					1.0f/((x-Kugel_X_2)*(x-Kugel_X_2) + (y+Kugel_Y_2)*(y+Kugel_Y_2) + (z-Kugel_Z_2)*(z-Kugel_Z_2)) +
					1.0f/((x-Kugel_X_3)*(x-Kugel_X_3) + (y+Kugel_Y_3)*(y+Kugel_Y_3) + (z-Kugel_Z_3)*(z-Kugel_Z_3)) +
					1.0f/((x-Kugel_X_4)*(x-Kugel_X_4) + (y+Kugel_Y_4)*(y+Kugel_Y_4) + (z-Kugel_Z_4)*(z-Kugel_Z_4));
				GridPotential[ index ] -= Potential;

				// So siehts normalerweise aus:
				// GridToggle[ index ] = (GridPotential[ index ]>0)?255:0;
				// und so kann man das Vorzeichen eines IEEE Floats schneller testen:
				unsigned int vz = *(DWORD*)&GridPotential[ index ]>>31;
				if ( vz )
					GridToggle[ index ] = 0; else
					GridToggle[ index ] = 255;	// 255 wegen der eleganteren Wahl der Cubeindizes (s.u.)

				index ++;

				x += stepx;
			}
			y+= stepy;
		}
		z += stepz;
	}
}

void InitMarchingCubes( float x1, float x2, float y1, float y2, float z1, float z2, float pot )
{
	GridVertex    = new int[ 3 * StepsX * StepsY * StepsZ ];
	VertexList    = new D3DVERTEX[ 3 * StepsX * StepsY * StepsZ ];
	FaceList      = new TRIANGLEIDX[ 4 * StepsX * StepsY * StepsZ ];
	GridPotential = new float[ 4 * (StepsX+1) * (StepsY+1) * (StepsZ+1) ];
	GridToggle    = new unsigned char[ 4 * (StepsX+1) * (StepsY+1) * (StepsZ+1) ];

	MB_x1 = x1; MB_x2 = x2;
	MB_y1 = y1; MB_y2 = y2;
	MB_z1 = z1; MB_z2 = z2;
	Potential  = pot;
	FrameTime  = 0;
	nFrames = 0;
}

void DoMarchingCubes()
{
	int		i, j, k;
	float	LinearStep;
	int		index;
	float	x, y, z;

	nVertices = nFaces = 0;
	FillInputData();

	float stepx = (MB_x2 - MB_x1) / StepsX;
	float stepy = (MB_y2 - MB_y1) / StepsY;
	float stepz = (MB_z2 - MB_z1) / StepsZ;

	// Alle Cubes durchlaufen
	index = 0;
	z = MB_z1;
	for ( k = 0; k < StepsZ; k ++ ) 
	{
		y = MB_y1;
		for ( j = 0; j < StepsY; j ++ ) 
		{
			x = MB_x1;
			for ( i = 0; i < StepsX; i ++ ) 
			{
				// �berpr�fen, ob an Eckpunkten unterschiedlicher
				// Innen/Au�en Zustant herrscht

				//index = i+j*(StepsX+1)+k*(StepsX_StepsY+StepsX+StepsY+1);
				// X-Achse
				if ( GridToggle[ index ]^GridToggle[ index + 1 ] ) 
				{
					// Ja, dann Punkt einf�gen
					float f1 = GridPotential[ index ];
					float f2 = GridPotential[ index + 1 ];
					GridVertex[i+j*StepsX+k*StepsX_StepsY+0] = nVertices;
					VertexList[nVertices].nx = 
					VertexList[nVertices].ny = 
					VertexList[nVertices].nz = 0.0;
					// und Position linear interpolieren
					LinearStep = (f1) / (f2-f1);
					VertexList[nVertices].x = x - stepx*LinearStep;
					VertexList[nVertices].y = y;
					VertexList[nVertices].z = z;
					nVertices++;
				}
				// Y-Achse
				if ( GridToggle[ index ]^GridToggle[index+StepsX+1] ) 
				{
					float f1 = GridPotential[ index ];
					float f2 = GridPotential[index+StepsX+1];
					GridVertex[i+j*StepsX+k*StepsX_StepsY+StepsX_StepsY_StepsZ] = nVertices;
					VertexList[nVertices].nx = 
					VertexList[nVertices].ny = 
					VertexList[nVertices].nz = 0.0;
					LinearStep = (f1) / (f2-f1);
					VertexList[nVertices].x = x;
					VertexList[nVertices].y = y - stepy*LinearStep;
					VertexList[nVertices].z = z;
					nVertices++;
				}
				// Z-Achse
				if ( GridToggle[ index ]^GridToggle[index+StepsX_StepsY+StepsX+StepsY+1] ) 
				{
					float f1 = GridPotential[ index ];
					float f2 = GridPotential[index+StepsX_StepsY+StepsX+StepsY+1];
					GridVertex[i+j*StepsX+k*StepsX_StepsY+StepsX_StepsY_StepsZ+StepsX_StepsY_StepsZ] = nVertices;
					VertexList[nVertices].nx = 
					VertexList[nVertices].ny = 
					VertexList[nVertices].nz = 0.0;
					LinearStep = (f1) / (f2-f1);
					VertexList[nVertices].x = x;
					VertexList[nVertices].y = y;
					VertexList[nVertices].z = z - stepz*LinearStep;
					nVertices++;
				} 	
				index ++;
				x += stepx;
			}
			index ++;
			y += stepy;
		}
		index += 1 + MB_DETAIL;
		z += stepz;
	}

	// JeKugel_Z_t die Dreiecke und Indizes in die Vertexliste aufbauen
	z = MB_z1;
	for ( k = 0; k < StepsZ - 1; k ++ ) 
	{
		y = MB_y1;
		for ( j = 0; j < StepsY - 1; j ++ ) 
		{
			x = MB_x1;
			for ( i = 0; i < StepsX - 1; i ++ ) 
			{
				// Die W�rfelecken testen und in Bits codieren
				index  = f(i  ,j  ,k  )&0x01;
				index |= f(i+1,j  ,k  )&0x02;
				index |= f(i  ,j+1,k  )&0x04;
				index |= f(i+1,j+1,k  )&0x08;
				index |= f(i  ,j  ,k+1)&0x10;
				index |= f(i+1,j  ,k+1)&0x20;
				index |= f(i  ,j+1,k+1)&0x40;
				index |= f(i+1,j+1,k+1)&0x80;

				int npolys = nTriangles[ index ] * 3;
				index *= 12;

				// Anzahl der Dreiecke f�r diesen Cube
				for ( int l = 0; l < npolys; l += 3 ) 
				{
					// Kanten und Vertices aus den Tabellen lesen
					int		eindex = CubeEdges[index+l]*4;
					int		v1 = FaceList[nFaces].v1 = GridVertex[i+EdgeTable[eindex+1]+(j+EdgeTable[eindex+2])*StepsX+(k+EdgeTable[eindex+3])*StepsX_StepsY+EdgeTable[eindex]*StepsX_StepsY_StepsZ];
					eindex = CubeEdges[index+l+1]*4;
					int		v2 = FaceList[nFaces].v2 = GridVertex[i+EdgeTable[eindex+1]+(j+EdgeTable[eindex+2])*StepsX+(k+EdgeTable[eindex+3])*StepsX_StepsY+EdgeTable[eindex]*StepsX_StepsY_StepsZ];
					eindex = CubeEdges[index+l+2]*4;
					int		v3 = FaceList[nFaces].v3 = GridVertex[i+EdgeTable[eindex+1]+(j+EdgeTable[eindex+2])*StepsX+(k+EdgeTable[eindex+3])*StepsX_StepsY+EdgeTable[eindex]*StepsX_StepsY_StepsZ];

					// Und Normale des Dreiecks berechnen
					float	ax = VertexList[v2].x - VertexList[v1].x;
					float	ay = VertexList[v2].y - VertexList[v1].y;
					float	az = VertexList[v2].z - VertexList[v1].z;
					float	bx = VertexList[v3].x - VertexList[v1].x;
					float	by = VertexList[v3].y - VertexList[v1].y;
					float	bz = VertexList[v3].z - VertexList[v1].z;
					float	nx = ay*bz - az*by;
					float	ny = az*bx - ax*bz;
					float	nz = ax*by - ay*bx;

					// Normale normalisieren, und auf die Normalen aller am Dreieck beteiligten Vertices
					// addieren
					float n = (float)sqrt(nx*nx+ny*ny+nz*nz);
					if (n != 0.0) 
					{
						n = 1.0f/n;
						nx *= n; ny *= n; nz *= n;
					}
					VertexList[v1].nx += nx; VertexList[v1].ny += ny; VertexList[v1].nz += nz;
					VertexList[v2].nx += nx; VertexList[v2].ny += ny; VertexList[v2].nz += nz;
					VertexList[v3].nx += nx; VertexList[v3].ny += ny; VertexList[v3].nz += nz;
					nFaces++;
				}
				x += stepx;
			}
			y += stepy;
		}
		z += stepz;
	}

	// Normalen der Vertices normalisieren
	for ( i = 0; i < nVertices; i ++ ) 
	{
		float n = (float)sqrt(VertexList[i].nx*VertexList[i].nx + VertexList[i].ny*VertexList[i].ny + VertexList[i].nz*VertexList[i].nz );
		if (n != 0.0) 
		{
			n = 1.0f/n;
			VertexList[i].nx *= n; 
			VertexList[i].ny *= n; 
			VertexList[i].nz *= n;
		}
	}
}
