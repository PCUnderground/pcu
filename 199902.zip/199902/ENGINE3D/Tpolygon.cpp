///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - Demo Projekt                            //
//                                                       //
//  Polygonroutinen f�r die 3D-Engine                    //
//                                                       //
///////////////////////////////////////////////////////////
#include "demo.h"
#include "polygon.h"

unsigned short *ZBUFFER;	

long ceil16(long x)
{
    x +=  0xffff;
    return (x >> 16);
}

long imul16(long x, long y)
{
#ifdef ASSEMBLER_FIXED_POINT
	long result;

	__asm {
		mov eax, x
		imul y
		shrd eax, edx, 16
		mov result, eax
	}
	return result;
#else
	return (long)( ( (__int64)x * (__int64)y ) / (__int64)65536 );
#endif
}

long imul14(long x, long y)
{
#ifdef ASSEMBLER_FIXED_POINT
	long result;

	__asm {
		mov eax, x
		imul y
		shrd eax, edx, 14
		mov result, eax
	}
	return result;
#else
	return (long)( ( (__int64)x * (__int64)y ) / (__int64)16384 );
#endif
}

long idiv16(long x, long y)
{
#ifdef ASSEMBLER_FIXED_POINT
	long result;

	__asm {
		mov eax, x
		mov edx, eax
		sar edx, 16
		shl eax, 16
		idiv y
		mov result, eax
	}
	return result;
#else
	return (long)( ( (__int64)x * (__int64)65536 ) / (__int64)y );
#endif
}

// Dies sind die Variablen, die die Polygonroutinen ben�tigt
// Variablen f�r Kantenzeichnen
int o_eck,u_eck;
int r_eck,l_eck;
int rechts_hoehe,links_hoehe;
// Vertikale Positionen
int rechts_x ,links_x, links_u, links_v, links_g, links_z;
// Deltas f�r das ganze Polygon
int tex_du, tex_dv, gouraud_d, zbuffer_d;
// vertikale Deltas
int rechts_dx, links_dx, links_du, links_dv, links_dg, links_dz;

// Zeiger auf die Polygondaten
POLYDATA *polygon;

int LoadTexture( char *name, bitmaptype *bmp, unsigned short *palette1, unsigned short *palette2 )
{
	if ( bmp_load( name , *bmp ) != BMP_NOERROR ) return 0;

    // Shading Tabelle erstellen
    for ( int level = 0; level < 16; level ++ )
        for ( int i = 0; i < 16; i++ )
        {
			int r, g, b;
			r = g = b = i * 16;
            int spot = level>12 ? 32 * ( level - 12 ) : 0;
            r = spot + ( ( r * level ) / 6 );
            g = spot + ( ( g * level ) / 6 );
            b = spot + ( ( b * level ) / 6 );
            palette1[ level * 256 + i ] = ColorCode( r, 0, 0 );
            palette2[ level * 256 + i ] = ColorCode( 0, g, 0 );
        }

	for ( int i = 0; i < 256 * 256; i++ )
	{
		int c = bmp->cBitmap[ i ];
        int r = bmp->cColors[ c * 4 ];
        int g = bmp->cColors[ c * 4 + 1 ];
        int b = bmp->cColors[ c * 4 + 2 ];
		int s = r + g + b;
		s /= 3;
		s >>= 4;
		bmp->cBitmap[ i ] = s;
	}
	return 1;
}

static void RechteSeite(void)
{
	int hoehe, prestep;

	// Neuer Eckpunkt
	int index = r_eck - 1;
	if (index == 3) index = 0;
	if (index == -1) index = 2;

	// Calculate number of scanlines in this section

	rechts_hoehe = ceil16(polygon->punkt2d[index].y) - 
				   ceil16(polygon->punkt2d[r_eck].y);

	if(rechts_hoehe <= 0)
	{
	    r_eck = index;
		return;
	}

	if(rechts_hoehe > 1) 
	{
		// Die H�he des Abschnitts ist > 1, also kann normal
		// mit idiv16 gearbeitet werden
		hoehe = polygon->punkt2d[index].y - polygon->punkt2d[r_eck].y;
		rechts_dx    = idiv16(polygon->punkt2d[index].x - polygon->punkt2d[r_eck].x, hoehe);
	} else 
	{
		// die H�he des Abschnitts ist <= 1; die Verwendung
		// von idiv16 w�rde zu einem �berlauf f�hren, deshalb
		// wird mit Steigung = Breite * 1 / H�he mit 14 Bit
		// Nachkommagenauigkeit gearbeitet
		long inv_hoehe = (0x10000 << 14) / (polygon->punkt2d[index].y - polygon->punkt2d[r_eck].y);
		rechts_dx   = imul14(polygon->punkt2d[index].x - polygon->punkt2d[r_eck].x, inv_hoehe);
	}

	// Bei Subpixelgenauigkeit wird der Wert noch angepa�t
#ifdef SUBPIXEL
	prestep = (ceil16(polygon->punkt2d[r_eck].y) << 16) - polygon->punkt2d[r_eck].y;
	rechts_x = polygon->punkt2d[r_eck].x + imul16(prestep, rechts_dx);
#else
	rechts_x = polygon->punkt2d[r_eck].x;
#endif
	r_eck = index;
}


static void LinkeSeite(void)
{
	int hoehe, prestep;

    // N�chster Eckpunkt
	int index = l_eck + 1;
	if (index == -1) index = 2;
	if (index == 3) index = 0;

	links_hoehe = ceil16(polygon->punkt2d[index].y) - 
				  ceil16(polygon->punkt2d[l_eck].y);

	if(links_hoehe <= 0)
	{
	    l_eck = index;
		return;
	}

	// Beschreibung f�r die Unterscheidung ist analog zu
	// RechteSeite(void)
	if(links_hoehe > 1) 
	{
		hoehe = polygon->punkt2d[index].y - polygon->punkt2d[l_eck].y;
		links_dx = idiv16(polygon->punkt2d[index].x - polygon->punkt2d[l_eck].x, hoehe);
		links_du = idiv16(polygon->punktdata[index].u - polygon->punktdata[l_eck].u, hoehe);
		links_dv = idiv16(polygon->punktdata[index].v - polygon->punktdata[l_eck].v, hoehe);
		links_dg = idiv16(polygon->punktdata[index].g - polygon->punktdata[l_eck].g, hoehe);
		links_dz = idiv16(polygon->punktdata[index].z - polygon->punktdata[l_eck].z, hoehe);
	} else 
	{
	    long inv_hoehe = (0x10000 << 14) / (polygon->punkt2d[index].y - polygon->punkt2d[l_eck].y);
		links_dx = imul14(polygon->punkt2d[index].x - polygon->punkt2d[l_eck].x, inv_hoehe);
		links_du = imul14(polygon->punktdata[index].u - polygon->punktdata[l_eck].u, inv_hoehe);
		links_dv = imul14(polygon->punktdata[index].v - polygon->punktdata[l_eck].v, inv_hoehe);
		links_dg = imul14(polygon->punktdata[index].g - polygon->punktdata[l_eck].g, inv_hoehe);
		links_dz = imul14(polygon->punktdata[index].z - polygon->punktdata[l_eck].z, inv_hoehe);
	}

	// Wieder Anpassung der Werte f�r Subpixelgenauigkeit
#ifdef SUBPIXEL
	prestep = (ceil16(polygon->punkt2d[l_eck].y) << 16) - polygon->punkt2d[l_eck].y;
	links_x = polygon->punkt2d[l_eck].x + imul16(prestep, links_dx);
	links_u = polygon->punktdata[l_eck].u + imul16(prestep, links_du);
	links_v = polygon->punktdata[l_eck].v + imul16(prestep, links_dv);
	links_g = polygon->punktdata[l_eck].g + imul16(prestep, links_dg);
	links_z = polygon->punktdata[l_eck].z + imul16(prestep, links_dz);
#else
	links_x = polygon->punkt2d[l_eck].x;
	links_u = polygon->punktdata[l_eck].u;
	links_v = polygon->punktdata[l_eck].v;
	links_g = polygon->punktdata[l_eck].g;
	links_z = polygon->punktdata[l_eck].z;
#endif
	l_eck = index;
}


void TexturePolygon(POLYDATA *thispoly, unsigned short *screen, unsigned char *texture, unsigned short *palette)
{
	int i,j;

	unsigned short *vbuffer;
	unsigned short *zbuffer;
	int x1, breite;
#ifdef SUBTEXEL
	int prestep;
#endif
	int u, v, g, z;
#ifdef ASSEMBLER_INNER_LOOP
	int end_of_line;
#endif

	double d, id;
	PUNKT2D *vtx0,*vtx1,*vtx2;
	PUNKTDATA *pdata0,*pdata1,*pdata2;
  
	// f�r LinkeSeite() und RechteSeite() zug�nglich machen
	polygon = thispoly;

	// neue Zeiger auf die Daten (wegen �bersichtlichkeit)
	vtx0 = &polygon->punkt2d[0];
	vtx1 = &polygon->punkt2d[1];
	vtx2 = &polygon->punkt2d[2];

	pdata0 = &polygon->punktdata[0];
	pdata1 = &polygon->punktdata[1];
	pdata2 = &polygon->punktdata[2];
	
	// miny und maxy auf Extremwerte setzen
	int miny = SCREEN_Y<<16;
	int maxy = 0;

	// oberen und unteren Eckpunkt bestimmen
	for ( i=0; i<3; i++ )
	{
		if ( (j=polygon->punkt2d[i].y) < miny )
		{
			o_eck = i;
			miny = j;
		}
		if ( (j=polygon->punkt2d[i].y) > maxy )
		{
			u_eck = i;
			maxy = j;
		}
	}

	// Start f�r die linke/rechte Kante ist der obere Eckpunkt
	l_eck = r_eck = o_eck;

	// Zeigt das Polygon zum Betrachter ?
	d = ( (double)( vtx0->x - vtx2->x ) / 65536.0 * 
     	  (double)( vtx1->y - vtx2->y ) / 65536.0 -
          (double)( vtx1->x - vtx2->x ) / 65536.0 * 
		  (double)( vtx0->y - vtx2->y ) / 65536.0 );

	if ( d == 0.0 ) return;

	id = 1.0 / d;

	// Berechnung der horizontalen Texture, Gouraud und Z-Buffer Deltas
	double y12 = (double)(vtx1->y - vtx2->y) / 65536.0;
	double y02 = (double)(vtx0->y - vtx2->y) / 65536.0;


	tex_du =  (int)(( (double)(pdata0->u - pdata2->u) * y12 -
					  (double)(pdata1->u - pdata2->u) * y02 ) * id);
	tex_dv =  (int)(( (double)(pdata0->v - pdata2->v) * y12 -
                      (double)(pdata1->v - pdata2->v) * y02 ) * id);

	gouraud_d =(int)(( (double)(pdata0->g - pdata2->g) * y12 -
                       (double)(pdata1->g - pdata2->g) * y02 ) * id);

	zbuffer_d =(int)(( (double)(pdata0->z - pdata2->z) * y12 -
                       (double)(pdata1->z - pdata2->z) * y02 ) * id);


	// Linke und rechte Seite initialisieren
	do {
		if (r_eck == u_eck) return;
		RechteSeite();
	} while (rechts_hoehe<=0);


	do {
	    if (l_eck == u_eck) return;
		LinkeSeite();
	} while (links_hoehe<=0);


	vbuffer = screen + ceil16(miny) * SCREEN_X;
	zbuffer = ZBUFFER + ceil16(miny) * SCREEN_X;

	// und Zeichnen
	for (;;)
	{
		// Startpixel links und Breite der Linie
		x1 = ceil16(links_x);
		breite = ceil16(rechts_x) - x1;

		if (breite > 0)
		{
			// F�r Subtexel m�ssen die Werte in jeder
			// Scanline angepa�t werden
#ifdef SUBTEXEL
			prestep = (x1 << 16) - links_x;
			u = links_u + imul16( prestep, tex_du );
		    v = links_v + imul16( prestep, tex_dv );
			g = links_g + imul16( prestep, gouraud_d );	
			z = links_z + imul16( prestep, zbuffer_d );	
#else
			u = links_u;
			v = links_v;
			g = links_g;
			z = links_z;
#endif

			// eine Zeile zeichnen
#ifdef ASSEMBLER_INNER_LOOP
			__asm {
				mov eax, breite
				mov ecx, x1

				mov edi, v

				add eax, ecx
				
				mov esi, z
				
				mov end_of_line, eax

				mov ebx, zbuffer

			spalte:
				// Diese Variante ist nicht 100%ig korrekt:
				// Es wird der interpolierte Z-Wert mit dem
				// ausgelesenen Wert als Vorkomma- und dem 
				// n�chsten Wert Nachkommastelle verglichen
				// Der Effekt f�llt aber nicht auf !
				mov eax, dword ptr [ebx+ecx*2-2]
				mov edx, esi
				// F�r korrekten Vergleich:
				/*mov eax, dword ptr [ebx+ecx*2]
				mov edx, esi
				and eax, 0ffffh
				sar edx, 16*/

				cmp edx, eax
				jle nicht_dieser_pixel

				// Position in der Texturemap berechnen
				mov eax, u
				sub edx, edx
				shr eax, 16
				mov zbuffer, ebx
				mov ebx, edi
				sar ebx, 8
				and ebx, 0FFFF00h
				add eax, ebx
				mov ebx, texture
				and eax, 65535
				// Texel auslesen
				mov dl,  byte ptr [eax + ebx]
				
				// Shadingtabelle mit Gouraudwert und Texel
				mov eax, g
				sar eax, 9
				mov ebx, palette
				and eax, 0FF00h
				add eax, edx
				mov ebx, dword ptr [ ebx + eax * 2 ]
				// und den fertigen Pixel schreiben
				mov edx, vbuffer
				mov word ptr [ecx * 2 + edx], bx

				// ZBuffer aktualisieren
				mov eax, esi
				sar	eax, 16
				mov ebx, zbuffer
				mov word ptr [ebx+ecx*2], ax

		nicht_dieser_pixel:
				// Deltas addieren
				mov eax, g
				mov edx, gouraud_d
				add edi, tex_dv
				add eax, edx
				mov edx, u
				mov g, eax

				mov eax, tex_du
				add esi, zbuffer_d
				add edx, eax

				inc ecx
				mov u, edx
				
				mov eax, end_of_line
				cmp ecx, eax
				jl  spalte
			}
#else
			for ( i = 0; i < breite ; i++ )
			{
				// der Pixel mu� nur gezeichnet werden, wenn er
				// n�her am Betrachter liegt als der bisherige Wert
				if ( ( z>>16 ) > zbuffer[ i + x1 ] )
				{
						//j = ( ( u>>16 ) + ( ( v>>16 ) << 8 ) );
						vbuffer[ i + x1 ] = 
							// Auslesen der Shadingtabelle mit
							// Gouraud Intensit�t
							palette[ ((g>>9)&65280) + 
							// und Texelfarbwert
							*(texture+( ( u>>16 ) + ( ( v>>16 ) << 8 ) )) ];

						// Z-Bufferwert aktualisieren
						zbuffer[ i + x1 ] = (z>>16);
				}
				// horizontale Werte aktualisieren
				u += tex_du;
				v += tex_dv;
				g += gouraud_d;
				z += zbuffer_d;
			}
#endif
		}

		vbuffer += SCREEN_X;
		zbuffer += SCREEN_X;

		// Wenn ein Kantenabschnitt abgelaufen wurde wird
		// der N�chste initialisiert. Falls es keinen mehr gibt
		// ( hoehe <= 0 ) dann ist das Polygon fertiggezeichnet
		if(--rechts_hoehe <= 0)
		{
			while (rechts_hoehe<=0)
			{
				if (r_eck == u_eck) return;
				RechteSeite();
			}
		} else
		  // ansonsten Kantenwerte aktualisieren
	      rechts_x += rechts_dx;

		if(--links_hoehe <= 0)
		{
			while (links_hoehe<=0)
			{
				if (l_eck == u_eck) return;
				LinkeSeite();
			}
		} else  
		{
			links_x += links_dx;
			links_u += links_du;
			links_v += links_dv;
			links_g += links_dg;
			links_z += links_dz;
		}
	}
}

static void RechteSeiteFlat(void)
{
	int hoehe, prestep;

	// Neuer Eckpunkt
	int index = r_eck - 1;
	if (index == 3) index = 0;
	if (index == -1) index = 2;

	// Calculate number of scanlines in this section

	rechts_hoehe = ceil16(polygon->punkt2d[index].y) - 
				   ceil16(polygon->punkt2d[r_eck].y);

	if(rechts_hoehe <= 0)
	{
	    r_eck = index;
		return;
	}

	if(rechts_hoehe > 1) 
	{
		// Die H�he des Abschnitts ist > 1, also kann normal
		// mit idiv16 gearbeitet werden
		hoehe = polygon->punkt2d[index].y - polygon->punkt2d[r_eck].y;
		rechts_dx    = idiv16(polygon->punkt2d[index].x - polygon->punkt2d[r_eck].x, hoehe);
	} else 
	{
		// die H�he des Abschnitts ist <= 1; die Verwendung
		// von idiv16 w�rde zu einem �berlauf f�hren, deshalb
		// wird mit Steigung = Breite * 1 / H�he mit 14 Bit
		// Nachkommagenauigkeit gearbeitet
		long inv_hoehe = (0x10000 << 14) / (polygon->punkt2d[index].y - polygon->punkt2d[r_eck].y);
		rechts_dx   = imul14(polygon->punkt2d[index].x - polygon->punkt2d[r_eck].x, inv_hoehe);
	}

	// Bei Subpixelgenauigkeit wird der Wert noch angepa�t
#ifdef SUBPIXEL
	prestep = (ceil16(polygon->punkt2d[r_eck].y) << 16) - polygon->punkt2d[r_eck].y;
	rechts_x = polygon->punkt2d[r_eck].x + imul16(prestep, rechts_dx);
#else
	rechts_x = polygon->punkt2d[r_eck].x;
#endif
	r_eck = index;
}


static void LinkeSeiteFlat(void)
{
	int hoehe, prestep;

    // N�chster Eckpunkt
	int index = l_eck + 1;
	if (index == -1) index = 2;
	if (index == 3) index = 0;

	links_hoehe = ceil16(polygon->punkt2d[index].y) - 
				  ceil16(polygon->punkt2d[l_eck].y);

	if(links_hoehe <= 0)
	{
	    l_eck = index;
		return;
	}

	// Beschreibung f�r die Unterscheidung ist analog zu
	// RechteSeite(void)
	if(links_hoehe > 1) 
	{
		hoehe = polygon->punkt2d[index].y - polygon->punkt2d[l_eck].y;
		links_dx = idiv16(polygon->punkt2d[index].x - polygon->punkt2d[l_eck].x, hoehe);
		links_dz = idiv16(polygon->punktdata[index].z - polygon->punktdata[l_eck].z, hoehe);
	} else 
	{
	    long inv_hoehe = (0x10000 << 14) / (polygon->punkt2d[index].y - polygon->punkt2d[l_eck].y);
		links_dx = imul14(polygon->punkt2d[index].x - polygon->punkt2d[l_eck].x, inv_hoehe);
		links_dz = imul14(polygon->punktdata[index].z - polygon->punktdata[l_eck].z, inv_hoehe);
	}

	// Wieder Anpassung der Werte f�r Subpixelgenauigkeit
#ifdef SUBPIXEL
	prestep = (ceil16(polygon->punkt2d[l_eck].y) << 16) - polygon->punkt2d[l_eck].y;
	links_x = polygon->punkt2d[l_eck].x + imul16(prestep, links_dx);
	links_z = polygon->punktdata[l_eck].z + imul16(prestep, links_dz);
#else
	links_x = polygon->punkt2d[l_eck].x;
	links_z = polygon->punktdata[l_eck].z;
#endif
	l_eck = index;
}


void FlatPolygon(POLYDATA *thispoly, unsigned short *screen, int farbe)
{
	int i,j;

	unsigned short *vbuffer;
	unsigned short *zbuffer;
	int x1, breite, z;

	double d, id;
	PUNKT2D *vtx0,*vtx1,*vtx2;
	PUNKTDATA *pdata0,*pdata1,*pdata2;
  
	// f�r LinkeSeite() und RechteSeite() zug�nglich machen
	polygon = thispoly;

	// neue Zeiger auf die Daten (wegen �bersichtlichkeit)
	vtx0 = &polygon->punkt2d[0];
	vtx1 = &polygon->punkt2d[1];
	vtx2 = &polygon->punkt2d[2];

	pdata0 = &polygon->punktdata[0];
	pdata1 = &polygon->punktdata[1];
	pdata2 = &polygon->punktdata[2];
	
	// miny und maxy auf Extremwerte setzen
	int miny = SCREEN_Y<<16;
	int maxy = 0;

	// oberen und unteren Eckpunkt bestimmen
	for ( i=0; i<3; i++ )
	{
		if ( (j=polygon->punkt2d[i].y) < miny )
		{
			o_eck = i;
			miny = j;
		}
		if ( (j=polygon->punkt2d[i].y) > maxy )
		{
			u_eck = i;
			maxy = j;
		}
	}

	// Start f�r die linke/rechte Kante ist der obere Eckpunkt
	l_eck = r_eck = o_eck;

	// Zeigt das Polygon zum Betrachter ?
	d = ( (double)( vtx0->x - vtx2->x ) / 65536.0 * 
     	  (double)( vtx1->y - vtx2->y ) / 65536.0 -
          (double)( vtx1->x - vtx2->x ) / 65536.0 * 
		  (double)( vtx0->y - vtx2->y ) / 65536.0 );

	if ( d == 0.0 ) return;

	id = 1.0 / d;

	// Berechnung der horizontalen Texture, Gouraud und Z-Buffer Deltas
	double y12 = (double)(vtx1->y - vtx2->y) / 65536.0;
	double y02 = (double)(vtx0->y - vtx2->y) / 65536.0;


	zbuffer_d =(int)(( (double)(pdata0->z - pdata2->z) * y12 -
                       (double)(pdata1->z - pdata2->z) * y02 ) * id);


	// Linke und rechte Seite initialisieren
	do {
		if (r_eck == u_eck) return;
		RechteSeiteFlat();
	} while (rechts_hoehe<=0);


	do {
	    if (l_eck == u_eck) return;
		LinkeSeiteFlat();
	} while (links_hoehe<=0);


	vbuffer = screen + ceil16(miny) * SCREEN_X;
	zbuffer = ZBUFFER + ceil16(miny) * SCREEN_X;

	// und Zeichnen
	for (;;)
	{
		// Startpixel links und Breite der Linie
		x1 = ceil16(links_x);
		breite = ceil16(rechts_x) - x1;

		if (breite > 0)
		{
			z = links_z;

			// eine Zeile zeichnen
#ifdef ASSEMBLER_INNER_LOOP
			__asm {
				mov edi, vbuffer
				mov esi, zbuffer

				mov ecx, x1
				add ecx, ecx
				add edi, ecx
				add esi, ecx

				mov ecx, breite
				mov eax, farbe
				add ecx, ecx
				mov ebx, z
				add edi, ecx
				add esi, ecx

				// Schneller als neg ecx ist
				xor ecx, -1
				inc ecx
				// weil es h�ufiger mit anderen Befehlen
				// parallel ausf�hrbar ist

				spalte:
				// Diese Variante ist nicht 100%ig korrekt:
				// Es wird der interpolierte Z-Wert mit dem
				// ausgelesenen Wert als Vorkomma- und dem 
				// n�chsten Wert Nachkommastelle verglichen
				// Der Effekt f�llt aber nicht auf, die Routine
				// wird aber beschleunigt, da kein 16Bit Zugriff
				// verwendet wird, der sehr langsam w�re.
				mov edx, dword ptr [esi+ecx-2]
				cmp ebx, edx
				jle nicht_dieser_pixel

				mov edx, ebx
				mov [edi+ecx], ax
				sar edx, 16
				mov [esi+ecx], dx

				nicht_dieser_pixel:

				inc ecx
				add ebx, zbuffer_d
				inc ecx
				jnz spalte
			}
#else
			for ( i = 0; i < breite ; i++ )
			{
				// der Pixel mu� nur gezeichnet werden, wenn er
				// n�her am Betrachter liegt als der bisherige Wert
				if ( ( z>>16 ) > zbuffer[ i + x1 ] )
				{
						// Z-Bufferwert aktualisieren
						zbuffer[ i + x1 ] = (z>>16);
						vbuffer[ i + x1 ] = farbe;
				}
				// horizontalen Z-Wert aktualisieren
				z += zbuffer_d;
			}
#endif
		}

		vbuffer += SCREEN_X;
		zbuffer += SCREEN_X;

		// Wenn ein Kantenabschnitt abgelaufen wurde wird
		// der N�chste initialisiert. Falls es keinen mehr gibt
		// ( hoehe <= 0 ) dann ist das Polygon fertiggezeichnet
		if(--rechts_hoehe <= 0)
		{
			while (rechts_hoehe<=0)
			{
				if (r_eck == u_eck) return;
				RechteSeiteFlat();
			}
		} else
		  // ansonsten Kantenwerte aktualisieren
	      rechts_x += rechts_dx;

		if(--links_hoehe <= 0)
		{
			while (links_hoehe<=0)
			{
				if (l_eck == u_eck) return;
				LinkeSeiteFlat();
			}
		} else  
		{
			links_x += links_dx;
			links_z += links_dz;
		}
	}
}

