///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - Demo Projekt                            //
//                                                       //
//  Der Header f�r die Clippingroutinen                  //
//                                                       //
///////////////////////////////////////////////////////////
#ifndef __3dclip_h
#define __3dclip_h

#include "3dtypes.h"

void setup_fustrum( float project_factor, int width, int height );

//void clippolygondraw( const tface &f, const tobject &o, unsigned short *screen );
void clippolygondraw (const tface &f, const tobject &o, unsigned short *screen, unsigned short *palette );

#endif

