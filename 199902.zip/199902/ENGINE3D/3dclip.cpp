///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - Demo Projekt                            //
//                                                       //
//  Die Clippingroutinen der 3D-Engine                   //
//                                                       //
///////////////////////////////////////////////////////////
#include <math.h>
#include "3dtypes.h"
#include "3dmath.h"
#include "polygon.h"
#include "demo.h"

struct tpointinfo
{
        tvector o;
		float   u, v, g;
        float   outside;
};

static tvector   fustrum[4];
static tvector   znear_normal;
static float     znear_distance;
static float     width_half;
static float     height_half;
static float     project_scale_factor;
static POLYDATA   poly;
static tpointinfo in[20];
static tpointinfo out[20];

// Initialisieren der Viewing-Frustrum
void setup_fustrum( float project_factor, int width, int height )
{
        width_half  = (float)width / 2.0f;
        height_half = (float)height / 2.0f;

        project_scale_factor = project_factor;

        float angle_horizontal = (float)atan2( width_half, project_factor) - 0.0001f;
        float angle_vertical   = (float)atan2( height_half, project_factor) - 0.0001f;

        float sh = (float)sin( angle_horizontal );
        float sv = (float)sin( angle_vertical );
        float ch = (float)cos( angle_horizontal );
        float cv = (float)cos( angle_vertical );

        // Linke Seite
        fustrum[ 0 ].x = ch;
        fustrum[ 0 ].y = 0.0f;
        fustrum[ 0 ].z = sh;
        // Rechte Seite
        fustrum[ 1 ].x = -ch;
        fustrum[ 1 ].y = 0.0f;
        fustrum[ 1 ].z = sh;
        // Obere Seite
        fustrum[ 2 ].x = 0.0f;
        fustrum[ 2 ].y = cv;
        fustrum[ 2 ].z = sv;
        // Untere Seite
        fustrum[ 3 ].x = 0.0f;
        fustrum[ 3 ].y = -cv;
        fustrum[ 3 ].z = sv;
        // Betrachter Z-Ebene
        znear_normal.x = 0.0f;
        znear_normal.y = 0.0f;
        znear_normal.z = 1.0f;
        // Entfernte Z-Ebene
        znear_distance = 1.0f;
}

// Diese Routine hier nimmt an, das Float 4 Bytes lang ist.
// Erkl�rung siehe Artikel
unsigned int inline different_sign( const float a, const float b )
{
        unsigned long int *int_a = (unsigned long int *) &a;
        unsigned long int *int_b = (unsigned long int *) &b;
        return (*int_a ^ *int_b) >> 31;

}

// Hier ist die dazugeh�rige portable Routine:
/*int different_sign( float a, float b )
{
        if ( ( a > 0 && b <= 0 ) ||
             ( a < 0 && b >= 0 ) )
           return 1; else
           return 0;
}*/


void cliptoplane( const tvector plane, float distance,
                                  tpointinfo *in, int nin, tpointinfo *out, int &nout )
{
        float scale;

        // Skalarprodukte berechnen
        for ( int i = 0; i < nin; i++ )
                in[ i ].outside = dotproduct( plane, in[i].o );

        nout = 0;

        // bis zum vorletzen Punkt berechnen:
        for ( i = 0; i < nin-1; i++ )
        {
                // Kein Clipping
                if ( in[ i ].outside >= distance )
                    out[ nout++ ] = in[ i ];
                if ( different_sign( in[ i ].outside-distance,
                     in[ i+1 ].outside-distance ) )
                {
                        // Clipping
                        scale = in[ i ].outside / ( in[ i ].outside - in[ i+1 ].outside );
                        out[ nout ].o.x = in[ i ].o.x + ( in[ i+1 ].o.x - in[ i ].o.x ) * scale;
                        out[ nout ].o.y = in[ i ].o.y + ( in[ i+1 ].o.y - in[ i ].o.y ) * scale;
                        out[ nout ].o.z = in[ i ].o.z + ( in[ i+1 ].o.z - in[ i ].o.z ) * scale;
                        out[ nout ].u = in[ i ].u + ( in[ i+1 ].u - in[ i ].u ) * scale;
                        out[ nout ].v = in[ i ].v + ( in[ i+1 ].v - in[ i ].v ) * scale;
                        out[ nout ].g = in[ i ].g + ( in[ i+1 ].g - in[ i ].g ) * scale;
                        nout++ ;
                }
        }

        // Letzter Punkt geclippt ?
        if ( in[ nin-1 ].outside >= distance )
                out[ nout++ ] = in[ nin-1 ];

        // Letze Zeile clippen ?
        if ( different_sign( in[ 0 ].outside-distance,
                         in[ nin-1 ].outside-distance ) )
        {
                // Clipping
                scale = in[0].outside/(in[0].outside-in[nin-1].outside);
                out[ nout ].o.x = (in[ 0 ].o.x+( in[ nin-1 ].o.x - in[ 0 ].o.x ) * scale );
                out[ nout ].o.y = (in[ 0 ].o.y+( in[ nin-1 ].o.y - in[ 0 ].o.y ) * scale );
                out[ nout ].o.z = (in[ 0 ].o.z+( in[ nin-1 ].o.z - in[ 0 ].o.z ) * scale );
                out[ nout ].u = (in[ 0 ].u+( in[ nin-1 ].u - in[ 0 ].u ) * scale );
                out[ nout ].v = (in[ 0 ].v+( in[ nin-1 ].v - in[ 0 ].v ) * scale );
                out[ nout ].g = (in[ 0 ].g+( in[ nin-1 ].g - in[ 0 ].g ) * scale );
                nout ++;
        }
}


void clippolygondraw (const tface &f, const tobject &o, unsigned short *screen, unsigned short *palette )
{
        int i;

        // Kopieren der 3d-Polygondaten in eine lokale Struktur
        in[ 0 ].o  = o.vertice_t[ f.a ];
		in[ 0 ].g  = max( 0, o.normale_t[ f.a ].z );
		in[ 0 ].u  = o.uv[ f.a*2 ];
		in[ 0 ].v  = o.uv[ f.a*2+1 ];
        in[ 1 ].o  = o.vertice_t[ f.b ];
		in[ 1 ].g  = max( 0, o.normale_t[ f.b ].z );
		in[ 1 ].u  = o.uv[ f.b*2 ];
		in[ 1 ].v  = o.uv[ f.b*2+1 ];
        in[ 2 ].o  = o.vertice_t[ f.c ];
		in[ 2 ].g  = max( 0, o.normale_t[ f.c ].z );
		in[ 2 ].u  = o.uv[ f.c*2 ];
		in[ 2 ].v  = o.uv[ f.c*2+1 ];
		in[ 0 ].g = f.g[ 0 ];
		in[ 1 ].g = f.g[ 1 ];
		in[ 2 ].g = f.g[ 2 ];

        int nout = 0;

        cliptoplane( znear_normal, znear_distance, in, 3, out, nout);
        if ( nout<3 ) return;
        cliptoplane( fustrum[ 1 ], 0.0f, out, nout, in, nout );
        if ( nout<3 ) return;
        cliptoplane( fustrum[ 2 ], 0.0f, in, nout, out, nout );
        if ( nout<3 ) return;
        cliptoplane( fustrum[ 3 ], 0.0f, out, nout, in, nout );
        if ( nout<3 ) return;
        cliptoplane( fustrum[0], 0.0f, in, nout, out, nout );
        if ( nout<3 ) return;

        // Projezieren der 3D-Koordinaten ins Screen-Koordinaten System
        for ( i=0; i<nout; i++ )
        {
			out[ i ].o.z = 65536.0f / out[ i ].o.z;
            out[ i ].o.x = project_scale_factor * out[ i ].o.x * out[ i ].o.z +
                           65536.0f * width_half;
            out[ i ].o.y = 65536.0f * height_half + (project_scale_factor * out[ i ].o.y * out[ i ].o.z) ;
        }

        // Berechnung der Polygonfarbe mit der Helligkeit
        // F�r Flatshading, Achtung f.color.shading mu� berechnet werden
        /*                
		int   Red   = ( f.color.r * f.color.shading ) / 156;
        int   Green = ( f.color.g * f.color.shading ) / 156;
        int   Blue  = ( f.color.b * f.color.shading ) / 156;

        Red     = min( Red, 255 );
        Green   = min( Green, 255 );
        Blue    = min( Blue, 255 );

        short farbe = Rtab[ Red ] | Gtab[ Green ] | Btab[ Blue ];
        */
		
        // Triangularieren und Zeichnen der Polygone
        for ( i = 2; i < nout; i++ )
        {
                poly.punkt2d[ 0 ].x   = (int)out[ 0 ].o.x;
                poly.punkt2d[ 0 ].y   = (int)out[ 0 ].o.y;
                poly.punktdata[ 0 ].z = (int)( out[ 0 ].o.z * 65536.0f );
                poly.punktdata[ 0 ].u = (int)( out[ 0 ].u * 65536.0f );
                poly.punktdata[ 0 ].v = (int)( out[ 0 ].v * 65536.0f );
                poly.punktdata[ 0 ].g = (int)( out[ 0 ].g * 31.0f * 65536.0f );

                poly.punkt2d[ 2 ].x   = (int)out[ i-1 ].o.x;
                poly.punkt2d[ 2 ].y   = (int)out[ i-1 ].o.y;
                poly.punktdata[ 2 ].z = (int)( out[ i-1 ].o.z * 65536.0f );
                poly.punktdata[ 2 ].u = (int)( out[ i-1 ].u * 65536.0f );
                poly.punktdata[ 2 ].v = (int)( out[ i-1 ].v * 65536.0f );
                poly.punktdata[ 2 ].g = (int)( out[ i-1 ].g * 31.0f * 65536.0f );

                poly.punkt2d[ 1 ].x   = (int)out[ i ].o.x;
                poly.punkt2d[ 1 ].y   = (int)out[ i ].o.y;
                poly.punktdata[ 1 ].z = (int)( out[ i ].o.z * 65536.0f );
                poly.punktdata[ 1 ].u = (int)( out[ i ].u * 65536.0f );
                poly.punktdata[ 1 ].v = (int)( out[ i ].v * 65536.0f );
                poly.punktdata[ 1 ].g = (int)( out[ i ].g * 31.0f * 65536.0f );

                // Entsprechende Polygonroutine aufrufen
				//FlatPolygon( &poly, screen, farbe );
                //TexturePolygon( &poly, screen, o.texture.cBitmap, (unsigned short*)&o.palette[0]);
                TexturePolygon( &poly, screen, o.texture.cBitmap, (unsigned short*)palette );
        }
}


