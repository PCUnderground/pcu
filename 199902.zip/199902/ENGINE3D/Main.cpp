///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - Demo Projekt                            //
//                                                       //
//  Ein Beispielprogramm, und 3D-Objekte mit Hilfe von   //
//  Autodesk 3D-Studio VUE-Files zu animieren            //
//                                                       //
///////////////////////////////////////////////////////////

#define SZENE1

#ifndef SZENE1
#define SZENE2
#endif

#include "demo.h"
#include "3dengine.h"
#include "3dmath.h"
// Der Bildspeicher
unsigned short *screen, *screen1;


// Objekte:
static tobject *obj1;
static tobject *obj2;
static tobject *obj3;
static tobject *obj4;

// Kamera
static tcamera camera, camera1;

// Key-frame Data
static objKey  *Key1;
static objKey  *Key2;
static objKey  *Key3;
static objKey  *Key4;
static camKey  *KeyC;

BOOL demoinit (void)
{
        Fenster_Modus = FENSTER;

        return TRUE;
}


void DrawSzene (int frame)
{
	// 2 Kameras berechnen:
	tvector von, nach, delta, up, left;

    up.x = 0.0f; up.y = 0.0f; up.z = 1.0f;
    
	von.x = KeyC[frame].pos[0];
    von.y = KeyC[frame].pos[1];
    von.z = KeyC[frame].pos[2];
    nach.x = KeyC[frame].target[0];
    nach.y = KeyC[frame].target[1];
    nach.z = KeyC[frame].target[2];
	delta.x = nach.x - von.x;
	delta.y = nach.y - von.y;
	delta.z = nach.z - von.z;

	light.x = delta.x;
	light.y = delta.y;
	light.z = delta.z;
	normvector( light );

	crossproduct( delta, up, left );
	normvector( left );

	float scale = -1.0;
    // Kamera Keyframes setzen
    camera.set_position  (KeyC[frame].pos[0]+left.x*scale,
                          KeyC[frame].pos[1]+left.y*scale,
                          KeyC[frame].pos[2]+left.z*scale);
    camera.set_target    (KeyC[frame].target[0],
                          KeyC[frame].target[1],
                          KeyC[frame].target[2]);
    camera.set_roll      (KeyC[frame].roll);
    camera1.set_position  (KeyC[frame].pos[0]-left.x*scale,
                           KeyC[frame].pos[1]-left.y*scale,
                           KeyC[frame].pos[2]-left.z*scale);
    camera1.set_target    (KeyC[frame].target[0],
                           KeyC[frame].target[1],
                           KeyC[frame].target[2]);
    camera1.set_roll      (KeyC[frame].roll);

    // Objekt Keyframing setzen
    obj1->set_matrix (&Key1[frame].data[0], &Key1[frame].data[9]);
#ifdef SZENE1
    obj2->set_matrix (&Key2[frame].data[0], &Key2[frame].data[9]);
    obj3->set_matrix (&Key3[frame].data[0], &Key3[frame].data[9]);
    obj4->set_matrix (&Key4[frame].data[0], &Key4[frame].data[9]);
#endif

    // Objekte Zeichnen

  
#ifdef SZENE2  
	clearZBUFFER();
    obj1->draw( screen, &camera, 0 );
    clearZBUFFER();
    obj1->draw( screen1, &camera1, 1 );
#endif

#ifdef SZENE1
	clearZBUFFER();
    obj1->draw( screen, &camera, 0 );
    obj2->draw( screen, &camera, 0 );
    obj3->draw( screen, &camera, 0 );
    obj4->draw( screen, &camera, 0 );
    clearZBUFFER();
    obj1->draw( screen1, &camera1, 1 );
    obj2->draw( screen1, &camera1, 1 );
    obj3->draw( screen1, &camera1, 1 );
    obj4->draw( screen1, &camera1, 1 );
#endif

	for ( int i = 0; i < 320*240; i++ )
		screen[i]|=screen1[i];
/*#ifdef SZENE1
    obj2->draw( screen, &camera);
    obj3->draw( screen, &camera);
    obj4->draw( screen, &camera);
#endif*/
}



void demomain( void )
{
        float anglex = 0.0f;
        float angley = 0.0f;
        float anglez = 0.0f;
        float oscale = 0.0f;

#ifdef SZENE1
		// Es gibt 500 definierte Bilder im VUE-File => 501
        Key1 = LoadObjKeys ("data\\pcmag.vue", "Boden",  501);
        Key2 = LoadObjKeys ("data\\pcmag.vue", "Ding", 501);
        Key3 = LoadObjKeys ("data\\pcmag.vue", "Kuppel",  501);
        Key4 = LoadObjKeys ("data\\pcmag.vue", "Tempel",  501);
        KeyC = LoadCamKeys ("data\\pcmag.vue", 501);
#endif

#ifdef SZENE2
        Key1 = LoadObjKeys ("data\\ludwig.vue", "tie",  401);
        KeyC = LoadCamKeys ("data\\ludwig.vue", 401);
#endif

        if (!Key1) return;
#ifdef SZENE1
        if (!Key2) return;
        if (!Key3) return;
        if (!Key4) return;
#endif
        if (!KeyC) return;

        // Speicher f�r das Bild reservieren
        screen = (unsigned short *)malloc( SCREEN_X * SCREEN_Y * 2 );
        screen1 = (unsigned short *)malloc( SCREEN_X * SCREEN_Y * 2 );
        if ( screen == NULL ) return ;
        memset (screen, 0, SCREEN_X * SCREEN_Y * 2);
        memset (screen1, 0, SCREEN_X * SCREEN_Y * 2);

        // 3D-Engine initialisieren
        if ( init3Dengine() == FALSE ) return ;//FALSE;

        // 3D-Objekt instanziieren und laden
#ifdef SZENE1
        obj1 = new tobject ("data\\Boden.3d");
        obj2 = new tobject ("data\\Ding.3d");
        obj3 = new tobject ("data\\Kuppel.3d");
        obj4 = new tobject ("data\\Tempel.3d");

        obj1->loadtexture( "data\\sand.bmp" );
        obj2->loadtexture( "data\\metal7.bmp" );
        obj3->loadtexture( "data\\sky.bmp" );
        obj4->loadtexture( "data\\benedeti.bmp" );
#endif

#ifdef SZENE2
        obj1 = new tobject ("data\\ludwig.3d");
        obj1->loadtexture( "data\\benedeti.bmp" );
#endif

        float StartTime = (float)GetDemoTime();

        int key=0;

        while ( DemoRunning )
        {
                float SceneTime = (GetDemoTime()-StartTime)*10.0f/1000.0f;

                // Richtung des Lichteinfalls
                anglex = (float)( GetDemoTime() * 0.0012/3.0 );
                angley = (float)( GetDemoTime() * 0.002 /3.0 );
                anglez = (float)( GetDemoTime() * 0.0028/3.0 );
                light.x = 50.0f * (float)sin( anglex );
                light.y = 50.0f * (float)cos( anglex );
                light.z = -60.0f * (float)sin( angley );
                normvector( light );

                // Z-Buffer l�schen
                // Bei Szene 1 braucht der Hintergrund nicht gel�scht zu werden,
				// da die 3d Objekte immer den ganzen Bildschirm f�llen
#ifdef SZENE2
				memset (screen, 0, SCREEN_X * SCREEN_Y * 2);
				memset (screen1, 0, SCREEN_X * SCREEN_Y * 2);
#endif

                // Szene Rendern und darstellen:
                DrawSzene (key);
                BlitGraphic( screen );

#ifdef SZENE1
                if (key++==500) key=0;
#else
                if (key++==500) key=0;
#endif
        }
}

void demoquit()
{
	free( screen );
	free( screen1 );
	quit3Dengine();
}