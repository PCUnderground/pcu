///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - Demo Projekt                            //
//                                                       //
//  Headerfile f�r die Polygon Routinen                  //
//                                                       //
///////////////////////////////////////////////////////////
#ifndef __POLYGON_H
#define __POLYGON_H

#define ASSEMBLER_INNER_LOOP
#define ASSEMBLER_FIXED_POINT

#define SUBPIXEL
#define SUBTEXEL

typedef struct
{
        int x, y;
}PUNKT2D;

typedef struct
{
        int u, v, g, z;
}PUNKTDATA;

typedef struct
{
        PUNKT2D    punkt2d[3];
        PUNKTDATA  punktdata[3];
}POLYDATA;

extern unsigned short *ZBUFFER;

void FlatPolygon(POLYDATA *thispoly, unsigned short *screen, int farbe);
int  LoadTexture( char *name, bitmaptype *bmp, unsigned short *palette1, unsigned short *palette2 );
void TexturePolygon(POLYDATA *thispoly, unsigned short *screen, unsigned char *texture, unsigned short *palette);

#endif

