///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - Demo Projekt                            //
//                                                       //
//  Definitionen f�r die 3D-Engine                       //
//                                                       //
///////////////////////////////////////////////////////////
#ifndef __3dtypes_h
#define __3dtypes_h

#include "demo.h"

// Ein Vektor
struct tvector
{
        float x,y,z;
};

// Farbstruktur
struct tcolor
{
        unsigned char r;
        unsigned char g;
        unsigned char b;
        unsigned char shading;
};

// Polygonstruktur
struct tface
{
        int     a,b,c;     // Vertex Indizes
        int     material;  // Material Index
        tvector normal;    // Normalenvektor des Polygons
        float   cullpoint; // Cullpoint des Polygons
		float	g[3];
        tface   *next;     // zum Bilden von Listen
        tcolor  color;     // Farbe und Shading des Polygons
};

// Die 3D-Camera Klasse
class tcamera
{
  private:
  public:
    tvector  position;
    tvector  target;
    float    roll;
    float    last_perspective;
    float   *matrix;
    float   *movematrix;
    float   *rotmatrix;
    int      dirty;
    void     build_matrix (void);
    tcamera  ();
    ~tcamera ();
    float   *get_matrix      (void);
    void     set_target      (const float x, const float y, const float z);
    void     set_position    (const float x, const float y, const float z);
    void     set_roll        (const float   aRoll);
    void     set_perspective (const float   aPerspective);
};


// Die 3D-Objektklasse
class tobject
{
        // Orientatierungs Information
        float   mrot[16];       // Rotationsmatrix
        float   mtrans[16];     // Translationsmatrix
        float   mscale[16];     // Skalierungsmatrix
        float   mirot[16];      // Inverse Rotationsmatrix
        float   ltm[16];        // Lokale Transformationsmatrix
        float   iltm[16];       // Inverse Lokale Transformationsmatrix
        void    build_ltm (tcamera * camera);

public:

        // Geometrie Information
        int     nfaces;         // Anzahl der Polygone
        int     nvertices;      // Anzahl der Eckpunkte
        tvector pivot;          // Pivot-Punkt des Objektes
        tface   *face;          // Polygon-Liste
        tvector *vertice;       // Eckpunkt
        float   *uv;            // Texturemapping Koordinaten in Fixpoint
        tvector *vertice_t;     // Transformierte Eckpunkte
        tvector *normale;
        tvector *normale_t;
        float   *gouraud;
        char    *vtransinfo;    // Info welche Punkt gedreht werden m�ssen

        bitmaptype  texture;
        unsigned short  palette_red[ 32 * 256 ];
        unsigned short  palette_green[ 32 * 256 ];


        tobject  ( char *name );
        tobject  ( void );
        ~tobject ( void );

        void calc_facenormals (void);
//        void draw        ( unsigned short *buffer, tcamera *camera);
        void draw( unsigned short *buffer, tcamera *camera, int redgreen );
        void setrot      ( float x, float y, float z );
        void setscale    ( float x, float y, float z );
        void settrans    ( float x, float y, float z );
        void set_matrix  ( float *matrix, float *trans );
        int  loadtexture ( char *name );

        void save3d ( char *name );

};

#endif
