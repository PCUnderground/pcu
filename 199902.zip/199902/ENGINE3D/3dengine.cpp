///////////////////////////////////////////////////////////
//                                                       //
//  PC MAGAZIN - Demo Projekt                            //
//                                                       //
//  Hauptprogramm der 3D-Engine                          //
//                                                       //
///////////////////////////////////////////////////////////
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <assert.h>

#include "demo.h"
#include "3dengine.h"

tvector light;
tvector nullvector = { 0.0f, 0.0f, 0.0f };

// Konstruktor f�r die Objektklasse
tobject::tobject( void )
{
    face          = NULL;
    vertice       = NULL;
    vertice_t     = NULL;
    vtransinfo    = NULL;
    nfaces        = 0;
    nvertices     = 0;
}

// Konstruktor mit Dateiname
tobject::tobject( char *name )
{
    int i;

    FILE *f = fopen( name, "rt" );

    assert( f );

    // Anzahl der Fl�chen und Eckpunkte lesen
    fscanf( f, "%i %i", &nvertices, &nfaces );

    face       = new tface   [ nfaces ];
    vertice    = new tvector [ nvertices ];
    normale    = new tvector [ nvertices ];
    normale_t  = new tvector [ nvertices ];
    gouraud    = new float   [ nvertices ];
    uv         = new float   [ nvertices * 2 ];
    vertice_t  = new tvector [ nvertices ];
    vtransinfo = new char    [ nvertices ];


    // Eckpunkte lesen
    for ( i = 0; i < nvertices; i++ )
    {
        fscanf( f, "%f %f %f", &vertice[ i ].x,
                               &vertice[ i ].y,
                               &vertice[ i ].z );
    }

    for ( i = 0; i < nvertices; i++ )
    {
        fscanf( f, "%f %f", &uv[ i * 2 + 0 ],
                            &uv[ i * 2 + 1 ] );

		// UV-Koordinaten auf Texturemapgr��e skalieren
		uv[ i * 2 + 0 ] *= 256.0f;
		uv[ i * 2 + 1 ] *= 256.0f;
    }

    // Polygone einlesen
    for ( i = 0; i < nfaces; i++ )
    {
        fscanf( f, "%i %i %i %i", &face[ i ].a, &face[ i ].b,
                                  &face[ i ].c, &face[ i ].material );
    }

    setscale ( 1.0f, 1.0f, 1.0f );
    settrans ( 0.0f, 0.0f, 0.0f );
    setrot   ( 0.0f, 0.0f, 0.0f );

    // Normalen berechnen
	calc_facenormals();

    memset( vtransinfo, 0, nvertices );

    fclose (f);

    // Farben an Fl�chen zuweisen
    for ( i = 0; i < nfaces; i++ )
    {
        face[ i ].color.r = 128;
        face[ i ].color.g = 128;
        face[ i ].color.b = 128;
    }
}


// Destruktor
tobject::~tobject( void )
{
  if (face)       delete [] face;
  if (vertice)    delete [] vertice;
  if (vertice_t)  delete [] vertice_t;
  if (vtransinfo) delete [] vtransinfo;
}

// Laedt eine Texturemap
int tobject::loadtexture( char *name )
{
	return LoadTexture( name, &texture, (unsigned short*)&palette_red[0], (unsigned short*)&palette_green[0] );
}

// Berechnet Normalen der Polygone
void tobject::calc_facenormals( void )
{
	int i;

	for ( i = 0; i < nvertices; i++ )
	{
		normale[ i ].x = 0.0f;
		normale[ i ].y = 0.0f;
		normale[ i ].z = 0.0f;
	}

    for ( i=0; i<nfaces; i++ )
    {
        polygon_normal( vertice[ face[ i ].a ],
                        vertice[ face[ i ].b ],
                        vertice[ face[ i ].c ],
                        face[ i ].normal );

		normale[ face[ i ].a ].x += face[ i ].normal.x;
		normale[ face[ i ].a ].y += face[ i ].normal.y;
		normale[ face[ i ].a ].z += face[ i ].normal.z;
		normale[ face[ i ].b ].x += face[ i ].normal.x;
		normale[ face[ i ].b ].y += face[ i ].normal.y;
		normale[ face[ i ].b ].z += face[ i ].normal.z;
		normale[ face[ i ].c ].x += face[ i ].normal.x;
		normale[ face[ i ].c ].y += face[ i ].normal.y;
		normale[ face[ i ].c ].z += face[ i ].normal.z;

        face[ i ].cullpoint =
            dotproduct( face[ i ].normal, vertice[ face[ i ].a ] );
    }

	for ( i = 0; i < nvertices; i++ )
	{
		normvector( normale[ i ] );
	}
}

// Legt Rotationswinkel fest
void tobject::setrot( float x, float y, float z )
{
    tvector v;

    v.x = x;
    v.y = y;
    v.z = z;

    make_rotation_matrix( mrot, v );
    angle_preserving_matrix_inverse( mrot, mirot );
}

// Legt Objektskalierung fest
void tobject::setscale( float x, float y, float z )
{
    tvector v;

    v.x = x;
    v.y = y;
    v.z = z;
    make_scale_matrix( mscale, v );
}

// Legt Objekttranslation fest
void tobject::settrans( float x, float y, float z )
{
    tvector v;
    v.x = x;
    v.y = y;
    v.z = z;
    make_move_matrix( mtrans, v );
}

// Berechnungen der Transformationsmatrix
void tobject::build_ltm(tcamera * camera)
{
    float   temp[16];
    matrix_mul ( temp, mrot, mscale);

    temp[ 3 ]  += mtrans[3] - camera->position.x;
    temp[ 7 ]  += mtrans[7] - camera->position.y;
    temp[ 11 ] += mtrans[11]- camera->position.z;

    matrix_mul (ltm, temp, camera->get_matrix());

    angle_preserving_matrix_inverse( ltm, iltm );
}

// Setze Matrix und Translationsvektor direkt (f�r VUE files)
void tobject::set_matrix ( float *matrix, float *trans)
{
    // 3x3 Matrix in die 4x4 rotations-matrix umkopieren
    mrot[ 0 ] = matrix[0];
    mrot[ 1 ] = matrix[1];
    mrot[ 2 ] = matrix[2];
    mrot[ 3 ] = 0.0f;

    mrot[ 4 ] = matrix[3];
    mrot[ 5 ] = matrix[4];
    mrot[ 6 ] = matrix[5];
    mrot[ 7 ] = 0.0f;

    mrot[ 8 ] = matrix[6];
    mrot[ 9 ] = matrix[7];
    mrot[10 ] = matrix[8];
    mrot[11 ] = 0.0f;

    mrot[12 ] = 0.0f;
    mrot[13 ] = 0.0f;
    mrot[14 ] = 0.0f;
    mrot[15 ] = 1.0f;

    // Translation setzen
    settrans (trans[0], trans[1], trans[2]);

    // Scaling �berschreiben (da schon in der Matrix enthalten/vorhanden)
    setscale ( 1.0f, 1.0f, 1.0f );

    // Inverse der Rotationsmatrix berechnen (f�r Licht)
    angle_preserving_matrix_inverse( mrot, mirot );
}


// Zeichnet das Objekt
void tobject::draw( unsigned short *buffer, tcamera *camera, int redgreen )
{
    // Transformationsmatrix des Objektes berechen
    build_ltm(camera);

    // Lichtberechung
    tvector local_light;
    transform  (light, mirot, local_light);
    normvector (local_light);

    // Vorberechnung f�r Backfaceculling
    tvector    local_orientation;
    transform  (nullvector, iltm, local_orientation);

    tface *visible_face_list = NULL;
    tface *currentface       = face;

    for ( int i = 0; i < nfaces; i++ )
    {
       if ( dotproduct (currentface->normal, local_orientation) <
            currentface->cullpoint )
        {
            // Die Eckpunkte die rotiert werden m�ssen, werden markiert
            vtransinfo[ currentface->a ]++;
            vtransinfo[ currentface->b ]++;
            vtransinfo[ currentface->c ]++;

            // Verkette die sichtbaren Polygon in einer Liste
            currentface->next = visible_face_list;
            visible_face_list = currentface;
        }
        currentface++;
    }

	// Eckpunkt Transformation
    for ( i = 0; i < nvertices; i++ )

		// OHNE BACKFACE CULLING:
		if ( vtransinfo[ i ] )
        {
            vtransinfo[ i ] = 0;
            gouraud[ i ] = max( 0.1f, dotproduct( normale[ i ], local_light ) );
            transform (vertice[i], ltm, vertice_t[i]);
        }

    // Alle Polygone Zeichnen
    for ( currentface = visible_face_list;
          currentface != NULL;
          currentface = currentface->next )
    {
        currentface->g[ 0 ] = gouraud[ currentface->a ];
        currentface->g[ 1 ] = gouraud[ currentface->b ];
        currentface->g[ 2 ] = gouraud[ currentface->c ];
		if ( redgreen )
			clippolygondraw( *currentface, *this, buffer, palette_green ); else
			clippolygondraw( *currentface, *this, buffer, palette_red );
    }
}

int init3Dengine()
{
    ZBUFFER = (unsigned short *)malloc( SCREEN_X * SCREEN_Y * 2 + 128 );

    if ( ZBUFFER == NULL ) return FALSE;

    return TRUE;
}

void clearZBUFFER()
{
    if ( ZBUFFER != NULL)
        memset( ZBUFFER, 0, SCREEN_X * SCREEN_Y * 2 + 128 );
}

void quit3Dengine()
{
    free( ZBUFFER );
}
